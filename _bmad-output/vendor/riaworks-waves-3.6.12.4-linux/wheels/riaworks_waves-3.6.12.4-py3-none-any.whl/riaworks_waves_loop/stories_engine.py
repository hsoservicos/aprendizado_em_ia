"""Engine variant for "stories mode" — folder+id dispatch (BMAD-METHOD #2549).

Where the default :class:`~riaworks_waves_loop.engine.Engine` walks ``sprint-status.yaml``,
``StoriesEngine`` drives a typed ``stories.yaml`` (the Story Breakdown output,
a fixed-name sibling of ``SPEC.md``). Each entry is dispatched by *spec folder +
story id* rather than a spec path: the inner ``bmad-build-auto`` skill reads its
own entry, creates-or-resumes the story spec at ``<spec-folder>/stories/<id>-<slug>.md``,
and the orchestrator reads that id-keyed path back deterministically — no
mtime-scan, no shared mutable board.

Like ``SweepEngine``, this is a thin override layer over the mature story
pipeline: only the story source (``_pick_next``), the dispatch prompt
(``_dev_prompt``), the (absent) bookkeeping sync (``_post_dev_state_sync``), the
deferral-harvest source (``_harvest_spec_path``), the board-ownership clause the
inherited review and plugin-workflow prompts inject (``_sprint_board_instruction``,
empty here — there is no board), artifact verification
(``_verify_dev_artifacts``), the session env
(``_extra_session_env``), and the HITL checkpoints differ. (That list is
illustrative and has run stale before — read the class, not it.) Everything else —
dev/verify/review/commit, crash resume, worktree isolation, gates — is inherited
unchanged.

HITL checkpoints (Phase 3) are per-story and independent (a story may set both
and pause twice):

* ``spec_checkpoint`` — a two-leg dispatch. Leg 1 sends ``Halt after planning.``
  (:meth:`_plan_halt_leg`); the skill HALTs at ``ready-for-dev``, the plan is
  verified, and the run pauses at :data:`PAUSE_PLAN_CHECKPOINT` for human plan
  review. Resume re-drives leg 2 (a plain folder+id dispatch that the skill routes
  straight to implementation) via :meth:`_resume_after_dev_verify`.
* ``done_checkpoint`` — after the story commits, the run pauses at
  :data:`PAUSE_STORY_CHECKPOINT` (:meth:`_after_story`), skipped when the story was
  the last one to dispatch.

A blocked / sentinel / ambiguous story stops the scan and escalates for resolve
(:meth:`_pause_wedged`); sentinel auto-clear on re-arm lives in
``runs.rearm_escalation``.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from . import envvars, gates, namespace, stories, verify
from .adapters.base import SessionResult
from .engine import Engine, RunPaused
from .model import (
    PAUSE_ESCALATION,
    PAUSE_PLAN_CHECKPOINT,
    PAUSE_SPEC_APPROVAL,
    PAUSE_STORY_CHECKPOINT,
    Phase,
    StoryTask,
    result_mapping,
)
from .runs import graceful_stop_requested


@dataclass(frozen=True)
class _StoryRef:
    """The minimal shape :meth:`Engine._loop` reads from a picked story: a key
    and an epic. Stories mode has no epic numbering (a flat list), so ``epic`` is
    always 0 — inert for the epic-boundary logic, which only fires on a change."""

    key: str
    epic: int = 0


class StoriesModeError(Exception):
    """Raised when stories mode cannot proceed for a structural reason the run
    should surface loudly (unreadable/invalid ``stories.yaml`` mid-run).

    Distinct from the contract-side :class:`stories.StoriesError` (the parser's
    error) so the two seams — parse vs engine drive — never get conflated when a
    parser error leaks through an engine catch."""


class _UnknownSelector(StoriesModeError):
    """The ``--story`` selector id is not (or no longer) in ``stories.yaml``.

    A subclass so :meth:`StoriesEngine._pick_next` can turn it into a pause for
    resolve (the id is recoverable — fix the typo or the manifest, then resume)
    rather than let it crash the run like a genuinely-unreadable manifest."""

    def __init__(self, selector: str):
        super().__init__(f"--story id {selector!r} is not in stories.yaml")
        self.selector = selector


class StoriesEngine(Engine):
    def __init__(self, *args: Any, spec_folder: str, **kwargs: Any):
        # `--story` is a plain story id here, not a sprint E-S ref — keep it out of
        # the base's sprint-style parse_selector (which would reject a bare "2")
        # and out of the epic filter (a flat list has no epics). We scan by id in
        # _pick_next instead. The CLI still persists story_filter on RunState, so
        # resume restores the id filter unchanged.
        self._story_id_filter = kwargs.get("story_filter") or None
        kwargs["story_filter"] = None
        kwargs["epic_filter"] = None
        super().__init__(*args, **kwargs)
        # Project-relative posix path to the epic spec folder. Anchored on the
        # *current* workspace root at use time (project root in place, the unit
        # worktree under isolation), which keeps _pick_next, _dev_prompt, verify,
        # and the adapter read-back all resolving against the same live checkout.
        self._spec_folder_rel = self._relativize(spec_folder)
        # journal `stories-validated` once per process (re-validated every pick).
        self._validated = False
        # story keys already warned about an unreadable manifest — journal once
        # each (``_entry_for`` is called several times per dispatch).
        self._warned_unreadable: set[str] = set()
        # pin the resolved mode into run state so resume/resolve rebuild a
        # StoriesEngine (not the sprint Engine) without re-reading policy.
        self.state.source = "stories"
        self.state.spec_folder = self._spec_folder_rel

    # ------------------------------------------------------------ spec folder

    def _relativize(self, spec_folder: str) -> str:
        """Store the spec folder project-relative when possible (we always
        dispatch project-relative). Shared with the CLI dry-run via
        :func:`stories.relativize_spec_folder` so both render the identical
        folder string."""
        return stories.relativize_spec_folder(self.paths.project, spec_folder)

    def _stories_folder(self) -> Path:
        """The spec folder resolved against the current workspace's PROJECT (the
        project at pick time, the unit's mount project during a driven story).

        The folder is stored project-relative (:meth:`_relativize`), so it joins on
        ``workspace.paths.project`` — not ``workspace.root``, the code root, which a
        ``repo_root:`` override moves away from the project (DW-379)."""
        rel = Path(self._spec_folder_rel)
        return rel if rel.is_absolute() else self.workspace.paths.project / rel

    def _load_stories(self) -> stories.Stories:
        return stories.load_stories(self._stories_folder())

    # --------------------------------------------------------------- picking

    def _compute_schedule(self) -> stories.Schedule:
        """Run the linear scheduler against fresh on-disk state, honoring the
        ``--story`` selector and the within-run skip set (stories already driven
        to a terminal *retirement* this run — mirrors the sprint engine's base_skip).
        Re-loads + re-validates stories.yaml every call (id-stability rule F: a
        between-runs re-derive is safe because pinned ids are stable and un-started
        ids reschedule by list order). Shared by :meth:`_pick_next` and the
        done_checkpoint skip-if-last check."""
        try:
            story_set = self._load_stories()
        except stories.StoriesError as e:
            raise StoriesModeError(f"stories.yaml no longer usable: {e}") from e
        self._journal_validated(story_set)
        # A --story id that vanished from the manifest mid-run (or slipped past
        # preflight) must not crash the run via find_entry: raise a recoverable
        # _UnknownSelector that _pick_next turns into a pause for resolve.
        if self._story_id_filter is not None and story_set.get(self._story_id_filter) is None:
            raise _UnknownSelector(self._story_id_filter)
        folder = self._stories_folder()
        states = {e.id: stories.resolve_story_spec(folder, e.id) for e in story_set.entries}
        # Skip only stories retired this run — DONE (completed) or DEFERRED
        # (plateaued). Crucially NOT ESCALATED: schedule() consults the skip set
        # *before* classifying disk state, so skipping a wedge would let a bare
        # `waves resume` (no resolve) leapfrog it and dispatch a later story
        # onto a tree missing the blocked story's work — breaking the linear
        # "a blocked story cannot be leapfrogged" invariant. Left out of the skip
        # set, an unresolved wedge re-classifies from disk (blocked/sentinel) and
        # re-pauses on itself; once `resolve` re-arms it to PENDING it re-dispatches.
        # (Only pick-time wedge tasks reach this scan while ESCALATED: an *in-run*
        # escalation — whose spec status proves nothing about resolution — is
        # re-paused before scheduling by _repause_inrun_escalation.)
        skip = {
            key
            for key, task in self.state.tasks.items()
            if task.phase in (Phase.DONE, Phase.DEFERRED)
        }
        return stories.schedule(story_set, states, selector=self._story_id_filter, skip=skip)

    def _journal_validated(self, story_set: stories.Stories) -> None:
        if self._validated:
            return
        self.journal.append(
            "stories-validated",
            count=len(story_set.entries),
            spec_folder=self._spec_folder_rel,
        )
        self._validated = True

    def _pick_next(self) -> _StoryRef | None:
        self._repause_inrun_escalation()  # raises when one is live
        try:
            sched = self._compute_schedule()
        except _UnknownSelector as e:
            # A bad/removed --story id: pause for resolve (fix the manifest, then
            # resume) rather than crash the run. Keyed on the selector id so the
            # escalation viewer + rearm act on the same key.
            self._pause_unknown_selector(e.selector)  # always raises RunPaused
        if sched.outcome == stories.SCHEDULE_NEXT and sched.entry is not None:
            return _StoryRef(key=sched.entry.id)
        if sched.outcome == stories.SCHEDULE_WEDGED and sched.entry is not None:
            self._pause_wedged(sched)
        return None  # SCHEDULE_COMPLETE — every story is done

    def _repause_inrun_escalation(self) -> None:
        """Re-pause on a story that escalated *after a session ran* (``attempt > 0``)
        instead of re-deriving its fate from disk.

        A pick-time wedge / unknown-selector task (attempt == 0) is a pure disk
        projection, and re-classifying it every pick is its designed lifecycle:
        fix the blocked spec / duplicate file / manifest by hand and a bare
        resume proceeds. An in-run escalation is not disk-derivable — a CRITICAL
        verify outcome (e.g. a proof-of-work GitError) or a resolved-redrive
        exhaustion pause escalates with the spec at a *resumable or even done*
        status, so the disk scan would silently re-dispatch the story (a fresh
        StoryTask overwrites the escalated one, destroying its escalation record
        and ``resolved_redrive`` guard — a later exhaustion then DEFERs the
        human-resolved work) or, at ``done``, leapfrog the unresolved escalation
        entirely. Only ``runs.rearm_escalation`` (`waves resolve`) discharges
        it: the re-arm resets the task to PENDING, after which this guard no
        longer matches and the normal re-drive proceeds. Never mutates the task —
        the escalation context must survive for resolve to act on."""
        for key, task in self.state.tasks.items():
            if task.phase == Phase.ESCALATED and task.attempt > 0:
                reason = (
                    f"story {key!r} escalated during this run and was not resolved — "
                    f"run `{namespace.PRODUCT} resolve {self.state.run_id}`, then resume"
                )
                self.journal.append("stories-escalation-unresolved", story_key=key)
                gates.notify(self.policy, self.run_dir, f"unresolved escalation: {key}", reason)
                raise RunPaused(reason, PAUSE_ESCALATION, key)

    def _run_end_retrospective(self) -> None:
        """Inert: stories mode has no epics (every ``_StoryRef.epic`` is the 0
        sentinel), so there is no finished epic to run a retrospective for — the
        run-end twin of the epic boundary that never fires here (DW-488)."""

    def _unresolved_escalation_key(self) -> str | None:
        """Only an in-run escalation (``attempt > 0``) blocks ``finished``. A
        pick-time wedge / unknown-selector task (``attempt == 0``) is re-classified
        from disk every pick (see ``_repause_inrun_escalation``), so reaching run end
        means the human fixed it by hand; its stale ESCALATED record must not
        re-pause the run, whose only way past would be a re-arm that re-drives the
        fixed story."""
        return next(
            (
                k
                for k, t in self.state.tasks.items()
                if t.phase == Phase.ESCALATED and t.attempt > 0
            ),
            None,
        )

    def _pause_unknown_selector(self, selector: str) -> None:
        """The ``--story`` selector resolves to no manifest entry: pause for
        resolve keyed on the selector, the same ESCALATED shape a wedge leaves, so
        the CLI/TUI surface + rearm handle it uniformly. Always raises."""
        task = StoryTask(story_key=selector, epic=0)
        task.phase = Phase.ESCALATED
        self.state.tasks[selector] = task
        reason = (
            f"--story id {selector!r} is not in stories.yaml — fix the id or the "
            f"manifest, then `{namespace.PRODUCT} resume {self.state.run_id}`"
        )
        self.journal.append("stories-selector-unknown", story_key=selector)
        gates.notify(self.policy, self.run_dir, f"unknown --story id: {selector}", reason)
        self._save()
        raise RunPaused(reason, PAUSE_ESCALATION, selector)

    def _pause_wedged(self, sched: stories.Schedule) -> None:
        """A blocked / sentinel / ambiguous story stopped the scan before any
        session ran this pick — it was already in that state on disk (a prior
        run, or a resume of one that halted). A blocked story cannot be
        leapfrogged, so pause for resolve.

        Records an ESCALATED task keyed by the story id — the same shape an in-run
        escalation leaves — so ``waves resolve`` (``runs.rearm_escalation`` +
        ``resolve.build_context``) and the sentinel auto-clear act on it uniformly,
        and the resolved re-drive flows through ``_finish_inflight`` exactly like a
        rearmed escalation. A PRESENT/SENTINEL wedge carries its spec path so
        resolve can open it; an AMBIGUOUS wedge leaves it unset (no single file to
        pick — the human removes the duplicate)."""
        entry = sched.entry
        state = sched.state
        assert entry is not None and state is not None
        task = StoryTask(story_key=entry.id, epic=0)
        task.phase = Phase.ESCALATED  # deliberate: a wedge has no legal advance from PENDING
        if state.kind in (stories.KIND_PRESENT, stories.KIND_SENTINEL) and state.path is not None:
            task.spec_file = str(state.path)
        self.state.tasks[entry.id] = task
        detail = self._wedged_detail(state)
        reason = f"story {entry.id!r} needs resolution before the run can continue: {detail}"
        if state.kind == stories.KIND_SENTINEL:
            # record the sentinel verdict on the task so rearm_escalation clears it by
            # this recorded kind, not by re-deriving from the spec_file basename.
            task.sentinel_kind = state.sentinel_kind
            self._journal_sentinel_detected(entry.id, state)
        self.journal.append(
            "stories-wedged",
            story_key=entry.id,
            state_kind=state.kind,
            sentinel_kind=state.sentinel_kind or None,
        )
        gates.notify(
            self.policy,
            self.run_dir,
            f"story blocked: {entry.id}",
            f"{detail} — resolve, then `{namespace.PRODUCT} resume {self.state.run_id}`",
        )
        self._save()
        raise RunPaused(reason, PAUSE_ESCALATION, entry.id)

    @staticmethod
    def _wedged_detail(state: stories.StoryState) -> str:
        if state.kind == stories.KIND_SENTINEL:
            return f"pre-planning halt sentinel ({state.sentinel_kind}) at {state.path}"
        if state.kind == stories.KIND_AMBIGUOUS:
            names = ", ".join(p.name for p in state.paths)
            return f"ambiguous story file match: {names}"
        # KIND_PRESENT with a blocked / unrecognized status.
        return f"story spec status {state.status!r} at {state.path}"

    def _journal_sentinel_detected(self, story_key: str, state: stories.StoryState) -> None:
        """Record that a read-back resolved a story to a fixed-slug pre-planning-halt
        sentinel, carrying its recorded blocking condition (the reason planning
        halted, parsed from ``## Auto Run Result``). Fires at pick-time (a sentinel
        left by a prior run/resume) and post-dev (this run's session HALTed), so the
        journal always has a distinct trace before the escalation/wedge event."""
        condition = ""
        if state.path is not None:
            try:
                condition = stories.recorded_blocking_condition(
                    state.path.read_text(encoding="utf-8")
                )
            except (OSError, UnicodeDecodeError):
                condition = ""
        self.journal.append(
            "sentinel-detected",
            story_key=story_key,
            sentinel_kind=state.sentinel_kind or None,
            condition=condition,
        )

    # -------------------------------------------------------------- dispatch

    def _dispatched_spec_for_attempt(self, task: StoryTask) -> str | None:
        """Bind only the unique readable id-keyed spec present at dispatch."""
        try:
            state = stories.resolve_story_spec(self._stories_folder(), task.story_key)
            if state.kind != stories.KIND_PRESENT or state.path is None:
                return None
            # Resolution degrades a read fault to PRESENT with an unknown status;
            # ownership must be stricter because recovery may later repair this
            # exact file. Re-read now and refuse a vanished/non-regular/unreadable
            # candidate rather than persisting an ownership claim we did not see.
            if not state.path.is_file():
                return None
            state.path.read_text(encoding="utf-8")
            return str(state.path)
        except (OSError, RuntimeError, UnicodeDecodeError):
            return None

    def _requires_dispatched_spec_snapshot(self, task: StoryTask, prompt: str) -> bool:
        """Require authority when folder+id dispatch targets an existing spec.

        A pending, ambiguous, or sentinel story does not claim file authority
        through this seam; normal Stories scheduling handles those states. Once
        resolution identifies one PRESENT spec, however, a transient binding/read
        fault must abort rather than let the folder+id child mutate an input
        recovery cannot restore. An uncertain second observation fails closed for
        the same reason.
        """
        try:
            state = stories.resolve_story_spec(self._stories_folder(), task.story_key)
        except (OSError, RuntimeError):
            return True
        return state.kind == stories.KIND_PRESENT and state.path is not None

    def _extra_session_env(
        self, task: StoryTask, role: str, label: str | None = None
    ) -> dict[str, str]:
        # Only PRIMARY dev/review sessions get the story-spec env. An injected
        # plugin-workflow session (label set — e.g. a TEA pre_commit_gate) runs the
        # generic adapter too; exporting WAVES_SPEC_FOLDER would make it
        # short-circuit to story-spec synthesis, so at pre_commit_gate (spec already
        # `done`) a gate session that did nothing would read `completed:done` and
        # bypass the completion-marker + monotonic stall-nudge contract (the
        # TEA-livelock fix). Withhold the env so workflow sessions keep the marker
        # contract; sprint-mode workflow sessions are already env-free here.
        if label is not None:
            return {}
        # Let the dev/review adapter resolve the story spec deterministically by
        # id (skip the mtime scan). Project-relative — the adapter anchors it on the
        # project's place in spec.cwd (`mountpaths.rebased_project`, the offset a
        # nested `repo_root:` adds, DW-379), matching `_stories_folder`, so it is
        # correct in place and under worktree isolation.
        env = {envvars.SPEC_FOLDER: self._spec_folder_rel}
        # On a plan-halt leg tell the adapter to synthesize the ready-for-dev spec
        # as a *successful* terminal (plan done), not died-mid-flight. Keyed off the
        # same on-disk state as the prompt's `Halt after planning.` leg, so the two
        # never disagree (both read before the session writes the spec).
        if role == "dev" and self._plan_halt_leg(task, self._entry_for(task)):
            env[envvars.PLAN_HALT] = "1"
        return env

    def _dev_prompt(self, task: StoryTask, feedback: Path | None) -> str:
        return self._stories_dev_prompt(task, feedback)

    def _stories_dev_prompt(self, task: StoryTask, feedback: Path | None) -> str:
        """Folder+id dispatch for a fresh (or resumed-to-implement) story; the
        repair leg falls back to the inherited explicit-spec-file resume.

        Fresh dispatch:
            ``/<dev primitive> Spec folder: <rel>. Story id: <id>.``
              (the primitive is disk-resolved — see ``Engine._dev_skill``)
            + (plan-halt leg) `` Halt after planning.``
            + (when ``invoke_dev_with`` non-empty) a newline then its verbatim text.
            + (on a retry with verified parked work) a blank line then
              ``recovery_flow.retry_preserve_paragraph`` (#777).

        The folder is always project-relative (kills the absolute-path concern;
        the contract allows an absolute one but we never emit it). ``invoke_dev_with``
        is appended verbatim — the single planner→dev channel, never interpreted."""
        if feedback is not None:
            # Deterministic-verify repair: re-open the id-keyed story spec and
            # resume on it in place. Identical to the base generic repair leg (an
            # explicit-spec-file invocation, a conforming mode) — the story spec
            # is just a normal spec file.
            self._reset_spec_for_repair(task)
            spec_ref = task.spec_file or task.story_key
            return (
                f"/{self._dev_skill()} Resume the autonomous dev session on the in-progress "
                f"spec at `{spec_ref}`. The previous session's work failed deterministic "
                f"verification; repair the working tree so verification passes without "
                f"changing the spec's frozen intent contract. Verification evidence is "
                f"in `{feedback}`."
            )
        entry = self._entry_for(task)
        prompt = (
            f"/{self._dev_skill()} Spec folder: {self._spec_folder_rel}. "
            f"Story id: {task.story_key}."
        )
        if self._plan_halt_leg(task, entry):
            prompt += " Halt after planning."
        if entry is not None and entry.invoke_dev_with:
            prompt += "\n" + entry.invoke_dev_with
        # A retry after a rolled-back attempt names its verified parked work (#777),
        # after the planner's verbatim text so that channel stays untouched.
        preserved = self._retry_preserve_notice(task)
        if preserved:
            prompt += "\n\n" + preserved
        return prompt

    def _entry_for(self, task: StoryTask) -> stories.StoryEntry | None:
        """The manifest entry for the task, re-read fresh so a resume (which does
        not go through ``_pick_next``) still resolves ``invoke_dev_with`` / the
        checkpoint flags. None when the id is absent — a pinned id never
        disappears, so this only happens on a hand-broken manifest, where the
        bare folder+id dispatch (title/description read by the skill) still runs.

        A parse failure journals a one-time ``stories-manifest-unreadable`` warning
        per story (this is called several times per dispatch) so the silent
        fallback leaves a trace, then returns None."""
        try:
            return self._load_stories().get(task.story_key)
        except stories.StoriesError as e:
            if task.story_key not in self._warned_unreadable:
                self._warned_unreadable.add(task.story_key)
                self.journal.append(
                    "stories-manifest-unreadable", story_key=task.story_key, error=str(e)
                )
            return None

    def _plan_halt_leg(self, task: StoryTask, entry: stories.StoryEntry | None) -> bool:
        """Whether this dispatch HALTs after planning for a human plan review.

        True only for a ``spec_checkpoint`` story whose plan has not yet reached
        ``ready-for-dev`` on disk — i.e. leg 1. Once the plan exists (leg 2 after
        the plan-checkpoint resume, or a mid-flight repair that reset the spec to
        in-progress) this is False and the story dispatches straight to
        implementation. Reading on-disk state (not a task flag) is what keeps the
        prompt's ``Halt after planning.`` leg and the env's ``WAVES_PLAN_HALT``
        in lock-step: both call this before the session writes the spec."""
        if entry is None:
            return False
        state = stories.resolve_story_spec(self._stories_folder(), task.story_key)
        return stories.is_plan_halt_leg(entry.spec_checkpoint, state)

    # ---------------------------------------------------------- sync + verify

    def _harvest_spec_path(self, task: StoryTask, result_json: dict | None) -> Path | None:
        """Resolve the same id-keyed story spec that verification will accept."""
        if not result_mapping(result_json).get("spec_file"):
            return None
        state = stories.resolve_story_spec(self._stories_folder(), task.story_key)
        return state.path if state.kind == stories.KIND_PRESENT else None

    def _post_dev_state_sync(self, task: StoryTask, result_json: dict | None) -> None:
        """No-op: stories mode has no sprint board. Honors the contract's "the
        orchestrator writes nothing" on the happy path — the dev skill is the sole
        writer of each story spec's status.

        Deferred-work closure is deliberately NOT here. It is project-wide state
        (a story's ``closes_deferred:`` declaration applies in this mode too), but
        it belongs at the commit boundary rather than at dev-sync time, so a story
        that later fails verification or review never leaves the ledger claiming
        its work resolved — see ``Engine._close_declared_deferred`` (#234)."""
        return

    def _manifest_closes_deferred(self, task: StoryTask) -> tuple[str, ...]:
        """The ``stories.yaml`` entry's ``closes_deferred`` ids.

        This is the channel that makes story-declared closure work unattended:
        ``bmad-build-auto`` writes the story spec and knows nothing of the ledger,
        so with the spec frontmatter alone a human would have to hand-edit every
        generated spec. The breakdown, by contrast, is authored while the ledger
        is in view. Both channels compose — the base hook unions them.

        Read here rather than through ``_entry_for`` because the two want opposite
        things from an unreadable manifest. ``_entry_for`` is a dispatch helper: it
        warns once per story and falls back to a bare folder+id dispatch that still
        works. Here the fallback is silence — the ids are not persisted anywhere,
        unlike the spec half's capture, so a parse failure at the commit boundary
        drops a declared closure with no trace beyond a generic one-time warning
        that may already have been spent earlier in the run. Say what was actually
        lost, at the site that lost it."""
        try:
            entry = self._load_stories().get(task.story_key)
        except stories.StoriesError as e:
            self.journal.append(
                "deferred-close-declaration-unreadable",
                story_key=task.story_key,
                source="stories.yaml",
                error=str(e),
                note="manifest-declared ids cannot be read; nothing is closed for them",
            )
            return ()
        return entry.closes_deferred if entry else ()

    def _verify_dev_artifacts(self, task: StoryTask, result_json: dict | None):
        # The adapter marks a plan-halt leg's synthesized result `plan_halt`; latch
        # it onto the task so _drive_story pauses for plan review (and clears it on
        # the leg-2 re-drive), and switch verify to the ready-for-dev plan gate.
        plan_halt = bool(result_mapping(result_json).get("plan_halt"))
        task.plan_checkpoint_pending = plan_halt
        # Read-back detection: the just-run dev session HALTed pre-planning and left
        # a fixed-slug sentinel. Journal it (with its recorded blocking condition)
        # before verify turns it into a retryable failure → escalation, so the
        # sentinel has a distinct trace at read-back, not only the later escalation.
        folder = self._stories_folder()
        state = stories.resolve_story_spec(folder, task.story_key)
        if state.kind == stories.KIND_SENTINEL:
            # record the sentinel verdict on the task (mirrors _pause_wedged) so a later
            # rearm clears it by recorded kind, not by re-deriving from the basename.
            task.sentinel_kind = state.sentinel_kind
            self._journal_sentinel_detected(task.story_key, state)
        outcome = verify.verify_dev_stories(
            task,
            self.workspace.paths,
            result_json,
            spec_folder=folder,
            review_enabled=self._dev_review_enabled(),
            plan_halt=plan_halt,
            engine_written=self._harvest_gate_exclude(task),
        )
        # The marker remains the independent authority that this was a deliberate
        # plan halt. Journal the proof waiver only after every artifact gate passes;
        # `zero_diff` is an observation of the skipped gate, never an input to it.
        waiver_already_recorded = (
            plan_halt
            and outcome.ok
            and any(
                entry.get("kind") == "plan-halt-proof-of-work-skipped"
                and entry.get("story_key") == task.story_key
                and entry.get("attempt") == task.attempt
                and entry.get("generation", 0) == task.generation
                for entry in self.journal.entries()
            )
        )
        if plan_halt and outcome.ok and not waiver_already_recorded:
            self.journal.append(
                "plan-halt-proof-of-work-skipped",
                story_key=task.story_key,
                attempt=task.attempt,
                generation=task.generation,
                zero_diff=outcome.plan_halt_zero_diff,
            )
        return outcome

    def _run_verify_commands_after_dev(self, task: StoryTask, result_json: dict | None) -> bool:
        # A plan-halt leg produced only the plan (spec at ready-for-dev); there is
        # no implementation yet, so skip the project build/test gate — it would
        # fail on a half-built tree before the human ever sees the plan.
        return not bool(result_mapping(result_json).get("plan_halt"))

    def _verify_review(self, task: StoryTask):
        # Drop the sprint-status gate (stories mode has no board); the id-keyed
        # story spec's own `done` frontmatter is authoritative. The sink is the
        # base engine's: stories mode runs the same verifier commands and its
        # results belong in the same journal record kind (see
        # `Engine._review_command_sink`), so a mode-specific one would only be a
        # way for the three gates to drift apart on what they record.
        return verify.verify_review_stories(
            task,
            self.workspace.paths,
            self.policy,
            on_results=self._review_command_sink(task),
        )

    def _sprint_board_instruction(self) -> str:
        # Stories mode has no sprint-status.yaml: `_post_dev_state_sync` is a no-op
        # here and `verify_review_stories` reads the id-keyed story spec alone. The
        # base clause would tell a session that a file it never sees is
        # orchestrator-owned — a false claim, not a harmless one. Dropped for the
        # same reason `_operator_park_enabled` is False below. This also drops the
        # inherited review prompt's `blocked` hand-back redirect, which gates itself
        # on this clause, and the `## Sprint board` section `_run_session` appends to
        # an injected plugin-workflow prompt: the board they speak about does not
        # exist here, so both stay byte-identical to their pre-#437 text in this mode.
        return ""

    def _operator_park_enabled(self) -> bool:
        # Stories mode has no sprint board, so the (awaiting-operator,
        # awaiting-operator) pair the park is verified against does not exist
        # here and `verify_review_stories` still demands `done`. Parking without
        # that gate would commit on the spec's word alone. Support is a follow-up
        # (spec-status + registry only); until then the token is simply not a
        # terminal this mode knows.
        return False

    # -------------------------------------------------------- HITL checkpoints

    def _drive_story(self, task: StoryTask, dev_resume: SessionResult | None = None) -> None:
        # Journal the plan-halt dispatch of a spec_checkpoint story's leg 1 (the
        # `Halt after planning.` prompt + WAVES_PLAN_HALT env are emitted by
        # _dev_prompt / _extra_session_env, both keyed off the same on-disk state).
        # dev_resume None means a fresh drive, not a mid-session crash replay.
        if dev_resume is None and self._plan_halt_leg(task, self._entry_for(task)):
            # Latch the plan-review obligation BEFORE the session runs, so it
            # survives a crash in the post-session window, a non-fixable retry that
            # advanced the on-disk plan status, or a skill that overran the Halt
            # directive — cases where _plan_halt_leg (on-disk-status keyed) and
            # plan_checkpoint_pending (result keyed) both go stale. Saved eagerly so
            # a host death before the durable session record still finds it set.
            task.plan_review_owed = True
            self._save()
            self.journal.append(
                "plan-halt", story_key=task.story_key, spec_folder=self._spec_folder_rel
            )
        if not self._dev_phase(task, resume_result=dev_resume):
            return
        if task.plan_checkpoint_pending:
            self._pause_plan_checkpoint(task)  # always raises RunPaused
        if task.plan_review_owed:
            # A plan review is still owed but this dev leg did NOT itself pause for
            # it: the skill overran `Halt after planning.` and drove to done, or a
            # crash/non-fixable-retry re-drove straight to implementation on an
            # already-planned spec. Pause before commit so a spec_checkpoint story
            # can never commit un-reviewed (distinct "owed but implemented" message).
            self._pause_plan_review_owed(task)  # always raises RunPaused
        # preserve the global spec-approval gate (rarely configured in stories
        # mode, but the plan-checkpoint is not a substitute for it).
        if gates.pause_after_spec(self.policy):
            gates.notify(
                self.policy,
                self.run_dir,
                f"spec ready for approval: {task.story_key}",
                f"review {self._operator_spec_path(task)}, then "
                f"`{namespace.PRODUCT} resume {self.state.run_id}`",
            )
            raise RunPaused(
                f"awaiting spec approval for {task.story_key}",
                PAUSE_SPEC_APPROVAL,
                task.story_key,
            )
        self._review_and_commit(task)

    def _pause_plan_checkpoint(self, task: StoryTask) -> None:
        """Leg 1 of a spec_checkpoint story verified (plan at ready-for-dev): pause
        for human plan review. The task stays at DEV_VERIFY with
        ``plan_checkpoint_pending`` set, so on resume _finish_inflight routes it to
        :meth:`_resume_after_dev_verify` for the implement leg. Always raises."""
        task.plan_review_owed = False  # discharged: we are pausing for the review now
        self.journal.append(
            "checkpoint-pause",
            story_key=task.story_key,
            checkpoint="plan",
            spec=self._operator_spec_path(task),
        )
        gates.notify(
            self.policy,
            self.run_dir,
            f"plan ready for review: {task.story_key}",
            f"review the planned spec {self._operator_spec_path(task)}, then "
            f"`{namespace.PRODUCT} resume {self.state.run_id}`",
        )
        self._save()
        raise RunPaused(
            f"plan checkpoint for {task.story_key}: review the spec, then resume",
            PAUSE_PLAN_CHECKPOINT,
            task.story_key,
        )

    def _pause_plan_review_owed(self, task: StoryTask) -> None:
        """A spec_checkpoint story reached implementation without ever pausing for
        its plan review (the skill overran ``Halt after planning.``, or a crash /
        non-fixable retry re-drove straight to implementation on an already-planned
        spec). The plan review is still owed, so pause before commit — distinct from
        :meth:`_pause_plan_checkpoint` in that the code is already written.

        ``plan_checkpoint_pending`` is deliberately NOT set: on resume the story is
        already implemented, so :meth:`_resume_after_dev_verify` proceeds to
        review+commit (the human approved) rather than re-driving an implement leg.
        Reuses PAUSE_PLAN_CHECKPOINT so the CLI/TUI resume handling is unchanged.
        Always raises."""
        task.plan_review_owed = False  # discharged: we are pausing for the review now
        self.journal.append(
            "checkpoint-pause",
            story_key=task.story_key,
            checkpoint="plan",
            spec=self._operator_spec_path(task),
            owed_after_implement=True,
        )
        gates.notify(
            self.policy,
            self.run_dir,
            f"plan review owed (already implemented): {task.story_key}",
            f"the story was implemented before its plan checkpoint fired — review "
            f"{self._operator_spec_path(task)}, then `{namespace.PRODUCT} resume {self.state.run_id}`",
        )
        self._save()
        raise RunPaused(
            f"plan review owed for {task.story_key}: the skill implemented before the "
            f"plan checkpoint — review the spec, then resume",
            PAUSE_PLAN_CHECKPOINT,
            task.story_key,
        )

    def _resume_after_dev_verify(self, task: StoryTask) -> None:
        # A plan-checkpoint pause re-drives the implement leg here rather than the
        # base review+commit. The on-disk status is now ready-for-dev, so _drive_story
        # dispatches a plain folder+id leg (implement) and, once it commits, the
        # done_checkpoint fires from _after_story like any other story.
        if task.plan_checkpoint_pending:
            task.plan_checkpoint_pending = False
            task.phase = Phase.PENDING  # deliberate reset for the re-drive
            self.journal.append("checkpoint-resume", story_key=task.story_key, checkpoint="plan")
            self._save()
            self._drive_story(task)
            return
        super()._resume_after_dev_verify(task)

    def _after_story(self, task: StoryTask) -> None:
        # done_checkpoint: after a committed story, pause for review — but skip when
        # this was the last story to dispatch (the run ends here anyway). Fires from
        # both _loop and _finish_inflight, always after any worktree integration.
        if task.phase != Phase.DONE:
            return
        try:
            entry = self._load_stories().get(task.story_key)
        except stories.StoriesError as e:
            # The manifest went unreadable between the commit and this check, so
            # the done_checkpoint flag is unknowable. Mirror _schedule_complete's
            # conservative default: pause for review rather than silently drop a
            # checkpoint the manifest may well set — the run cannot proceed past
            # a broken manifest anyway (the next pick would halt on it loud), so
            # the only thing a skip could save is the human review itself.
            self.journal.append(
                "stories-manifest-unreadable", story_key=task.story_key, error=str(e)
            )
        else:
            if entry is None or not entry.done_checkpoint:
                return
        # skip-if-last: no further story will dispatch. Either the schedule is
        # complete OR this committed story is the run's --max-stories-th (the bound
        # stops the loop next iteration). Honoring the cap here — durably, from
        # committed-story count, not the resume-reset _loop counter — is what keeps
        # a done_checkpoint pause from letting a resume leapfrog past the bound (the
        # pause+resume would otherwise reset the local counter and dispatch more).
        # A pending graceful stop also skips the done_checkpoint pause: the
        # loop-head check will end the run as `stopped` on the next iteration, so
        # pausing here would strand it `paused` instead — the stop must win (see
        # the plan's "done_checkpoint + graceful after same story" disposition).
        graceful = graceful_stop_requested(self.run_dir)
        if self._schedule_complete() or self._max_stories_reached() or graceful:
            fields: dict[str, Any] = {"story_key": task.story_key, "checkpoint": "story"}
            if graceful:
                # tag the cause so the journal distinguishes a graceful-stop skip
                # from a natural last-story / --max-stories skip.
                fields["reason"] = "graceful-stop"
            self.journal.append("checkpoint-skip-last", **fields)
            return
        self.journal.append(
            "checkpoint-pause", story_key=task.story_key, checkpoint="story", commit=task.commit_sha
        )
        gates.notify(
            self.policy,
            self.run_dir,
            f"story committed — review checkpoint: {task.story_key}",
            f"review {task.story_key}, then `{namespace.PRODUCT} resume {self.state.run_id}`",
        )
        self._save()
        raise RunPaused(
            f"story checkpoint for {task.story_key}: review, then resume",
            PAUSE_STORY_CHECKPOINT,
            task.story_key,
        )

    def _schedule_complete(self) -> bool:
        """Whether the schedule has no more actionable stories. Guarded: a manifest
        that went unreadable (or a --story id that vanished) between the commit and
        this skip-if-last check must not crash the after-commit path — treat an
        error as "not complete" so the done_checkpoint still fires (the safe default
        is to pause for review, never to silently swallow it)."""
        try:
            return self._compute_schedule().is_complete
        except (StoriesModeError, stories.StoriesError):
            return False

    def _max_stories_reached(self) -> bool:
        """Whether the run has dispatched its ``--max-stories`` allotment. Consults the
        same durable :meth:`Engine._dispatched_count` the loop's dispatch gate uses, so
        the done_checkpoint's skip-if-last fires exactly when the loop will stop next
        iteration — no drift between the two guards across a pause/resume."""
        if self.max_stories is None:
            return False
        return self._dispatched_count() >= self.max_stories

    def _remaining_estimate(self) -> int | None:
        """Stories a resume would still drive, for the graceful-stop journal +
        notify. Mirrors the scheduler that drives ``is_complete``
        (:meth:`_compute_schedule`) but without its journaling/selector-pause side
        effects: scan the manifest in list order, skip entries already retired this
        run (DONE/DEFERRED) or done on disk, count the actionable ones, and stop at
        the first wedge — a blocked story a plain resume cannot leapfrog, so later
        entries are unreachable until ``resolve``. Reuses the scheduler's own
        classifier so the count stays in lockstep with ``is_complete`` (both derive
        from :func:`stories._classify`). Best-effort — any manifest/spec read error
        returns None so a graceful stop is never blocked on it."""
        try:
            story_set = self._load_stories()
            folder = self._stories_folder()
            skip = {
                key
                for key, task in self.state.tasks.items()
                if task.phase in (Phase.DONE, Phase.DEFERRED)
            }
            entries = story_set.entries
            if self._story_id_filter is not None:
                entries = tuple(e for e in entries if e.id == self._story_id_filter)
            remaining = 0
            for entry in entries:
                if entry.id in skip:
                    continue
                disposition = stories._classify(stories.resolve_story_spec(folder, entry.id))
                if disposition == "done":
                    continue
                if disposition == "wedged":
                    break  # a blocked story stops the scan; the rest is unreachable
                remaining += 1  # actionable
            return remaining
        except Exception:  # a hint must never break the stop
            return None
