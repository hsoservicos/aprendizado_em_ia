"""The configuration map behind ``waves config`` and the ``waves-config`` skill.

Every file a waves run reads, its state on this machine and in this project, and the
door that owns it — one document, so the skill never re-derives what the loop already
knows (the policy's stage inheritance, the agents ``init`` would render, where each
skill's overrides live) and never guesses what a `git status` would say.

A read-model: it writes nothing and never raises for a file that is missing or
unreadable — that is a finding, with the door that fixes it. The five surfaces:

* the loop policy (machine-local) — the adapters per role, ``[scm]``, ``[tests.capacity]``;
* the adapter agents ``init`` renders from it, per CLI that reads agent definitions;
* the tests config (the project's, versioned) the gate reads from the merge-base;
* the provisioning recipe named by ``[scm] provision`` / ``teardown``;
* each customizable skill's overrides (team, versioned; personal, gitignored) and the
  watcher's rules — plus the skill trees themselves, against the installed version.

Obeys the pure-document contract in :mod:`machine` (additive-only evolution; anything
breaking bumps :data:`CONFIG_SCHEMA_VERSION`).
"""

from __future__ import annotations

import tomllib
from importlib import resources
from pathlib import Path
from typing import Any

from . import __version__, namespace
from .adapters.profile import CLIProfile, ProfileError, load_profiles
from .install import AGENT_FILE, AGENT_MARKER, MODULE_SKILLS, RULES_FILE, agent_name
from .policy import PARALLELISM_ROLES, Policy, PolicyError
from .policy import load as load_policy
from .verify import GitError, git_bytes

CONFIG_SCHEMA_VERSION = 1

#: The bundled skills that ship a ``customize.toml`` and read ``_waves/custom/<skill>.toml``.
CUSTOMIZABLE_SKILLS = (
    namespace.SKILL_MASTER_PARALLELISM,
    namespace.SKILL_CORE_PARALLELISM,
    namespace.SKILL_TESTS,
)
POLICY_REL = f"{namespace.STATE_REL}/policy.toml"
_LEGACY_CUSTOM = Path("_bmad") / "custom"
# What `waves-tests` ships when its customize.toml cannot be read (it always can; the
# literal is the last resort, never the source).
_TESTS_CONFIG_FALLBACK = (namespace.PROJECT_HOME / "tests_memory.toml").as_posix()
_TESTS_MEMORY_FALLBACK = namespace.TESTS_MEMORY_DIR.as_posix()

Finding = dict[str, str]


def _read_toml(path: Path) -> tuple[dict[str, Any] | None, str | None]:
    try:
        return tomllib.loads(path.read_text(encoding="utf-8")), None
    except FileNotFoundError:
        return None, None
    except (OSError, UnicodeDecodeError, tomllib.TOMLDecodeError) as e:
        return None, str(e)


def _git_tracked(project: Path, rel: str) -> bool | None:
    try:
        proc = git_bytes(project, "ls-files", "--error-unmatch", rel, timeout_s=10)
    except GitError:
        return None
    return proc.returncode == 0


def _git_dirty(project: Path, rel: str) -> bool | None:
    try:
        proc = git_bytes(project, "status", "--porcelain", "--", rel, timeout_s=10)
    except GitError:
        return None
    if proc.returncode != 0:
        return None
    return bool(proc.stdout.strip())


def _shipped_workflow(skill: str) -> dict[str, Any]:
    """The `[workflow]` table a skill ships — its defaults and the keys an override may set."""
    try:
        text = (
            resources.files("riaworks_waves_loop.data")
            .joinpath("skills", skill, "customize.toml")
            .read_text(encoding="utf-8")
        )
        table = tomllib.loads(text).get("workflow", {})
    except (OSError, tomllib.TOMLDecodeError, TypeError):
        return {}
    return table if isinstance(table, dict) else {}


def _override_layer(project: Path, rel: Path) -> dict[str, Any]:
    doc, error = _read_toml(project / rel)
    keys: list[str] = []
    if doc is not None:
        table = doc.get("workflow", {})
        if isinstance(table, dict):
            keys = sorted(str(k) for k in table)
    return {
        "path": rel.as_posix(),
        "exists": (project / rel).is_file(),
        "error": error,
        "keys": keys,
    }


def _customizations(project: Path, findings: list[Finding]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for skill in CUSTOMIZABLE_SKILLS:
        team = _override_layer(project, namespace.CUSTOM_DIR / f"{skill}.toml")
        personal = _override_layer(project, namespace.CUSTOM_DIR / f"{skill}.user.toml")
        legacy = (project / _LEGACY_CUSTOM / f"{skill}.toml").is_file()
        shipped = _shipped_workflow(skill)
        for layer in (team, personal):
            if layer["error"]:
                findings.append(
                    {
                        "severity": "problem",
                        "area": "custom",
                        "message": f"{layer['path']} is unreadable: {layer['error']}",
                        "door": f"{namespace.SKILL_CONFIG} [S]",
                    }
                )
            unknown = [k for k in layer["keys"] if k not in shipped]
            if unknown:
                findings.append(
                    {
                        "severity": "warning",
                        "area": "custom",
                        "message": f"{layer['path']} sets keys {skill} does not ship: {unknown}",
                        "door": f"{namespace.SKILL_CONFIG} [S]",
                    }
                )
        if legacy:
            findings.append(
                {
                    "severity": "warning",
                    "area": "custom",
                    "message": f"{(_LEGACY_CUSTOM / f'{skill}.toml').as_posix()} still exists — "
                    f"the team layer moved to {namespace.CUSTOM_DIR.as_posix()}",
                    "door": f"{namespace.PRODUCT} init",
                }
            )
        out[skill] = {
            "team": team,
            "personal": personal,
            "legacy": legacy,
            "defaults": {k: v for k, v in shipped.items() if not isinstance(v, (dict, list))},
            "list_defaults": {k: v for k, v in shipped.items() if isinstance(v, list)},
        }
    return out


def _tests_paths(project: Path) -> tuple[str, str]:
    """The tests config and memory dir, resolved the way the skill does: personal over
    team over the shipped default."""
    shipped = _shipped_workflow(namespace.SKILL_TESTS)
    config = str(shipped.get("config_file", _TESTS_CONFIG_FALLBACK))
    memory = str(shipped.get("memory_dir", _TESTS_MEMORY_FALLBACK))
    for name in (f"{namespace.SKILL_TESTS}.toml", f"{namespace.SKILL_TESTS}.user.toml"):
        doc, _ = _read_toml(project / namespace.CUSTOM_DIR / name)
        table = (doc or {}).get("workflow", {})
        if isinstance(table, dict):
            config = str(table.get("config_file", config))
            memory = str(table.get("memory_dir", memory))
    return config, memory


def _tests(project: Path, policy: Policy | None, findings: list[Finding]) -> dict[str, Any]:
    config_rel, memory_rel = _tests_paths(project)
    path = project / config_rel
    doc, error = _read_toml(path)
    kinds: list[dict[str, Any]] = []
    if doc is not None:
        for raw in doc.get("kind", []) if isinstance(doc.get("kind"), list) else []:
            if isinstance(raw, dict):
                kinds.append(
                    {
                        "id": str(raw.get("id", "")),
                        "type": str(raw.get("type", "")),
                        "capacity": raw.get("capacity", 1),
                    }
                )
    tracked = _git_tracked(project, config_rel) if path.is_file() else None
    dirty = _git_dirty(project, config_rel) if path.is_file() else None
    door = f"{namespace.SKILL_TESTS} [D]"
    if not path.is_file():
        findings.append(
            {
                "severity": "problem",
                "area": "tests",
                "message": f"{config_rel} is missing: no gate, no queue, and a plan without it "
                "does not run",
                "door": door,
            }
        )
    elif error:
        findings.append(
            {
                "severity": "problem",
                "area": "tests",
                "message": f"{config_rel} is unreadable: {error}",
                "door": f"{namespace.SKILL_TESTS} [C]",
            }
        )
    else:
        if tracked is False:
            findings.append(
                {
                    "severity": "problem",
                    "area": "tests",
                    "message": f"{config_rel} is not tracked: the gate reads it from the story's "
                    "merge-base, so it must be committed on the integration branch",
                    "door": "commit it on the integration branch",
                }
            )
        elif dirty:
            findings.append(
                {
                    "severity": "warning",
                    "area": "tests",
                    "message": f"{config_rel} has uncommitted changes: the gate reads the "
                    "committed version",
                    "door": "commit it on the integration branch",
                }
            )
        isolated = bool(policy.scm.isolated_data) if policy is not None else False
        shared = sorted(
            {
                k["type"]
                for k in kinds
                if k["type"] in ("integration", "api", "e2e")
                and k["capacity"] != 1
                and not isolated
            }
        )
        if shared:
            findings.append(
                {
                    "severity": "warning",
                    "area": "tests",
                    "message": f"capacity above 1 for {shared} while the provisioning declares no "
                    "isolated data: two fronts on one database corrupt each other whatever "
                    "the queue says",
                    "door": f"{namespace.SKILL_PROVISIONING} [D] or {namespace.SKILL_TESTS} [C]",
                }
            )
    return {
        "config_file": config_rel,
        "memory_dir": memory_rel,
        "exists": path.is_file(),
        "error": error,
        "tracked": tracked,
        "dirty": dirty,
        "kinds": kinds,
        "scope": str((doc or {}).get("story", {}).get("scope", "")) if doc else "",
        "epic_full_suite": (doc or {}).get("epic", {}).get("full_suite") if doc else None,
    }


def _provisioning(project: Path, policy: Policy | None, findings: list[Finding]) -> dict[str, Any]:
    if policy is None:
        return {"provision": "", "teardown": "", "isolated_data": False, "max_parallel": None}
    scm = policy.scm
    provision = scm.provision.strip()
    teardown = scm.teardown.strip()
    recipe = provision.split()[0] if provision else ""
    recipe_exists = (project / recipe).is_file() if recipe and not recipe.startswith("/") else None
    if provision and not teardown:
        findings.append(
            {
                "severity": "warning",
                "area": "provisioning",
                "message": "[scm] provision is set and teardown is empty: every front's stack "
                "stays up after its tree is given back",
                "door": f"{namespace.SKILL_PROVISIONING} [D]",
            }
        )
    if recipe_exists is False:
        findings.append(
            {
                "severity": "problem",
                "area": "provisioning",
                "message": f"[scm] provision names {recipe}, which does not exist",
                "door": f"{namespace.SKILL_PROVISIONING} [C]",
            }
        )
    return {
        "provision": provision,
        "teardown": teardown,
        "recipe": recipe,
        "recipe_exists": recipe_exists,
        "isolated_data": scm.isolated_data,
        "max_parallel": scm.max_parallel,
        "worktree_seed": list(scm.worktree_seed),
    }


def _agents(
    project: Path, profiles: dict[str, CLIProfile], policy: Policy | None, findings: list[Finding]
) -> list[dict[str, Any]]:
    expected = {""}
    if policy is not None:
        expected |= {policy.adapter.resolved(role).effort for role in PARALLELISM_ROLES}
    expected_names = sorted(agent_name(e) for e in expected)
    out: list[dict[str, Any]] = []
    for name, profile in sorted(profiles.items()):
        if not profile.agents_dir:
            continue
        agents_dir = project / profile.agents_dir
        rendered: list[str] = []
        foreign: list[str] = []
        if agents_dir.is_dir():
            for path in sorted(agents_dir.glob(f"{AGENT_FILE}*.md")):
                try:
                    mine = AGENT_MARKER in path.read_text(encoding="utf-8")
                except (OSError, UnicodeDecodeError):
                    mine = False
                (rendered if mine else foreign).append(path.stem)
        rendered.sort()
        foreign.sort()
        missing = [n for n in expected_names if n not in rendered and n not in foreign]
        stale = [n for n in rendered if n not in expected_names]
        if missing or stale:
            findings.append(
                {
                    "severity": "warning",
                    "area": "agents",
                    "message": f"{profile.agents_dir}: adapter agents "
                    + (f"missing {missing}" if missing else "")
                    + (" and " if missing and stale else "")
                    + (f"stale {stale}" if stale else "")
                    + " against the policy's efforts",
                    "door": f"{namespace.PRODUCT} init",
                }
            )
        out.append(
            {
                "profile": name,
                "dir": profile.agents_dir,
                "exists": agents_dir.is_dir(),
                "expected": expected_names,
                "rendered": rendered,
                "foreign": foreign,
                "missing": missing,
                "stale": stale,
            }
        )
    return out


def _skill_trees(
    project: Path, profiles: dict[str, CLIProfile], findings: list[Finding]
) -> dict[str, Any]:
    out: dict[str, Any] = {}
    trees = sorted({p.skill_tree for p in profiles.values()})
    for tree in trees:
        root = project / tree
        if not root.is_dir():
            continue
        present = sorted(s for s in MODULE_SKILLS if (root / s / "SKILL.md").is_file())
        if not present:
            # a tree another tool keeps (a project's own agents, a sibling CLI's skills):
            # the module was never installed there, so nothing of it is missing there
            continue
        missing = sorted(s for s in MODULE_SKILLS if s not in present)
        version: str | None = None
        module_yaml = root / namespace.SKILL_SETUP / "assets" / "module.yaml"
        if module_yaml.is_file():
            for line in module_yaml.read_text(encoding="utf-8", errors="replace").splitlines():
                if line.startswith("module_version:"):
                    version = line.split(":", 1)[1].strip().strip('"')
        drift = (version != __version__) if version is not None else None
        rules = root / namespace.SKILL_MASTER_TUI / RULES_FILE
        if missing:
            findings.append(
                {
                    "severity": "warning",
                    "area": "skills",
                    "message": f"{tree}: missing {missing}",
                    "door": f"{namespace.PRODUCT} init",
                }
            )
        if drift:
            findings.append(
                {
                    "severity": "warning",
                    "area": "skills",
                    "message": f"{tree}: skills are version {version}, the installed package is "
                    f"{__version__}",
                    "door": f"{namespace.PRODUCT} init --force-skills",
                }
            )
        out[tree] = {
            "present": present,
            "missing": missing,
            "module_version": version,
            "package_version": __version__,
            "drift": drift,
            "watcher_rules": rules.as_posix() if rules.is_file() else None,
        }
    if not out:
        findings.append(
            {
                "severity": "problem",
                "area": "skills",
                "message": "no skill tree in the project: the module is not installed",
                "door": f"{namespace.PRODUCT} init",
            }
        )
    return out


def _watcher(project: Path, trees: dict[str, Any]) -> dict[str, Any]:
    for info in trees.values():
        rel = info.get("watcher_rules")
        if not rel:
            continue
        doc, error = _read_toml(project / rel)
        return {
            "path": rel,
            "exists": True,
            "error": error,
            "limiares": (doc or {}).get("limiares", {}),
            "autonomia": (doc or {}).get("autonomia", {}),
        }
    return {"path": None, "exists": False, "error": None, "limiares": {}, "autonomia": {}}


def config_document(project: Path) -> dict[str, object]:
    """The `config --json` document. ``ok`` is false when any finding is a problem."""
    findings: list[Finding] = []
    policy_path = project / POLICY_REL
    policy: Policy | None = None
    policy_error: str | None = None
    if policy_path.is_file():
        try:
            policy = load_policy(policy_path)
        except PolicyError as e:
            policy_error = str(e)
            findings.append(
                {
                    "severity": "problem",
                    "area": "policy",
                    "message": f"{POLICY_REL} does not load: {e}",
                    "door": f"{namespace.SKILL_CONFIG} [L]",
                }
            )
    else:
        findings.append(
            {
                "severity": "problem",
                "area": "policy",
                "message": f"{POLICY_REL} is missing: the module is not initialized here",
                "door": f"{namespace.PRODUCT} init",
            }
        )
    try:
        profiles = load_profiles(project)
    except ProfileError as e:
        profiles = {}
        findings.append(
            {
                "severity": "problem",
                "area": "profiles",
                "message": f"a CLI profile does not load: {e}",
                "door": f"{namespace.PRODUCT} probe-adapter",
            }
        )
    roles: dict[str, Any] = {}
    adapter: dict[str, Any] = {}
    capacity: dict[str, int] = {}
    if policy is not None:
        adapter = {
            "name": policy.adapter.name,
            "model": policy.adapter.model,
            "effort": policy.adapter.effort,
        }
        for role in PARALLELISM_ROLES:
            resolved = policy.adapter.resolved(role)
            runner = profiles.get(resolved.name)
            launch = runner.headless_argv(resolved.model, resolved.effort) if runner else None
            roles[role] = {
                "runner": resolved.name,
                "model": resolved.model,
                "effort": resolved.effort,
                # The adapter agent exists only where the runner reads agent
                # definitions (its profile's `agents_dir`); elsewhere there is no file.
                "agent": agent_name(resolved.effort) if runner and runner.agents_dir else "none",
                "native": resolved.name == policy.adapter.name,
                # The literal argv a master on another CLI runs for this role, with the
                # brief on stdin. None = the runner declares no headless mode.
                "launch": list(launch) if launch is not None else None,
            }
    # `[tests.capacity]` is this machine's lowering of the owner's capacities, read
    # by the tests tool straight from the file; the policy model does not carry it.
    capacity = _machine_capacity(policy_path)
    # every section first — each contributes findings — then the verdict
    trees = _skill_trees(project, profiles, findings)
    agents = _agents(project, profiles, policy, findings)
    tests = _tests(project, policy, findings)
    provisioning = _provisioning(project, policy, findings)
    custom = _customizations(project, findings)
    watcher = _watcher(project, trees)
    return {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "project": project.as_posix(),
        "package_version": __version__,
        "ok": not any(f["severity"] == "problem" for f in findings),
        "policy": {
            "path": POLICY_REL,
            "exists": policy_path.is_file(),
            "error": policy_error,
            "adapter": adapter,
            "roles": roles,
            "tests_capacity": capacity,
        },
        "agents": agents,
        "tests": tests,
        "provisioning": provisioning,
        "custom": custom,
        "skills": trees,
        "watcher": watcher,
        "findings": findings,
    }


def _machine_capacity(policy_path: Path) -> dict[str, int]:
    doc, _ = _read_toml(policy_path)
    table = (doc or {}).get("tests", {})
    raw = table.get("capacity", {}) if isinstance(table, dict) else {}
    if not isinstance(raw, dict):
        return {}
    return {str(k): int(v) for k, v in raw.items() if isinstance(v, int)}


def render_text(doc: dict[str, Any]) -> str:
    lines: list[str] = [
        f"{namespace.PRODUCT} config — {doc['project']} (package {doc['package_version']})"
    ]
    policy = doc["policy"]
    lines.append(f"policy: {policy['path']} " + ("present" if policy["exists"] else "MISSING"))
    for role, entry in policy.get("roles", {}).items():
        lines.append(
            f"  {role:<10} runner {entry['runner']:<12} model {entry['model'] or 'default':<18} "
            f"effort {entry['effort'] or 'default':<8} agent {entry['agent']}"
            + ("" if entry["native"] else "  (another CLI: launched in the role's tree)")
        )
        if not entry["native"]:
            launch = entry.get("launch")
            lines.append(
                "             launch: "
                + (
                    " ".join(launch) + " < brief"
                    if launch
                    else "none — the runner declares no headless mode"
                )
            )
    for agents in doc["agents"]:
        state = ", ".join(agents["rendered"]) or "none rendered"
        extra = ""
        if agents["missing"]:
            extra += f"  missing {agents['missing']}"
        if agents["stale"]:
            extra += f"  stale {agents['stale']}"
        lines.append(f"agents ({agents['profile']}): {agents['dir']}/ — {state}{extra}")
    tests = doc["tests"]
    lines.append(
        f"tests: {tests['config_file']} "
        + ("present" if tests["exists"] else "MISSING")
        + (
            f" · {len(tests['kinds'])} kind(s) · scope {tests['scope'] or '?'}"
            f" · tracked {tests['tracked']} · dirty {tests['dirty']}"
            if tests["exists"]
            else ""
        )
    )
    prov = doc["provisioning"]
    lines.append(
        f"provisioning: provision {prov.get('provision') or '(none)'} · teardown "
        f"{prov.get('teardown') or '(none)'} · isolated_data {prov.get('isolated_data')} · "
        f"max_parallel {prov.get('max_parallel')}"
    )
    for skill, layers in doc["custom"].items():
        team, personal = layers["team"], layers["personal"]
        lines.append(
            f"custom {skill}: team "
            + (f"{team['keys'] or 'present, no keys'}" if team["exists"] else "absent")
            + " · personal "
            + (f"{personal['keys'] or 'present, no keys'}" if personal["exists"] else "absent")
        )
    for tree, info in doc["skills"].items():
        lines.append(
            f"skills {tree}: {len(info['present'])}/{len(MODULE_SKILLS)} · version "
            f"{info['module_version'] or '?'}" + (" (DRIFT)" if info["drift"] else "")
        )
    watcher = doc["watcher"]
    autonomia = watcher["autonomia"] if isinstance(watcher["autonomia"], dict) else {}
    lines.append(
        f"watcher: {watcher['path'] or 'no rules.toml'}"
        + (f" · modo {autonomia['modo']}" if "modo" in autonomia else "")
        + (f" · {len(watcher['limiares'])} threshold(s)" if watcher["limiares"] else "")
    )
    findings = doc["findings"]
    lines.append("")
    if not findings:
        lines.append("findings: none")
    for f in findings:
        lines.append(f"{f['severity']:<8} {f['area']:<13} {f['message']}  -> {f['door']}")
    return "\n".join(lines)
