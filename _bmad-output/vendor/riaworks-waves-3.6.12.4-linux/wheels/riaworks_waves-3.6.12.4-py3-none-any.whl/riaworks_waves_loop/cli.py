"""waves command line interface."""

from __future__ import annotations

import argparse
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import time
from enum import IntEnum
from pathlib import Path
from stat import S_ISREG
from typing import TYPE_CHECKING, Any

from . import (
    __version__,
    bmadconfig,
    decisions,
    deferredwork,
    devcontract,
    envvars,
    events,
    frontmatter,
    gates,
    install,
    machine,
    namespace,
    operatoractions,
    operatorhold,
)
from . import policy as policy_mod
from . import (
    resolve,
    runs,
    runsetup,
    sprintstatus,
)
from . import stories as stories_mod
from . import (
    verify,
    waveplan,
)

# Re-exported for the test suite, which stubs `_platform_preflight` with
# `cli.Finding(...)`; no longer referenced within this module (the preflight body
# moved to runsetup), so it needs the pin or ruff F401 autofix would drop it.
from .checks import Finding  # noqa: F401 — re-export
from .checks import ValidationReport

# The --json document builders live in documents.py (the library-level projection
# layer a non-CLI frontend imports). The schema constants are re-exported rather
# than used here — `cli.STATUS_SCHEMA_VERSION` and friends are the published names
# consumers and tests already resolve — so each carries a noqa: without it ruff
# F401 autofixes the re-export away and every `cli.*_SCHEMA_VERSION` reference
# breaks. Keep the noqa when adding a command.
from .documents import CLEAN_SCHEMA_VERSION  # noqa: F401 — re-export
from .documents import CLEANUP_SCHEMA_VERSION  # noqa: F401 — re-export
from .documents import CONFIRM_SCHEMA_VERSION  # noqa: F401 — re-export
from .documents import DECISIONS_SCHEMA_VERSION  # noqa: F401 — re-export
from .documents import INTERVENE_SCHEMA_VERSION  # noqa: F401 — re-export
from .documents import LIST_SCHEMA_VERSION  # noqa: F401 — re-export
from .documents import STATUS_SCHEMA_VERSION  # noqa: F401 — re-export
from .documents import TEACONFIG_SCHEMA_VERSION  # noqa: F401 — re-export
from .documents import VALIDATE_SCHEMA_VERSION  # noqa: F401 — re-export
from .documents import (
    clean_document,
    cleanup_document,
    confirm_document,
    decisions_document,
    intervene_document,
    list_document,
    run_token_totals,
    status_document,
    teaconfig_document,
    validate_document,
)
from .engine import Engine, _publication_refusal
from .escalation import display_pause_reason
from .journal import LOGS_DIR, Journal, load_state, save_state, state_lock
from .model import RunState, StoryTask
from .platform_util import (
    MAX_SEGMENT,
    LockUnavailableError,
    resolve_or_lexical,
    walk_files_unlinked,
)
from .process_host import ProcessHostError, get_process_host

# The run-composition helpers now live in runsetup.py (the library layer a non-CLI
# frontend imports). They are re-exported under their historical private names —
# used within this module (validate/mux/sweep/resume) and monkeypatched as
# `cli.<name>` by the test suite — so the seams stay importable here. Each is
# genuinely referenced below, so no noqa is needed (an unused-import pin would
# itself trip RUF100); a future caller-less re-export would need a `noqa: F401`
# pin. Written without the leading hash on purpose: ruff scans comment TEXT for
# directives, so spelling one out in prose is read as a real (and malformed) one.
from .runsetup import ROLES
from .runsetup import make_adapters as _make_adapters
from .runsetup import mux_reason_label as _mux_reason_label
from .runsetup import platform_preflight as _platform_preflight
from .runsetup import policy_absence
from .stories_engine import StoriesEngine
from .sweep import (
    DW_ID_RE,
    SEVERITY_ORDER,
    SWEEP_OVERRIDE_KEYS,
    DecisionOption,
    SweepEngine,
    decimal_digits_key,
    increment_decimal_digits,
    resolve_sweep_override,
    select_entries,
)

if TYPE_CHECKING:
    from collections.abc import Callable, Mapping

    # Type-only: annotate the profile-lookup map without a module-level adapter
    # import (cli.py imports the adapter package lazily inside functions).
    from .adapters.profile import CLIProfile

POLICY_FILE = policy_mod.POLICY_FILE

#: The invocable command name — the console script in pyproject, the `prog` in
#: usage output, and what every operator-facing message tells someone to type.
#: Named once so those three can never drift apart, which they did the moment the
#: fork stopped being installable under the upstream name.
PROG = namespace.PRODUCT


class ExitCode(IntEnum):
    """The process exit codes ``main()`` contracts — names for the released numbers.

    ``rc`` is a released contract, so these values do not move; the enum just gives
    the existing numbers a name at their use sites. Being an ``IntEnum`` it returns
    from ``main()`` (``-> int``) and reaches ``sys.exit`` transparently.

    - ``OK`` — a command handler returned success (``args.func`` returns it, not
      ``main`` directly).
    - ``FAILURE`` — a typed error surfaced to the dispatch tail, or the broad
      backstop caught an unexpected exception; both print ``error: …`` to stderr.
    - ``USAGE`` — an argument error: an unknown subcommand or bad flag, which argparse
      raises as ``SystemExit(2)`` before dispatch, or a flag COMBINATION argparse
      cannot express, which a handler returns (``decisions --answer`` alongside
      ``--json`` or ``--list``). The latter is a handler return because ``--json`` is
      registered by ``machine.add_json_flag``, whose parameter is an
      ``ArgumentParser``; putting it in a mutually exclusive group would mean widening
      a pyright-strict module's signature to a private argparse type for a code that
      is already reachable without it.
    - ``INTERRUPTED`` — Ctrl+C (SIGINT) escaped ``main()`` outside ``engine.run()``
      (config load, engine construction, a handler with no run loop). 130 = 128 +
      SIGINT(2), the shell's conventional code for an interrupt; uncaught this path
      already reached 130 (CPython re-raises SIGINT) but as a bare traceback, so
      ``main()`` catches it for a clean one-line exit at the same code. The in-run
      interrupt converts to a clean ``RunStopped`` (``engine.py``) and never reaches
      here — a Ctrl+C during a run stays rc 0.

    Codes ``3``-``129`` and ``131+`` are intentionally absent until a consumer needs one.
    """

    OK = 0
    FAILURE = 1
    USAGE = 2
    INTERRUPTED = 130


def _project(args: argparse.Namespace) -> Path:
    """The project root every handler works from, canonicalized.

    Degrades rather than fails when the OS cannot canonicalize it — see
    :func:`platform_util.resolve_or_lexical` for the decision and its bounds. This
    is called from ``main()`` before dispatch, so a raise here takes out every
    subcommand at the backstop, ``diagnose`` and ``validate`` included (#552)."""
    return resolve_or_lexical(args.project)


def _policy_path(project: Path) -> Path:
    return project / POLICY_FILE


def _configure_mux(project: Path) -> None:
    """Install the policy ``[mux] backend`` choice into the multiplexer seam, and
    point this process at the project's multiplexer registry root.

    The single configuration point, called from ``main()`` before dispatch so
    every mux consumer — including probe/diagnose/attach/stop, which never load
    policy themselves — selects under the persisted choice. Tolerant of a broken
    policy file: diagnostics must keep working on a misconfigured host, and the
    commands that need policy re-load it loudly themselves.

    The registry export belongs *here*, and not at backend construction, for two
    reasons this is the only place that satisfies at once: it is the last point
    that still knows the project (``--project`` has been parsed, no handler has
    run) and it precedes every psmux spawn in the process, the ctl session the
    TUI mints included. Backend construction knows neither — a factory takes no
    arguments, and ``detect_multiplexers`` builds every registered backend for a
    diagnostic table, which must not move a registry as a side effect.
    ``runs.export_psmux_registry_root`` never raises, on the same
    keep-diagnostics-working rule as the policy read above.

    It also *overrides* an ambient ``PSMUX_DATA_DIR`` rather than honouring it —
    the root is derived, always, so that two processes given one project cannot
    disagree about where its sessions live (the full argument is in that
    function). Overriding an operator's variable silently is how someone loses an
    hour to `psmux ls` showing nothing, so it is said once, here, at the only
    point that runs ahead of every command. stderr, not stdout: the ``--json``
    contract is one object on stdout and nothing else, and this is the
    ``unverifiable_pid`` precedent."""
    from .adapters.multiplexer import MultiplexerError, configure_multiplexer, get_multiplexer

    path = _policy_path(project)
    try:
        name = policy_mod.load(path).mux.backend or None
    except (policy_mod.PolicyError, OSError):
        name = None
    configure_multiplexer(name, origin=path)
    # Automatic selection probes availability before returning its cached
    # instance. Give that probe the derived root first: psmux's version probe
    # reaches `_run`, which must reject an empty/relative ambient value, and a
    # failed probe stays cached for this process. The override is temporary in
    # every arm: the ambient value is restored before the real export, which is
    # the last reader of it.
    # The gate asks only the seam's `has_registry_namespace()` question. Ceiling,
    # named: an out-of-tree backend that namespaces through some other variable
    # still sees this export, because the seam has no finer question. Adding one
    # for a backend that does not exist yet is not worth expanding the seam;
    # `waves mux` discloses the root either way.
    ambient = os.environ.get(runs.PSMUX_DATA_DIR)
    try:
        probe_root = str(runs.mux_registry_root(project))
    except (runs.StateRootError, OSError, RuntimeError):
        probe_root = None
    if probe_root is not None:
        os.environ[runs.PSMUX_DATA_DIR] = probe_root
    try:
        namespaced = get_multiplexer().has_registry_namespace()
    except MultiplexerError:
        # A backend that cannot even be selected runs no verb, so there is
        # nothing to point anywhere; diagnostics keep working.
        return
    finally:
        # Undone on EVERY arm, the psmux one included, because the export below
        # is the last reader of the operator's own value. Restore only the
        # namespace-less arms and `export_psmux_registry_root` reads the derived
        # root back as the displaced one, finds it equal to what it is about to
        # write, and skips `note_displaced_registry` — so a machine that had an
        # absolute `PSMUX_DATA_DIR` before the upgrade keeps its pre-upgrade
        # sessions in a registry `legacy_registries` can no longer name, and
        # cleanup reports a clean machine while their coding processes run on.
        if probe_root is not None:
            if ambient is None:
                os.environ.pop(runs.PSMUX_DATA_DIR, None)
            else:
                os.environ[runs.PSMUX_DATA_DIR] = ambient
    if not namespaced:
        return
    root = runs.export_psmux_registry_root(project)
    if root is not None:
        if ambient is not None and ambient != root:
            print(
                f"note: using {namespace.PRODUCT}'s own psmux registry {root} — your "
                f"{runs.PSMUX_DATA_DIR}={ambient} is left for your own sessions "
                f"(`{namespace.PRODUCT} mux` prints the export that reaches these)",
                file=sys.stderr,
            )
        return
    # The degrade arms, and the ones an operator most needs told: no root could
    # be derived, so every psmux verb this command runs — the kill path included
    # — addresses a registry that is not waves's own. With an ambient value
    # that is THEIR registry as found; with none it is psmux's shared default.
    # Cleanup will not claim an untagged session in either
    # (`runs._registry_proves_ownership`), but silence would still read as
    # "waves is using its own registry".
    if ambient is not None:
        print(
            f"warning: no state root could be derived, so {namespace.PRODUCT} has no registry of "
            f"its own here and is using {runs.PSMUX_DATA_DIR}={ambient} as found — set "
            f"{envvars.STATE_DIR} to an absolute path, or unset it, to get one",
            file=sys.stderr,
        )
        return
    # No ambient value either: psmux's shared default is what every verb here
    # will address. Unconditional now — the namespacing gate above already
    # returned on a transport with no registry for the degrade to have cost.
    print(
        f"warning: no state root could be derived, so {namespace.PRODUCT} has no registry of "
        f"its own here and is using the multiplexer's shared default registry — set "
        f"{envvars.STATE_DIR} to an absolute path, or unset it, to get one",
        file=sys.stderr,
    )


def _reject_bad_run_id(run_id: str | None) -> int | None:
    """Guard the hidden ``--run-id`` flag before the id becomes a directory name, a
    multiplexer session name and a git ref component. Rejects rather than sanitizes
    (see ``runs.is_valid_run_id``): a coerced id would no longer name the run the
    caller asked for. Returns 1 to abort, None to proceed."""
    if run_id is not None and not runs.is_valid_run_id(run_id):
        print(
            f"error: invalid --run-id {run_id!r} — expected {runs.RUN_ID_RE.pattern} "
            f"(at most {MAX_SEGMENT} characters, not a reserved device name, and not "
            f"the reserved control-session shape 'ctl'/'ctl-…' in any letter case)",
            file=sys.stderr,
        )
        return 1
    return None


def _reject_isolation_conflict(paths: bmadconfig.ProjectPaths, pol) -> int | None:
    """Refuse `isolation = "worktree"` when the project is not inside `repo_root` — a
    DISJOINT layout (#414, narrowed to that layout by DW-379; a project nested in
    `repo_root` is supported). Returns 1 to abort, None to proceed — the
    `_reject_bad_run_id` shape.

    Called from the four sites that return an rc to a human: `cmd_run`, `cmd_sweep`,
    `_resume_paused_run` — the shared helper behind both `resume` and `resolve`'s
    re-arm — and `cmd_resolve`, which calls it TWICE: once before the interactive
    session and once after the config re-read that authorises the re-arm. A fifth
    site, the auto-triggered child sweep in `_sweep_factory`, shares the refusal but
    not this disposition: it has no rc channel, so it raises (see the comment there).

    Keyed on provisioning-or-arming a run against the config, NOT on Engine
    construction: `cmd_resolve` constructs no Engine and delegates to
    `_resume_paused_run` for that, but `runs.rearm_escalation` mutates persisted run
    state — advancing the attempt baseline and re-stamping the spec — against the
    same `repo_root` this refuses, and it does so BEFORE the delegate is reached. A
    refusal keyed on Engine construction alone therefore arrives after the damage.
    Both keyings exclude the same wider "loads policy.toml" set, which does not all
    provision — `_configure_mux` reads the file on every command and builds nothing;
    `cmd_validate` and `cmd_clean` load it and never mount a worktree.

    `validate` deliberately does not call this — it reports rather than aborts, so
    it renders the same message as a Finding and keeps running its other gates."""
    conflict = bmadconfig.worktree_isolation_conflict(paths, pol.scm.isolation)
    if conflict is None:
        return None
    print(conflict, file=sys.stderr)
    return 1


def _reject_missing_policy(project: Path) -> int | None:
    """Refuse a run that would take every default because this checkout has no
    policy file while the repository's main checkout does (`runsetup.policy_absence`
    says why that is a refusal and not a warning); warn, and go on, when no checkout
    has one. Returns 1 to abort, None to proceed — the `_reject_bad_run_id` shape.
    `validate` reports the same finding instead of calling this."""
    finding = policy_absence(project)
    if finding is None:
        return None
    if finding.severity == "problem":
        print(finding.message, file=sys.stderr)
        return 1
    print(f"warning: {finding.message}", file=sys.stderr)
    return None


def _reject_under_floor_git(project: Path) -> int | None:
    """Refuse to start against a git older than `verify.GIT_FLOOR`. Returns
    `ExitCode.FAILURE` to abort, None to proceed — the `_reject_bad_run_id` shape.

    Called from the four Engine-construction sites, with the same split of
    dispositions as `_reject_isolation_conflict`: an rc to a
    human from `cmd_run`, `cmd_sweep` and `_resume_paused_run`, and a raise from the
    auto-triggered child sweep in `_sweep_factory`, which has no rc channel.

    Takes the PROJECT root, not `paths.repo_root`. `git version` answers for the
    git BINARY and reads no repository, so the directory only has to exist — and
    `repo_root` is an operator-set config key that need not, while `project` is what
    `_project()` already resolved. Probing the configurable one would spend this
    refusal on a mistyped `repo_root`, reporting a broken git to someone whose git
    is fine and burying the isolation refusal that names the real fault. `validate`
    and `diagnose` probe the project root for the same reason.

    FAIL CLOSED on both arms. An unparseable `git version` is refused by
    `verify.git_below_floor`, and a git that could not be run at all — absent,
    unspawnable, timed out — is refused here: a run that cannot ask git its version
    is not a run that should reach `git worktree add`. Neither degrades to "assume
    it's fine", which is the only failure mode that matters for a floor.

    Unlike `_reject_isolation_conflict`, `validate` DOES report this one, as a
    `git.version` problem, so its exit code agrees with this abort."""
    try:
        found = verify.git_below_floor(project)
    except verify.GitError as e:
        print(f"error: git is required but could not be run: {e}", file=sys.stderr)
        return ExitCode.FAILURE
    if found is None:
        return None
    print(f"error: {verify.under_floor_git_message(found)}", file=sys.stderr)
    return ExitCode.FAILURE


def _launch_profiles(pol, project: Path) -> dict[str, CLIProfile]:
    """Resolve a run's profiles ONCE, for the two human-initiated entrypoints that
    stamp an integrity baseline (`cmd_run`, `_resume_paused_run`).

    The stamp and the adapters must describe the SAME bytes. Each used to read
    `profiles/*.toml` on its own — the digest via `config_digest`, the adapters via
    `make_adapters` — so a write landing between them stamped a baseline for config
    the run never launched.

    This is NOT the child gate's check-then-use, and must not be read as one: there
    is no comparison here. At launch the on-disk config IS the trust anchor, so an
    adversary who can write in that gap could equally have written BEFORE it and
    been blessed outright, with no timing at all — the race grants no capability.
    The defect runs the other way, toward over-refusal. This pin is the one
    baseline a session cannot reach (`_sweep_factory` holds every later auto-sweep
    to it from MEMORY, unlike resume's disk-backed advisory), so a pin describing
    bytes the run did not launch makes those children refuse the config the parent
    has been running all along — every trigger, for the life of the run. The
    refusal no longer *burns* each trigger (#501: `sweeps_triggered` records only
    a child that started), but that buys nothing here: a wrong pin refuses the next
    trigger exactly as it refused the last.

    `cmd_sweep` deliberately keeps its fresh read: a human started it, and the pin
    it stamps gates no child.

    Same `ProfileError` -> `SystemExit` contract as `_trusted_config_digest`, for
    the same reason — resolving here happens a few frames EARLIER than
    `make_adapters` used to, and a misconfigured `[adapter] name` must still exit 1
    as `error: unknown CLI profile ...` rather than escape as a traceback."""
    from .adapters.profile import ProfileError

    try:
        return runsetup.resolve_profiles(pol, project)
    except ProfileError as e:
        raise SystemExit(f"error: {e}") from e


def _trusted_config_digest(pol, project: Path, *, profiles=None) -> str:
    """The launch-time integrity baseline the auto-sweep child is held to (#461
    point 4). Thin wrapper over :func:`runsetup.config_digest` for the two
    human-initiated entrypoints that stamp one (`cmd_run`, `_resume_paused_run`)
    plus `_start_sweep`.

    Its only job is the error contract: `config_digest` resolves profiles, so an
    unknown `[adapter] name` now fails a few frames EARLIER than it used to.
    `make_adapters` renders that as `error: unknown CLI profile ...` and exits 1,
    so re-raise it in the same shape rather than letting a `ProfileError`
    traceback escape a misconfigured `run`. The child-sweep gate deliberately does
    NOT go through here — there a raise is the point.

    `profiles` forwards an already-resolved `runsetup.resolve_profiles` mapping,
    so the stamped pin is taken from the same resolution the caller gated on and
    the adapters are built from — never a fresh read."""
    from .adapters.profile import ProfileError

    try:
        return runsetup.config_digest(pol, project, profiles=profiles)
    except ProfileError as e:
        raise SystemExit(f"error: {e}") from e


def _reconcile_stale(project: Path, paths: bmadconfig.ProjectPaths, pol) -> None:
    """Tear down worktrees leaked by a prior run that stopped mid-flight, before
    starting a new run/sweep — the clean-finish GC never reached them. Gated on
    [cleanup] auto_clean_on_finish; only touches terminal (finished/stopped) dead
    runs, never anything resumable."""
    if not pol.cleanup.auto_clean_on_finish:
        return
    freed, fault = runs.reconcile_stale_worktrees(paths.repo_root, project)
    if freed:
        print(f"reclaimed {len(freed)} stale worktree(s) from prior runs")
    if fault is not None:
        # DW-468/DW-470: an unread run, or a worktree list git would not give, was
        # not reconciled; "reclaimed nothing" must not stand for it. Advisory — the
        # new run does not depend on this sweep.
        print(f"warning: stale-worktree reconcile incomplete: {fault}", file=sys.stderr)


# ----------------------------------------------------------------- commands


def cmd_config(args: argparse.Namespace) -> int:
    """The configuration map: every file a run reads, its state, the door that owns it.

    A read-model (`configmap`): it writes nothing. `--json` emits the document under
    the pure-document contract; like `validate`, the exit code is the verdict (`ok`)
    and the document is still owed at rc 1."""
    from .configmap import config_document, render_text

    doc = config_document(_project(args))
    if getattr(args, "json", False):
        machine.emit(doc)
    else:
        print(render_text(doc))
    return 0 if doc["ok"] else 1


def cmd_validate(args: argparse.Namespace) -> int:
    from .install import relay_registered

    project = _project(args)
    report = ValidationReport()

    try:
        paths = bmadconfig.load_paths(project)
        report.ok(
            "bmad-config",
            f"BMAD config OK: artifacts at {paths.implementation_artifacts}",
            {"implementation_artifacts": str(paths.implementation_artifacts)},
        )
    except bmadconfig.BmadConfigError as e:
        report.fail("bmad-config", str(e))
        paths = None
    # The supported-floor gate reads the installer's manifest, not the bmm config,
    # so it reports whether or not the block above resolved.
    report.extend(install.bmad_method_floor_findings(project))

    # Policy first — its [stories].source (or a --spec override) selects which
    # story-queue gate runs below: the sprint-status file (sprint mode) or the
    # stories.yaml manifest (stories mode). Loaded before the queue gate so a
    # stories-only project is not failed on a missing sprint-status.yaml.
    from .adapters import registry as adapter_registry
    from .adapters.profile import ProfileError, external_profile_errors, get_profile

    profiles = []
    profile_by_name: dict[str, CLIProfile] = {}
    pol = None
    try:
        pol = policy_mod.load(_policy_path(project))
        role_names = {role: pol.adapter.resolved(role).name for role in ROLES}
        report.ok(
            "policy",
            f"policy OK: gates={pol.gates.mode}, "
            f"adapter dev={role_names['dev']}, review={role_names['review']}, "
            f"triage={role_names['triage']}, retro={role_names['retro']}",
            {"gates_mode": pol.gates.mode, "adapters": dict(role_names)},
        )
        for name in dict.fromkeys(role_names.values()):
            try:
                profile = get_profile(name, project)
                profiles.append(profile)
                profile_by_name[name] = profile
            except ProfileError as e:
                report.fail("adapter.profile", str(e), {"profile": name})
    except policy_mod.PolicyError as e:
        report.fail("policy", str(e))
    # "policy OK" above is about the values, and a missing file yields valid ones —
    # every default — so the file's absence is its own finding.
    if (absent := policy_absence(project)) is not None:
        report.extend([absent])

    # #414: the one configuration where every gate below reports on a surface the
    # isolated run will never see — worktree isolation beside a `repo_root` the
    # project does not lie inside (a disjoint layout; a nested one is supported since
    # DW-379). Reported only when it fires — there is no `ok` twin, because the
    # supported case is "no such conflict", which would print a line about a coupling
    # most projects have never configured either half of. Needs both halves loaded;
    # either failing already has its own finding above.
    if paths is not None and pol is not None:
        conflict = bmadconfig.worktree_isolation_conflict(paths, pol.scm.isolation)
        if conflict is not None:
            report.fail(
                "policy.isolation-repo-root",
                conflict,
                {"repo_root": str(paths.repo_root), "project": str(paths.project)},
            )
        # DW-485: advisory, one per dir, and silent when nothing is shared — the
        # same no-`ok`-twin reasoning as the gate above.
        for key, shared in bmadconfig.shared_artifact_dirs(paths, pol.scm.isolation):
            report.warn(
                "policy.isolation-shared-artifact-dir",
                f"{key} ({shared}) is inside repo_root ({paths.repo_root}) but outside "
                f'the project ({paths.project}): under isolation = "worktree" it is '
                "shared with the main checkout, not per-worktree — every isolated "
                "session reads and writes the main checkout's copy. Move it inside the "
                "project for a per-worktree copy, or keep it if sharing is intended.",
                {
                    "key": key,
                    "path": str(shared),
                    "repo_root": str(paths.repo_root),
                    "project": str(paths.project),
                },
            )

    # The engine builds its registry from `paths.repo_root` (a `repo_root:` override
    # under isolation = "none" points it at another checkout), so read the manifests
    # that run will load. A failed BMAD config already failed above; fall back to
    # the project dir so the manifest check still reports something.
    _validate_plugin_manifests(paths.repo_root if paths is not None else project, report)

    # A cap nobody can reach: parallel stories need a tree each, so without worktree
    # isolation both loops run a `--plan` wave serially whatever max_parallel says.
    if pol is not None and pol.scm.max_parallel > 1 and pol.scm.isolation != "worktree":
        report.warn(
            "policy.parallel-needs-worktree",
            f"[scm] max_parallel = {pol.scm.max_parallel} has no effect with "
            f'isolation = "{pol.scm.isolation}": stories in flight would share one '
            'checkout, so a --plan run stays serial — set [scm] isolation = "worktree" '
            "to run a wave's fronts in parallel",
            {"max_parallel": pol.scm.max_parallel, "isolation": pol.scm.isolation},
        )

    # Built exactly the way run/sweep's real preflight builds it, so validate's
    # verdict and their abort cannot disagree. Deliberately NOT `[p.skill_tree for p
    # in profiles]`: that carries triage's tree, and every skills check below asks a
    # dev-primitive question. The `pol is not None` guard is load-bearing —
    # `resolved` never raises, so the except above fires only on a policy that failed
    # to load, and an unguarded call would crash validate instead of reporting the
    # parse failure.
    dev_trees = _skill_trees(project, pol) if pol is not None else []

    stories_on, spec_folder = _stories_mode(args, pol)
    if paths:
        if stories_on:
            _validate_stories_queue(project, paths, spec_folder, dev_trees, report)
            _validate_deferred_ledger(paths, report, spec_folder=spec_folder)
        else:
            _validate_deferred_ledger(paths, report)
            _validate_operator_registry(project, paths, report)
            try:
                ss = sprintstatus.load(paths.sprint_status)
                actionable = [s for s in ss.stories if s.status in sprintstatus.ACTIONABLE_STATUSES]
                report.ok(
                    "queue.sprint-status",
                    f"sprint-status OK: {len(ss.stories)} stories, {len(actionable)} actionable",
                    {"stories": len(ss.stories), "actionable": len(actionable)},
                )
                if ss.unknown_keys:
                    report.warn(
                        "queue.sprint-status-unknown-keys",
                        f"unknown keys ignored: {', '.join(ss.unknown_keys)}",
                        {"unknown_keys": list(ss.unknown_keys)},
                    )
            except sprintstatus.SprintStatusError as e:
                report.fail("queue.sprint-status", str(e))

    # `git_answers` carries ONE fact from this probe to the two below it: not
    # whether the tree was clean, but whether the binary answered at all. A
    # non-zero rc IS an answer and leaves it True — the next git command will fail
    # just as promptly, and the version probe is the one that names WHY the host is
    # refused, so an rc-level fault here (dubious ownership, a corrupt index, a
    # directory that is not a repo) must not cost the operator that second finding.
    # Spawn and timeout are the opposite: git is not going to start, or is not
    # going to return, and each further probe re-pays the entire `GIT_TIMEOUT_S` to
    # learn what this one already reported. Three probes against one hung git is
    # three deadlines — on the 120s default, six minutes to print one line.
    #
    # Probes the CODE root, as `cmd_run` and `cmd_sweep` do, so validate's verdict and
    # their abort cannot disagree under a `repo_root:` override whose checkout is dirty
    # outside the project (DW-379) — with the project's own policy.toml excluded at its
    # offset there. A config that failed to load already failed above; the project is
    # probed then, as before.
    #
    # The probed root is named (text and detail) only under a `repo_root` override,
    # so the default config's output stays byte-identical.
    git_answers = True
    clean_root = paths.repo_root if paths is not None else project
    overridden = clean_root != project
    where = f" ({clean_root})" if overridden else ""
    try:
        if not verify.worktree_clean(
            clean_root, project=paths.project if paths is not None else None
        ):
            report.fail(
                "git.worktree-clean",
                f"git worktree is not clean{where} — commit or stash before running",
                {"root": str(clean_root)} if overridden else None,
            )
        else:
            report.ok("git.worktree-clean", f"git worktree clean{where}")
    except verify.GitError as e:
        git_answers = not isinstance(e, (verify.GitSpawnError, verify.GitTimeoutError))
        report.fail("git.probe", f"git check failed: {e}")

    # A `problem`, not a warning, and deliberately so: `_reject_under_floor_git`
    # aborts run/sweep/resume on exactly this condition, and validate's verdict and
    # their abort must not disagree (the reason the adapter/profile block below is
    # built the way run's real preflight builds it). Both render
    # `verify.under_floor_git_message`, so the surfaces cannot drift apart in wording
    # either.
    #
    # Silent on `GitError`: `git.probe` immediately above already owns "git did not
    # answer" — worktree_clean runs first and raises the same taxonomy from the same
    # binary, so a second line would double-report one fault. Same disposition as
    # `git.render-tracked` below. The `git_answers` skip is that same disposition
    # made cheap, not a new one: what it skips is exactly the branch that was
    # already silent, so the report reads identically either way.
    if git_answers:
        try:
            if (found := verify.git_below_floor(project)) is not None:
                report.fail(
                    "git.version", verify.under_floor_git_message(found), {"reported": found}
                )
            else:
                report.ok("git.version", f"git {verify.git_floor_text()}+ satisfied")
        except verify.GitError:
            pass

    # An ignore/exclude cannot shield renderer output that is already in the index.
    # This is advisory: tracked output causes churn but does not prevent a session
    # from running. A failed git probe stays silent rather than fabricating an OK.
    if git_answers:
        try:
            if verify.path_tracked(project, install.RENDER_DIR_REL):
                report.warn(
                    "git.render-tracked",
                    f"{install.RENDER_DIR_REL}/ is tracked by git; run "
                    f"`git rm -r --cached {install.RENDER_DIR_REL}` and commit once to stop "
                    "committing rendered skill output",
                    {"path": install.RENDER_DIR_REL},
                )
        except verify.GitError:
            pass

    # Advisory, and gated on `git_answers` for the same reason as the probe above:
    # `_validate_deferred_ledger` runs before the `git.worktree-clean` probe, so a
    # git-backed check placed there would re-pay a hung git's full deadline.
    if git_answers and paths is not None:
        _validate_deferred_ledger_tracking(paths, report)
        _validate_isolated_ledger_ignored(paths, pol, report)

    report.extend(_platform_preflight(project))

    # #231: notify.desktop defaults to true but only fires when a platform notifier
    # exists (osascript/PowerShell/notify-send). When none does, the setting is
    # silently inert — warn so it stops being a no-op nobody can see.
    if pol is not None and pol.notify.desktop and gates.desktop_notifier_kind() is None:
        # The ATTENTION file is only a fallback when notify.file is also on; with it
        # off there is no alert channel left at all, so say so rather than pointing
        # at a file that is never written.
        channel = (
            "the ATTENTION file in the run directory is the only alert channel left"
            if pol.notify.file
            else "notify.file is also off, so no alert channel is configured — enable notify.file"
        )
        report.warn(
            "notify.desktop-unavailable",
            f"notify.desktop is set but no desktop notifier is available on "
            f"{sys.platform} — desktop notifications are silently skipped; "
            f"{channel} (macOS ships osascript; Linux needs notify-send; Windows "
            f"needs PowerShell). Install one or set notify.desktop = false.",
            {"platform": sys.platform},
        )

    from . import probe as probe_mod

    packaged_binaries = {p.binary for p in profiles if p.packaged}
    for tool in dict.fromkeys(p.binary for p in profiles):
        resolved = shutil.which(tool)
        if resolved:
            report.ok("adapter.binary", f"{tool} found", {"binary": tool})
        else:
            report.fail("adapter.binary", f"{tool} not found on PATH", {"binary": tool})
            continue
        # #294: the gate above answers "a file with that name carries the execute
        # bit", which a dead WSL/npm shim satisfies while every launch of it fails.
        # So validate went green on an install that could not start a session —
        # and opencode_http's own "binary not found" remedy points the user at
        # `waves validate`, which then told them everything was fine. Probe the
        # path `which` RETURNED rather than the bare name: re-resolving is a TOCTOU,
        # and on Windows the PATHEXT shim `which` picked is the very file at issue.
        # Probe ONLY a binary a PACKAGED profile named. `binary` is
        # project-controlled end to end — policy.toml picks the profile and
        # `.waves/loop/profiles/*.toml` supplies its fields, both arriving with a
        # clone — and this line EXECUTES it, inside the one command a user runs to
        # decide whether a checkout is safe to run at all (the TUI runs it too).
        #
        # The boundary is provenance because no test on the SPELLING of `binary`
        # can hold: rejecting a path (`./tool`) still leaves a bare `pwn`, which
        # `which` resolves to a repository file whenever a checkout-local
        # directory is on PATH. "Who wrote this profile" is the question actually
        # being asked, and it has a categorical answer. An overlay or entry-point
        # profile keeps the pre-#294 behavior: resolved, reported found, never
        # launched. #294's own case is a packaged profile (opencode), so the dead
        # WSL/npm shim is still caught.
        #
        # What this bounds is WHICH NAME is probed, never what that name resolves
        # to. Resolution is `shutil.which` against the user's PATH, so a PATH
        # carrying a checkout-local directory can still answer `claude` with a
        # file the clone ships. That residual is deliberate and is NOT a hole this
        # gate is failing to close: the name is ours rather than the project's, and
        # the same resolution is what the session launch itself performs — the
        # generic adapter puts this bare `binary` at argv[0] (adapters/generic.py)
        # and the opencode adapter calls the identical `shutil.which` before
        # spawning (adapters/opencode_http.py). A PATH that redefines `claude`
        # has already redefined it for the run, and for the user's own shell.
        # Refusing checkout-local RESOLUTIONS would be a different guard, over a
        # predicate (realpath containment) that leaks through symlinks, `..`,
        # win32 case-folding, UNC paths, and worktree-root vs project-root.
        if tool not in packaged_binaries:
            continue
        rc = probe_mod.binary_runs(resolved)
        if rc == 0:
            continue
        # Any nonzero code, never an allowlist: #294's own transcript reports rc 2
        # and a reproduction of the same shim exits 127, the code being a property
        # of the shell and the failure mode. {126, 127} would miss the case fixed.
        #
        # `warning`, deliberately, and not to be promoted without evidence: severity
        # `problem` is validate's exit code (checks.py), and rc is a compatibility
        # contract (AGENTS.md). Nothing rules out one of claude/codex/gemini/copilot/
        # antigravity answering `--version` nonzero on a perfectly live install, and
        # that user must not start failing validate.
        outcome = "could not be launched" if rc is None else f"exited {rc}"
        report.warn(
            "adapter.binary-unrunnable",
            f"{tool} is on PATH at {resolved} but `{tool} --version` {outcome} — "
            "the usual cause is a stale or broken install (a dead WSL/npm shim), "
            "and runs using it would then fail to start; a CLI that does not "
            "implement `--version` also lands here. Reinstall it or fix PATH, or "
            "ignore this if that CLI has no `--version`.",
            {"binary": tool, "path": resolved, "returncode": rc},
        )

    registered_relays: set[tuple[Path, str]] = set()
    relay_interpreters: set[str] = set()
    for profile in profiles:
        # Keyed on the adapter KIND, not on `hookless`. httpx is the bundled
        # opencode family's optional extra — a fact about one adapter class, which
        # is a different question from "does this profile register hooks". Those
        # were the same question only while `hookless` selected the adapter; the
        # registry decoupled them, so a hookless profile driven by some other
        # registered kind needs nothing from `waves[opencode]` and must not be
        # FAILed with a remedy that installs the wrong package. Naming one bundled
        # kind here is not the hardcoded-valid-set the registry exists to remove:
        # the set of VALID kinds is only ever `known_adapter_kinds()` (below).
        if profile.adapter == adapter_registry.OPENCODE_HTTP:
            # Surface a missing install here instead of at run start.
            if importlib.util.find_spec("httpx") is not None:
                report.ok(
                    "adapter.httpx",
                    f"httpx available for {profile.name}",
                    {"profile": profile.name},
                )
            else:
                report.fail(
                    "adapter.httpx",
                    f"{profile.name}: httpx not installed — "
                    f"run `pip install '{namespace.DISTRIBUTION}[opencode]'`",
                    {"profile": profile.name},
                )
            # The serve argv is `[binary, *launch_args, "serve", <owned flags>]`
            # (`_serve_argv`). A shape it cannot serve would otherwise surface
            # only at run start, as SPAWN_ATTEMPTS failed health polls. A pure
            # shape check — never a probe: `binary` is project-controlled (#294).
            # `warning`: validate's exit code is a compatibility contract.
            # Imported here, not at the top of cmd_validate, so a project with no
            # opencode-kind profile never imports the opencode module (the import
            # itself is httpx-free: `_require_httpx` is lazy).
            from .adapters.opencode_http import launch_args_unservable

            unservable = launch_args_unservable(profile.binary, profile.launch_args)
            if unservable is not None:
                report.warn(
                    "adapter.launch-args-unservable",
                    f"{profile.name} (opencode-http): {unservable}",
                    {
                        "profile": profile.name,
                        "binary": profile.binary,
                        "launch_args": list(profile.launch_args),
                    },
                )
        if profile.hookless:
            report.ok(
                "adapter.hookless",
                f"{profile.name}: hookless (HTTP/SSE transport) — no hook registration needed",
                {"profile": profile.name},
            )
            continue
        hook_config = project / profile.hooks.config_path
        hooks_ok = False
        parsed: dict = {}
        if hook_config.is_file():
            try:
                parsed = json.loads(hook_config.read_text(encoding="utf-8"))
                hooks_ok = isinstance(parsed, dict) and relay_registered(
                    parsed, profile.hooks.dialect, profile.hooks.events
                )
                if isinstance(parsed, dict):
                    container = install.hook_event_container(parsed, profile.hooks.dialect)
                    malformed = [
                        event
                        for event in profile.hooks.events
                        if event in container and not isinstance(container[event], list)
                    ]
                    if malformed:
                        hooks_ok = False
                        report.fail(
                            "hooks.config-parse",
                            f"{hook_config} has malformed handlers for {', '.join(malformed)}",
                            {"profile": profile.name, "config_path": str(hook_config)},
                        )
            except json.JSONDecodeError:
                report.fail(
                    "hooks.config-parse",
                    f"{hook_config} is not valid JSON",
                    {"profile": profile.name, "config_path": str(hook_config)},
                )
        if isinstance(parsed, dict):
            registered_relays.update(
                install.registered_relay_paths(
                    parsed, profile.hooks.dialect, profile.hooks.events, project
                )
            )
            relay_interpreters.update(
                install.registered_relay_interpreters(
                    parsed, profile.hooks.dialect, profile.hooks.events
                )
            )
        if hooks_ok:
            report.ok(
                "hooks.registered",
                f"{namespace.PRODUCT} hooks registered for {profile.name}",
                {"profile": profile.name, "config_path": str(hook_config)},
            )
        else:
            report.fail(
                "hooks.registered",
                f"{namespace.PRODUCT} hooks not registered for {profile.name} — "
                f"run `{namespace.PRODUCT} init --cli {profile.name}`",
                {"profile": profile.name, "config_path": str(hook_config)},
            )

        if profile.hooks.dialect == "codex-hooks-json":
            from .codex_trust import (
                hook_discovery_args_safe,
                hook_trust_bypass_supported,
                project_hook_trust,
            )

            unsafe_roles = []
            if pol is not None:
                for role in ROLES:
                    cfg = pol.adapter.resolved(role)
                    if cfg.name == profile.name and not hook_discovery_args_safe(cfg.extra_args):
                        unsafe_roles.append(role)

            if not profile.packaged:
                trust_message = (
                    "hook trust unverifiable: project-owned Codex profile may name an "
                    "untrusted executable; validation will not launch it"
                )
            elif (
                pol is not None
                and pol.scm.isolation == "worktree"
                and not hook_trust_bypass_supported(profile)
            ):
                trust_message = (
                    "hook trust unverifiable for future worktree sessions: each isolated "
                    "directory needs its own Codex trust grant (a run escalates an "
                    "untrusted worktree before launching Codex there)"
                )
            elif not hooks_ok:
                trust_message = "hook trust cannot pass: Codex relay hooks are not registered"
            elif unsafe_roles:
                trust_message = (
                    "hook trust unverifiable: adapter.extra_args may change Codex hook "
                    f"discovery for {', '.join(unsafe_roles)}"
                )
            else:
                trust = project_hook_trust(project, profile)
                trust_message = None if trust.status == "trusted" else trust.reason
                if trust_message and pol is not None and pol.scm.isolation == "worktree":
                    # This fork: every unit worktree inherits THIS grant, so each would
                    # escalate until the main checkout is trusted.
                    trust_message += (
                        " — unit worktrees inherit this grant, so each would escalate "
                        "until it is trusted here"
                    )
            if trust_message is None:
                # Under worktree isolation (this fork), every unit worktree inherits
                # this grant when its hook config is the same — the gate checks that
                # per session and launches with the profile's hook-trust bypass.
                inherits = (
                    f"; unit worktrees inherit it (same hook config, launched with "
                    f"{profile.hook_trust_bypass_args[0]})"
                    if pol is not None and pol.scm.isolation == "worktree"
                    else ""
                )
                report.ok(
                    "hooks.trust",
                    f"Codex hook trust current for {profile.name} in {project}{inherits}",
                    {"profile": profile.name, "project": str(project), "binary": profile.binary},
                )
            else:
                report.fail(
                    "hooks.trust",
                    f"{profile.name}: {trust_message}",
                    {"profile": profile.name, "project": str(project), "binary": profile.binary},
                )

    # Inspect the executable each managed registration actually names. A new
    # installation in this process cannot repair an older path in a hook config.
    # Compare with the command init would write now: an old executable can remain
    # usable after switching installations, while still running an outdated relay.
    # The comparison is on the registered TEXT, the same test init's merge_hooks
    # applies: on Windows both `Path` equality and `str(Path)` normalize
    # separators, so a pre-#773 backslash registration (which Git Bash mangles,
    # stalling every session) would otherwise never be flagged.
    expected_text = None
    if registered_relays:
        hook_profile = next(profile for profile in profiles if not profile.hookless)
        try:
            expected_text = install.relay_executable_text(
                install._hook_command(project, hook_profile, "Stop")
            )
        except ProfileError:
            # No current executable to compare. The registered path still gets
            # its own presence check below; do not call it stale by inference.
            pass
    try:
        quoting_host = get_process_host()
    except ProcessHostError:
        quoting_host = None  # the platform preflight's host.process check reports it
    for relay, spelling in sorted(registered_relays):
        # DW-346: advisory, independent of presence — a metacharacter the host's
        # hook quoting leaves exposed can split or expand the command in the hook
        # shell whether or not the file exists. Warn only; `ok` is unaffected. A
        # legacy copied script is skipped: its registration names it through
        # `$CLAUDE_PROJECT_DIR`, so the substituted project path is never exposed.
        unsafe_chars = (
            quoting_host.unsafe_shell_chars(spelling)
            if quoting_host and relay.name != namespace.HOOK_RELAY
            else ()
        )
        if unsafe_chars:
            report.warn(
                "hooks.relay-path-unsafe",
                f"registered hook executable {spelling} contains shell "
                f"metacharacter(s) {' '.join(unsafe_chars)} this host's hook quoting "
                f"leaves unsafe — hook runs may fail; reinstall {namespace.PRODUCT} under a path "
                f"without them and re-run `{namespace.PRODUCT} init`",
                {"path": spelling, "chars": list(unsafe_chars)},
            )
        if not relay.is_file():
            report.fail(
                "hooks.relay-present",
                f"registered hook executable {relay} is missing — re-run `{namespace.PRODUCT} init`",
                {"path": str(relay)},
            )
        elif not os.access(
            relay, os.R_OK if relay.name == namespace.HOOK_RELAY else os.R_OK | os.X_OK
        ):
            report.fail(
                "hooks.relay-present",
                f"registered hook executable {relay} is not usable — repair its permissions or re-run `{namespace.PRODUCT} init`",
                {"path": str(relay)},
            )
        else:
            report.ok(
                "hooks.relay-present",
                f"registered hook executable available: {relay}",
                {"path": str(relay)},
            )
            if expected_text is not None and spelling != expected_text:
                report.warn(
                    "hooks.relay-stale",
                    f"registered hook executable {spelling} differs from this "
                    f"installation's {expected_text} — re-run `{namespace.PRODUCT} init` "
                    "to update the hook registration",
                    {"path": spelling, "expected_path": expected_text},
                )
    # A legacy copied-script relay runs through a PATH interpreter; one that
    # cannot be found fails every hook run as surely as a missing script. Only
    # the command's first token is looked up: after `uv run --no-project`, the
    # `python` word is resolved by uv itself, not by the hook runner's PATH.
    for interpreter in sorted(relay_interpreters):
        if shutil.which(interpreter) is None:
            report.fail(
                "hooks.relay-present",
                f"registered hook interpreter {interpreter} cannot be found — "
                f"re-run `{namespace.PRODUCT} init` to register the installed relay",
                {"path": interpreter, "interpreter": interpreter},
            )

    # Adapter-kind validity is enforced against the LIVE registry, never a
    # hardcoded set: a profile.adapter naming no registered kind is a config error
    # (a typo, or an uninstalled plugin package). External adapter/profile packages
    # that failed to load are surfaced as warnings — selection already degraded
    # past them (the same non-blocking treatment as a failed mux backend package).
    kinds = adapter_registry.known_adapter_kinds()
    for profile in profiles:
        if profile.adapter in kinds:
            report.ok(
                "adapter.kind",
                f"{profile.name}: adapter kind {profile.adapter!r} registered",
                {"profile": profile.name, "adapter": profile.adapter},
            )
        else:
            report.fail(
                "adapter.kind",
                f"{profile.name}: unknown adapter kind {profile.adapter!r} — "
                f"known: {', '.join(kinds)} (install the plugin that provides it, "
                f"or fix the profile's `adapter`)",
                {"profile": profile.name, "adapter": profile.adapter, "known": kinds},
            )
    for ep_name, reason in sorted(adapter_registry.external_adapter_errors().items()):
        report.warn(
            "adapter.external",
            f"external adapter '{ep_name}' failed to load: {reason}",
            {"entry_point": ep_name, "error": reason},
        )
    for ep_name, reason in sorted(external_profile_errors().items()):
        report.warn(
            "adapter.external-profile",
            f"external profile '{ep_name}' failed to load: {reason}",
            {"entry_point": ep_name, "error": reason},
        )

    # opencode config-file model ids are "provider/model" (see the opencode_http docstring);
    # a bare model name silently falls back to the server's default model, so warn
    # (advisory — a note, not a FAIL: an empty model legitimately means "default").
    #
    # Keyed on the adapter KIND, for the same reason `adapter.httpx` above is: the
    # "provider/model" spelling is a fact about the opencode server's config file,
    # not about whether a profile registers hooks. Those were one question only
    # while `hookless` selected the builder; the registry decoupled them, and
    # keying on `hookless` is now wrong in BOTH directions — it warns an
    # out-of-tree hookless family whose server takes bare model names, naming a
    # convention that family does not use, and it stays silent for an
    # `opencode-http` profile carrying a hook dialect, which is exactly where the
    # bare name really does fall back to the server default.
    if pol is not None:
        for role in ROLES:
            cfg = pol.adapter.resolved(role)
            prof = profile_by_name.get(cfg.name)
            if (
                prof is not None
                and prof.adapter == adapter_registry.OPENCODE_HTTP
                and cfg.model
                and "/" not in cfg.model
            ):
                report.warn(
                    "policy.model-qualified",
                    f"{role} model {cfg.model!r} is not 'provider/model' — "
                    f"{prof.name} expects e.g. 'anthropic/claude-haiku-4-5'",
                    {"role": role, "model": cfg.model, "profile": prof.name},
                )
            # DW-483: `_serve_argv` appends extra_args AFTER the adapter-owned
            # `--port`/`--hostname`/`--print-logs`, so a repeat overrides them and
            # the health poll dials a port the server is not on. Per role, because
            # extra_args resolve per stage; the launch_args twin above is per
            # profile. Advisory, like `adapter.launch-args-unservable`: validate's
            # exit code is a compatibility contract. Lazy import: a project with no
            # opencode-kind profile never imports the opencode module.
            if (
                prof is not None
                and prof.adapter == adapter_registry.OPENCODE_HTTP
                and cfg.extra_args
            ):
                from .adapters.opencode_http import extra_args_unservable

                if (unservable := extra_args_unservable(cfg.extra_args)) is not None:
                    report.warn(
                        "policy.extra-args-unservable",
                        f"{role} adapter.extra_args for {prof.name} (opencode-http): {unservable}",
                        {"role": role, "profile": prof.name, "extra_args": list(cfg.extra_args)},
                    )
            # Reasoning effort (#643) has two carriers in this fork: a tmux profile's
            # `effort_args` render it into the CLI's argv, and the opencode-http
            # kind sends it as the per-prompt `variant`. A GENERIC profile without
            # `effort_args` has no channel for it, so a stage that sets it there
            # runs at the provider default with nothing to show for it. Keyed on
            # the bundled GENERIC kind, like the two checks above, because "cannot
            # carry effort" is a fact about that family; an out-of-tree kind's
            # capability is not knowable here, so it stays silent rather than
            # assert one. Advisory: severity `problem` is validate's exit code, and
            # an ignored knob does not make a run unrunnable.
            if (
                prof is not None
                and prof.adapter == adapter_registry.GENERIC
                and cfg.effort
                and not prof.effort_args
            ):
                report.warn(
                    "policy.effort-unsupported",
                    f"{role} effort {cfg.effort!r} is ignored by {prof.name}: its profile "
                    f"declares no effort_args, and only those (or the opencode-http "
                    f"adapter's variant) carry a reasoning-effort value",
                    {"role": role, "effort": cfg.effort, "profile": prof.name},
                )
            # DW-349: an explicit extra_args REPLACES the profile's bypass_args, so
            # an override that forgets them launches a session that stalls on a
            # permission prompt. GENERIC-only for the reason above: it is the one
            # bundled kind whose argv consumes bypass_args. Advisory, like the
            # effort check — the run is still runnable, just likely to stall.
            if prof is not None and (missing := _bypass_drops(cfg, prof)):
                report.warn(
                    "policy.bypass-dropped",
                    _bypass_dropped_message(role, prof, missing),
                    {"role": role, "profile": prof.name, "missing": list(missing)},
                )

    base_findings = install.missing_base_skills(project, dev_trees)
    # gated on PROBLEMS, not on any finding: an advisory review layer (a `when`
    # gate, a phrasing this check can't confirm, a broken override) is a warning
    # that must ride alongside the ok line rather than suppress it.
    #
    # Gate on `dev_trees`, not `profiles`: policy never validates an adapter name
    # (the first test is `get_profile`), so `[adapter] name = "nosuchcli"` beside a
    # loadable `[adapter.triage]` leaves `profiles` non-empty while nothing dev-side
    # resolved — and the ok line would then be a green sentence assembled from an
    # empty probe. Can only tighten: `dev_trees` truthy implies `profiles` truthy.
    if dev_trees and not any(f.severity == "problem" for f in base_findings):
        # Name the primitive that actually resolved, not a hardcoded era: on an
        # upgraded project this is the operator's confirmation that the rename was
        # picked up (and, across trees, that both picked up the same one).
        resolved = list(
            dict.fromkeys(
                name
                for tree in dict.fromkeys(dev_trees)
                if (name := install.resolve_dev_primitive(project, tree)) is not None
            )
        )
        report.ok(
            "skills.base",
            f"upstream skills present ({' + '.join(resolved)} + review layers)",
            {"trees": list(dict.fromkeys(dev_trees)), "dev_primitive": resolved},
        )
    report.extend(base_findings)
    report.extend(install.dev_primitive_warnings(project, dev_trees))
    # The bundled skills age exactly like the hook relay above, and until now
    # nothing said so. Not gated on `dev_trees`: the check asks about every tree
    # `init` writes into, and the skill it most needs to reach — the operator's
    # `waves` monitor — is dispatched by no run at all, so a dev-scoped
    # probe would skip precisely the copy the incident found out of date.
    report.extend(install.module_skill_freshness(project))
    report.extend(install.override_location_findings(project))

    # The TEA configuration surface, for a project with the plugin on — which is
    # the default now, so this runs almost everywhere. A project without TEA
    # installed gets one warning naming the inert plugin and the two ways out
    # (install TEA, or opt out in [plugins]); a project that opted out is told
    # nothing, for the same reason the game-engine checks are gated: a project
    # that runs no TEA has nothing to be told about it.
    #
    # The plugin re-reads this at startup and before each step; surfacing it here
    # is what lets an operator see a stale or hand-taken-over customization BEFORE
    # a run reaches the step that depends on it.
    # An enabled plugin name nothing answers to is the allowlist's quiet failure:
    # the entry enables nothing, every consumer reads an empty list, and the TEA
    # block below is skipped as if the project had opted out. Measured 2026-09-07:
    # a policy still naming the 1.x plugin ran for days without ATDD or boundary
    # steps while this command said "policy OK". Manifests only — no in-process
    # plugin is constructed here; the run builds its own registry.
    if pol is not None:
        import warnings

        from .plugins import PluginError
        from .plugins.loader import load_plugins
        from .plugins.registry import unknown_enabled

        try:
            with warnings.catch_warnings():
                # A manifest skipped for its api_version warns; `plugins.manifests`
                # captures and reports that, and a second, uncaptured warning here
                # would reach stderr past the `--json` contract.
                warnings.simplefilter("ignore")
                unknown = unknown_enabled(load_plugins(project), pol)
        except PluginError:
            # The same parse `plugins.manifests` reports (upstream 0.13): one
            # broken manifest is one problem, not two.
            unknown = []
        for name, reason in unknown:
            report.warn(
                "plugins.unknown",
                f"[plugins] enabled: {name!r} {reason}. Until the entry names a plugin that "
                "exists it enables nothing — no step, hook or gate of it runs.",
                {"plugin": name},
            )

    if pol is not None and namespace.PLUGIN_TEA in pol.plugins.enabled:
        from . import teaconfig

        report.extend(teaconfig.check(project))
    # Opt-in only: the probe executes project-controlled content (the stub's argv and
    # render_skill.py), and plain validate must stay non-executing for a fresh clone.
    # Gated on `dev_trees` too, as `skills.base` is: an unloadable policy leaves it
    # empty, and "nothing to render" would be a green line from an empty probe.
    if dev_trees and getattr(args, "render_probe", False):
        report.extend(install.dev_renderer_probe(project, dev_trees))

    # The triage tree's `waves-core-sweep`, probed exactly as `_require_sweep_skill`
    # probes it so validate and the sweep refusal agree. Only when a triage tree
    # resolved: an unloadable triage profile is already reported above, and an ok
    # line over an empty probe would be a green sentence about nothing.
    triage_trees = _triage_trees(project, pol) if pol is not None else []
    if triage_trees:
        sweep_findings = install.missing_sweep_skill(project, triage_trees)
        if not sweep_findings:
            report.ok(
                "skills.sweep",
                f"{install.SWEEP_SKILL} present ({', '.join(triage_trees)})",
                {"trees": triage_trees, "skill": install.SWEEP_SKILL},
            )
        report.extend(sweep_findings)

    if getattr(args, "json", False):
        # getattr, not args.json: cmd_validate is called directly by tests (and by
        # anything holding a hand-built Namespace) that predate the flag.
        machine.emit(validate_document(report, stories_on, spec_folder))
    else:
        report.render()
    return 0 if report.passed else 1


def cmd_tea_config(args: argparse.Namespace) -> int:
    """Resolve the TEA integration's configuration surface, and optionally write
    the customization files this tool manages inside ``_bmad/custom/``.

    The read form is the mirror of the BMAD Method's own
    ``_bmad/scripts/resolve_customization.py``: one resolver, a JSON document on
    stdout, read by the plugin, by this tool's skills on activation, and by the
    TUI — so no consumer re-derives the artifacts directory for itself.

    ``--write`` is what ``init`` calls. It is idempotent and never overwrites a
    customization file the project took ownership of (one lacking the managed
    header), because a team that edited a skill's overrides made a decision this
    tool must not silently reverse.

    Like ``validate``, a nonzero exit is a *verdict* and the document is still
    owed — parse stdout whatever the code, and read ``ok``.
    """
    from . import teaconfig

    project = _project(args)
    findings = teaconfig.write_customizations(project) if args.write else []
    if getattr(args, "json", False):
        document = teaconfig_document(project)
        if findings:
            document["written"] = [
                {"check": f.check, "severity": f.severity, "message": f.message} for f in findings
            ]
        machine.emit(document)
        return 0 if document["ok"] else 1
    report = ValidationReport()
    report.extend(findings)
    report.extend(teaconfig.check(project))
    report.render()
    return 0 if report.passed else 1


def cmd_mux(args: argparse.Namespace) -> int:
    """List registered terminal-multiplexer backends and the selection, or
    persist a machine-scoped choice (`mux set <name>` / `mux set --clear`) into
    .waves/loop/policy.toml. Never prompts — runs are unattended."""
    from .adapters.multiplexer import (
        MultiplexerError,
        detect_multiplexers,
        external_backend_errors,
        get_multiplexer,
    )

    project = _project(args)
    if args.action == "set":
        return _mux_set(project, args)
    if args.clear or args.force:
        print(f"error: --clear/--force apply to `{namespace.PRODUCT} mux set`", file=sys.stderr)
        return 1

    rows = detect_multiplexers()
    header = ("NAME", "PLATFORM", "AVAILABLE", "VERSION", "SELECTED")
    table = [
        (
            r.name,
            "yes" if r.matches_platform else "no",
            "yes" if r.available else "no",
            # detect_multiplexers folds multi-line versions (fold_version), so
            # an out-of-tree backend can't split the row and strand SELECTED.
            r.version or "-",
            f"* {_mux_reason_label(r.reason)}" if r.selected else "",
        )
        for r in rows
    ]
    widths = [max(len(h), *(len(row[i]) for row in table), 0) for i, h in enumerate(header)]
    for row in (header, *table):
        print("  ".join(cell.ljust(w) for cell, w in zip(row, widths)).rstrip())
    # AVAILABLE answers "could this backend run here", not "could it be picked",
    # and the two diverge whenever a foreign-platform binary shares a name with
    # a local one — on Windows `tmux` is psmux's compatibility shim, so the tmux
    # row reads as a real tmux install. Explaining the row beats gating the
    # column: a forced choice genuinely does reach these backends.
    # A forced backend is exempt: it IS selected, and telling an operator the
    # row they just pinned cannot be selected reads as a contradiction of the
    # `*` marker one line above.
    stranded = [r.name for r in rows if r.available and not r.matches_platform and not r.selected]
    if stranded:
        print(
            "note: AVAILABLE means the binary answers here, not that the backend supports "
            f"{sys.platform} — {', '.join(stranded)} can only be reached by forcing the choice"
        )
    # A VERSION of `-` is the same cell whether the binary reports no version or
    # crashed answering (#428). The row can't carry the difference — a table cell
    # holds no stderr — so the dropped diagnostic is named here, beside the other
    # reason a backend looks absent for no visible cause.
    for r in rows:
        if r.version_error:
            # Whitespace-collapsed: the text carries the probe's own stderr, which
            # is routinely multi-line, and a warning that spans lines reads as
            # several unrelated ones. Not length-bounded like a table cell (#321)
            # — nothing here sizes a column, and the diagnostic IS the payload.
            detail = " ".join(r.version_error.split())
            print(f"warning: {r.name} version probe failed: {detail}", file=sys.stderr)
        # Same blindness one column over (DW-464): a PLATFORM or AVAILABLE of
        # `no` that a raising probe forced, not the host's answer.
        if r.probe_error:
            detail = " ".join(r.probe_error.split())
            print(f"warning: {r.name} backend probe failed: {detail}", file=sys.stderr)
    # A failed external package is invisible in the table (it never registered),
    # so name it here — the one place an operator looks when a backend is missing.
    for ep_name, reason in sorted(external_backend_errors().items()):
        print(f"warning: external backend '{ep_name}' failed to load: {reason}", file=sys.stderr)
    print(
        f"override: {envvars.MUX_BACKEND} env var, or `{namespace.PRODUCT} mux set <name>` "
        f"(persists to {POLICY_FILE})"
    )
    try:
        backend = get_multiplexer()
    except MultiplexerError as e:
        # A forced unknown name (env or policy): the listing above still helps.
        print(f"FAIL: {e}", file=sys.stderr)
        return 1
    chosen = next((r for r in rows if r.selected), None)
    reason = _mux_reason_label(chosen.reason) if chosen else "fallback"
    # no selected row means _select bottomed out at its documented historical
    # fallback, which is tmux by contract — not a stale hardcoding
    name = chosen.name if chosen else "tmux"
    print(f"selection: {name} ({type(backend).__name__}) — {reason}")
    _print_registry(project)
    return 0


def _print_registry(project: Path) -> None:
    """Name the multiplexer registry this project's sessions live in, and how to
    reach them from a bare psmux.

    Without this the repo lies by omission: waves points psmux at a
    per-project root (``runs.mux_registry_root``), so an operator's own
    ``psmux ls`` — which reads psmux's default registry — shows none of this
    project's sessions and answers "no sessions" rather than erroring. Printing
    the root and a paste-ready export turns that into a fact they can act on.
    Silent on a backend with no registry namespace (tmux), which has nothing to
    disclose, and on one that cannot be selected at all — the caller has already
    reported that.

    Line per fact rather than a table row: this is a path, which is exactly the
    cell an aligned table mangles (#321), and there is only one of them."""
    from .adapters.multiplexer import MultiplexerError, get_multiplexer

    try:
        mux = get_multiplexer()
        root = mux.registry_root()
        if root is None:
            # For a namespacing backend, no root in force means the shared
            # default registry — the one situation `registry:` must not stay
            # silent about, since silence reads as "per-project as usual".
            if mux.has_registry_namespace():
                print(
                    "registry: the multiplexer's shared default (no state root "
                    f"could be derived — set {envvars.STATE_DIR} to an absolute "
                    "path, or unset it, to get a per-project one)"
                )
            return
    except MultiplexerError:
        return
    try:
        derived = str(runs.mux_registry_root(project))
    except (runs.StateRootError, OSError, RuntimeError):
        derived = None
    # waves always derives, so a mismatch is not an operator's honoured
    # export — that is not a thing any more — but the one case the export
    # degrades on: an underivable state root, where it leaves whatever it found
    # rather than inventing a root. Saying "derived" there would be a lie about
    # the one situation an operator most needs told.
    origin = (
        "derived from the project"
        if root == derived
        else f"NOT {namespace.PRODUCT}'s — ${runs.PSMUX_DATA_DIR} as found, "
        "because no state root could be derived here"
    )
    print(f"registry: {root} ({origin})")
    # A single-quoted PowerShell literal, whose only escape is doubling the quote:
    # an unescaped `C:\Users\O'Brien\...` ends the string mid-path and the line
    # will not parse. Anything printed as paste-ready has to actually paste. Same
    # rule as `psmux_backend._pwsh_quote`, spelled out rather than imported — a
    # backend's argv quoting is not this module's to reach into, and the
    # dependency only runs the other way.
    quoted = root.replace("'", "''")
    print(
        f"  a bare `psmux ls` reads psmux's default registry, not this one — "
        f"export {runs.PSMUX_DATA_DIR} to see these sessions: "
        f"$env:{runs.PSMUX_DATA_DIR} = '{quoted}'"
    )


def _mux_set(project: Path, args: argparse.Namespace) -> int:
    from .adapters.multiplexer import detect_multiplexers

    path = _policy_path(project)
    if args.clear:
        if args.name:
            print("error: `mux set --clear` takes no backend name", file=sys.stderr)
            return 1
        policy_mod.write_mux_backend(path, None, confine_root=project)
        print(f"mux backend cleared (auto-select) in {path}")
        return 0
    if not args.name:
        print(
            f"error: `mux set` requires a backend name (run `{namespace.PRODUCT} mux` to list), "
            "or `mux set --clear` to return to auto-select",
            file=sys.stderr,
        )
        return 1
    rows = {r.name: r for r in detect_multiplexers()}
    row = rows.get(args.name)
    if row is None and not args.force:
        known = ", ".join(sorted(rows)) or "(none registered)"
        print(
            f"error: {args.name!r} is not a registered backend; known: {known}. "
            "A plugin backend that only registers on the target machine can be "
            "persisted with --force.",
            file=sys.stderr,
        )
        return 1
    if row is not None and not row.available:
        # Deliberate choice = trusted (same doctrine as the env override), but
        # say so: a pinned backend bypasses the availability gate at launch
        # (with a warning there too — see multiplexer.mux_usable), so a
        # version-gated binary would otherwise run into its gated defect.
        print(
            f"warning: backend {args.name!r} is not available on this host (transport "
            "binary missing, version unsupported, or a required helper like `pwsh` "
            "absent); persisted anyway — launches will proceed with a warning, and "
            f"`{namespace.PRODUCT} validate` will report it",
            file=sys.stderr,
        )
    if envvars.mux_backend():
        print(
            f"note: {envvars.MUX_BACKEND} is set in this shell and outranks the persisted choice",
            file=sys.stderr,
        )
    # a junk name raises PolicyError → main()
    policy_mod.write_mux_backend(path, args.name, confine_root=project)
    print(f'mux backend set to "{args.name}" in {path}')
    return 0


def _skill_trees(project: Path, pol) -> list[str]:
    """The skill trees this run's dev-primitive adapters read, one per distinct name.

    Shared by the real preflight and `cmd_validate` so the two cannot drift:
    validate's verdict has to key on exactly what makes run abort. Profiles that
    fail to load are skipped rather than raising — an unknown adapter name is the
    policy loader's problem, not the skill probe's.

    Scoped to :data:`install.DEV_PRIMITIVE_ROLES`, not :data:`ROLES`: every skill
    these trees are asked about is one only a dev or review session dispatches, and
    triage's whole prompt surface ships in this wheel. It is also the set
    `WorktreeFlow.worktree_profiles` provisions, so what is gated and what is carried
    into a worktree stay one decision.

    Deliberately does NOT consult `review.enabled`. Disabling review does not retire
    the review ADAPTER: a plugin workflow may declare `role = "review"` and dispatch
    on `adapters["review"]` with review disabled, and `worktree_profiles` drives
    per-CLI Stop-signal hook registration as well as seeding — a worktree
    provisioned without the review profile has no completion signal for those
    sessions and stalls rather than merely missing a skill. See #424 for the narrow
    residue that IS real."""
    from .adapters.profile import ProfileError, get_profile

    trees = []
    for name in dict.fromkeys(
        pol.adapter.resolved(role).name for role in install.DEV_PRIMITIVE_ROLES
    ):
        try:
            trees.append(get_profile(name, project).skill_tree)
        except ProfileError:
            continue
    return trees


def _dev_skill_for_role(pol, project: Path, role: str) -> str:
    """The dev-primitive skill name ``role``'s adapter would invoke, for dry-run
    previews. Mirrors `_require_base_skills`' profile→skill_tree lookup so the
    preview and the real dispatch (``Engine._dev_skill``) resolve identically —
    a pre-rename project previews ``/bmad-dev-auto``, a post-rename one
    ``/bmad-build-auto``. An unloadable profile falls back to the legacy name;
    the run itself would fail preflight before ever dispatching."""
    from .adapters.profile import ProfileError, get_profile

    try:
        tree = get_profile(pol.adapter.resolved(role).name, project).skill_tree
    except ProfileError:
        tree = None
    return install.dev_primitive_or_default(project, tree)


def _unknown_adapter_kinds(project: Path, pol) -> list[str]:
    """Problem lines for each role-selected profile whose ``adapter`` names no
    registered kind — resolved against the live registry, never a hardcoded set.

    Such a profile renders a perfectly plausible dry-run preview (``_render_invocation``
    reads only ``binary``/``launch_args``/``prompt_template``) but aborts the real
    run in ``make_adapters``, which is precisely the gap the banner exists to close.
    Only the roles a run would actually build are checked; `validate` reports the
    same condition over *every* profile as an ``adapter.kind`` finding.

    A profile that will not even parse is skipped rather than reported here: the
    renderer immediately after raises the ``ProfileError`` itself, which names the
    real problem better than a derived one would."""
    from .adapters.profile import ProfileError, get_profile
    from .adapters.registry import known_adapter_kinds

    kinds = known_adapter_kinds()
    problems: list[str] = []
    for name in dict.fromkeys(pol.adapter.resolved(role).name for role in ROLES):
        try:
            profile = get_profile(name, project)
        except ProfileError:
            continue
        if profile.adapter not in kinds:
            problems.append(
                f"profile {profile.name!r} names unknown adapter kind "
                f"{profile.adapter!r} — known: {', '.join(kinds)} "
                f"(install the plugin that provides it, or fix the profile's `adapter`)"
            )
    return problems


def _bypass_drops(cfg, profile: CLIProfile) -> tuple[str, ...]:
    """The bypass tokens ``cfg.extra_args`` drops from ``profile``'s argv (DW-349).

    The one home of the predicate `validate` and every dry-run share: scoped to
    the bundled GENERIC kind — the only one whose argv consumes ``bypass_args``
    (an out-of-tree kind's consumption is unknowable, so it stays silent) — and
    delegating the replace rule to ``CLIProfile.missing_bypass_tokens``."""
    from .adapters import registry as adapter_registry

    if profile.adapter != adapter_registry.GENERIC:
        return ()
    return profile.missing_bypass_tokens(cfg.extra_args)


def _bypass_dropped_message(role: str, profile: CLIProfile, missing: tuple[str, ...]) -> str:
    """One wording for the DW-349 warning, shared by `validate` and every dry-run.

    Names the dropped tokens AND the full bypass sequence to include: on a
    partial drop (e.g. ``--permission-mode acceptEdits``) adding only the missing
    token would leave a still-broken argv."""
    return (
        f"{role} adapter.extra_args replaces {profile.name}'s bypass_args and drops "
        f"{' '.join(missing)} — unattended sessions may stall on permission prompts; "
        f"include `{' '.join(profile.bypass_args)}` in extra_args to keep the bypass"
    )


def _sprint_launch_roles(pol) -> tuple[str, ...]:
    """The roles a SPRINT-mode story run launches: dev + review, plus the auto
    retrospective's ``retro`` session when ``gates.retrospective = "auto"``
    (DW-389). Stories mode never crosses an epic boundary, so it stays dev + review."""
    return ("dev", "review", "retro") if pol.gates.retrospective == "auto" else ("dev", "review")


def _warn_bypass_dropped(
    pol,
    project: Path,
    roles: tuple[str, ...],
    *,
    profiles: Mapping[str, CLIProfile] | None = None,
    journal: Journal | None = None,
) -> None:
    """Stderr twin of validate's ``policy.bypass-dropped`` finding (DW-349, DW-410),
    for every dry-run AND every real launch (run, sweep — auto-sweep children
    included — and resume).

    Prints one ``warning:`` line to stderr for each of ``roles`` (the roles the
    calling run type launches) whose resolved ``extra_args`` drops profile bypass
    tokens — before the schedule is printed on a dry-run, before ``engine.run()``
    on a launch. ``profiles`` (role → profile, as ``_launch_profiles`` /
    ``runsetup.resolve_profiles`` return) is the launch's frozen resolution; when
    given it is used instead of re-reading ``get_profile``, so the warning speaks
    about the bytes the run actually launches. Without it, a profile that will not
    parse is skipped silently: the renderer/composer raises the ``ProfileError``
    itself. ``journal`` (a launch only) also records one ``bypass-dropped`` event
    per hit. stderr only, rc unchanged — stdout stays the preview/render."""
    from .adapters.profile import ProfileError, get_profile

    for role in roles:
        cfg = pol.adapter.resolved(role)
        profile = profiles.get(role) if profiles is not None else None
        if profile is None:
            try:
                profile = get_profile(cfg.name, project)
            except ProfileError:
                continue
        if missing := _bypass_drops(cfg, profile):
            print(
                f"warning: {_bypass_dropped_message(role, profile, missing)}",
                file=sys.stderr,
            )
            if journal is not None:
                journal.append(
                    "bypass-dropped", role=role, profile=profile.name, missing=list(missing)
                )


def _warn_preflight_would_abort(
    paths: bmadconfig.ProjectPaths,
    pol,
    *,
    require_stories: bool = False,
    require_sweep: bool = False,
) -> None:
    """Dry-run honesty banner: say so when the real command would refuse to run.

    ``--dry-run`` returns before `_require_base_skills` (cmd_run/cmd_sweep), so a
    project whose skills are broken still gets a plausible-looking preview. Since
    the upstream rename that preview is actively misleading rather than merely
    incomplete: the forwarding shim IS a valid slash command, so a previewed
    ``/bmad-dev-auto`` reads fine and would HALT an unattended session on the
    shim's interactive migration gate.

    Mirrors the refusals the dry-run's early return skips past, and only those:
    the under-floor git `_reject_under_floor_git` refuses first, the finding list
    `_require_base_skills` gates on, the #414 isolation conflict
    `_reject_isolation_conflict` refuses ahead of it, and the unregistered adapter
    kind `make_adapters` aborts on (`_unknown_adapter_kinds` — a preview reads none
    of the fields that would give the misconfiguration away).

    The git floor belongs here for the reason the dirty-tree and queue gates do
    NOT: it is a fact about the HOST, so it cannot come true between this preview
    and the real command the way cleaning a tree can. Both of its arms are
    mirrored — too old, and could not be run at all — because `cmd_run` aborts on
    each, and a banner silent on the second would promise a run guaranteed to
    exit 1. Reading the same
    sources as the gates themselves is what keeps the preview from disagreeing with
    the real command about what "runnable" means. Severity-filtered to `problem`
    for that same reason — `_require_base_skills` ignores warnings, so reporting one
    as a `FAIL:` line would promise an abort that never comes. The dirty-tree, queue
    and run-id gates are deliberately not part of this banner.

    Takes the whole :class:`~bmadconfig.ProjectPaths` rather than `project` alone
    because the #414 refusal is a fact about the two roots' relationship; every
    other probe here still reads `paths.project`, which is what `init` wrote and
    what a session's own root resolution will re-derive.

    The exit code deliberately stays 0. A dry-run is a diagnostic — refusing to
    print the schedule would withhold the very thing the operator asked for, and
    every existing caller reads rc 0 as "the preview rendered", not as "the
    project is ready". The banner goes to stderr so stdout stays the preview.

    ``require_sweep`` (the sweep dry-run) also mirrors `_require_sweep_skill`:
    the triage tree's ``waves-core-sweep`` is a sweep-only gate, so a story-run
    preview must not promise an abort over it."""
    trees = _skill_trees(paths.project, pol)
    problems = [
        p.message
        for p in install.missing_base_skills(paths.project, trees)
        + (install.missing_stories_support(paths.project, trees) if require_stories else [])
        + (
            install.missing_sweep_skill(paths.project, _triage_trees(paths.project, pol))
            if require_sweep
            else []
        )
        if p.severity == "problem"
    ]
    conflict = bmadconfig.worktree_isolation_conflict(paths, pol.scm.isolation)
    if conflict is not None:
        problems.insert(0, conflict)
    try:
        if (found := verify.git_below_floor(paths.project)) is not None:
            problems.insert(0, verify.under_floor_git_message(found))
    except verify.GitError as e:
        problems.insert(0, f"git is required but could not be run: {e}")
    problems += _unknown_adapter_kinds(paths.project, pol)
    if not problems:
        return
    print(
        "note: this preview is NOT runnable as-is — the real command aborts at preflight:",
        file=sys.stderr,
    )
    for problem in problems:
        print(f"  FAIL: {problem}", file=sys.stderr)
    print(f"run `{namespace.PRODUCT} validate` for details", file=sys.stderr)


def cmd_adapters(args: argparse.Namespace) -> int:
    """List the registered coding-CLI adapter kinds (the CLI axis's counterpart to
    `waves mux` for the transport axis) and name any out-of-tree adapter or
    profile package that failed to load. Unlike `mux`, there is no global choice
    to persist: an adapter kind is selected per profile by its `adapter` field."""
    from .adapters.profile import ProfileError, external_profile_errors, load_profiles
    from .adapters.registry import detect_adapters, external_adapter_errors

    # Loading profiles also triggers the riaworks_waves_loop.profiles entry-point scan, so a
    # broken profile package surfaces below alongside a broken adapter package.
    # A malformed project overlay is the operator's own file and aborts — this is a
    # listing command, and printing a table assembled from a profile set that
    # silently lost an entry is worse than saying which file is wrong.
    try:
        profiles = load_profiles(_project(args))
    except ProfileError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    by_kind: dict[str, list[str]] = {}
    for prof in profiles.values():
        by_kind.setdefault(prof.adapter, []).append(prof.name)

    rows = detect_adapters()
    header = ("NAME", "ORIGIN", "NEEDS MUX", "PROFILES")
    table = [
        (
            r.name,
            "builtin" if r.builtin else "external",
            "yes" if r.needs_mux else "no",
            ", ".join(sorted(by_kind.get(r.name, []))) or "-",
        )
        for r in rows
    ]
    widths = [max(len(h), *(len(row[i]) for row in table), 0) for i, h in enumerate(header)]
    for row in (header, *table):
        print("  ".join(cell.ljust(w) for cell, w in zip(row, widths)).rstrip())
    # A profile whose adapter kind never registered (a typo, or an uninstalled
    # plugin) is invisible in the table above — name it so an operator can see the
    # dangling reference, exactly as `mux` names a failed backend package.
    known = {r.name for r in rows}
    for kind in sorted(set(by_kind) - known):
        print(
            f"warning: profile(s) {', '.join(sorted(by_kind[kind]))} reference unknown "
            f"adapter kind '{kind}' (no registered kind or plugin provides it)",
            file=sys.stderr,
        )
    for ep_name, reason in sorted(external_adapter_errors().items()):
        print(f"warning: external adapter '{ep_name}' failed to load: {reason}", file=sys.stderr)
    for ep_name, reason in sorted(external_profile_errors().items()):
        print(f"warning: external profile '{ep_name}' failed to load: {reason}", file=sys.stderr)
    print(
        "adapter kind is selected per profile by its `adapter` field "
        "(default: generic); an out-of-tree package registers new kinds via the "
        "riaworks_waves_loop.adapters + riaworks_waves_loop.profiles entry points"
    )
    return 0


def _require_base_skills(project: Path, pol, *, require_stories: bool = False) -> bool:
    """Preflight the upstream skills the orchestrator drives (the dev primitive —
    bmad-build-auto, or a complete pre-rename bmad-dev-auto — plus the review layers
    it invokes inline).

    Returns True when everything is in place; otherwise prints the problems and
    returns False so the caller can abort before spawning any session (a missing
    skill would otherwise stall as an `Unknown command` until the run times out).
    Warnings are printed but never abort — only ``problem`` findings block.
    A post-rename install left with only the forwarding shim fails here too: the
    shim's interactive migration gate would HALT the session with nothing written.

    ``require_stories`` additionally content-probes the resolved primitive for
    folder+id dispatch — stories mode needs a newer skill than sprint mode, so an
    older install must fail loudly here rather than HALT `no stories.yaml`-style at
    dispatch time."""
    skill_trees = _skill_trees(project, pol)
    # The BMAD-METHOD floor first: a tree below it is refused before its skill
    # shapes are read, from the same finding `validate` fails on.
    findings = install.bmad_method_floor_findings(project)
    findings += install.missing_base_skills(project, skill_trees)
    if require_stories:
        findings += install.missing_stories_support(project, skill_trees)
    # Severity decides. A review layer we can't statically resolve (a `when` gate,
    # an unrecognized handoff phrasing, an unparseable override) is reported and
    # then stepped over: aborting on it would be the false FAIL of #260, only now
    # on every run rather than only on validate.
    problems = [f for f in findings if f.severity == "problem"]
    for warning in (f for f in findings if f.severity != "problem"):
        print(f"warning: {warning.message}", file=sys.stderr)
    if problems:
        for problem in problems:
            print(f"FAIL: {problem.message}", file=sys.stderr)
        print(f"run `{namespace.PRODUCT} validate` for details", file=sys.stderr)
        return False
    return True


def _triage_trees(project: Path, pol) -> list[str]:
    """The skill tree the triage adapter reads — where a sweep dispatches
    ``/waves-core-sweep``. A list (empty or one entry) so it composes with the
    ``Sequence[str]`` probes; an unloadable profile is skipped exactly as
    :func:`_skill_trees` skips one, since an unknown adapter name is the policy
    loader's problem, not the skill probe's.

    Separate from :func:`_skill_trees` on purpose, not a widening of it: that
    helper's role set is the one `WorktreeFlow.worktree_profiles` provisions and
    every question it answers is a dev-primitive one (see its docstring)."""
    from .adapters.profile import ProfileError, get_profile

    try:
        return [get_profile(pol.adapter.resolved("triage").name, project).skill_tree]
    except ProfileError:
        return []


def _require_sweep_skill(project: Path, pol) -> bool:
    """Preflight the triage tree for the complete bundled ``waves-core-sweep`` skill.

    Returns True when it is in place; otherwise prints each problem as a ``FAIL:``
    line plus the validate hint to stderr and returns False, so every entrypoint
    that is about to dispatch ``/waves-core-sweep`` can refuse before any side
    effect instead of stalling each triage session at ``Unknown command``."""
    problems = install.missing_sweep_skill(project, _triage_trees(project, pol))
    if not problems:
        return True
    for problem in problems:
        print(f"FAIL: {problem.message}", file=sys.stderr)
    print(f"run `{namespace.PRODUCT} validate` for details", file=sys.stderr)
    return False


def _stories_mode(args: argparse.Namespace, pol) -> tuple[bool, str]:
    """Resolve whether this run is stories mode and its spec folder.

    ``run --spec <folder>`` forces stories mode (overrides policy); otherwise the
    run follows ``[stories].source``. Returns ``(is_stories, spec_folder)`` — the
    folder is "" in sprint mode. ``pol`` may be None (e.g. a policy that failed to
    load in ``validate``): then only an explicit ``--spec`` can force stories mode."""
    spec = getattr(args, "spec", None)
    if spec:
        return True, spec
    if pol is not None and pol.stories.source == "stories":
        return True, pol.stories.spec_folder
    return False, ""


def _validate_stories_folder(
    paths: bmadconfig.ProjectPaths, spec_folder: str, *, selector: str | None = None
) -> str | None:
    """Preflight the stories-mode inputs: stories.yaml parses + rules pass, SPEC.md
    (the epic spec every first dispatch loads) exists, and — when a ``--story``
    ``selector`` is given — the id is actually in the manifest. Returns a problem
    string to print, or None when OK. Catching an unknown ``--story`` here fails the
    run before it starts, instead of crashing it mid-flight in the scheduler."""
    folder = stories_mod.resolve_spec_folder(paths.project, spec_folder)
    try:
        story_set = stories_mod.load_stories(folder)
    except stories_mod.StoriesError as e:
        return f"stories mode: {e} (spec folder: {folder})"
    if not story_set.entries:
        return f"stories mode: stories.yaml has no entries: {folder}"
    if not (folder / "SPEC.md").is_file():
        return (
            f"stories mode: {folder}/SPEC.md not found — a first dispatch loads the "
            f"epic spec (the skill would HALT `no epic spec found`)"
        )
    if selector is not None and story_set.get(selector) is None:
        return (
            f"stories mode: --story id {selector!r} is not in stories.yaml — "
            f"pick one of: {', '.join(e.id for e in story_set.entries)}"
        )
    return None


def _validate_stories_queue(
    project: Path,
    paths: bmadconfig.ProjectPaths,
    spec_folder: str,
    skill_trees: list[str],
    report: ValidationReport,
) -> None:
    """Stories-mode counterpart of ``cmd_validate``'s sprint-status gate: validate
    the ``stories.yaml`` manifest + ``SPEC.md`` and confirm the installed
    dev primitive carries the folder+id dispatch flow stories mode needs (an older
    skill would HALT at dispatch). Appends findings to ``report`` in place; the
    probe carries its own remediation text ("update the bmm module")."""
    folder = stories_mod.resolve_spec_folder(paths.project, spec_folder)
    problem = _validate_stories_folder(paths, spec_folder)
    if problem:
        report.fail("queue.stories-manifest", problem, {"spec_folder": str(folder)})
    else:
        try:
            count = len(stories_mod.load_stories(folder).entries)
            report.ok(
                "queue.stories-manifest",
                f"stories mode OK: {count} stories in {folder}/stories.yaml, SPEC.md present",
                {"spec_folder": str(folder), "stories": count},
            )
        except stories_mod.StoriesError as e:  # already validated above — defensive
            report.fail(
                "queue.stories-manifest",
                f"stories mode: {e} (spec folder: {folder})",
                {"spec_folder": str(folder)},
            )
    stories_probs = install.missing_stories_support(project, skill_trees)
    if skill_trees and not stories_probs:
        # The total form, not `resolve_dev_primitive`: this ok line only renders when
        # the probe passed, and the probe ran against exactly this name — so an
        # unresolvable tree that somehow satisfied it is still reported as what was
        # actually read.
        probed = list(
            dict.fromkeys(
                install.dev_primitive_or_default(project, tree)
                for tree in dict.fromkeys(skill_trees)
            )
        )
        report.ok(
            "skills.stories-dispatch",
            f"{' + '.join(probed)} supports folder+id dispatch (stories mode)",
            {"trees": list(dict.fromkeys(skill_trees)), "dev_primitive": probed},
        )
    report.extend(stories_probs)


def _spec_closes_deferred(path: Path) -> tuple[tuple[str, ...], str | None]:
    """One story spec's ``closes_deferred:`` declaration, degrading an unreadable
    spec to an empty one — other gates own spec readability, and an advisory
    check must never be the thing that crashes the preflight it is advising."""
    try:
        raw = frontmatter.read_frontmatter(path).get("closes_deferred")
    except (OSError, UnicodeDecodeError):
        return (), None
    return deferredwork.parse_declaration(raw)


def _validate_plugin_manifests(root: Path, report: ValidationReport) -> None:
    """Parse every discovered plugin manifest the way a run will (#765).

    `root` is the code root the engine hands `PluginRegistry.build` —
    `paths.repo_root`, not necessarily the project dir.

    Without this the first reader of a malformed project `plugin.toml` was
    `PluginRegistry.build` inside `Engine.__init__` — after the run's directory,
    state and journal were already published. `load_plugins` is manifest-only
    discovery: it never imports a `[python]` module, which matters here because
    validate is the command a user runs to decide whether a checkout is safe to
    run at all. `PluginRegistry.build` would exec every allowlisted module.

    A PluginError is the whole message: every manifest fault names its source
    (the manifest path, for a project plugin). `load_plugins` stops at the first
    bad manifest, so one fault is reported per pass. A third-party manifest on an
    unsupported api_version is skipped with `warnings.warn`, which a run keeps;
    here it is captured and reported as a warning finding instead, so it neither
    leaks to stderr nor breaks the `--json` stream contract.
    """
    import warnings

    from .plugins import PluginError, load_plugins

    with warnings.catch_warnings(record=True) as skipped:
        warnings.simplefilter("always")  # the once-per-location default would drop a repeat
        try:
            manifests = load_plugins(root)
        except PluginError as e:
            manifests = None
            report.fail("plugins.manifests", str(e))
    for w in skipped:
        report.warn("plugins.manifests", f"{w.message} — skipped; a run will not load it")
    if manifests is not None:
        names = sorted(manifests)
        report.ok(
            "plugins.manifests",
            f"plugin manifests OK: {len(names)} loaded ({', '.join(names) or 'none'})",
            {"plugins": names},
        )


def _validate_operator_registry(
    project: Path, paths: bmadconfig.ProjectPaths, report: ValidationReport
) -> None:
    """Report drift between the park records and the committed state they point
    at (#335, #356).

    A record is committed beside the truth it points at, but it can still
    disagree with it — a story re-driven to done, a reverted commit, a
    hand-edited spec, a record file mangled in a merge. That is only a safe
    trade if something says so out loud.

    Never a failure, always a warning, in every direction. `confirm` already
    refuses to act on a drifted entry, so nothing here gates anything; a stale
    record must not be able to block a run that would otherwise start. The
    directions carry different ids because their remedies differ: an entry the
    committed state has moved past is stale bookkeeping to discard
    (`registry-stale`), while a board sitting at `awaiting-operator` that no
    record claims (`park-record-missing`) is an obligation whose spec nothing
    can find. Before #356 that second arm was the fresh-clone NORM and shared
    `registry-stale`; now the record travels with the park's own commit, so a
    missing one is always evidence of something — a record write that failed at
    park time, a park from a version that recorded only machine-locally, a
    checkout without the park's branch, or a record deleted without confirming.

    An INTERRUPTED confirmation gets its own id rather than being reported as
    stale, because its remedy inverts: re-running `confirm` finishes it. Saying
    "the entry is stale and confirm will refuse it" about a story confirm now
    completes would be the same class of lie the state itself is."""
    parked = operatoractions.resolve(project, paths)
    for story in parked:
        if story.spec_status == operatoractions.AWAITING_OPERATOR and not story.actions:
            report.warn(
                "operator.actions-malformed",
                f"{story.story_key} is parked at awaiting-operator but its "
                f"operator_actions: declares nothing readable — `{namespace.PRODUCT} confirm "
                f"{story.story_key}` has no actions to acknowledge; repair the list in "
                f"{story.spec_path}",
                {"story_key": story.story_key, "spec": str(story.spec_path)},
            )
            # NO `continue`: the malformed list is about the INDEX side, and a
            # co-occurring disagreement on the committed side is a separate
            # finding with a separate remedy (repair the list vs discard the
            # entry). `committed_drift()` is the half that answers about spec and
            # board only, so the empty list is not re-reported as the drift —
            # `drift()` would collapse both into whichever it found first. The
            # sibling `_validate_closes_deferred` has the same shape and reports
            # every cause it finds, for the same reason.
            drift = story.committed_drift()
        elif story.resumable:
            # Not `registry-stale`: to `drift()` this looks stale ("its spec now
            # says status: done"), but the remedy INVERTS — re-run confirm to
            # finish it, rather than discard the entry — and `checks` splits ids
            # exactly where the remedy differs.
            report.warn(
                "operator.confirm-interrupted",
                f"{story.story_key} was confirmed but the board was never advanced: its "
                f"spec is signed off and reads done while the park entry still lists it. "
                f"`{namespace.PRODUCT} confirm {story.story_key}` finishes it without asking you to "
                f"acknowledge anything again",
                {"story_key": story.story_key, "board_status": story.board_status},
            )
            continue
        else:
            drift = story.drift()
        if drift is not None:
            report.warn(
                "operator.registry-stale",
                f"the park entry lists {story.story_key} as parked, but "
                f"{drift} — the entry is stale and `{namespace.PRODUCT} confirm "
                f"{story.story_key}` will refuse it",
                {"story_key": story.story_key, "drift": drift},
            )
    try:
        ss = sprintstatus.load(paths.sprint_status)
    except (sprintstatus.SprintStatusError, OSError, UnicodeDecodeError):
        return  # the queue gate below owns board readability — don't double-report
    indexed = {story.story_key for story in parked}
    orphans = sorted(
        s.key
        for s in ss.stories
        if s.status == operatoractions.AWAITING_OPERATOR and s.key not in indexed
    )
    if orphans:
        report.warn(
            "operator.park-record-missing",
            f"the board parks {', '.join(orphans)} at awaiting-operator, but no park "
            f"record under {operatoractions.RECORDS_REL.as_posix()}/ claims them, so "
            f"`{namespace.PRODUCT} confirm` cannot find their specs from this checkout. The record "
            f"travels with the park's own commit — a missing one means the record write "
            f"failed at park time (journaled as operator-index-failed), the park predates "
            f"committed records (confirm it on the machine that ran it), this checkout "
            f"lacks the branch carrying the park commit (pull it), or the record was "
            f"deleted without confirming; otherwise finish the story by hand",
            {"story_keys": orphans},
        )


def _validate_deferred_ledger(
    paths: bmadconfig.ProjectPaths,
    report: ValidationReport,
    *,
    spec_folder: str | None = None,
) -> None:
    """Read the deferred-work ledger once, then run every check that needs it.

    The read sits here rather than inside each check because an unreadable ledger
    is one fault, not one per reader: two checks opening the same file would
    report the same outage twice under two ids.

    A ledger that cannot be read at all is reported. Staying quiet there is not
    the same trade as staying quiet about an unparseable manifest: the manifest is
    already reported by ``queue.stories-manifest``, while nothing else in
    ``validate`` reads the ledger, so silence meant reporting success for
    preflights that checked nothing.

    The gate runs first for one reason only: an operator who has both a blocked
    story and a stale traceability field should meet the refusal before the
    advisory. Presentation, nothing more — ``_validate_closes_deferred``'s early
    return leaves *that function*, so it could never have skipped a sibling call
    here, and swapping the two lines changes no severity and no exit code.
    """
    ledger = paths.deferred_work
    # OBSERVATION arm of the ledger-read contract (DW-146), kept inline rather than
    # routed through `read_for_observation`: `validate` writes nothing, but it has
    # to REPORT the fault as a graded problem rather than degrade quietly to an
    # empty ledger — see the reasoning below. Same classification, richer response.
    # The presence probe is `stat` + `S_ISREG` INSIDE the `try` (DW-267): the
    # `is_file()` it replaced suppresses every OS error on Python 3.14 and answers
    # False, so a refused ledger read as an empty one and `validate` reported a
    # clean deferred check with the finding below unreachable. Only absence
    # (`ENOENT`/`ENOTDIR`, a present non-regular file) is the empty text; a
    # refused probe takes the same arm a refused `read_text` does. `ValueError`,
    # not `UnicodeDecodeError` (its subclass): `Path.stat` raises a plain
    # `ValueError` for an embedded NUL in the configured path and a
    # `UnicodeEncodeError` for a lone surrogate, neither an `OSError`, which
    # `is_file()` had answered False for — an observation arm attributes those
    # as a fault, never as absence, so they are the same graded problem.
    try:
        try:
            text = ledger.read_text(encoding="utf-8") if S_ISREG(ledger.stat().st_mode) else ""
        except (FileNotFoundError, NotADirectoryError):
            text = ""
    except (OSError, ValueError) as e:
        # Split from the manifest read in the checks below, which is silent for a
        # good reason that does not apply here: nothing else in `validate` reads
        # the ledger, so returning quietly reported success for preflights that
        # checked nothing, against the very file the run's closure will fail on
        # (#284 round-5 review, finding 6).
        #
        # A problem rather than a warning, escalated from the severity this id
        # carried while the read served only `closes_deferred`. The hard gate now
        # rides on the same bytes, and a warning exits 0 having evaluated no gate
        # at all — a fail-open on the one deferred check that is a refusal, and one
        # that cannot be narrowed by asking whether the project uses gates, because
        # the file that would answer is the unreadable one. `Engine._loop` refuses
        # the same way for the same reason, so preflight and dispatch agree about
        # this file instead of `validate` reporting a run that then pauses at its
        # first story. Nothing is lost by failing early: the message's last clause
        # is literal — the run's own closure reads this file too.
        report.fail(
            "deferred.ledger-unreadable",
            f"{ledger} cannot be read ({e}) — neither closes_deferred declarations nor "
            "`gate:` hard gates were checked against it, so an open entry could be "
            "gating an actionable story unseen; the run's own closure will fail the same way",
            {"ledger": str(ledger), "error": str(e)},
        )
        return
    _validate_hard_gates(paths, text, report, spec_folder=spec_folder)
    _validate_closes_deferred(paths, text, report, spec_folder=spec_folder)


def _validate_deferred_ledger_tracking(
    paths: bmadconfig.ProjectPaths, report: ValidationReport
) -> None:
    """WARN when the ledger exists but git neither tracks nor ignores it (DW-361).

    Tracked and gitignored are both decisions a project made; the third setting is
    one nobody made, and it does not stay put. `git add` takes an untracked,
    non-ignored path, so since #460 the first isolated merge that carries a ledger
    write (`_carry_story_deferred_closes`, the harvest carry) commits the whole file,
    and a non-isolated story commit's `git add -A` sweeps it up the same way. Not
    wrong, exactly — but a file entering git should not be the first anyone hears
    of the setting.

    Under git's defaults the same file also fails ``git.worktree-clean``, and
    ``run``/``sweep`` refuse a dirty tree — so there this line adds the WHICH and the
    WHY that "commit or stash" does not (and a plain `git stash` leaves an untracked
    file where it is). Where untracked files are hidden from `git status`
    (`status.showUntrackedFiles=no`) the tree reads clean, the run starts, and this is
    the only line that speaks before the commit lands.

    A warning, never a problem: nothing is lost either way.
    Silent on an absent ledger (nothing to commit yet, and every fresh project would
    otherwise print it), on one outside ``paths.repo_root`` (``commit_paths`` skips
    such a path too), and on a git fault — ``git.probe`` owns that report, and an
    advisory must not fabricate an answer git did not give. An unreadable ledger is
    already ``deferred.ledger-unreadable``; the presence probe here stays silent on
    it rather than reporting the one fault twice.
    """
    ledger = paths.deferred_work
    repo = paths.repo_root
    try:
        if not S_ISREG(ledger.stat().st_mode):
            return
        rel = ledger.resolve().relative_to(repo.resolve()).as_posix()
    except (OSError, RuntimeError, ValueError):
        return
    try:
        if verify.path_tracked(repo, rel) or verify.path_ignored(repo, ledger):
            return
    except verify.GitError:
        return
    report.warn(
        "deferred.ledger-untracked",
        f"{ledger} is neither committed nor gitignored, so nothing has decided whether it "
        f"belongs in git — left that way, {namespace.PRODUCT}'s own commits decide (the first isolated "
        "merge that carries a ledger write, or a non-isolated story commit's `git add -A`, "
        "takes it in); commit it or add it to .gitignore to decide on purpose",
        {"ledger": str(ledger), "path": rel},
    )


def _validate_isolated_ledger_ignored(
    paths: bmadconfig.ProjectPaths, pol: policy_mod.Policy | None, report: ValidationReport
) -> None:
    """WARN when worktree isolation meets a gitignored ledger (DW-375).

    Under ``scm.isolation = "worktree"`` a gitignored ledger reaches each unit only
    as a seeded copy, shielded from the unit commit, and the post-merge carry brings
    back only the writes the engine recorded (harvested deferrals, story and bundle
    closes). Anything a session appends to that copy itself is lost at teardown;
    the run journals ``isolated-ledger-writes-uncarried`` when it happens, and this
    says so before the first run.

    The ledger need not exist yet: the hazard applies to the file the first harvest
    creates. A warning, never a problem. Silent under ``isolation = "none"``, on a
    ledger outside ``paths.repo_root`` (the worktree then shares the main file), on a
    path that exists but is not a regular file, and on a git fault (``git.probe``
    owns that report).
    """
    if pol is None or pol.scm.isolation != "worktree":
        return
    ledger = paths.deferred_work
    repo = paths.repo_root
    try:
        try:
            st = ledger.stat()
        except (FileNotFoundError, NotADirectoryError):
            st = None
        if st is not None and not S_ISREG(st.st_mode):
            return
        rel = (ledger.parent.resolve() / ledger.name).relative_to(repo.resolve()).as_posix()
    except (OSError, RuntimeError, ValueError):
        return
    try:
        if verify.path_tracked(repo, rel) or not verify.path_ignored(repo, ledger):
            return
    except verify.GitError:
        return
    report.warn(
        "deferred.ledger-ignored-isolated",
        f'{ledger} is gitignored and scm.isolation is "worktree", so each unit works on a '
        "seeded copy and only the engine's own recorded ledger writes are carried back — "
        "entries a session writes to that copy itself are lost at teardown (journaled as "
        "isolated-ledger-writes-uncarried); track the ledger in git to keep them",
        {"ledger": str(ledger), "path": rel},
    )


def _validate_hard_gates(
    paths: bmadconfig.ProjectPaths,
    text: str,
    report: ValidationReport,
    *,
    spec_folder: str | None = None,
) -> None:
    """FAIL when the queue would dispatch a story an unlanded ledger entry gates.

    The preflight half of a two-sided refusal: ``Engine._refuse_gated_story``
    enforces the same gate at dispatch, so a ``run`` that skipped ``validate``
    pauses instead of proceeding. This side exists to move the answer earlier —
    the operator learns before the run starts, and learns about *every* gated
    story on the queue rather than just the first one picked.

    The two must keep agreeing about what "unlanded" means (only an explicit
    ``done`` retires a gate) and about an unreadable ledger (both refuse); a
    ``validate`` that passed a run which then paused at its first story would
    teach operators to trust neither.

    A ledger entry could always *say* it blocked a story — ``HARD GATE: must land
    before 3-2`` in its reason — and saying it stopped nothing. ``run`` took the
    story off the board and drove it, and the gate was discovered afterwards, in
    the diff of work built on a leg nobody had wired. A ``gate:`` line makes the
    claim matchable and this check makes it a refusal.

    The only deferred check that is a gate rather than an advisory, and the
    severity is the whole point: the ``closes-*`` siblings describe traceability
    that is wrong, which must never block a run, while this one describes work
    that must not start, which is exactly what a non-zero exit is for.

    Silent on a ledger nobody has gated, so the zero-config output is unchanged.
    Once a gate exists the passing case reports itself — a gate that only ever
    speaks when it fires is indistinguishable, on the day it matters, from one
    nobody remembered to write.
    """
    declared = [(entry, deferredwork.gates(entry)) for entry in deferredwork.parse_ledger(text)]
    for entry, entry_gates in declared:
        if entry.done:
            continue  # a landed entry gates nothing; that is what closing it means
        _report_unstructured_gate(entry, entry_gates, report)
    # Keyed on enforceable tokens, not on `gate:` lines: a ledger whose only gate is
    # malformed enforced nothing, and an `ok` there would be the same false all-clear
    # the warning above exists to break. Closed entries still count, deliberately —
    # the passing case has to keep speaking after the gate lands, or `ok` and "nobody
    # ever wrote a gate" become the same silence. Reading the queue sits behind this
    # test so a project that gates nothing pays neither the walk nor its failure modes.
    if not any(entry_gates.tokens for _, entry_gates in declared):
        return
    story_keys = _actionable_story_keys(paths, spec_folder)
    if story_keys is None:
        # The queue could not be read, so nothing was compared. `queue.sprint-status`
        # and `queue.stories-manifest` already fail for it; adding an `ok` here would
        # say "no story is gated" about a queue this check never saw.
        return
    gating = [e.id for e, g in declared if not e.done and g.tokens]
    gated = False
    for entry, entry_gates in declared:
        # `done`, not `not open` — the tri-state is the whole point. An entry whose
        # status the format cannot read (`status: opne`, or no status line) is not
        # evidence the work landed, and skipping it let one typo disable the gate
        # *and* emit an `ok` naming the entry as clear. Only an explicit `done`
        # retires a gate; everything else holds until someone writes that word.
        if entry.done:
            continue
        for story_key in story_keys:
            hits = [t for t in entry_gates.tokens if deferredwork.gates_story(t, story_key)]
            if not hits:
                continue
            gated = True
            report.fail(
                "deferred.hard-gate",
                f"{entry.id} ({entry.title}) {_gate_status_clause(entry)} and gates "
                f"{story_key} (gate: {', '.join(hits)}) — that story must not run until "
                f"the entry lands. Close it in {paths.deferred_work.name} "
                f"(`status: done <date>`), or drop the token from its `gate:` line if it "
                f"no longer blocks this work",
                {
                    "dw_id": entry.id,
                    "title": entry.title,
                    "story_key": story_key,
                    "tokens": hits,
                },
            )
    if not gated:
        report.ok(
            "deferred.hard-gate",
            f"deferred-work gates OK: no actionable story is gated by an unlanded entry "
            f"({', '.join(gating) if gating else 'no unlanded gated entries'})",
            {"gating_ids": gating, "actionable": list(story_keys)},
        )


def _gate_status_clause(entry: deferredwork.DWEntry) -> str:
    """How the failure names *why* this entry still gates.

    An unreadable status is reported as what it is rather than folded into "is
    open": the remedy differs — the operator with a typo fixes the `status:` line,
    and telling them the entry "is open" sends them to close work that may already
    have landed. Naming the offending value is what makes a one-character typo
    findable in a ledger of fifty entries.
    """
    if entry.open:
        return "is open"
    if not entry.status:
        return "has no `status:` line, so it cannot be read as landed"
    return f"has an unreadable status (`{entry.status}`), so it cannot be read as landed"


def _report_unstructured_gate(
    entry: deferredwork.DWEntry,
    entry_gates: deferredwork.EntryGates,
    report: ValidationReport,
) -> None:
    """Warn about a hard gate the mechanical check cannot enforce.

    Three causes, one id, because the remedy is the same line in the same file.
    A ``HARD GATE:`` written as prose is the pre-``gate:`` convention still
    holding nothing back. A token that cannot name a story key, and a ``gate:``
    line with nothing after the colon, are that same nothing with the field's
    syntax around it — worse, because to anyone scanning the entry they read as a
    gate already in force.

    An entry carrying a valid token *and* an unenforceable one is still reported,
    and each cause is reported on its own rather than the first one winning: the
    valid half gates what it names, and the operator's belief about the other half
    is exactly the thing that goes wrong quietly. That applies to an empty line as
    much as to a malformed token — ``gate: 3-2`` followed by a bare ``gate:`` used
    to report neither, because the entry had tokens and so read as fully gated.

    A fourth cause, and the only one that is about a line the parser never saw: a
    ``gate:`` the strict field anchor misses (``Gate:``, or indented). It is a
    warning rather than an accepted gate on purpose — see :data:`_GATE_NEAR_RE`.

    Runs for every entry that is not ``done``, which is the same set the refusal
    holds against. Keying it on ``open`` instead would have left an entry with an
    unreadable status silent about a malformed token as well as about its gate.
    """
    reasons: list[str] = []
    if entry_gates.malformed:
        reasons.append(
            f"declares `gate:` tokens that cannot name a story: {', '.join(entry_gates.malformed)}"
        )
    if entry_gates.empty == 1:
        reasons.append("declares an empty `gate:` line, which names no story")
    elif entry_gates.empty:
        reasons.append(f"declares {entry_gates.empty} empty `gate:` lines, which name no story")
    if entry_gates.near_miss:
        reasons.append(
            f"spells {entry_gates.near_miss} `gate:` line(s) in a form the field does not "
            f"read (the field is a lowercase `gate:` at the very start of a line)"
        )
    prose_only = not entry_gates.tokens and not reasons
    if prose_only and deferredwork.declares_prose_gate(entry):
        reasons.append("declares a `HARD GATE:` in prose but carries no `gate:` line")
    if not reasons:
        return
    report.warn(
        "deferred.hard-gate-unstructured",
        f"{entry.id} ({entry.title}) {' and '.join(reasons)} — so `validate` cannot refuse "
        f"the gated story and nothing holds it back; name the blocked stories on a `gate:` "
        f"line (comma-separated) to make the gate enforceable",
        {
            "dw_id": entry.id,
            "malformed": list(entry_gates.malformed),
            "empty": entry_gates.empty,
            "near_miss": entry_gates.near_miss,
        },
    )


def _actionable_story_keys(
    paths: bmadconfig.ProjectPaths, spec_folder: str | None
) -> list[str] | None:
    """The story keys this queue could dispatch, in queue order, in either mode.

    ``None`` when the queue could not be read, which is not the same answer as an
    empty list: ``queue.sprint-status`` and ``queue.stories-manifest`` own queue
    readability, so this check stays quiet rather than raising — but a caller that
    read ``[]`` as "nothing is gated" would report an all-clear about a queue it
    never saw. The whole walk is inside the guard for the same reason: the
    per-story ``resolve_story_spec`` globs the filesystem too, and leaving it
    outside turned a degraded check into a traceback out of ``validate``.

    Stories mode has no status column — the manifest is a flat schedule and the
    story's own spec carries the status — so actionability comes from
    :func:`stories._classify`, the predicate the scheduler itself picks with.
    Dropping only ``done`` is not the same line the sprint board draws:
    ``ACTIONABLE_STATUSES`` is a two-element allowlist, so ``blocked`` and the
    rest are already out on that side. In stories mode a ``blocked``, sentinel,
    ambiguous or unknown-status entry is one :func:`stories.schedule` refuses to
    dispatch (``SCHEDULE_WEDGED``), so treating every non-``done`` state as
    actionable made ``validate`` exit nonzero over a gate on a story the queue
    could not run — and made the two queue modes disagree about what a gate
    refuses.

    What is shared is that per-entry predicate and deliberately NOT the scan's
    stop rule: ``schedule`` gives up at the FIRST wedged entry, and mirroring that
    here would drop every later story from this list. Two reasons not to. A wedge
    is a property of some *other* story, and ``run --story <id>`` scans that entry
    alone (``selector``), so a later story really is reachable while the wedge
    stands — while ``validate`` takes no story selector and so cannot know which
    run is coming. And stopping would let one blocked entry near the top of a
    manifest silence the gate check for everything below it, which is the failure
    this check exists to prevent, arriving by a quieter route than the one it
    fixed. Over-reporting a real gate on a story that needs an unrelated
    resolution first is the cheaper wrong answer, and dispatch still refuses
    independently.
    """
    if spec_folder is not None:
        keys: list[str] = []
        try:
            folder = stories_mod.resolve_spec_folder(paths.project, spec_folder)
            for entry in stories_mod.load_stories(folder).entries:
                state = stories_mod.resolve_story_spec(folder, entry.id)
                if stories_mod._classify(state) != "actionable":
                    continue
                keys.append(entry.id)
        except (OSError, UnicodeDecodeError, stories_mod.StoriesError):
            return None
        return keys
    try:
        ss = sprintstatus.load(paths.sprint_status)
    except (sprintstatus.SprintStatusError, OSError, UnicodeDecodeError):
        return None
    return [s.key for s in ss.stories if s.status in sprintstatus.ACTIONABLE_STATUSES]


def _validate_closes_deferred(
    paths: bmadconfig.ProjectPaths,
    text: str,
    report: ValidationReport,
    *,
    spec_folder: str | None = None,
) -> None:
    """Warn when a story declares ``closes_deferred:`` ids the deferred-work
    ledger does not carry, or declares them in a shape nothing can read (#234).

    At clean close the orchestrator flips each declared id to ``status: done
    <date>`` + a ``resolution:`` line. An id that names no entry — a typo, or an
    entry reworded/renumbered since the spec was written — annotates nothing, and
    the run says so only in the journal, where nobody looks until the retro that
    the annotation exists to spare. Saying it at preflight is the whole point:
    the declaration is fixable before the run, not after.

    Runs in **both** queue modes, because the declaration exists in both. With
    ``spec_folder`` (stories mode) each manifest entry is checked together with
    its id-resolved spec, unioned — the manifest half is what makes this genuinely
    a *pre*-flight, since those ids are readable before the story has ever been
    dispatched. Without it (sprint mode) the story specs already sitting in the
    artifacts dir are scanned instead; those are written by `create-story` ahead
    of the run, which is exactly while a typo is still cheap to fix. Reporting
    only in stories mode left sprint-mode operators with nothing but a journal
    line after the fact.

    An id present but already ``done`` is a declaration a prior run already
    satisfied (a resume re-drives the same close), so it stays silent — the same
    classification the engine's close hook makes, for the same reason. Everything
    else it can journal is reported here: an absent id, an id whose ledger entry
    carries neither an ``open`` nor a ``done`` status (nothing will be marked, and
    the remedy is in the ledger rather than in the declaration), and a
    wrong-container declaration, which names real intent that would otherwise
    close nothing and say nothing. Covering only two of the three left the third
    to be discovered in the journal after the run it should have preceded.

    Never a failure. The annotation is traceability, not a gate, so a stale
    reference must not be able to block a run that would otherwise start.
    ``text`` is the ledger snapshot :func:`_validate_deferred_ledger` already
    read; an unreadable ledger never reaches here.
    """
    ledger = paths.deferred_work
    try:
        sources = (
            _stories_declarations(paths, spec_folder)
            if spec_folder is not None
            else _sprint_declarations(paths)
        )
    except (OSError, UnicodeDecodeError, stories_mod.StoriesError):
        # An unparseable manifest is already a `queue.stories-manifest` failure from
        # the gate above — don't double-report it.
        return
    for label, ids, error in sources:
        if error:
            report.warn(
                "deferred.closes-malformed",
                f"{label} declares closes_deferred in a shape that cannot be read: "
                f"{error} — nothing will be marked resolved for it",
                {"source": label, "error": error},
            )
        declared = deferredwork.classify(text, ids)
        if declared.malformed:
            malformed = list(declared.malformed)
            report.warn(
                "deferred.closes-entry-unreadable",
                f"{label} declares closes_deferred ids whose {ledger.name} entries carry "
                f"neither an `open` nor a `done` status: {', '.join(malformed)} — nothing "
                "will be marked resolved for them until the entry status is repaired",
                {"source": label, "dw_ids": malformed},
            )
        if declared.unknown:
            unknown = list(declared.unknown)
            report.warn(
                "deferred.closes-unknown",
                f"{label} declares closes_deferred ids that are not in "
                f"{ledger.name}: {', '.join(unknown)} — nothing will be marked "
                f"resolved for them (typo, or a renumbered/reworded entry?)",
                {"source": label, "unknown_ids": unknown},
            )


def _stories_declarations(
    paths: bmadconfig.ProjectPaths, spec_folder: str
) -> list[tuple[str, tuple[str, ...], str | None]]:
    """Per manifest entry: the union of its ``stories.yaml`` ids and its
    id-resolved spec's, deduped across both channels."""
    folder = stories_mod.resolve_spec_folder(paths.project, spec_folder)
    out = []
    for entry in stories_mod.load_stories(folder).entries:
        ids = list(entry.closes_deferred)
        error = None
        state = stories_mod.resolve_story_spec(folder, entry.id)
        if state.kind == stories_mod.KIND_PRESENT and state.path is not None:
            spec_ids, error = _spec_closes_deferred(state.path)
            ids += spec_ids
        out.append((f"story {entry.id}", tuple(dict.fromkeys(ids)), error))
    return out


def _sprint_declarations(
    paths: bmadconfig.ProjectPaths,
) -> list[tuple[str, tuple[str, ...], str | None]]:
    """Sprint mode has no manifest, so the declarations that exist yet are the
    ones in story specs already on disk — the flat ``*.md`` layout the artifacts
    dir holds."""
    impl = paths.implementation_artifacts
    if not impl.is_dir():
        return []
    out = []
    for path in sorted(impl.glob("*.md")):
        if path == paths.deferred_work:
            continue
        ids, error = _spec_closes_deferred(path)
        if ids or error:
            out.append((f"spec {path.name}", ids, error))
    return out


def _warn_unknown_keys(ss: sprintstatus.SprintStatus) -> None:
    """Surface sprint-status keys the parser could not classify. Silently
    dropping one reads to the operator as "that story is done, or not mine to
    do" (issue #144) — so `run`/`--dry-run` say it out loud; the journal's
    ``sprint-status-unknown-keys`` event stays the durable record."""
    if ss.unknown_keys:
        print(
            f"warning: ignoring unparseable sprint-status keys: {', '.join(ss.unknown_keys)}",
            file=sys.stderr,
        )


def cmd_run(args: argparse.Namespace) -> int:
    """``waves run``: the LLM control loop by default, the deterministic engine
    under ``--deterministic`` (3.0.0). One command, one default, and the mode is a
    flag the operator can read back from the argv — the skill that asks which mode
    to launch prints exactly this line in its summary.

    ``--dry-run`` previews the scope either way: the plan is the same list of
    stories whoever drives them, so it goes through the engine's projection with a
    line naming the mode. Stories mode (``--spec``) is the engine's alone."""
    if (rc := _reject_bad_run_id(args.run_id)) is not None:
        return rc
    plan_doc, rc = _resolve_plan(args)
    if rc is not None:
        return rc
    args.plan_doc = plan_doc
    if getattr(args, "front", None) and not args.deterministic:
        print(
            "--front is the deterministic wave master's child flag; it needs --deterministic",
            file=sys.stderr,
        )
        return ExitCode.USAGE
    if args.deterministic:
        if args.resume:
            print(
                f"--resume is the LLM loop's; a deterministic run resumes with "
                f"`{namespace.cmd('resume', '<ref>')}`",
                file=sys.stderr,
            )
            return ExitCode.USAGE
        return _run_deterministic(args)
    if args.spec:
        print(
            "stories mode (--spec) runs on the deterministic engine; add --deterministic",
            file=sys.stderr,
        )
        return ExitCode.USAGE
    if args.dry_run:
        print("mode: LLM orchestration (the plan below is the same under --deterministic)")
        return _run_deterministic(args)
    from .llm.cli import cmd_llm_run

    return cmd_llm_run(args)


def _resolve_plan(args: argparse.Namespace) -> tuple[dict[str, Any] | None, int | None]:
    """``--plan <file>`` into the record the run carries, or the exit code that
    refuses it. Resolved here, before the loop is chosen, so the deterministic
    engine and the LLM supervisor read one validated record.

    Refused: beside ``--epic``/``--story``/``--spec`` (the plan IS the scope);
    a plan that is not ``approved`` or carries pending approvals (the door's
    ``[A]`` answers those, a run cannot); a plan measured against a branch other
    than the one this run merges into (its matrix is about that branch); a plan
    naming stories the sprint status does not have (stale, not partially right)."""
    path_arg = getattr(args, "plan", None)
    if not path_arg:
        return None, None
    if args.epic is not None or args.story or getattr(args, "spec", None):
        print(
            "--plan is the run's whole scope: drop --epic, --story and --spec "
            "(--max-stories still caps it)",
            file=sys.stderr,
        )
        return None, ExitCode.USAGE
    project = _project(args)
    plan_path = Path(path_arg)
    if not plan_path.is_absolute():
        plan_path = project / plan_path
    try:
        plan = waveplan.load(plan_path)
    except waveplan.WavePlanError as e:
        print(f"--plan: {e}", file=sys.stderr)
        return None, 1
    paths = bmadconfig.load_paths(project)
    pol = policy_mod.load(_policy_path(project))
    target = pol.scm.target_branch.strip()
    if not target:
        try:
            target = verify.current_branch(paths.repo_root)
        except verify.GitError:
            target = ""
    if plan.integration_branch and target and plan.integration_branch != target:
        print(
            f"--plan: the plan was measured against branch {plan.integration_branch!r}, but "
            f"this run merges into {target!r} — re-measure it there "
            f"({namespace.SKILL_MASTER_PARALLELISM} [R]) or run on that branch",
            file=sys.stderr,
        )
        return None, 1
    doc = plan.to_dict()
    front = getattr(args, "front", None)
    if front:
        # A wave master's child: its scope is one front of one wave, nothing else.
        wave = getattr(args, "wave", None)
        if wave is None:
            print("--front needs --wave", file=sys.stderr)
            return None, ExitCode.USAGE
        stories = waveplan.front_stories(doc, int(wave), front)
        if not stories:
            print(f"--plan: wave {wave} has no front {front!r}", file=sys.stderr)
            return None, 1
        doc["story_order"] = list(stories)
    try:
        ss = sprintstatus.load(paths.sprint_status)
        sprintstatus.select_actionable(ss, None, None, order=tuple(doc["story_order"]))
    except (sprintstatus.SprintStatusError, OSError) as e:
        print(f"--plan: {e}", file=sys.stderr)
        return None, 1
    return doc, None


def _run_deterministic(args: argparse.Namespace) -> int:
    project = _project(args)
    paths = bmadconfig.load_paths(project)
    pol = policy_mod.load(_policy_path(project))
    stories_on, spec_folder = _stories_mode(args, pol)

    if stories_on and args.epic is not None:
        # stories mode dispatches the manifest's single flat schedule; StoriesEngine
        # nulls epic_filter, so --epic has no effect. Warn rather than silently drop
        # it, so a caller who passed both (e.g. `run --spec ... --epic 3`) isn't
        # surprised by an unfiltered run. Use --story to scope to one id.
        print(
            "note: --epic is ignored in stories mode; use --story to filter to one id",
            file=sys.stderr,
        )

    if args.dry_run:
        return _dry_run(paths, pol, args, stories_on, spec_folder)

    # The HOST refusal leads the configuration ones: an under-floor git is a fact
    # about the machine that no edit to policy.toml can answer, so telling the
    # operator to fix their isolation setting first would send them at the wrong
    # problem. Everything else in this block would be refused again anyway.
    if (rc := _reject_under_floor_git(paths.project)) is not None:
        return rc

    if (rc := _reject_missing_policy(paths.project)) is not None:
        return rc

    # First of the configuration refusals (`_reject_bad_run_id` and the two loaders
    # above can abort earlier), and deliberately before the queue and worktree-clean
    # gates: this one says the configuration cannot run at all, so making the
    # operator clear a dirty tree or fix a story key first would only delay the
    # same abort.
    if (rc := _reject_isolation_conflict(paths, pol)) is not None:
        return rc

    if stories_on:
        problem = _validate_stories_folder(paths, spec_folder, selector=args.story)
        if problem:
            print(problem, file=sys.stderr)
            return 1
    else:
        try:
            ss = sprintstatus.load(paths.sprint_status)
            _warn_unknown_keys(ss)
            sprintstatus.select_actionable(
                ss, args.epic, args.story, order=waveplan.story_order_of(args.plan_doc)
            )
        except sprintstatus.SprintStatusError as e:
            print(e, file=sys.stderr)
            return 1

    if not verify.worktree_clean(paths.repo_root, project=paths.project):
        print("git worktree is not clean — commit or stash first", file=sys.stderr)
        return 1

    if not _require_base_skills(project, pol, require_stories=stories_on):
        return 1

    _reconcile_stale(project, paths, pol)

    # The launch baseline for the auto-sweep child's config re-read (#461 point 4).
    # Taken ONCE, from the same `pol` the engine is about to freeze, and used for
    # both the factory's gate and the RunState stamp so the two cannot disagree.
    #
    # `profiles` is resolved once here for the same reason and carried into
    # compose_run: the digest and `make_adapters` each used to read
    # profiles/*.toml separately, so the stamped baseline could describe bytes
    # this run never launched — and every later auto-sweep is held to that
    # baseline. See `_launch_profiles` for why this is an over-refusal fix and
    # not the child gate's check-then-use.
    profiles = _launch_profiles(pol, project)
    trusted_digest = _trusted_config_digest(pol, project, profiles=profiles)

    # The composition (run dir + state + pid + adapters + engine) lives in
    # runsetup; cmd_run stays parse -> compose -> render. Engine/StoriesEngine and
    # _make_adapters are handed in from this module's namespace so the test suite's
    # `monkeypatch.setattr(cli, "Engine"/"_make_adapters", ...)` still applies.
    composed = runsetup.compose_run(
        project=project,
        paths=paths,
        policy=pol,
        run_id=args.run_id,
        epic_filter=args.epic,
        story_filter=args.story,
        max_stories=args.max_stories,
        plan=args.plan_doc,
        plan_front=getattr(args, "front", None) or "",
        plan_wave=getattr(args, "wave", None),
        plan_parent=getattr(args, "parent", None) or "",
        stories_on=stories_on,
        spec_folder=spec_folder,
        sweep_factory=_sweep_factory(project, paths, trusted_digest),
        make_adapters=_make_adapters,
        engine_cls=Engine,
        stories_engine_cls=StoriesEngine,
        trusted_config_digest=trusted_digest,
        profiles=profiles,
    )
    _warn_bypass_dropped(
        pol,
        project,
        ("dev", "review") if stories_on else _sprint_launch_roles(pol),
        profiles=profiles,
        journal=composed.journal,
    )
    print(f"run {composed.run_id} starting (attach: {namespace.PRODUCT} attach)")
    summary = composed.engine.run()
    print(summary.render())
    return 0


def _render_invocation(pol, project: Path, role: str, prompt: str) -> str:
    from .adapters import registry as adapter_registry
    from .adapters.profile import get_profile

    cfg = pol.adapter.resolved(role)
    profile = get_profile(cfg.name, project)
    # Keyed on the adapter KIND, not on `hookless`: the registry decoupled the two
    # axes, so an `opencode-http` profile carrying a hook dialect still launches
    # the HTTP adapter (and sends effort), while a hookless profile of another
    # kind never does. The preview must follow the adapter `make_adapters` builds.
    if profile.adapter == adapter_registry.OPENCODE_HTTP:
        # HTTP/SSE transport — there is no shell invocation to print. Render
        # the real sequence (per-session server spawn + API prompt) instead of
        # a fake argv that run would never execute.
        model = f" model={cfg.model}" if cfg.model else ""
        # effort rides the prompt_async body as `variant` (#643); shown under the
        # policy's own key so the preview distinguishes the configurations.
        effort = f" effort={cfg.effort}" if cfg.effort else ""
        # launch_args sits between binary and `serve`, as `_serve_argv` builds it.
        launcher = " ".join((profile.binary, *profile.launch_args))
        return (
            f"{launcher} serve --hostname 127.0.0.1 --port <auto> "
            f'(cwd=<worktree>) → POST /session → prompt_async "{profile.render_prompt(prompt)}"'
            f"{model}{effort}"
        )
    extra = cfg.extra_args if cfg.extra_args is not None else profile.bypass_args
    argv = [
        profile.binary,
        *profile.launch_args,
        f'"{profile.render_prompt(prompt)}"',
        *extra,
    ]
    if cfg.model:
        argv += [profile.model_flag, cfg.model]
    # The launch mints a fresh UUID4 per session (DW-505) and appends it last,
    # as `build_command` does; a preview has none, so it shows the placeholder.
    if profile.session_id_flag:
        argv += [profile.session_id_flag, "<auto>"]
    return " ".join(argv)


def _events_dir_preview(project: Path) -> str | None:
    """``WAVES_EVENTS_DIR`` as a real run would set it, with a ``<run-id>``
    placeholder standing in for the id no dry run has (a preview creates nothing,
    so the placeholder never reaches a filesystem). Printed once per preview
    rather than on every story's ``env:`` line: only the run id varies, and the
    path is long.

    ``None`` — plus the state root's own error on stderr — when no state root can
    be resolved. A real run resolves the same path while building its adapters, so
    silently dropping the line would turn a preview into a promise the run cannot
    keep."""
    try:
        return str(runs.events_dir_for(project, "<run-id>"))
    except runs.StateRootError as e:
        print(f"warning: {e}", file=sys.stderr)
        return None


def _dry_run(
    paths: bmadconfig.ProjectPaths,
    pol,
    args: argparse.Namespace,
    stories_on: bool = False,
    spec_folder: str = "",
) -> int:
    if stories_on:
        return _dry_run_stories(paths, pol, args, spec_folder)

    _warn_preflight_would_abort(paths, pol)
    _warn_bypass_dropped(pol, paths.project, _sprint_launch_roles(pol))

    def render(role: str, prompt: str) -> str:
        return _render_invocation(pol, paths.project, role, prompt)

    ss = sprintstatus.load(paths.sprint_status)
    _warn_unknown_keys(ss)
    plan_doc = getattr(args, "plan_doc", None)
    try:
        queue = sprintstatus.select_actionable(
            ss, args.epic, args.story, order=waveplan.story_order_of(plan_doc)
        )
    except sprintstatus.SprintStatusError as e:
        print(e, file=sys.stderr)
        return 1
    if args.max_stories is not None:
        queue = queue[: args.max_stories]
    if not queue:
        print("no actionable stories")
        return 0
    if plan_doc:
        print(
            f"plan: {plan_doc['scope']} ({plan_doc['path']}) — wave order, one story at a "
            "time (parallel fronts are not built yet; the plan fixes the order)"
        )
    print(f"would process {len(queue)} stories (gates={pol.gates.mode}):")
    if (events_dir := _events_dir_preview(paths.project)) is not None:
        print(f"  env (every session): {envvars.EVENTS_DIR}={events_dir}")
    dev_skill = _dev_skill_for_role(pol, paths.project, "dev")
    review_skill = _dev_skill_for_role(pol, paths.project, "review")
    for story in queue:
        where = waveplan.front_of(plan_doc, story.key) if plan_doc else None
        tag = f" · wave {where['wave']} front {where['front']}" if where else ""
        print(f"\n  {story.key} (epic {story.epic}, status {story.status}){tag}")
        print(f"    dev:    {render('dev', f'/{dev_skill} {story.key}')}")
        print(f"    review: {render('review', f'/{review_skill} <done spec from dev>')}")
        print(f"    env:    {envvars.MODE}=1 {envvars.STORY_KEY}={story.key}")
    return 0


def _checkpoint_badge(row: stories_mod.StoryRow) -> str:
    """`` [spec-checkpoint, done-checkpoint]`` for a story's HITL flags, or ``""``
    when it sets neither. Shared spelling for the dry-run schedule + status."""
    marks = []
    if row.spec_checkpoint:
        marks.append("spec-checkpoint")
    if row.done_checkpoint:
        marks.append("done-checkpoint")
    return f" [{', '.join(marks)}]" if marks else ""


def _dry_run_stories(
    paths: bmadconfig.ProjectPaths, pol, args: argparse.Namespace, spec_folder: str
) -> int:
    """Print the linear stories-mode schedule (list order, checkpoints, live
    on-disk state) — no topo waves, one story per line, spawns nothing."""
    _warn_preflight_would_abort(paths, pol, require_stories=True)
    _warn_bypass_dropped(pol, paths.project, ("dev", "review"))
    folder = stories_mod.resolve_spec_folder(paths.project, spec_folder)
    # The real dispatch always uses the project-relative folder (the engine
    # relativizes it); render the identical string here so dry-run and run agree —
    # including the refusal, which is the one answer `run` would not survive. No
    # `(spec folder: ...)` suffix like the sibling below: the reason already names
    # the spec folder and the project root, and on this leg `folder` is only
    # `spec_folder` re-spelled (the raise is reachable from the absolute branch
    # alone), so the suffix would print the same path a third time.
    try:
        rel = stories_mod.relativize_spec_folder(paths.project, spec_folder)
    except stories_mod.StoriesError as e:
        print(f"stories mode: {e}", file=sys.stderr)
        return 1
    try:
        rows = stories_mod.story_rows(folder, selector=args.story, max_stories=args.max_stories)
    except stories_mod.StoriesError as e:
        print(f"stories mode: {e} (spec folder: {folder})", file=sys.stderr)
        return 1
    if args.story and not rows:
        print(f"stories mode: story id {args.story!r} not found in stories.yaml", file=sys.stderr)
        return 1
    spec_ok = "" if (folder / "SPEC.md").is_file() else "  [!] SPEC.md missing"
    print(
        f"stories mode: {len(rows)} stories from {folder}/stories.yaml "
        f"(gates={pol.gates.mode}){spec_ok}"
    )
    if (events_dir := _events_dir_preview(paths.project)) is not None:
        print(f"  env (every session): {envvars.EVENTS_DIR}={events_dir}")
    print("linear schedule (list order — no depends_on, strictly serial):")
    dev_skill = _dev_skill_for_role(pol, paths.project, "dev")
    for row in rows:
        print(f"\n  {row.position}. {row.id}  ({row.label}){_checkpoint_badge(row)}  {row.title}")
        # A spec_checkpoint story whose plan is not yet on disk dispatches leg 1
        # (Halt after planning + WAVES_PLAN_HALT); mirror the real dispatch's
        # markers so dry-run does not under-report what run would emit.
        plan_halt = stories_mod.is_plan_halt_leg(row.spec_checkpoint, row.state)
        dispatch = f"/{dev_skill} Spec folder: {rel}. Story id: {row.id}."
        if plan_halt:
            dispatch += " Halt after planning."
        print(f"    dev:    {_render_invocation(pol, paths.project, 'dev', dispatch)}")
        env = f"{envvars.MODE}=1 {envvars.STORY_KEY}={row.id} {envvars.SPEC_FOLDER}={rel}"
        if plan_halt:
            env += f" {envvars.PLAN_HALT}=1"
        print(f"    env:    {env}")
    return 0


def _print_stories_status(state: RunState, project: Path) -> None:
    """The stories-mode board for `status`: id, live on-disk state, checkpoint
    markers and title, read from the run's pinned spec folder. Mode-aware
    counterpart of the sprint-backlog line — the run stamped ``source`` and
    ``spec_folder`` at start, so no flag is needed to re-derive the mode."""
    folder = stories_mod.resolve_spec_folder(project, state.spec_folder)
    try:
        rows = stories_mod.story_rows(folder)
    except stories_mod.StoriesError as e:
        print(f"stories: {e} (spec folder: {folder})")
        return
    done = sum(1 for r in rows if r.label == stories_mod.DONE)
    print(f"stories: {done}/{len(rows)} done  ({folder}/stories.yaml)")
    for row in rows:
        print(
            f"  {row.position:2d}. {row.id:12s} {row.label:16s}"
            f"{_checkpoint_badge(row)}  {row.title}"
        )


def _start_sweep(
    project: Path,
    paths: bmadconfig.ProjectPaths,
    pol,
    *,
    prompting: bool,
    decisions_only: bool,
    max_bundles: int | None,
    repeat: bool | None = None,
    max_cycles: int | None = None,
    trigger: str,
    only_ids: tuple[str, ...] | None = None,
    min_severity: str | None = None,
    run_id: str | None = None,
    profiles=None,
    on_started: Callable[[], None] | None = None,
) -> int:
    # The composition (run dir + state + pid + sweep.json + adapters + engine)
    # lives in runsetup; this stays compose -> render. SweepEngine and
    # _make_adapters are handed in from this module's namespace so the test suite's
    # `monkeypatch.setattr(cli, "SweepEngine"/"_make_adapters", ...)` still applies.
    #
    # `profiles` is the auto-sweep gate's frozen resolution (#461 point 4) — it
    # both stamps the pin and builds the adapters, so neither re-reads
    # profiles/*.toml after the gate compared it. `cmd_sweep` passes None: a human
    # started that one, so a fresh read is the point.
    #
    # `on_started` is the auto-sweep parent's latch, likewise absent for
    # `cmd_sweep`; `compose_sweep` fires it at the boundary where this child owns a
    # published, resumable run dir.
    composed = runsetup.compose_sweep(
        project=project,
        paths=paths,
        policy=pol,
        run_id=run_id,
        prompting=prompting,
        decisions_only=decisions_only,
        max_bundles=max_bundles,
        repeat=repeat,
        max_cycles=max_cycles,
        only_ids=only_ids,
        min_severity=min_severity,
        trigger=trigger,
        make_adapters=_make_adapters,
        sweep_engine_cls=SweepEngine,
        trusted_config_digest=_trusted_config_digest(pol, project, profiles=profiles),
        profiles=profiles,
        on_started=on_started,
    )
    _warn_bypass_dropped(
        pol,
        project,
        ("triage", "dev", "review"),
        profiles=profiles,
        journal=composed.journal,
    )
    print(f"sweep {composed.run_id} starting (attach: {namespace.PRODUCT} attach)")
    summary = composed.engine.run()
    print(summary.render())
    return ExitCode.FAILURE if summary.crashed and only_ids is not None else ExitCode.OK


def _sweep_factory(project: Path, paths: bmadconfig.ProjectPaths, trusted_digest: str):
    """Child-sweep launcher injected into story-run engines. Auto-triggered
    sweeps are unattended: never prompt, never run decision bundles.

    The returned callable implements :class:`engine.SweepFactory`: every refusal
    below raises *before* the keyword-only ``started`` thunk can fire, which is
    what leaves the parent run's trigger unspent for a child that never launched.

    ``trusted_digest`` is the caller's launch-time :func:`runsetup.config_digest`
    — the integrity pin for the config this factory re-reads from disk below.
    Required, with no default: an omitted baseline would silently disable the
    refusal, which is the failure mode a security gate can least afford. The
    re-read happens once and is frozen, so the gate validates the bytes the child
    actually launches from rather than a separate read of the same files."""

    def factory(trigger: str, *, started: Callable[[], None]) -> None:
        pol = policy_mod.load(_policy_path(project))
        # Read the agent-writable config EXACTLY ONCE, here, and run the child off
        # these two objects: `pol` and `profiles` are threaded through the gate
        # below, the pin `_start_sweep` stamps, and `make_adapters`. Before this
        # the gate hashed its own `get_profile` read while the adapters took a
        # later one, so a session that leaves a background writer alternating a
        # benign and a hostile profiles/*.toml only had to land the benign copy on
        # the digest's read — and losing a round costs it nothing, since the
        # refusal is swallowed by `_maybe_auto_sweep` and the next trigger deals
        # again. Freezing the read is the fix; narrowing the window is not.
        profiles = runsetup.resolve_profiles(pol, project)
        # #461 point 4. This reload is the ONE path where a mid-run rewrite of the
        # agent-writable config reaches host code execution with no human
        # initiating the change: the driven sessions can write policy.toml and
        # profiles/*.toml, and this factory re-reads both on a trigger the engine
        # raised, not an operator. The parent loop is already safe — it froze its
        # Policy at launch — and the two documented human-present mid-run edits
        # (the TUI live-edit, resume-to-fix-a-setting) stay trusted; resume only
        # warns. So refuse here and only here.
        #
        # ABLATION GUARDS: deleting this block must fail
        # test_auto_sweep_refuses_a_rewritten_verify_command,
        # test_auto_sweep_refuses_a_rewritten_profile_binary, and
        # test_auto_sweep_refuses_a_widened_plugin_allowlist in tests/test_cli.py.
        if runsetup.config_digest(pol, project, profiles=profiles) != trusted_digest:
            raise RuntimeError(
                "policy.toml/profiles changed under a running loop before an auto-sweep"
                " — refusing the child sweep; no human initiated this config change."
                f" Run `{namespace.PRODUCT} sweep` yourself to proceed under the new config."
            )
        # Raise rather than return the rc the other three sites return. By the time
        # the engine calls this it has journaled `sweep-auto-trigger`, and it reads
        # a plain return as a child that ran — latching the trigger on one whether
        # or not `started` fired — so a bare decline would be recorded as
        # `sweep-auto-finished`, which `engine.py` defines as "a clean completion
        # from the parent's perspective": a child sweep that ran and finished when
        # none was ever launched. Raising lands on the `sweep-auto-not-started` +
        # notify path the `load` above already takes on an unparseable policy.toml,
        # which is the same kind of event — the config on disk changed under a run
        # that had already started.
        conflict = bmadconfig.worktree_isolation_conflict(paths, pol.scm.isolation)
        if conflict is not None:
            raise RuntimeError(conflict)
        # Same refusal as the three rc-returning sites, same raise-not-return reason
        # as the two above it. A `GitError` here needs no arm of its own: it is
        # already an exception, and this factory's contract is that any raise before
        # `started` leaves the parent's trigger unspent.
        if (found := verify.git_below_floor(paths.project)) is not None:
            raise RuntimeError(verify.under_floor_git_message(found))
        # The child's triage sessions dispatch `/waves-core-sweep` from this `pol`'s
        # triage tree; a deleted or partial skill would stall each one at `Unknown
        # command`. Raise, not return, for the reason above. The tree comes off the
        # frozen `profiles` read, not `_triage_trees`' fresh one, so the probe asks
        # about the exact tree the child is about to launch into.
        triage_tree = profiles["triage"].skill_tree
        if sweep_problems := install.missing_sweep_skill(project, [triage_tree]):
            raise RuntimeError("; ".join(p.message for p in sweep_problems))
        _start_sweep(
            project,
            paths,
            pol,
            prompting=False,
            decisions_only=False,
            max_bundles=None,
            trigger=trigger,
            only_ids=None,
            min_severity=None,
            profiles=profiles,
            on_started=started,
        )

    return factory


def cmd_sweep(args: argparse.Namespace) -> int:
    if (rc := _reject_bad_run_id(args.run_id)) is not None:
        return rc
    project = _project(args)
    paths = bmadconfig.load_paths(project)

    only_arg = getattr(args, "only", None)
    min_severity = getattr(args, "min_severity", None)
    if only_arg is not None and min_severity is not None:
        print("--only cannot combine with --min-severity", file=sys.stderr)
        return ExitCode.FAILURE

    if args.before is not None and not args.archive:
        print("--before requires --archive", file=sys.stderr)
        return ExitCode.FAILURE

    if args.archive:
        if (
            args.decisions_only
            or args.repeat is not None
            or args.max_bundles is not None
            or args.max_cycles is not None
            or args.no_prompt
            or args.run_id is not None
            or only_arg is not None
            or min_severity is not None
        ):
            print(
                "--archive cannot combine with --decisions-only, --repeat, "
                "--max-bundles, --max-cycles, --no-prompt, --run-id, --only, "
                "or --min-severity",
                file=sys.stderr,
            )
            return ExitCode.FAILURE
        return _sweep_archive(project, paths, args)

    try:
        only_ids = _parse_sweep_only(only_arg) if only_arg is not None else None
    except ValueError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return ExitCode.FAILURE

    pol = policy_mod.load(_policy_path(project))

    if args.dry_run:
        return _sweep_dry_run(paths, pol, only_ids=only_ids, min_severity=min_severity)

    if (rc := _reject_under_floor_git(paths.project)) is not None:
        return rc

    if (rc := _reject_missing_policy(paths.project)) is not None:
        return rc

    if (rc := _reject_isolation_conflict(paths, pol)) is not None:
        return rc

    if not verify.worktree_clean(paths.repo_root, project=paths.project):
        print("git worktree is not clean — commit or stash first", file=sys.stderr)
        return 1

    if not _require_base_skills(project, pol):
        return 1

    if not _require_sweep_skill(project, pol):
        return 1

    _reconcile_stale(project, paths, pol)

    return _start_sweep(
        project,
        paths,
        pol,
        prompting=not args.no_prompt,
        decisions_only=args.decisions_only,
        max_bundles=args.max_bundles,
        repeat=args.repeat,
        max_cycles=args.max_cycles,
        only_ids=only_ids,
        min_severity=min_severity,
        trigger="cli",
        run_id=args.run_id,
    )


def _sweep_archive(project: Path, paths: bmadconfig.ProjectPaths, args: argparse.Namespace) -> int:
    """`waves sweep --archive`: move closed deferred-work entries to a
    sibling archive file. A self-contained sub-mode — no worktree, no
    preflight, no LLM. Refuses while any engine run is live or unverifiably
    so: this is the one out-of-band ledger writer, and a concurrent close or
    harvest landing between its read and its writes would be silently
    clobbered. An unverifiable pid is treated as live — a write op takes the
    conservative side, unlike the cleanup guards which only warn.

    Run dirs are enumerated raw (:func:`runs.all_run_dirs`) rather than through
    the ``state.json``-gated :func:`runs.list_run_dirs`: a run whose state file
    was removed still owns its ``engine.pid`` and still writes this ledger, and
    the gated view would report it as no run at all. An unreadable runs root
    answers nothing, so it refuses too — same conservative side."""
    # The pid-liveness gate below is now belt-and-braces: `archive_closed` takes
    # the cross-process ledger lock beneath it (#286/#469), so a run that started
    # after this check still cannot interleave its writes with the archive's. The
    # gate STAYS, because its semantics are deliberately coarser than the lock's:
    # the lock only serializes the two writers' read->edit->write cycles, while
    # the gate refuses to rewrite the archive AT ALL while any run is live —
    # including a run that would merely be surprised to find its open entries
    # moved out from under a plan it has already read. Removing it would trade a
    # refusal a human can act on for a race the lock does not cover.
    run_dirs = runs.all_run_dirs(project)
    if run_dirs is None:
        print(
            f"cannot list runs under {project / runs.RUNS_DIR} — "
            "refusing to archive ledger entries",
            file=sys.stderr,
        )
        return ExitCode.FAILURE
    for run_dir in run_dirs:
        if runs.engine_liveness(run_dir) != "dead":
            print(
                f"run {run_dir.name} may still be live — stop it before archiving ledger entries",
                file=sys.stderr,
            )
            return ExitCode.FAILURE
    ledger = paths.deferred_work
    # Call the primitive BEFORE reporting a missing ledger, and report the
    # missing ledger from its empty result. `archive_closed` validates `before`
    # ahead of its own presence guard precisely so a malformed date fails the
    # same way whether or not a ledger exists; short-circuiting here first put
    # that back, and `--before not-a-date` then exited 0 on a project that
    # happens to have no ledger today and 1 on one that does — the same
    # invocation graded by optional project data rather than by its own shape
    # (#711 review). The call is safe on a missing file: it short-circuits to
    # an empty list without writing.
    #
    # The post-report presence probe sits INSIDE the same `try`, as `stat` +
    # `S_ISREG` (DW-265). It is reachable only in the window after
    # `archive_closed`'s own guard answered without raising, but a probe that
    # raised a traceback out of the CLI (Python 3.13, where `is_file()` raises
    # EACCES) or reported "no deferred-work ledger" after a successful archive
    # (3.14, where `is_file()` suppresses every OS error and answers False) is
    # still wrong; a refused probe now reaches the FAILURE arm below, whose
    # message already says the ledger could not be read.
    try:
        archived = deferredwork.archive_closed(
            ledger,
            before=args.before,
            dry_run=args.dry_run,
        )
        try:
            present = S_ISREG(ledger.stat().st_mode)
        except (FileNotFoundError, NotADirectoryError):
            present = False
    except ValueError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return ExitCode.FAILURE
    except (OSError, deferredwork.LedgerReadFault, runs.StateRootError) as exc:
        # `archive_closed` serializes on the ledger's sidecar lock (#286/#469).
        # Acquisition raises `OSError` (a rival holder outlasting the blocking
        # retry, or an unwritable locks dir); deriving the sidecar's path raises
        # `runs.StateRootError` — NOT an OSError — when the environment names no
        # usable state root; pre-lock probes and atomic writes raise `OSError`,
        # while the authoritative read wraps OS faults as `LedgerReadFault`
        # (DW-279). Naming the lock makes the message actionable — a bare
        # `error: [Errno 11] ...` from a command with no other lock in sight reads as a bug in the archive — but
        # the message must not ASSERT contention, or a full disk sends the
        # operator hunting a rival process that was never there. So it names both
        # possibilities and lets the carried cause decide between them. Existing
        # FAILURE path, no new exit code, and `--archive` has no --json arm.
        print(
            f"error: cannot archive the deferred-work ledger ({exc}) — another "
            f"{namespace.PRODUCT} process may hold its ledger lock, or the ledger or its "
            "archive could not be read or written",
            file=sys.stderr,
        )
        return ExitCode.FAILURE
    if not present:
        print(f"no deferred-work ledger at {ledger}")
        return ExitCode.OK
    archive_path = ledger.parent / deferredwork.ARCHIVE_REL
    if not archived:
        print("no closed entries to archive")
        return ExitCode.OK
    noun = "entry" if len(archived) == 1 else "entries"
    if args.dry_run:
        print(f"would archive {len(archived)} {noun}:")
        for dw_id in archived:
            print(f"  {dw_id}")
        return ExitCode.OK
    print(f"archived {len(archived)} {noun} to {archive_path}:")
    for dw_id in archived:
        print(f"  {dw_id}")
    print("note: if the ledger is tracked, commit both files to make the move durable")
    return ExitCode.OK


def _parse_sweep_only(value: str) -> tuple[str, ...]:
    parts = [part.strip() for part in value.split(",")]
    if not parts or any(not part for part in parts):
        raise ValueError("--only requires a comma-separated list of DW-<n> ids")
    malformed = [part for part in parts if not DW_ID_RE.fullmatch(part)]
    if malformed:
        raise ValueError("--only contains malformed ids: " + ", ".join(malformed))
    return tuple(dict.fromkeys(parts))


def _sweep_dry_run(
    paths: bmadconfig.ProjectPaths,
    pol,
    *,
    only_ids: tuple[str, ...] | None = None,
    min_severity: str | None = None,
) -> int:
    # Before the no-ledger early return below: a broken install is worth saying so
    # about whether or not there is anything to sweep.
    _warn_preflight_would_abort(paths, pol, require_sweep=True)
    ledger = paths.deferred_work
    # OBSERVATION arm of the ledger-read contract (DW-146): this listing writes
    # nothing, but it is an OPERATOR SURFACE, so degrading to an empty document
    # would report "0 open" for a ledger nobody could read — a fabricated listing
    # is worse than no listing. Say which file and which fault, and fail.
    # Absence is taken from the reader's own `("", None)` answer rather than an
    # `is_file()` pre-gate (DW-265): that gate suppressed every OS error on
    # Python 3.14 and answered False, printing "no deferred-work ledger" for a
    # refused one (and raised a traceback out of the CLI on 3.11–3.13), so the
    # DW-254 attributed fault below was shadowed before the reader was asked. A
    # 0-byte ledger answers the same empty text and is reported as absent too —
    # deliberate, it holds nothing to list.
    text, fault = deferredwork.read_for_observation(ledger)
    if fault is not None:
        print(f"error: {ledger} cannot be read ({fault})", file=sys.stderr)
        return ExitCode.FAILURE
    if not text:
        if only_ids is not None:
            try:
                select_entries((), only_ids=only_ids, validate_only=True)
            except ValueError as exc:
                print(f"error: {exc}", file=sys.stderr)
                return ExitCode.FAILURE
        print(f"no deferred-work ledger at {ledger}")
        return 0
    entries = deferredwork.parse_ledger(text)
    open_entries = [e for e in entries if e.open]
    legacy = deferredwork.parse_legacy(text)
    highest_suffix = max(
        (entry.id.removeprefix("DW-").lstrip("0") or "0" for entry in entries),
        key=decimal_digits_key,
        default="0",
    )
    next_suffix = increment_decimal_digits(highest_suffix)
    projected_legacy = []
    for entry in legacy:
        projected_legacy.append((f"DW-{next_suffix}", entry))
        next_suffix = increment_decimal_digits(next_suffix)
    projected_open = [(dw_id, entry) for dw_id, entry in projected_legacy if not entry.done]
    closed = len(entries) - len(open_entries)
    print(f"{ledger}: {len(open_entries)} open, {closed} closed/non-open")
    try:
        selection = select_entries(
            entries,
            only_ids=only_ids,
            min_severity=min_severity,
            validate_only=only_ids is None,
        )
    except ValueError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return ExitCode.FAILURE
    if only_ids is not None:
        available = {entry.id for entry in open_entries} | {dw_id for dw_id, _ in projected_open}
        unavailable = [dw_id for dw_id in only_ids if dw_id not in available]
        if unavailable:
            print(
                "error: --only ids must exist and be open: " + ", ".join(unavailable),
                file=sys.stderr,
            )
            return ExitCode.FAILURE
    shown = selection.selected if only_ids is not None or min_severity is not None else open_entries
    for entry in shown:
        print(f"  {entry.id:8s} {entry.title}")
    if selection.excluded:
        print("excluded by sweep selector:")
        for entry in selection.excluded:
            print(f"  {entry.id:8s} {entry.title}")
    if selection.missing_severity:
        print("excluded for missing or unrecognized severity:")
        for entry in selection.missing_severity:
            print(f"  {entry.id:8s} {entry.title}")
    legacy_open = [e for e in legacy if not e.done]
    projected_selected = projected_open
    projected_excluded: list[tuple[str, deferredwork.LegacyEntry]] = []
    projected_missing_severity: list[tuple[str, deferredwork.LegacyEntry]] = []
    if only_ids is not None:
        requested = set(only_ids)
        projected_selected = [item for item in projected_open if item[0] in requested]
        projected_excluded = [item for item in projected_open if item[0] not in requested]
    elif min_severity is not None:
        floor = SEVERITY_ORDER[min_severity]
        projected_selected = [
            (dw_id, entry)
            for dw_id, entry in projected_open
            if entry.severity is not None and SEVERITY_ORDER[entry.severity] >= floor
        ]
        selected_keys = {entry.key for _, entry in projected_selected}
        projected_excluded = [
            (dw_id, entry)
            for dw_id, entry in projected_open
            if entry.severity is not None and entry.key not in selected_keys
        ]
        projected_missing_severity = [
            (dw_id, entry) for dw_id, entry in projected_open if entry.severity is None
        ]
    if legacy:
        print(
            f"plus {len(legacy)} legacy (pre-DW-format) entries, {len(legacy_open)} open"
            " — a sweep would first migrate them to DW format"
        )
        if projected_selected:
            print("projected legacy selection (pre-migration; provisional ids):")
        for dw_id, entry in projected_selected:
            print(f"  {dw_id:8s} {entry.title}  [pre-migration projection]")
        if min_severity is not None and projected_selected:
            print(
                f"{len(projected_selected)} matching legacy entr"
                f"{'y' if len(projected_selected) == 1 else 'ies'} will be migrated then triaged"
            )
        if projected_excluded:
            print("projected legacy entries excluded by sweep selector:")
            for dw_id, entry in projected_excluded:
                print(f"  {dw_id:8s} {entry.title}  [pre-migration projection]")
        if projected_missing_severity:
            print("projected legacy entries excluded for missing or unrecognized severity:")
            for dw_id, entry in projected_missing_severity:
                print(f"  {dw_id:8s} {entry.title}  [pre-migration projection]")
    if selection.selected or projected_selected:
        # Before the projected-legacy early return below: a sweep launches triage
        # and then dev + review for its bundles, whichever preview branch prints.
        _warn_bypass_dropped(pol, paths.project, ("triage", "dev", "review"))
        print("a sweep would triage the open entries in one LLM session, then run bundles")
        if projected_selected and (only_ids is not None or min_severity is not None):
            print(
                "  triage: projected legacy ids are provisional; semantic duplicate merging may "
                "compact them, and the real run revalidates --only against the actual "
                "post-migration universe"
            )
            return 0
        prompt = f"/{namespace.SKILL_CORE_SWEEP}"
        if only_ids is not None or min_severity is not None:
            selected_ids = {entry.id for entry in selection.selected}
            ordered = (
                [dw_id for dw_id in only_ids if dw_id in selected_ids]
                if only_ids is not None
                else [entry.id for entry in selection.selected]
            )
            prompt += " --only " + ",".join(ordered)
        print(f"  triage: {_render_invocation(pol, paths.project, 'triage', prompt)}")
    return 0


def _prepare_resume_locked(project: Path, run_dir: Path, *, accept_baseline: bool = False):
    """Publish resume state while the caller holds this run's state lock.

    ``accept_baseline`` is `resume --accept-baseline` (DW-371). It is written onto
    ``state.accept_baseline`` on EVERY resume — False included — so a plain, TUI,
    or `resolve` resume clears a latch a paused `--accept-baseline` resume left."""
    # An id that aliases a control session (`ctl` / `ctl-<16hex>` —
    # runs.run_id_aliases_control_session; NOT the mint's broader reservation,
    # since a historical `ctl-foo` run has a genuine agent session and resumes
    # safely) can reach here only from a run dir an OLDER release persisted:
    # minting refuses the shape, but validation never sees what is already on
    # disk. Driving such a run is not possible — its agent session name IS the
    # control session's, so the relaunch would adopt the live control session —
    # and the refusal names the way out instead of just the wall: stop/delete
    # work on the run dir and, via the kill_session chokepoint, never touch any
    # session under this name. This is `resume`'s gate and the backstop for any
    # future caller; `resolve` gates AT ENTRY (cmd_resolve), because its flow
    # runs the interactive session and re-arms the escalation before reaching
    # here, and a refusal after those is a refusal after the side effects.
    if runs.run_id_aliases_control_session(run_dir.name):
        print(
            f"run {run_dir.name}: cannot resume — its agent session name "
            f"({runs.session_name(run_dir.name)}) is the control session's own, so "
            "driving it would take over the live control session (ids of this shape "
            "are now refused at creation; this run predates that). The run directory "
            "and any worktree are intact: recover the work by hand, then remove the "
            f"run with `{namespace.PRODUCT} delete {run_dir.name}` — stop and delete do not "
            "touch any session under this name",
            file=sys.stderr,
        )
        return 1
    paths = bmadconfig.load_paths(project)
    state = load_state(run_dir)
    if state.finished:
        print(f"run {run_dir.name} already finished", file=sys.stderr)
        return 1
    # Refuse before the preflight and before the state re-stamp below: an LLM-held
    # run is driven by llm.supervisor, and rebuilding a deterministic engine over
    # it would put two orchestrators with different decision models on one
    # state.json. compose_resume raises for the same reason, but by then this
    # function has already rewritten the run's policy snapshot and pid.
    if state.source == "llm":
        print(
            f"run {run_dir.name} is an LLM-held run — resume it with "
            f"`{namespace.PRODUCT} llm-run --resume {run_dir.name}`",
            file=sys.stderr,
        )
        return 2
    sweep_options = None
    if state.run_type == "sweep":
        try:
            runsetup.validate_sweep_options_version(state.sweep_options_version)
            sweep_options = runsetup.load_sweep_resume_options(
                run_dir,
                required=state.sweep_options_version >= runsetup.SWEEP_OPTIONS_VERSION,
                expected_digest=(
                    state.sweep_options_digest
                    if state.sweep_options_version == runsetup.SWEEP_OPTIONS_VERSION
                    else None
                ),
            )
        except runsetup.SweepOptionsError as exc:
            print(f"cannot resume {run_dir.name}: {exc}", file=sys.stderr)
            return 1
    pol = policy_mod.load(_policy_path(project))
    # Resume re-reads config.yaml and policy.toml from disk, so it is a second
    # entrypoint into the same engine and gets the same refusal — a run started
    # before the override was added must not finish its remaining stories through
    # provisioning the preflight would now refuse. The git floor rides along for the
    # same reason: a run started on a supported git can be resumed after a downgrade.
    if (rc := _reject_under_floor_git(paths.project)) is not None:
        return rc
    if (rc := _reject_missing_policy(paths.project)) is not None:
        return rc
    if (rc := _reject_isolation_conflict(paths, pol)) is not None:
        return rc
    if not _require_base_skills(project, pol, require_stories=state.source == "stories"):
        return 1
    # A resumed sweep re-dispatches `/waves-core-sweep`; a story run never does, so
    # only the sweep arm is gated. Same placement constraint as the gate above:
    # ahead of every journal/pin/stop-request side effect below.
    if state.run_type == "sweep" and not _require_sweep_skill(project, pol):
        return 1
    journal = Journal(run_dir)
    # Read the outgoing weight BEFORE the re-stamp below replaces it: the
    # session-end entries this run already wrote were weighted at it, so without
    # recording it here they stop being reconstructible from the (now newer)
    # snapshot — the very guarantee #129 exists to provide. Scalars only, never
    # policy keys or values: journal entries are unsanitized at write time, and
    # diagnose scrubs unknown fields with scrub_json, NOT the key-aware
    # _scrub_policy that reduces adapter.env and plugins.settings.
    new_snapshot = pol.to_dict()
    # Resolved once and carried into compose_resume below, so the re-stamped pin
    # describes the bytes this resumed process actually launches (see
    # `_launch_profiles`). A resume mints the same in-memory baseline `cmd_run`
    # does — `_sweep_factory(..., new_digest)` — so the same reasoning applies.
    profiles = _launch_profiles(pol, project)
    new_digest = _trusted_config_digest(pol, project, profiles=profiles)
    # Discard any stop request left over from a prior stopped run — either mode — so
    # the re-armed engine does not consume it at the first item boundary and
    # immediately re-stop. A resume is fresh user intent, which is what makes a
    # request lodged against the previous one stale.
    #
    # Placed here, and not beside write_pid with the rest of the arming, because this
    # branch RETURNS. `_require_base_skills` above used to be this function's last
    # early exit — everything below it ran straight through — so a refusal sited
    # further down leaves persistent side effects behind for a resume that never
    # happened: the `run-resume` journal entry, and the re-stamped integrity pin.
    # The pin is the one that bites. `write_trusted_config_digest` below writes the
    # exact file the NEXT resume reads back as `pinned`, so re-baselining it on a
    # refusal inverts the advisory: it fires on the attempt that stopped and goes
    # silent on the attempt that actually armed an engine. The re-stamp's own
    # justification — that the engine this process is about to arm re-reads the
    # config from there — is false on a path that arms nothing.
    #
    # No earlier than here either: `_launch_profiles` and `_trusted_config_digest`
    # above both raise SystemExit on a bad profile, and clearing ahead of them would
    # destroy the operator's lodged request on a resume that then aborts. This window
    # is the only one past every raise site and ahead of both writes — and it is
    # still before write_pid, the constraint that governs correctness: the moment the
    # pid lands the engine is "live" and a lingering request becomes honorable.
    if runs.clear_graceful_stop(run_dir):
        print(
            f"run {run_dir.name}: discarded a stale stop request before resuming",
            file=sys.stderr,
        )
    elif runs.graceful_stop_requested(run_dir):
        # The clear is never-raise by contract (five callers depend on that), so it
        # answers False for "nothing was pending" and "could not remove it" alike.
        # Re-read to tell them apart: a request that survived the clear would be
        # consumed at the very first item boundary and re-stop the run, and because
        # the print above never fired the operator would see no reason why — then
        # resume again, to the same end.
        print(
            f"run {run_dir.name}: a stale stop request could not be discarded "
            f"({runs.STOP_REQUEST_FILE} is not removable); resuming would stop again "
            "at the first item. Remove it and retry.",
            file=sys.stderr,
        )
        return 1
    # #461 point 4, human-present half. A resume IS a deliberate human choice, so
    # the on-disk config is re-blessed (new_digest is re-stamped below) and the run
    # proceeds — the auto-sweep child is the only path that refuses. But the issue's
    # real complaint is that the change is SILENT, so say it out loud: a session may
    # have rewritten the verify commands / launch binary / plugin allowlist while
    # the operator was away, and `resume` is the moment they can still look.
    # Deliberately no --allow-config-change flag: a refuse-by-default gate here
    # would break resume-to-fix-a-setting, which is a supported workflow.
    #
    # ADVISORY, not a control, and the asymmetry with the gate is deliberate: the
    # auto-sweep refusal in `_sweep_factory` baselines off a digest threaded in
    # MEMORY from launch (see cmd_run/the compose_resume call below), which nothing
    # on disk can reach at all. This one has to survive the pause, so it is read
    # back — and since #498 from the run's out-of-tree state dir rather than from
    # <project>/.waves/loop/runs/<id>/state.json, which is inside the very tree the
    # digest exists to police. It used to be readable there: a session that
    # rewrote policy.toml could blank the field in the same breath and silence this
    # warning (blank sufficed — the bool() guard reads "" as no prior pin), so the
    # advisory caught the incidental change and never the deliberate one.
    #
    # The legacy fallback, for one release: a run PAUSED under the old code has no
    # file in the state root, and its baseline is in state.json and nowhere else.
    # `None` from the reader means exactly that "no file" — distinct from an empty
    # file, which is a real answer of "no baseline" and must NOT reopen the tree —
    # so the fallback fires only for those runs, and the re-stamp below migrates
    # them on this very resume. Empty either way keeps its meaning: no prior pin,
    # no warning.
    #
    # A `None` that is a read FAULT rather than absence (DW-467) takes the same
    # fallback — the decision is unchanged — but not silently: the fallback is the
    # session-writable copy, so a planted FIFO or garbage bytes at the out-of-tree
    # path would otherwise quietly hand the comparison back to the tree it polices.
    # Printed ahead of the fallback's own verdict, so an operator who sees no
    # config-change warning below knows what that silence was measured against.
    pinned, digest_fault = runs.read_trusted_config_digest(project, run_dir.name)
    if digest_fault is not None:
        print(
            f"warning: run {run_dir.name}: the trusted host-exec config baseline could"
            f" not be read ({digest_fault}); falling back to the copy in state.json,"
            " which the driven session can rewrite — a changed-config warning may be"
            " missing below",
            file=sys.stderr,
        )
    if pinned is None:
        pinned = state.trusted_config_digest
    security_config_changed = bool(pinned) and new_digest != pinned
    # The recorded code root against the one THIS process just loaded. Resume
    # re-reads config.yaml, so a `repo_root:` key added, changed or removed while the
    # run was paused re-points the engine at a different git tree — `compose_resume`
    # below builds the Workspace off `paths`, not off state.json. The persisted
    # mirror is what `runs.rearm_escalation` reads back OUT OF PROCESS
    # (`RunState.code_root`), so leaving it at its launch value makes the two readers
    # disagree exactly when the config moved: `resolve` would advance the attempt
    # baseline in the old tree while the resumed engine resets and measures in the
    # new one. Re-stamped below, with the snapshot and the digest.
    #
    # An exact string compare, deliberately, with no canonicalization: both sides are
    # `str(paths.repo_root)` off `bmadconfig.load_paths`, which resolves every member
    # or raises, so they are spelled the same way whenever they name the same tree.
    # The `bool(state.repo_root)` guard is what keeps a legacy state.json — written
    # before the field existed, and read back as "" — out of the comparison: it is a
    # missing value, not a divergent one, and the re-stamp migrates it silently.
    #
    # `code_root_restamp_pending` is deliberately NOT part of this compare. That marker
    # is a RECORD DEBT — a move `runs.restamp_code_root` already persisted whose
    # `rearm-code-root-restamped` record never landed — and not a move of its own: the
    # mirror it left behind already agrees with config, which is precisely why the
    # compare reads "no move". Counting it as one made resume warn that "the code root
    # has changed since this run started" on a resume whose tree IS the tree the run
    # started in, and discharged the owed record with a `run-resume` boolean that
    # carries no root at all — so an operator who edited `repo_root:` between the failed
    # append and the resume had the owed A→B row answered by a row describing a
    # different move, unreconstructable after the fact. The debt is discharged just
    # below, on its own line, under the root the marker still names.
    code_root_changed = bool(state.repo_root) and state.repo_root != str(paths.repo_root)
    fields: dict[str, object] = {
        # Scalars only, per the note above: a bool records THAT the pinned surface
        # moved without journaling a command, a binary path or a plugin name.
        "security_config_changed": security_config_changed,
        # Same treatment, same reason: a bool, never either path. `diagnose` renders
        # the split as a presence flag for exactly this reason (`repo_root_diverges`).
        "code_root_changed": code_root_changed,
        "was_paused": state.paused_reason,
        "cache_read_weight": pol.limits.cache_read_weight,
        # Compare JSON-normalized, the way save_state persists it: to_dict()
        # returns TUPLES (verify.commands, extra_args, plugins.enabled) where the
        # reloaded snapshot has lists, so a plain != reports "changed" on every
        # resume — including one where policy.toml was never touched.
        "policy_changed": bool(state.policy_snapshot)
        and json.dumps(new_snapshot, sort_keys=True)
        != json.dumps(state.policy_snapshot, sort_keys=True),
    }
    prior_weight = state.cache_read_weight()
    if prior_weight != pol.limits.cache_read_weight:
        fields["cache_read_weight_was"] = prior_weight
    # Discharge an OWED record FIRST — before the `run-resume` row, before the pin
    # re-baseline below, and before `state.repo_root` is overwritten. The twin of
    # `runs.restamp_code_root`'s own discharge, same shape and same field names, and
    # the same at-least-once bargain: this is the FIRST fallible write of the resume,
    # so an append that raises here leaves journal, pin and run state intact — no
    # resume row to duplicate, no re-baselined pin to silence the host-exec advisory
    # on the retry, and a root and marker still exactly as the retry needs them.
    # First also puts it in
    # chronological order: the owed move pre-dates this resume, so its row must
    # pre-date the `run-resume` row too, the way the twin appends it. The marker is a
    # bare bool, so `state.repo_root` here — still the pre-overwrite value — is the
    # only surviving description of the root the unlanded record was owed for; once
    # the re-stamp below re-points it, that record can never be reconstructed. The one
    # residual is the twin's: a `save_state` that fails after a successful append
    # costs a duplicate — but TRUE — record on the retry, and a duplicate is
    # recoverable from the journal where a missing or a false record is not.
    if state.code_root_restamp_pending:
        journal.append(
            "rearm-code-root-restamped",
            repo=state.repo_root,
            code_root_changed=True,
        )
    journal.append("run-resume", **fields)
    if security_config_changed:
        # STATIC category names — the ones config_digest covers. A single sha256
        # cannot say which of them moved, and naming the actual old/new values is
        # exactly what this must not do (the mutation is attacker-controlled text
        # headed for an operator's terminal).
        print(
            f"warning: run {run_dir.name}: the host-exec config pinned at launch has"
            " changed — one or more of: verify commands, launch binary/args/env,"
            " plugin allowlist. Resuming trusts the config now on disk; re-read"
            f" {namespace.STATE_REL}/policy.toml and {namespace.STATE_REL}/profiles/ first if you did not"
            " make that edit.",
            file=sys.stderr,
        )
    if code_root_changed:
        # Loud, because the re-stamp below is not a repair: every sha this run already
        # recorded — each task's `baseline_commit`, its preserve refs, its unit
        # branches — names an object in the PREVIOUS tree, and nothing here can move
        # them. The re-stamp only stops the two readers from disagreeing about which
        # tree the run is in from here on; whether the new tree can honor those shas
        # is the operator's call, and this is the moment they can still make it.
        print(
            f"warning: run {run_dir.name}: the code root in the BMAD config has"
            " changed since this run started — the resumed engine works in the tree"
            " configured now, while the baselines, preserve refs and branches this run"
            " already recorded name objects in the previous one. Restore the previous"
            " `repo_root` value if you did not intend the move.",
            file=sys.stderr,
        )
    # Re-stamp: the snapshot must describe the policy THIS process enforces, for
    # its whole lifetime (Policy is loaded once here and frozen — the engine never
    # re-reads policy.toml). Enforcement already reads the reloaded `pol` (the
    # per-story budget in Engine._finish_commit, every SessionSpec), so leaving
    # the launch-time snapshot in place made every display — status, the TUI, the
    # run summary, the diagnose bundle — report a weight the budget was not using,
    # silently up to 10x off at the legal extremes (#189).
    # Deliberately NOT re-derived from the new policy: state.source/spec_folder/
    # run_type/epic_filter/target_branch stay pinned at launch (see RunState), so
    # a policy edit mid-run cannot switch a live run's mode or scope. The snapshot
    # can therefore disagree with those fields; that is correct, not a bug.
    state.policy_snapshot = new_snapshot
    # Re-baseline the integrity pin for the same reason and at the same moment: a
    # human typed `resume`, which re-blesses the config on disk, and the engine
    # this process is about to arm re-reads it from there. Leaving the launch
    # digest would make every auto-sweep after a legitimate resume-to-fix-a-setting
    # refuse — and would make the warning above fire forever, on every later resume.
    #
    # This is also the migration for a run paused under the old code: it read its
    # baseline out of state.json above, and from here on it has a file in the state
    # root, so the in-tree copy stops deciding anything for it.
    runs.write_trusted_config_digest(project, run_dir.name, new_digest)
    # ...and the in-tree secondary is re-stamped in the same breath, for the same
    # reason it is written at launch: the state root is keyed by the project's
    # RESOLVED PATH (`runs.project_tag`), so moving or renaming the project — a
    # documented operation, FEATURES.md states the GC half of it — keys the run
    # somewhere new and the file above becomes unreachable. Leaving only that copy
    # made a move silently retire the pin, and the advisory this whole guard exists
    # to raise never fired again. Writing both keeps the warning alive across a move
    # without making this copy authoritative: the reader prefers the out-of-tree
    # file whenever it exists, so a session that rewrites this one is still ignored
    # (which is #498, and its test still holds). Same for a changed
    # WAVES_STATE_DIR. Tampering that removes the out-of-tree file is a
    # different problem with no fix at equal privilege — #571.
    state.trusted_config_digest = new_digest
    # ...and the code root, for the same reason and at the same moment: this process
    # arms an engine against `paths.repo_root` (compose_resume -> Workspace), so that
    # is the tree `runs.rearm_escalation` must read back. Unconditional, so it also
    # migrates a pre-field state.json onto the root it was already using.
    state.repo_root = str(paths.repo_root)
    # The debt the marker carried was discharged on its own line above, under its own
    # root, ahead of the `run-resume` row — a `run-resume` boolean, which names no
    # root, can no longer stand in for it. Unconditional, and on the same write that
    # persists the resume: a separate write could land without the append and leave
    # the run owing a record it has already written, or clear the marker for a record
    # that never landed.
    state.code_root_restamp_pending = False
    # The one-resume `--accept-baseline` latch (DW-371): overwritten, never merged,
    # and only here — past every refusal above — on the write that persists this
    # resume, so a refused resume cannot arm it and a plain one always clears it.
    state.accept_baseline = accept_baseline
    # DW-446: reconcile the mint-time root identities — past every refusal above,
    # before the engine's first pinned write, and persisted by the `save_state`
    # below. A state.json written before they existed records them (one
    # `root-identity-recorded` per record); a record whose root still lstats as a
    # real directory with the same inode but a renumbered `st_dev` (a reboot or
    # remount) is re-bound (one `root-identity-rebound`). An inode mismatch is never
    # re-recorded — its pinned writes keep refusing.
    runs.reconcile_root_identities(state, run_dir, journal, project)
    state.clear_pause()
    runs.write_pid(run_dir)
    # Persist before the engine starts: status, the TUI and diagnose only ever
    # read state.json, and Engine._save() may not fire for minutes. write_pid
    # runs FIRST so no observer catches a window of "not paused + dead pid",
    # which runs.discover_runs classifies as INTERRUPTED.
    save_state(run_dir, state)
    # The adapter build + engine selection (sweep vs stories vs plain, from
    # persisted state) lives in runsetup; the re-stamp/pid/save bookkeeping above
    # stays here because its ordering is load-bearing. Engine/StoriesEngine/
    # SweepEngine and _make_adapters are handed in from this module's namespace so
    # the test suite's `monkeypatch.setattr(cli, "SweepEngine"/"Engine"/..., ...)`
    # still applies.
    return paths, state, pol, journal, new_digest, profiles, sweep_options


def _resume_paused_run(project: Path, run_dir: Path, *, accept_baseline: bool = False) -> int:
    """Resume a paused/interrupted run without holding its lock across execution.

    Also resolve's re-arm path, which never passes ``accept_baseline`` — its re-arm
    (`runs.rearm_escalation`) already advances the baseline to HEAD."""
    with state_lock(run_dir):
        # Cleanup removes the run under this same hold. A resume that resolved the
        # path before cleanup won must not let Journal/save_state recreate it after
        # its wait ends.
        if not runs.is_run(run_dir):
            print(f"no such run: {run_dir.name}", file=sys.stderr)
            return 1
        # Repeat the command's liveness decision after exclusion.  A concurrent
        # resume publishes its pid under this same hold, so the waiter refuses
        # instead of reloading the predecessor's old paused state and double-driving.
        if runs.engine_liveness(run_dir) == "alive":
            print(
                f"run {run_dir.name} is still live — resuming would double-drive it; stop it first",
                file=sys.stderr,
            )
            return 1
        prepared = _prepare_resume_locked(project, run_dir, accept_baseline=accept_baseline)
    if isinstance(prepared, int):
        return prepared
    paths, state, pol, journal, new_digest, profiles, sweep_options = prepared

    # Adapter construction and the engine lifetime are deliberately outside the
    # state hold.  The pid/state publication above makes a rival control command
    # observe this process as live while these unbounded operations proceed.
    composed = runsetup.compose_resume(
        project=project,
        paths=paths,
        run_dir=run_dir,
        state=state,
        policy=pol,
        journal=journal,
        sweep_factory=_sweep_factory(project, paths, new_digest),
        make_adapters=_make_adapters,
        engine_cls=Engine,
        stories_engine_cls=StoriesEngine,
        sweep_engine_cls=SweepEngine,
        profiles=profiles,
        sweep_options=sweep_options,
    )
    _warn_bypass_dropped(
        pol,
        project,
        (
            ("triage", "dev", "review")
            if state.run_type == "sweep"
            else ("dev", "review") if state.source == "stories" else _sprint_launch_roles(pol)
        ),
        profiles=profiles,
        journal=composed.journal,
    )
    summary = composed.engine.run()
    print(summary.render())
    return (
        ExitCode.FAILURE
        if summary.crashed and sweep_options is not None and sweep_options.only_ids is not None
        else ExitCode.OK
    )


def cmd_resume(args: argparse.Namespace) -> int:
    project = _project(args)
    try:
        run_dir = runs.resolve_run_dir(project, args.run_id)
    except runs.RunRefError as e:
        print(str(e), file=sys.stderr)
        return 1
    args.run_id = run_dir.name  # normalize so messages show the full id
    # Gate here, NOT in _resume_paused_run: that helper is also resolve's re-arm
    # path, which is already gated at resolve entry. A provably-live engine blocks
    # outright (the TUI warns in its confirm modal instead; the CLI has no confirm
    # step). 'unknown' warns but proceeds: resume is the recovery path that
    # rewrites engine.pid, so it must stay usable when liveness is unverifiable.
    live = runs.engine_liveness(run_dir)
    if live == "alive":
        print(
            f"run {args.run_id} is still live — resuming would double-drive it; stop it first",
            file=sys.stderr,
        )
        return 1
    if live == "unknown":
        print(
            f"run {args.run_id}: engine may still be live (unverifiable pid) — "
            "resuming could double-drive this run",
            file=sys.stderr,
        )
    # DW-204: sweep runs only, for a ledger that cannot currently be read — bytes
    # that do not decode, or (since DW-234) a read the OS refused; each names its
    # own repair (see the helper). Gated HERE and not in `_resume_paused_run`, for
    # the same reason the liveness block above is:
    # that helper is also resolve's re-arm path, which has already run its
    # interactive session and re-armed the escalation by the time it is reached, so
    # a refusal there would be a refusal after the side effects. Deliberately AFTER
    # the 'unknown' warning, so the recovery warning still prints; the live-engine
    # refusal above still wins outright and never probes the ledger.
    #
    # The probe lives in `runs` because two more entry points take it at their own
    # entries for that same reason (DW-229/DW-230): `cmd_resolve` below, and the
    # TUI's `_do_rearm`. One implementation, so the three cannot drift.
    if (refusal := runs.unreadable_sweep_ledger(project, run_dir)) is not None:
        print(refusal, file=sys.stderr)
        return ExitCode.FAILURE
    # No `verify.worktree_clean` gate here, unlike cmd_run / cmd_sweep — on purpose
    # (DW-360). Those gates prove a run LAUNCHES from a clean tree; resume continues
    # a run that already passed one. A dirty tree at resume is often the
    # sanctioned recovery itself: when a CRITICAL resolution's `redrive_base_ref`
    # is `HEAD`, the operator re-applies the corrected spec in the main checkout
    # UNCOMMITTED, because the re-drive reads that working tree as-is (see the
    # waves-resolve skill). A clean-tree gate would refuse exactly that resume.
    # Anything else the operator changed while the run sat paused is theirs to
    # commit or stash first.
    return _resume_paused_run(
        project, run_dir, accept_baseline=bool(getattr(args, "accept_baseline", False))
    )


def _confirm(question: str) -> bool:
    try:
        ans = input(f"{question} [y/N] ").strip().lower()
    except EOFError:
        return False
    return ans in ("y", "yes")


def _resolve_restore_patch(
    project: Path,
    run_dir: Path,
    story_key: str,
    args: argparse.Namespace,
    pol,
    state,
    task,
) -> tuple[str | None, str | None]:
    """Determine the intent-gap patch-restore latch (BMAD-METHOD #2564) for a re-arm.

    Precedence: the explicit ``--restore-patch`` flag (hand-driven recovery) wins;
    otherwise, on the interactive path, the resolve agent may have recorded a
    ``restore_patch`` field in resolution.json. The flag path is fully knowable
    before the interactive session, so cmd_resolve validates it FIRST and only
    falls back here post-session for the resolution.json read. Returns
    ``(latch, error)``: a validated absolute patch path to latch (None = ordinary
    from-scratch re-drive), or an error string when a supplied path is missing /
    outside the trusted roots, the run can't restore in place, or the restore
    input itself is corrupt (unreadable resolution.json, empty/non-string value)
    — the caller aborts strictly rather than silently re-driving from scratch
    when a restore was (or may have been) asked for.

    The run-state preconditions come from ``runs.validate_restore_latch``, shared
    verbatim with ``runs.rearm_escalation``; only the CLI-side halves live here —
    path resolution against ``--project`` and trusted-roots containment, which need
    the loaded bmad config."""
    raw = getattr(args, "restore_patch", None)
    if raw is not None and not raw.strip():
        # `--restore-patch ""` is a classic unset-shell-var slip. Treating it as
        # "no restore" would silently re-drive from scratch (and even mask a
        # restore the resolve agent recorded) — and a re-arm consumes the
        # escalation, so the dropped decision would be unrecoverable.
        return None, (
            "--restore-patch got an empty path (unset shell variable?) — pass the "
            "saved patch path, or drop the flag entirely for a from-scratch re-drive"
        )
    if raw is None and args.interactive:
        try:
            doc = resolve.read_resolution(run_dir, story_key)
        except resolve.ResolutionError as e:
            return None, (
                f"{e} — the recorded resolution (and any restore_patch decision in "
                "it) cannot be read; fix or delete the file, or re-run with "
                "--no-interactive [--restore-patch <path>] to decide by hand"
            )
        val = None if doc is None else doc.get("restore_patch")
        if val is not None:
            # the schema says omit the field for an ordinary resolution; an empty
            # or non-string value is a corrupted recorded decision, not "none"
            if not isinstance(val, str) or not val.strip():
                return None, (
                    f"resolution.json for {story_key} carries an invalid "
                    f"restore_patch value {val!r} — expected a non-empty path (or "
                    "the field omitted); fix the file, or re-run with "
                    "--no-interactive [--restore-patch <path>] to decide by hand"
                )
            raw = val
    if not raw:
        return None, None
    # The state-side preconditions (sentinel wedge, spec-less escalation, worktree
    # isolation) are the same set rearm_escalation enforces — run them here so an
    # unhonorable restore aborts BEFORE the interactive resolve session rather than
    # after. The live policy's isolation mode is the one input run state can't
    # carry, so pass it: a policy edit between escalation and resolve can't skew
    # the guard.
    err = runs.validate_restore_latch(
        state, task, story_key, worktree_isolation=pol.scm.isolation == "worktree"
    )
    if err is not None:
        return None, err
    # `.resolve()` on top of the shared normalizer: this is the one consumer that
    # feeds a containment check (spec_within_roots), which needs `..`/symlinks
    # collapsed. The resolved absolute path is what gets latched, so this stays a
    # bare `.resolve()` rather than `resolve_or_lexical`: a degraded, non-canonical
    # answer here could pass containment on the wrong directory.
    try:
        patch = verify.resolve_restore_path(raw, project).resolve()
    except (OSError, RuntimeError, ValueError) as e:
        return None, (
            f"cannot canonicalize the restore patch path {raw!r}: {e} — whether it "
            "lies inside or outside the project tree cannot be determined, so the "
            f"restore cannot be latched. Run `{namespace.PRODUCT} validate` for what this host "
            "is doing."
        )
    # Same trusted-roots shape as the frontmatter reconcile's spec_within_roots:
    # bmad-build-auto saves the patch under implementation_artifacts, and artifact
    # dirs configured OUTSIDE the project tree are a supported layout — a bare
    # is_relative_to(project) check would reject every legitimate restore there.
    try:
        paths = bmadconfig.load_paths(project)
    except bmadconfig.BmadConfigError as e:
        return None, f"cannot validate the restore patch path against the project config: {e}"
    if not patch.is_file() or not verify.spec_within_roots(patch, paths):
        return None, (
            f"restore patch {raw!r} is not a file under the project or its "
            "configured artifact roots — refusing to re-arm (fix the path, or "
            "re-run without a restore to re-drive from scratch)"
        )
    return str(patch), None


def _echo_rearm_events(run_dir: Path, before: list[dict[str, Any]] | None) -> None:
    """Surface the events a just-completed re-arm journaled: the residue of the restore
    attempt it abandoned — the `stale-restore-*` records AND `rearm-commits-probe-failed`,
    all written by `runs._stale_restore_residue` — and the `rearm-*` records the status
    flip, the advance and the re-stamp write. Split by PRODUCER, not on the prefix,
    because the prefix does not partition them: the commits probe's failure record is
    spelled `rearm-*` for the re-arm it degrades, not for the abandoned restore it
    measures. The commits pair is what the human must act on — nothing else will tell
    them — and it takes both, because `stale-restore-commits` is written only when the
    probe ANSWERED: without its twin, that record's absence reads as "clean" whether or
    not anyone could tell.

    Named for the re-arm, not for the stale restore: it began as a `stale-restore-*`
    echo and now carries the baseline family too, so a name from the narrower era
    would send the next re-arm record somewhere else.

    Routing lives in `runs.rearm_event_notice`, not here, because the TUI re-arms
    through the same journal and used to carry its own divergent copy of this chain —
    it surfaced three of the kinds and silently dropped the rest. One table, two
    renderings: this one appends the `next_step` imperative, the TUI omits it because
    it resumes in the same gesture.

    The baseline records are echoed because a failed advance means the re-drive
    rebuilds against the tree as it stood BEFORE the resolve, and the re-stamp then
    deliberately refuses to write a sha it did not earn. All of it is warn-only by
    contract (a project that is not a repo must not fail re-arm), so without an echo
    the whole degrade is journal-only — the invisibility #640(b) exists to end, not to
    relocate.

    This is abort-only diagnostic recovery: a raised call has no authoritative outcome,
    so the journal is the only place to recover records that were appended before the
    abort. It deliberately does not infer a resume hold for a call that did not succeed."""
    after = runs.journal_entries_or_none(run_dir)
    if before is None or after is None:
        # Either end of the diff is unreadable, so there is no trustworthy "new since
        # the re-arm" window. Skip rather than guess: this runs from a `finally`, and a
        # raise here would replace the `RearmError` the operator needs, while treating a
        # failed read as "no entries seen" would replay the whole journal as new. The
        return
    for entry in after[len(before) :]:
        notice = runs.rearm_event_notice(entry)
        if notice is None:
            continue
        severity, message, next_step = notice
        tail = f"; {next_step}" if next_step else ""
        print(f"{severity}: {message}{tail}", file=sys.stderr)


def _echo_rearm_notices(notices: tuple[runs.RearmNotice, ...]) -> None:
    """Render a successful re-arm's authoritative notices in append order."""
    for notice in notices:
        tail = f"; {notice.next_step}" if notice.next_step else ""
        print(f"{notice.severity}: {notice.message}{tail}", file=sys.stderr)


def cmd_resolve(args: argparse.Namespace) -> int:
    from .model import PAUSE_ESCALATION, Phase

    project = _project(args)
    try:
        run_dir = runs.resolve_run_dir(project, args.run_id)
    except runs.RunRefError as e:
        print(str(e), file=sys.stderr)
        return 1
    args.run_id = run_dir.name  # normalize so echoed hints show the full id
    # Ahead of EVERY side effect, not delegated to _resume_paused_run's gate:
    # this flow launches the interactive resolve session and re-arms the
    # escalation before it reaches that helper, and refusing after either
    # leaves the run re-armed-but-not-running (or a whole agent conversation
    # thrown away). Same rule, same message shape as the resume gate.
    if runs.run_id_aliases_control_session(run_dir.name):
        print(
            f"run {run_dir.name}: cannot resolve — its agent session name "
            f"({runs.session_name(run_dir.name)}) is the control session's own, so "
            "re-arming and resuming it would take over the live control session "
            "(ids of this shape are now refused at creation; this run predates "
            "that). The run directory and any worktree are intact: recover the "
            f"work by hand, then remove the run with `{namespace.PRODUCT} delete "
            f"{run_dir.name}` — stop and delete do not touch any session under "
            "this name",
            file=sys.stderr,
        )
        return 1
    state = load_state(run_dir)
    if state.paused_stage != PAUSE_ESCALATION:
        print(
            f"run {args.run_id} is not paused at an escalation "
            f"(stage: {state.paused_stage or 'none'})",
            file=sys.stderr,
        )
        return 1
    # Not a cleanup path, so the "unknown must not block" invariant does not apply:
    # an unverifiable-but-live pid must not be re-driven. A provably-live engine
    # always blocks (--force never bypasses it); unknown blocks unless the operator
    # vouches with --force — `stop` cannot verify or clear an unverifiable pid, so
    # without an escape hatch a squatted pid would lock resolve out forever.
    live = runs.engine_liveness(run_dir)
    if live == "alive":
        print(f"run {args.run_id} is still live — stop it first", file=sys.stderr)
        return 1
    if live == "unknown":
        if not args.force:
            print(
                f"run {args.run_id}: engine may still be live (unverifiable pid) — "
                "refusing to re-arm. Confirm the engine process is gone, then re-run "
                "with --force (`stop` cannot verify or clear an unverifiable pid).",
                file=sys.stderr,
            )
            return 1
        print(
            f"run {args.run_id}: engine may still be live (unverifiable pid) — "
            "proceeding anyway (--force)",
            file=sys.stderr,
        )
    story_key = args.story or state.paused_story_key
    task = state.tasks.get(story_key) if story_key else None
    if story_key is None or task is None or task.phase != Phase.ESCALATED:
        print(f"no escalated story to resolve in run {args.run_id}", file=sys.stderr)
        return 1

    # DW-204/DW-229: the same probe `cmd_resume` takes, taken here at resolve's own
    # entry. `_resume_paused_run` cannot carry this gate for resolve — by the time
    # this flow reaches it the interactive session has run and `runs.rearm_escalation`
    # has spent the escalation, so a refusal there is a refusal after the side
    # effects. LAST in this gate block, not first: the refusals above answer "this
    # gesture does not apply to this run at all" (alias, not paused at an escalation,
    # live engine, no escalated story) and must not be displaced by a ledger-repair
    # steer that would not help. Mirrors `cmd_resume`, where the live-engine refusal
    # also wins outright and the ledger gate follows it.
    if (refusal := runs.unreadable_sweep_ledger(project, run_dir)) is not None:
        print(refusal, file=sys.stderr)
        return ExitCode.FAILURE

    # DW-386: adopt the kept branch instead of re-arming. Behind every gate above —
    # the same gates, in the same order, as the re-arm path — and ahead of the
    # interactive session, which adopting never runs.
    if getattr(args, "adopt_branch", False):
        return _resolve_adopt(args, project, run_dir, state, task, story_key)

    pol = policy_mod.load(_policy_path(project))

    # intent-gap patch-restore latch (#2564), explicit-flag path: everything about
    # it (isolation mode, path containment) is knowable NOW — validate before the
    # interactive resolve session, not after a whole agent conversation the abort
    # would throw away. The resolution.json path can only be validated
    # post-session (below); build_context tells the agent up front when a restore
    # can't be honored so it never negotiates one.
    restore_patch: str | None = None
    if args.restore_patch is not None:
        restore_patch, err = _resolve_restore_patch(
            project, run_dir, story_key, args, pol, state, task
        )
        if err is not None:
            print(err, file=sys.stderr)
            return 1

    # DW-11: whether THIS gesture accepted a resolution, which is what gates the
    # `escalations_resolved_upto` watermark in `runs.rearm_escalation`. False here
    # covers `--no-interactive` deliberately: that path accepted nothing IN THIS
    # GESTURE (the human may have fixed the spec by hand, but nothing recorded which
    # escalations that answered), so the next cycle shows everything — today's
    # behavior, and the safe direction. Not derived from `resolution.json`: the marker
    # survives the re-arm that consumed it, so its presence says nothing about this
    # gesture.
    resolution_recorded = False
    if args.interactive:
        # The interactive session uses the CURRENT CLI project as cwd. Its code root
        # must come from the CURRENT config too: both can have moved since state.json
        # was written. This is best-effort observation only; the mandatory config
        # re-read after the human conversation remains the authority for re-arm.
        #
        # Read BEFORE `_make_adapters` so the refusal below can precede it. Ordering
        # only, no new failure mode: `load_paths` is a read, and the arm that cannot
        # read degrades exactly as it did when it sat lower.
        try:
            pre_session_paths = bmadconfig.load_paths(project)
        except (bmadconfig.BmadConfigError, OSError):
            pre_session_code_root = state.code_root
        else:
            pre_session_code_root = pre_session_paths.repo_root
            # Refuse the unsupported config BEFORE the interactive session, not only
            # after it. Both inputs are already in hand here — `pol` was loaded at the
            # top of this function and is being read for `isolation` two calls below —
            # so the late refusal alone let an operator build adapters, converse with a
            # full agent session and answer the re-arm prompt, only to be handed rc 1
            # for a configuration knowable before any of it. `cmd_run` and `cmd_sweep`
            # refuse the same config before provisioning anything; this restores the
            # parity, and honours the rule the restore latch states one screen down
            # ("validate before the interactive resolve session, not after a whole
            # agent conversation the abort would throw away"). Ahead of the adapter
            # build for the same reason `cmd_run` puts it ahead of the queue and
            # worktree-clean gates: this one says the configuration cannot run at all,
            # so an adapter fault reported first would send the operator at the wrong
            # problem — and would be refused again anyway.
            #
            # It does NOT replace the refusal after the confirm: that one re-reads the
            # config, which is the authority for the re-arm and is the only check the
            # `--no-interactive` path reaches. This is a strictly earlier exit on the
            # same predicate, so an operator who declines still gets no config lecture.
            if (rc := _reject_isolation_conflict(pre_session_paths, pol)) is not None:
                return rc
        adapters = _make_adapters(project, run_dir, pol)
        dev_cfg = pol.adapter.resolved("dev")
        model = dev_cfg.model
        effort = dev_cfg.effort
        _ctx_path, withheld, unreadable = resolve.build_context(
            state,
            run_dir,
            story_key,
            isolation=pol.scm.isolation,
            project_root=project,
            code_root=pre_session_code_root,
        )
        if pre_session_code_root != project:
            print(
                f"warning: resolve session stays project-rooted at {project.as_posix()!r}; "
                "code fixes and commits belong in the run's code root at "
                f"{pre_session_code_root.as_posix()!r}",
                file=sys.stderr,
            )
        print(f"launching resolve agent for {story_key} — converse, fix the spec, then exit…")
        try:
            produced = resolve.run_session(
                adapters["dev"],
                project,
                run_dir,
                story_key,
                # This CALL precedes the re-arm below, so the generation it passes is
                # the one still on disk — the pre-bump value. Not an ordering of the
                # read: `rearm_escalation` reloads state and bumps its own copy, so
                # this `task` object reads the same either way.
                generation=task.generation,
                model=model,
                effort=effort,
            )
        except NotImplementedError:
            print(
                "the dev adapter has no interactive session mode — fix the spec by hand, "
                f"then: {namespace.PRODUCT} resolve {args.run_id} --no-interactive",
                file=sys.stderr,
            )
            return 1
        # DW-11, second half. `produced` alone is not enough to record coverage,
        # because the watermark `rearm_escalation` stamps is `len(task.sessions)` — it
        # covers every recorded session, INCLUDING the ones whose artifacts this walk
        # could not read. `_gather_escalations` degrades on those by design (an
        # observation path must not raise out of an interactive command), but the
        # watermark turns that transient silence into a durable claim: the next cycle
        # reads the file fine and withholds it as already answered. So a skipped
        # artifact withholds COVERAGE instead. The cost is one repeated presentation;
        # the alternative cost is an escalation nobody ever sees.
        resolution_recorded = bool(produced) and not unreadable
        # DW-11. Reported to the operator, never into `context.json`: filtering the
        # agent's list silently would trade one misleading surface for another — the
        # human would have no way to tell "nothing else was ever raised" from "the rest
        # is hidden". Worded for what the code can prove: these entries were PRESENTED
        # to an earlier resolve cycle that recorded a resolution — not that any
        # particular one of them was individually answered.
        #
        # Printed here rather than beside the context build, because until
        # `run_session` returns without `NotImplementedError` this adapter is not known
        # to support an interactive session at all — and an operator whose command is
        # about to fail must not be told escalations were withheld from an agent that
        # never launched.
        if withheld:
            print(
                f"{withheld} earlier escalation(s) for {story_key} were not shown to the "
                "agent: they were presented to an earlier resolve cycle that recorded a "
                "resolution"
            )
        if produced and unreadable:
            # Only when a resolution WAS produced: with nothing recorded the watermark
            # would not have advanced anyway, and reporting a withheld coverage the
            # operator never had is noise. Counts, not paths — the operator's action is
            # the same for one unreadable artifact as for five, and the run-dir names
            # are not theirs to chase.
            print(
                f"{unreadable} session artifact(s) for {story_key} could not be read, so "
                "this resolution was NOT recorded as covering the escalations they hold "
                "— the next resolve will show every escalation for this story again",
                file=sys.stderr,
            )
        if not produced:
            print(
                f"no resolution recorded for {story_key} (agent did not write resolution.json)",
                file=sys.stderr,
            )
        # `pol` was read BEFORE a session that blocks on a human conversation of
        # arbitrary length, and everything below keys the re-arm on its isolation mode
        # while `_resume_paused_run` at the bottom of this function re-reads policy for
        # the engine. An edit made while the agent was open would therefore re-arm under
        # the old answer and re-drive under the new one — `none -> worktree` re-arms
        # treating the main-checkout edit as reachable, emits no hold, and then mounts a
        # fresh worktree cut from git that cannot see it: the escalation is spent and the
        # story re-wedges. Re-read so the re-arm and the engine agree, which is also what
        # lets the reachability gate below fire against the mode actually in force.
        # Unguarded, exactly like the first load above: nothing has been mutated yet, so
        # an unreadable policy aborts before the re-arm rather than guessing a mode — and
        # `resolution.json` is already on disk, so `--no-interactive` resumes the work.
        isolation_before_session = pol.scm.isolation
        pol = policy_mod.load(_policy_path(project))
        if pol.scm.isolation != isolation_before_session:
            print(
                f"warning: [scm] isolation changed "
                f"{isolation_before_session} -> {pol.scm.isolation} during the resolve "
                "session; re-arming against the new mode (the agent was told where the "
                "correction had to land under the old one)",
                file=sys.stderr,
            )

    # resolution.json restore latch: only exists after the session ran, so this
    # arm of the validation cannot be hoisted above it.
    if args.restore_patch is None:
        restore_patch, err = _resolve_restore_patch(
            project, run_dir, story_key, args, pol, state, task
        )
        if err is not None:
            print(err, file=sys.stderr)
            return 1

    # confirm-then-resume (args.resume: None = ask, True = auto, False = re-arm only)
    if args.resume is None and not _confirm(f"re-arm {story_key} and resume run {args.run_id}?"):
        print("cancelled — run is still paused at the escalation")
        return 0
    # The code root `runs.rearm_escalation` reads back OUT OF PROCESS
    # (`RunState.code_root`). `_resume_paused_run` re-stamps it because the engine it
    # arms works in `paths.repo_root` — but on THIS path the re-arm runs FIRST, so that
    # re-stamp lands too late to aim it: a `repo_root:` key added, changed or removed
    # while the run was paused split the two readers exactly the way the re-stamp exists
    # to prevent — the attempt baseline advanced (and `baseline_revision` re-stamped) in
    # the tree the run has LEFT, while the engine resumed at the bottom of this function
    # reset and measured in the new one, with no error anywhere.
    #
    # AFTER the confirm, deliberately: a cancelled resolve writes nothing, so the
    # divergence is still there for `resume` to report on its own terms.
    try:
        paths = bmadconfig.load_paths(project)
    except (bmadconfig.BmadConfigError, OSError) as e:
        paths = None
        # An observation, so it degrades: without the config this process cannot NAME
        # the tree, and re-pointing the mirror at a guess is the one outcome worse than
        # leaving it alone. The re-arm then reads the root the run recorded — precisely
        # what it did before this seam existed — and the default flow's
        # `_resume_paused_run` raises on the same config moments later. Reported, never
        # silent: the write this could not aim is the whole subject of the block above.
        print(
            f"warning: run {args.run_id}: cannot read the project config to confirm the "
            f"code root ({e}) — re-arming against the root this run recorded",
            file=sys.stderr,
        )
    else:
        if args.interactive and paths.repo_root != pre_session_code_root:
            print(
                "error: the code root changed during the resolve session from "
                f"{pre_session_code_root.as_posix()!r} to {paths.repo_root.as_posix()!r}; "
                "the agent's guidance no longer names the tree the re-drive would use. "
                "No re-arm was performed; reconcile the code change, then run resolve again.",
                file=sys.stderr,
            )
            return 1
        # The SAME refusal `_resume_paused_run` makes, hoisted ahead of both writes
        # below — because aiming the mirror at the tree config.yaml names is only
        # correct for a configuration the orchestrator will actually run, and this is
        # not one. `worktree_isolation_conflict` fires exactly when `repo_root` does
        # not contain the project beside `isolation = "worktree"` (a disjoint layout;
        # DW-379 supports the nested one), so on that config the re-stamp
        # persisted the unsupported root and `rearm_escalation` then advanced the
        # attempt baseline (and re-stamped the spec's `baseline_revision`) against it
        # — all of it before `_resume_paused_run` at the bottom of this function
        # reached the refusal and returned 1.
        #
        # Everything about that was spent: the operator was told "re-armed <story>"
        # and then refused, and the story was no longer ESCALATED, so `resolve` — which
        # requires an escalation — could not re-run to correct it. The escalation was
        # burned on a gesture the orchestrator had already decided it would not honor.
        #
        # It also reached a configuration the baseline advance is not built for:
        # `runs` reads the code tree's HEAD, which is right in place and superseded
        # under isolation, but a disjoint isolated layout never runs at all — a path
        # that mutates first and refuses second made that configuration reachable, in
        # the one function that had ruled it out.
        #
        # Ordered after the confirm with the re-stamp, not before it: a cancelled
        # resolve still writes nothing, and an operator who declines is not owed a
        # config lecture about a gesture they did not make.
        if (rc := _reject_isolation_conflict(paths, pol)) is not None:
            return rc
    before_entries = runs.journal_entries_or_none(run_dir)
    outcome: runs.RearmOutcome | None = None
    try:
        with state_lock(run_dir):
            # The pre-session checks intentionally stay lock-free; this is the
            # mutation boundary, so repeat every state/liveness precondition from
            # the snapshot left by the preceding writer before restamping anything.
            fresh_state = load_state(run_dir)
            if fresh_state.paused_stage != PAUSE_ESCALATION:
                print(
                    f"run {args.run_id} is not paused at an escalation "
                    f"(stage: {fresh_state.paused_stage or 'none'})",
                    file=sys.stderr,
                )
                return 1
            fresh_live = runs.engine_liveness(run_dir)
            if fresh_live == "alive":
                print(f"run {args.run_id} is still live — stop it first", file=sys.stderr)
                return 1
            if fresh_live == "unknown" and not args.force:
                print(
                    f"run {args.run_id}: engine may still be live (unverifiable pid) — "
                    "refusing to re-arm. Confirm the engine process is gone, then re-run "
                    "with --force (`stop` cannot verify or clear an unverifiable pid).",
                    file=sys.stderr,
                )
                return 1
            fresh_task = fresh_state.tasks.get(story_key)
            if fresh_task is None or fresh_task.phase != Phase.ESCALATED:
                print(f"no escalated story to resolve in run {args.run_id}", file=sys.stderr)
                return 1
            if fresh_task.generation != task.generation:
                print(
                    f"the escalation for {story_key} changed while resolve was in progress "
                    "— not re-arming",
                    file=sys.stderr,
                )
                return 1
            if paths is not None:
                if (moved := runs.restamp_code_root(run_dir, paths.repo_root)) is not None:
                    print(f"warning: {moved}", file=sys.stderr)
            outcome = runs.rearm_escalation(
                run_dir,
                story_key,
                restore_patch=restore_patch,
                isolated_redrive=pol.scm.isolation == "worktree",
                resolution_recorded=resolution_recorded,
                # The tree this invocation is acting in, which is also the tree
                # `build_context` published a `spec_file` from. `state.project` is where the
                # run was LAUNCHED and nothing re-stamps it, so a moved project would have
                # the agent edit one file and the re-arm flip another.
                project_root=project,
            )
    except runs.RearmError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    finally:
        # In the `finally`, not after the `try`: `_stale_restore_residue` journals
        # BEFORE the re-stamp block that raises `RearmError`, so on that path the
        # records were already written and returning early threw them away — including
        # the commits PAIR (`stale-restore-commits` when the probe answered,
        # `rearm-commits-probe-failed` when it could not), whose whole point is that
        # nothing else will tell the human. An abort is when that residue matters most: the
        # re-arm half-ran and the operator has to decide what to do with the tree.
        if outcome is None:
            _echo_rearm_events(run_dir, before_entries)
    assert outcome is not None
    _echo_rearm_notices(outcome.notices)
    print(
        f"re-armed {story_key}"
        + (" (restoring the attempted change for review)" if restore_patch else "")
    )
    if args.resume is False:
        print(f"resume when ready: {namespace.PRODUCT} resume {args.run_id}")
        return 0
    if outcome.hold_resume:
        # The re-arm SUCCEEDED — the task is armed and persisted — so this is a 0, and it
        # stops the GESTURE, not the run. `--resume` does not override it: that flag
        # skips the confirmation prompt, while the hold is not a question but a proof
        # that resuming now spends the escalation on a session that cannot route
        # (`runs.rearm_holds_the_resume`). The escape hatch is the command this prints,
        # which the operator reaches the moment their correction is committed.
        print(
            "NOT resuming in this gesture — the correction has to reach the re-drive "
            f"first (see the warning above). Then: {namespace.PRODUCT} resume {args.run_id}"
        )
        return 0
    from .tui import launch  # import-safe: launch.py has no textual imports

    if launch.in_ctl_session():
        # We are inside the TUI's control-session window the user is attached to.
        # Tell them, hand the terminal back, and let the engine run on here — a
        # tmux pane keeps running after its client detaches.
        print(
            f"✓ resuming run {args.run_id} in the background — "
            f"watch it in the TUI, or: {namespace.PRODUCT} attach {args.run_id}"
        )
        launch.detach_client()
    return _resume_paused_run(project, run_dir)


def _resolve_adopt(
    args: argparse.Namespace,
    project: Path,
    run_dir: Path,
    state: RunState,
    task: StoryTask,
    story_key: str,
) -> int:
    """`resolve --adopt-branch` (DW-386): finish an escalated story from its kept
    worktree branch instead of re-driving it from scratch.

    `cmd_resolve` has already run the shared gates (alias, paused-at-escalation,
    liveness, ESCALATED story, sweep ledger). This adds the kept-work preconditions,
    confirms, re-checks everything under the run lock and hands the state
    transaction to `runs.adopt_escalated_branch`; the resumed engine then commits
    and merges the branch through its COMMITTING recovery arm. No interactive
    session runs, and review, the `[verify]` commands and `pre_commit_gate`
    workflows are NOT re-run."""
    from .model import PAUSE_ESCALATION, Phase

    if (refusal := runs.adopt_refusal(state, task, story_key)) is not None:
        print(f"error: {refusal}", file=sys.stderr)
        return 1
    print(
        f"warning: adopting {task.branch} bypasses automated checks for {story_key} — "
        "review, the [verify] commands and pre_commit_gate workflows are not re-run; the "
        "kept branch is committed and merged as-is on your word that it is finished",
        file=sys.stderr,
    )
    if args.resume is None and not _confirm(
        f"adopt kept branch {task.branch} of {story_key} and resume run {args.run_id}?"
    ):
        print("cancelled — run is still paused at the escalation")
        return 0
    try:
        with state_lock(run_dir):
            # Same mutation-boundary re-check as the re-arm path: the checks above
            # ran lock-free, so repeat them against the state left by the last writer.
            fresh_state = load_state(run_dir)
            if fresh_state.paused_stage != PAUSE_ESCALATION:
                print(
                    f"run {args.run_id} is not paused at an escalation "
                    f"(stage: {fresh_state.paused_stage or 'none'})",
                    file=sys.stderr,
                )
                return 1
            fresh_live = runs.engine_liveness(run_dir)
            if fresh_live == "alive":
                print(f"run {args.run_id} is still live — stop it first", file=sys.stderr)
                return 1
            if fresh_live == "unknown" and not args.force:
                print(
                    f"run {args.run_id}: engine may still be live (unverifiable pid) — "
                    "refusing to adopt. Confirm the engine process is gone, then re-run "
                    "with --force (`stop` cannot verify or clear an unverifiable pid).",
                    file=sys.stderr,
                )
                return 1
            fresh_task = fresh_state.tasks.get(story_key)
            if fresh_task is None or fresh_task.phase != Phase.ESCALATED:
                print(f"no escalated story to resolve in run {args.run_id}", file=sys.stderr)
                return 1
            if fresh_task.generation != task.generation:
                print(
                    f"the escalation for {story_key} changed while resolve was in progress "
                    "— not adopting",
                    file=sys.stderr,
                )
                return 1
            branch = runs.adopt_escalated_branch(run_dir, story_key)
    except runs.RearmError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    print(f"adopted {branch} for {story_key} — it commits and merges on resume")
    if args.resume is False:
        print(f"resume when ready: {namespace.PRODUCT} resume {args.run_id}")
        return 0
    from .tui import launch  # import-safe: launch.py has no textual imports

    if launch.in_ctl_session():
        print(
            f"✓ resuming run {args.run_id} in the background — "
            f"watch it in the TUI, or: {namespace.PRODUCT} attach {args.run_id}"
        )
        launch.detach_client()
    return _resume_paused_run(project, run_dir)


def _print_parked(parked: list[operatoractions.ParkedStory]) -> int:
    if not parked:
        print("no stories are awaiting operator actions")
        return 0
    print(f"{len(parked)} story/stories awaiting operator actions:\n")
    for p in parked:
        # `resumable` first, for the same reason `cmd_confirm` tests it first: an
        # interrupted confirmation drifts, so reading `drift()` alone would label
        # a story confirm will happily finish as NOT CONFIRMABLE.
        if p.resumable:
            suffix = "  — ALREADY SIGNED OFF: re-run confirm to advance the board"
        else:
            drift = p.drift()
            suffix = f"  — NOT CONFIRMABLE: {drift}" if drift else ""
        # `commit` is derived provenance and legitimately empty for a record not
        # yet in any commit (NO_VCS, or a crash before the park's commit landed)
        # — render nothing rather than a dangling "commit " fragment.
        provenance = f", commit {p.commit[:8]}" if p.commit else ""
        print(f"  {p.story_key} (parked {p.parked_at}{provenance}){suffix}")
        for i, action in enumerate(p.actions, 1):
            print(f"      {i}. {action}")
        print("")
    print(f"confirm one when its actions are done: {namespace.PRODUCT} confirm <story-key>")
    return 0


def _reverify(project: Path, cwd: Path) -> str | None:
    """Re-run the project's deterministic verify commands, returning a failure
    reason or None when they all passed.

    Deliberately NOT `verify_commands_outcome`: that classifies into the engine
    loop's vocabulary (retry/fixable/escalate), and a CLI confirm has no attempt
    budget and no repair session to dispatch — only "the flip proceeds" or "it
    does not". The environment-fault reading IS reused, so a missing binary reads
    as the operator's environment rather than as their story having regressed."""
    pol = policy_mod.load(_policy_path(project))
    if not pol.verify.commands:
        print("note: --reverify: no [verify] commands are configured — nothing to re-run")
        return None
    print(f"re-running {len(pol.verify.commands)} verify command(s)...")
    for result in verify.run_verify_commands(pol, cwd):
        fault = verify.env_fault_reason(result, cwd)
        if fault is not None:
            return f"{result.command!r} could not run: {fault}"
        if result.returncode != 0:
            return f"{result.command!r} failed (rc {result.returncode}):\n{result.output_tail}"
    print("  verify commands passed")
    return None


def cmd_confirm(args: argparse.Namespace) -> int:
    """Complete a story parked at `awaiting-operator` once the human has carried
    out the external actions it owes (#335).

    Out of band by construction. The run that parked the story is long finished
    and its task is in a terminal phase with no legal transition, so this touches
    no run state at all — it writes the two things that DEFINE the story's
    completion (the spec and the board) and drops the park record that pointed at
    them. Nothing is re-driven: the agent-doable work was committed at park time,
    and re-running a session would redo finished work while the human's actions
    stayed outside the repo. `--reverify` is there for the case that matters —
    the external action may have changed what the tests see."""
    project = _project(args)
    try:
        paths = bmadconfig.load_paths(project)
    except bmadconfig.BmadConfigError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    parked = operatoractions.resolve(project, paths)
    if args.json:
        # Before any early return and before any prompt: --json IS the listing,
        # and nothing parked is a valid empty document, not a text line.
        machine.emit(confirm_document(parked))
        return 0
    if args.list:
        return _print_parked(parked)
    if not args.story_key:
        print(
            "error: specify a story key to confirm, or --list to see what is parked",
            file=sys.stderr,
        )
        return 2

    key = args.story_key
    story = next((p for p in parked if p.story_key == key), None)
    if story is None:
        print(
            f"error: {key} is not awaiting operator actions in this checkout. A park is "
            f"recorded under {operatoractions.RECORDS_REL.as_posix()}/ and travels with "
            f"the story's own commit, so if another machine's run parked it, pull the "
            f"branch that carries the park commit. `{namespace.PRODUCT} confirm --list` shows "
            f"what is parked here.",
            file=sys.stderr,
        )
        return 1
    if story.resumable:
        return _resume_confirmation(project, paths, args, story)
    drift = story.drift()
    if drift is not None:
        print(
            f"error: refusing to confirm {key}: {drift}. The park entry disagrees with the "
            f"committed state; `{namespace.PRODUCT} validate` reports the same drift. Nothing was "
            f"changed.",
            file=sys.stderr,
        )
        return 1
    spec = story.spec_path
    assert spec is not None  # drift() is non-None whenever the spec path is missing

    print(f"{key} owes {len(story.actions)} external action(s):\n")
    if args.yes:
        for i, action in enumerate(story.actions, 1):
            print(f"  {i}. {action}")
        print("")
    else:
        # Per action, not one blanket prompt: the whole failure this state exists
        # to prevent is a story marked done with some of its obligations quietly
        # unmet, and a single "all done? [y/N]" invites exactly that.
        for i, action in enumerate(story.actions, 1):
            if not _confirm(f"  {i}. {action}\n     done?"):
                print("cancelled — nothing was changed")
                return 0
        print("")

    if args.reverify:
        failure = _reverify(project, paths.repo_root)
        if failure is not None:
            print(
                f"error: --reverify failed, so {key} was NOT confirmed: {failure}",
                file=sys.stderr,
            )
            return 1

    return _apply_confirmation(project, paths, story, spec)


def _resume_confirmation(
    project: Path,
    paths: bmadconfig.ProjectPaths,
    args: argparse.Namespace,
    story: operatoractions.ParkedStory,
) -> int:
    """Finish a confirmation that was interrupted between its spec writes and its
    board write (see `ParkedStory.resumable`).

    Checked BEFORE the drift refusal, because to `drift()` this state looks like
    an ordinary stale entry ("its spec now says status: done") — so without this
    branch `confirm` refuses the one state re-running it exists to clear, and
    nothing else will ever drop the entry.

    Deliberately does NOT re-prompt and does NOT append a second audit section.
    The section already on disk IS the acknowledgment; asking again would have no
    honest meaning over a spec that already says `done`, and
    `append_operator_confirmation` accumulates rather than no-ops, so a second
    pass would have the audit trail claim two sign-offs for one event.

    `--reverify` still runs, because it is a gate the caller requested for THIS
    invocation rather than an acknowledgment of anything — its failure says "NOT
    advanced", since the confirmation itself already happened."""
    spec = story.spec_path
    assert spec is not None  # resumable requires a spec that read back as done
    print(
        f"{story.story_key} was already confirmed — its spec is signed off and reads "
        f"done, but the board and the park entry were left behind. Finishing that; "
        f"you will not be asked to acknowledge anything again.\n"
    )
    if args.reverify:
        failure = _reverify(project, paths.repo_root)
        if failure is not None:
            print(
                f"error: --reverify failed, so {story.story_key} was NOT advanced: {failure}",
                file=sys.stderr,
            )
            return 1
    return _land_confirmation(project, paths, story, spec, time.strftime("%Y-%m-%d"))


# Both refusals below land AFTER the audit section is on disk and both ask for a
# re-run, which appends a second one. Said out loud rather than left as a
# surprise: only the human can decide whether one sign-off should show as two.
_SECOND_SECTION_NOTE = (
    "Note: that re-run appends a SECOND `## Operator Confirmation` section — "
    "delete this one first if the audit trail should record a single sign-off."
)


def _apply_confirmation(
    project: Path,
    paths: bmadconfig.ProjectPaths,
    story: operatoractions.ParkedStory,
    spec: Path,
) -> int:
    """Write the confirmation: spec audit section, spec status, board, park entry.

    Ordered so a failure part-way is recoverable rather than stranded. The audit
    section goes first because it is the only record of what happened outside the
    repo and it does not change any gate. The park entry is dropped LAST, so
    anything that raises before it leaves the story findable and the command
    re-runnable — see `ParkedStory.resumable` for the state that leaves behind.

    A repeat between the section and the status write is the one case that does
    NOT round-trip cleanly: `append_operator_confirmation` accumulates rather than
    no-ops (a genuinely repeated confirmation — a spec reverted to the park status
    and signed off again — is a real event the audit trail must not lose), so a
    re-run after a failure *here* appends a second section for one event. That is
    a known gap, not the deliberate case the writer's docstring describes.

    It is not only a crash window either: the refusals below both END by asking
    for exactly that re-run, so the duplicate is the ORDINARY outcome of taking
    their advice. Both therefore say so — an unmentioned second sign-off in an
    audit trail is worse than a mentioned one, and the human is the only one who
    can decide whether the first record should stay.

    Repair-write doctrine: these writes RAISE rather than degrade, and this
    asserts the resulting STATE rather than trusting a return value. `confirm` is
    about to declare a story finished; a skipped write it did not notice would
    make it declare that falsely. The commit alone is best-effort — the files are
    the state, git history is the record of it."""
    today = time.strftime("%Y-%m-%d")
    if not devcontract.append_operator_confirmation(
        spec, story.actions, date=today, confine_root=project
    ):
        # The one False the writer returns: the spec is gone since `resolve` read
        # it. Fatal here — the audit section is the ONLY record of the part of
        # this story that happened outside the repository, and there is nothing
        # left to write a status onto either.
        print(
            f"error: {spec} disappeared before {story.story_key} could be confirmed — "
            f"nothing was changed and the park entry has been left in place.",
            file=sys.stderr,
        )
        return 1
    try:
        frontmatter.set_frontmatter_status(spec, "done", confine_root=project)
    except frontmatter.FrontmatterWriteError as e:
        print(
            f"error: {spec} carries a status this cannot rewrite, so {story.story_key} "
            f"was NOT confirmed: {e}. The audit section was appended; the board and the "
            f"park entry are untouched, so re-run `{namespace.PRODUCT} confirm {story.story_key}` "
            f"once the frontmatter is repaired. {_SECOND_SECTION_NOTE}",
            file=sys.stderr,
        )
        return 1
    # Read the FILE back, not the writer's return: `set_frontmatter_status`
    # returns False for "nothing to change" as well as for "already there", and
    # this is about to declare the story done. It also covers what no return
    # value can — an `atomic_replace` that landed somewhere else, a shape nobody
    # enumerated, a concurrent writer. Symmetric with the board half below, which
    # has always read itself back via `landed`.
    if frontmatter.status_of(frontmatter.read_frontmatter(spec)) != "done":
        print(
            f"error: {spec} still does not read status: done, so {story.story_key} was "
            f"NOT confirmed. The audit section was appended; the board and the park "
            f"entry are untouched. {_SECOND_SECTION_NOTE}",
            file=sys.stderr,
        )
        return 1
    return _land_confirmation(project, paths, story, spec, today)


def _land_confirmation(
    project: Path,
    paths: bmadconfig.ProjectPaths,
    story: operatoractions.ParkedStory,
    spec: Path,
    today: str,
) -> int:
    """The half of a confirmation that lives OUTSIDE the spec: advance the board,
    drop the park record, commit the set.

    Split out because it is exactly what an interrupted confirmation still owes.
    The spec half is already on disk in that case — audit section appended, status
    at `done` — and re-running it would append a second section for one event, so
    the resume path enters here instead of at :func:`_apply_confirmation`.

    A board row the writer refuses (``SprintStatusWriteRefused``) and one that
    otherwise did not reach ``done`` both exit 1 with the park entry kept, so a
    re-run after the operator repairs the board resumes here."""
    # The sole write path to the board, and an ordinary FORWARD move:
    # `awaiting-operator` sits immediately below `done` in STATUS_ORDER, so
    # confirming needs no exception to never-regress. Idempotent at `done`, which
    # is what lets a resume run it after a human fixed the board by hand.
    try:
        landed = sprintstatus.advance(paths.sprint_status, story.story_key, "done", now=today)
    except sprintstatus.SprintStatusWriteRefused as e:
        # The row is there and the writer cannot rewrite its shape (#842): name the
        # repair, and keep the park entry so the re-run below finishes the job.
        print(
            f"error: {spec} was updated but the board write was refused: {e}\n"
            f"The spec is already correct and signed off, and the park entry has been "
            f"left in place: after fixing that row, re-run "
            f"`{namespace.PRODUCT} confirm {story.story_key}` to finish without acknowledging "
            f"anything twice.",
            file=sys.stderr,
        )
        return 1
    if landed != "done":
        print(
            f"error: {spec} was updated but {paths.sprint_status} did not advance "
            f"{story.story_key} to done (it reads {landed!r}). Fix the board by hand, then "
            f"re-run `{namespace.PRODUCT} confirm {story.story_key}` — the spec is already correct "
            f"and signed off, and the park entry has been left in place, so the re-run "
            f"finishes what is left without asking you to acknowledge anything twice.",
            file=sys.stderr,
        )
        return 1
    # Resolve the record path BEFORE dropping it: the drop unlinks the file, and
    # a committed record's deletion must ride the confirm commit (#356) — the
    # record arrived in the park's commit, so leaving its removal uncommitted
    # would dirty the tree the next run's preflight refuses. `commit_paths`
    # skips the path when no record was ever committed (a legacy-index park).
    record = operatoractions.record_path(project, story.story_key)
    operatoractions.drop(project, story.story_key)
    # A GITIGNORED board is left OUT of the list rather than handed over and
    # forgiven (#577). `commit_paths` forces every operand literal, so `git add`
    # refuses an ignored one with rc 1 — and refuses the whole operand list with
    # it, staging nothing — which the swallow below then turns into a silent loss
    # of the other two. That is right for the board (a file git will not track has
    # no commit to ride; the status on disk is the value) and wrong for the spec
    # and the record, whose deletion in particular MUST land per the #356 note
    # above. #350's board carry makes a gitignored board an ordinary shape, so
    # this is the common park's exit and not an exotic one.
    try:
        board_ignored = verify.path_ignored(paths.repo_root, paths.sprint_status)
    except verify.GitError:
        board_ignored = False  # uncertainty keeps the board in: the older behavior
    # THE PUBLISHABLE-TARGET GUARD (DW-237), per operand and before any git runs.
    # `commit_paths` forces every operand LITERAL, so an operand replaced by a
    # DIRECTORY is handed to `git add` as a pathspec and staged RECURSIVELY —
    # an unrelated tree published under this `chore(operator):` message.
    # Family `"store"` at all three: the family names the validation POLICY, not
    # the file's role, and a spec, a board and a park record all want exactly
    # "a regular file is there" and nothing about their bytes.
    # PER OPERAND, like `decisions.apply_pre_answer`'s GATE TWO: a dropped one must
    # not sink its siblings, which is the whole point of the `board_ignored` drop
    # this joins.
    operands: list[Path] = [spec, record] if board_ignored else [spec, paths.sprint_status, record]
    survivors: list[Path] = []
    for path in operands:
        # The SAME resolve-then-guard the four carries take, imported rather than
        # re-spelled: one rule, one place it can drift from. Its resolve fold matters
        # here too — an operand `confirm` cannot even NAME must not be handed to git.
        refusal = _publication_refusal(path, "store")
        if refusal is None or refusal[0] == "target-absent":
            # An ABSENT operand STAYS (#356): `record` was unlinked by the drop a few
            # lines above, and its DELETION is exactly what must ride this commit —
            # `commit_paths` keeps a missing-but-TRACKED path for that reason and
            # drops one git has never seen. Only a present-but-wrong-TYPE or
            # unreadable operand is a hazard to git, and only those are dropped.
            survivors.append(path)
            continue
        cause, error = refusal
        # ONE collapsed line per dropped operand: git's own text is multi-line
        # where this prints on one, and the operator needs the full path (not the
        # basename a journal row carries) to find what is sitting there.
        detail = "" if error is None else f": {' '.join(error.split())}"
        print(
            f"warning: {path} was left out of the {story.story_key} confirm commit "
            f"({cause}){detail} — the confirm's on-disk change landed before the path "
            f"took this shape; inspect it and commit it by hand once the path is repaired.",
            file=sys.stderr,
        )
    if survivors:
        # An empty list spawns no git at all, rather than handing `commit_paths`
        # nothing and letting it decide what that means.
        try:
            verify.commit_paths(
                paths.repo_root,
                f"chore(operator): confirm {story.story_key}",
                survivors,
            )
        except verify.GitError:
            pass  # files are written; git history is best effort (as `decisions`)
    print(f"✓ {story.story_key} confirmed — spec and board are done")
    return 0


def _decision_outcome(
    option: DecisionOption, result: decisions.PreAnswerResult, ledger: Path
) -> str:
    """What answering with this option did, for the operator's progress line.

    Shared by both answering channels — the interactive prompter and
    `--answer` — so the two cannot describe the same write differently. It reads
    what `apply_pre_answer` actually persisted (`result`), never the option alone:
    a success claim for an answer whose `decision:` line was never written is the
    report DW-198 exists to stop.
    """
    if option.effect == "close":
        outcome = "closed now"
    elif option.effect == "build":
        outcome = "queued — the next sweep will build it"
    else:
        outcome = "kept open (recorded)"
    if not result.recorded:
        # Replace success claims with what apply_pre_answer actually persisted.
        # The probe is only diagnostic and is the observation reader, not
        # `is_file()` (DW-282: on Python 3.14 that answers False for a refused
        # ledger), and `observe_ledger` rather than the text-only reader, which
        # folds a present 0-byte ledger into the same answer as a missing one
        # (upstream PR #794 review). `None` is absence; `""` is a present, empty
        # ledger the recorder reached and found no entry in.
        outcome = "no decision line was written"
        text, fault = deferredwork.observe_ledger(ledger)
        if fault is not None:
            outcome += "; ledger state unavailable"
        elif text is None:
            outcome += ": the ledger file is gone"
        else:
            outcome += ": the ledger holds no entry for this id"
        if option.effect != "close":
            outcome += "; your answer was saved to the pre-answer store"
    # A written operand that could not be published (refused before git ran, or
    # git answered `GitError`): reportable on TOP of a successful record, never an
    # error — the exit code and the walk are unchanged by it.
    note = result.publish_note()
    if note is not None:
        outcome += f"; {note}"
    return outcome


def _commit_answer_batch(project: Path, answered: list[str]) -> None:
    """Commit a whole `--answer` batch once — best effort, exactly as
    `apply_pre_answer`'s own commit is.

    `apply_pre_answer` commits per call, which is right for the interactive
    prompter (one answer per human turn, and the session can be abandoned at any
    prompt, so each answer must be durable on its own) and wrong for a batch: at
    the measured scale of 93 answers it is 93 `git add` + `git commit` rounds and
    93 commits for one sitting of the operator's attention. The `--answer` loop
    passes `commit=False` and lands one commit here instead.

    A partial batch still commits what landed: a write that raised mid-loop left
    the earlier answers on disk, and leaving those uncommitted would be the one
    regression against the per-call behaviour. Commit granularity is history, not
    state — the ledger and store bytes are the same either way, so the two
    channels' parity is untouched by this.
    """
    if not answered:
        return
    shown = ", ".join(answered[:4])
    if len(answered) > 4:
        shown += f", +{len(answered) - 4} more"
    plural = "" if len(answered) == 1 else "s"
    message = f"chore(decisions): pre-answer {len(answered)} decision{plural} ({shown})"
    try:
        operands = [bmadconfig.load_paths(project).deferred_work, decisions.store_path(project)]
    except bmadconfig.BmadConfigError:
        return  # files are written; git history is best effort
    # One commit for the sitting when both operands commit together — the batch's
    # whole point. When they cannot (the ledger in another repository than the store
    # under a `repo_root:` override, a gitignored operand), fall back to the shape
    # `apply_pre_answer` commits in (DW-226): one operand at a time, each rooted at its
    # OWN parent, so one that cannot be committed does not take its sibling's commit
    # down with it. Still best effort, but no longer silent: a written answer missing
    # from history is news the operator gets, on the same terms the interactive
    # channel reports it.
    try:
        verify.commit_paths(project, message, operands)
        return
    except verify.GitError:
        pass
    for target in operands:
        try:
            verify.commit_paths(target.parent, message, [target])
        except verify.GitError as e:
            collapsed = " ".join(str(e).split())
            if len(collapsed) > decisions.PUBLISH_ERROR_MAX:
                collapsed = collapsed[: decisions.PUBLISH_ERROR_MAX - 1] + "…"
            print(f"note: {target.name} was written but not committed: {collapsed}")


def cmd_decisions(args: argparse.Namespace) -> int:
    """Answer deferred-work decisions earlier sweeps left unanswered (skipped by
    an unattended sweep, or an interactive one that was abandoned). Answers are
    recorded so the next sweep acts on them without re-asking."""
    from .sweep import DecisionPrompter

    if args.answer and (args.json or args.list):
        conflict = "--json" if args.json else "--list"
        print(f"error: --answer cannot be combined with {conflict}", file=sys.stderr)
        return ExitCode.USAGE
    project = _project(args)
    try:
        paths = bmadconfig.load_paths(project)
        pending = decisions.pending_missed_decisions(project)
    except bmadconfig.BmadConfigError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    # The OBSERVATION arm's evidence, surfaced HERE because it cannot be surfaced
    # where the degrade happens (DW-146). `pending_missed_decisions` reads the
    # ledger through `read_for_observation` and discards the fault, because no
    # journal is reachable from a module-level function handed only a project path
    # — so an unreadable ledger yields no open ids and this command would print
    # "no unanswered decisions from past sweeps" and exit 0. That is indisputably
    # the WRONG silence: the answer is not "nothing is pending", it is "nothing
    # could be read". The contract says an observation site degrades with an
    # attributed fault, and for this one the operator's own terminal is the only
    # place the attribution can land. Same probe the helper runs, so the two
    # cannot disagree about whether the file is readable.
    #
    # stderr, never stdout: `--json` promises exactly one document on stdout, and
    # a note there would corrupt the contract for every machine consumer. Exit
    # stays 0 for the same reason `_sweep_dry_run` does NOT — nothing here is
    # fabricated, the empty listing is honest once the note explains it, and an
    # operator answering an unrelated decision must not be blocked by a ledger
    # this command was not asked to repair.
    _, ledger_fault = deferredwork.read_for_observation(paths.deferred_work)
    if ledger_fault is not None:
        print(
            f"note: {paths.deferred_work} cannot be read ({ledger_fault}) — "
            "no pending decisions could be resolved from it",
            file=sys.stderr,
        )
    # Same reasoning for the run listing the triage caches are read from (DW-468):
    # a run dir that cannot be read contributes no decisions, and says so here.
    _, listing_fault = runs.list_run_dirs(project)
    if listing_fault is not None:
        print(
            f"note: run listing incomplete ({listing_fault}) — "
            "decisions from those runs' triage could not be read",
            file=sys.stderr,
        )
    if args.answer:
        try:
            resolved = decisions.resolve_answers(pending, args.answer)
        except decisions.AnswerError as e:
            print(f"error: {e}", file=sys.stderr)
            return 1
        today = time.strftime("%Y-%m-%d")
        print(f"recording {len(resolved)} answer(s):")
        # `commit=False` per answer, one commit after the loop: a batch is one
        # sitting, so it is one commit (see `_commit_answer_batch`). The failure
        # path breaks rather than returning, so what landed still gets committed.
        answered: list[str] = []
        failure: str | None = None
        for decision, option in resolved:
            try:
                result = decisions.apply_pre_answer(
                    project, decision, option, date=today, commit=False
                )
            # The interactive loop's inventory, same reasons (see there): the ledger
            # lock's state-root failure and an undecodable ledger are not OSErrors.
            except (
                OSError,
                bmadconfig.BmadConfigError,
                ValueError,
                runs.StateRootError,
                deferredwork.LedgerReadError,
            ) as e:
                failure = f"error: could not record {decision.id}: {e}"
                break
            answered.append(decision.id)
            print(f"  {decision.id}: {_decision_outcome(option, result, paths.deferred_work)}")
        _commit_answer_batch(project, answered)
        if failure is not None:
            print(failure, file=sys.stderr)
            return 1
        print(f"\nrun `{namespace.PRODUCT} sweep` to act on any builds.")
        return 0
    if args.json:
        # Before the empty-set early return (nothing pending is a valid empty
        # document, not the text line), and regardless of --list: --json *is*
        # the listing. It cannot fall through to the prompter, which reads stdin
        # and prints per-answer progress — neither survives a pure document.
        machine.emit(decisions_document(pending))
        return 0
    if not pending:
        print("no unanswered decisions from past sweeps")
        return 0
    if args.list:
        print(f"{len(pending)} unanswered decision(s) from past sweeps:\n")
        for d in pending:
            print(f"  {d.id}: {d.question}")
            for opt in d.options:
                rec = "  (recommended)" if opt.key == d.recommendation else ""
                print(f"      [{opt.key}] {opt.label} — {opt.effect}{rec}")
            print("")
        print(f"answer them interactively: {namespace.PRODUCT} decisions")
        return 0
    prompter = DecisionPrompter()
    print(f"{len(pending)} unanswered decision(s) — your answers carry into the next sweep:")
    today = time.strftime("%Y-%m-%d")
    for decision in pending:
        option = prompter.ask(decision)
        try:
            result = decisions.apply_pre_answer(project, decision, option, date=today)
        except (
            OSError,
            bmadconfig.BmadConfigError,
            ValueError,
            runs.StateRootError,
            deferredwork.LedgerReadError,
        ) as e:
            # What this buys is the `{decision.id}` in the message, and only
            # that: `main`'s tail catches BmadConfigError by name and everything
            # else through a bare `except Exception`, so none of these ever
            # reached argparse as a traceback, and the exit code is 1 either way.
            # The loop is what makes attribution worth a handler — it has already
            # printed an outcome line per answered decision, and a bare
            # `error: <msg>` after them does not say which one did not land.
            #
            # The inventory: OSError covers the ledger and store writes and the
            # ledger lock's own acquisition (#286/#469). StateRootError is that
            # lock's other failure — deriving its state-root sidecar from an
            # environment that names no usable root — and it is NOT an OSError, so
            # leaving it out would let it fall through to `main`'s bare tail and
            # lose the attribution this handler exists for. ValueError is the
            # ledger writers' `date` precondition, unreachable from the strftime
            # above and here for the same reason as the TUI's copy of this call.
            # BmadConfigError is the reachable one:
            # `apply_pre_answer` re-reads the BMAD config on every call and
            # `prompter.ask` blocks on the human in between, so a config removed
            # or broken mid-prompt raises here even though the read at the top of
            # this command succeeded. Leaving it out gave the likelier failure the
            # worse message.
            #
            # LedgerReadError is the SAME reachable shape as BmadConfigError, and it
            # is here for the same reason (DW-146). `prompter.ask` blocks on the
            # human, so a ledger that goes undecodable while the prompt is open
            # raises out of `record_decision`'s locked `read_for_write` — the exact
            # failure this tuple used to catch as a bare `ValueError`, back when the
            # codec error escaped untyped. Retyping it to a plain `Exception` is what
            # dropped it out of this handler; naming it puts it back, so the
            # attribution this arm exists for is not lost to the contract that made
            # the fault attributable. Its `LedgerReadFault` subclass also covers
            # OS metadata/text-read failures since DW-279.
            print(f"error: could not record {decision.id}: {e}", file=sys.stderr)
            return 1
        print(f"  {decision.id}: {_decision_outcome(option, result, paths.deferred_work)}")
    print(f"\nrun `{namespace.PRODUCT} sweep` to act on any builds.")
    return 0


def _sweep_options_line(run_dir: Path, state: RunState) -> str:
    """The text-status line naming a sweep run's effective options (#815).

    `policy_snapshot` alone reads as the enforced cap, but a launch override in
    `sweep.json` wins over it (`resolve_sweep_override`, as `SweepEngine.__init__`
    applies it). The policy half comes from the run's snapshot, never live
    policy.toml: the engine loads policy once, and resume re-stamps the snapshot
    to the policy it reloads. `sweep.json` is read the way resume reads it —
    bounded, version-checked and digest-bound — but status only observes, so a
    refusal degrades to "unverifiable" rather than failing the command."""
    version = state.sweep_options_version
    try:
        runsetup.validate_sweep_options_version(version)
        current = version == runsetup.SWEEP_OPTIONS_VERSION
        options = runsetup.load_sweep_resume_options(
            run_dir,
            required=version >= runsetup.SWEEP_OPTIONS_VERSION,
            expected_digest=state.sweep_options_digest if current else None,
        )
        runsetup.validate_sweep_options_binding(version, state.sweep_options_digest, options)
    except runsetup.SweepOptionsError as exc:
        return f"sweep options: unverifiable — {exc}"
    if options.digest is None:
        # The legacy loader's tolerant empty shape: no readable sweep.json, so the
        # launch overrides were never recorded (resume would run on policy alone).
        return "sweep options: unknown — legacy run with no readable sweep.json"
    raw_policy = state.policy_snapshot.get("sweep")
    snapshot: dict[str, Any] = raw_policy if isinstance(raw_policy, dict) else {}
    parts: list[str] = []
    for key in SWEEP_OVERRIDE_KEYS:
        override = options.values.get(key)
        from_policy = snapshot.get(key)
        if override is None and from_policy is None:
            parts.append(f"{key} unknown (no override; not in the policy snapshot)")
            continue
        value = json.dumps(resolve_sweep_override(override, from_policy))
        if override is None:
            source = "policy"
        elif from_policy is None:
            source = "override"
        else:
            source = f"override; policy {json.dumps(from_policy)}"
        parts.append(f"{key} {value} ({source})")
    if options.only_ids is not None:
        parts.append(f"only {','.join(options.only_ids)}")
    if options.min_severity is not None:
        parts.append(f"min_severity {options.min_severity}")
    legacy = " [legacy options format]" if version == 0 else ""
    return f"sweep options: {', '.join(parts)}{legacy}"


def _latest_run_dir(project: Path) -> Path | None:
    """:func:`runs.latest_run_dir` for a command that falls back to the newest run,
    with the listing fault on stderr (DW-468): over an unreadable runs dir the
    "no runs found" that follows is not the answer, and over an unreadable run
    dir the pick is only the newest readable run."""
    run_dir, fault = runs.latest_run_dir(project)
    if fault is not None:
        print(f"warning: run listing incomplete: {fault}", file=sys.stderr)
    return run_dir


def cmd_status(args: argparse.Namespace) -> int:
    project = _project(args)
    if args.run_id:
        try:
            run_dir = runs.resolve_run_dir(project, args.run_id)
        except runs.RunRefError as e:
            print(str(e), file=sys.stderr)
            return 1
    else:
        run_dir = _latest_run_dir(project)
    if run_dir is None or not (run_dir / "state.json").is_file():
        print("no runs found", file=sys.stderr)
        return 1
    state = load_state(run_dir)
    # A pending graceful stop is not in state.json (it's the control file + a live
    # engine), so derive it here and hand it to the builder / text branch. Order the
    # `and` so the cheap file read gates the engine_liveness probe: skip it when the
    # run is already concluded or no request is on disk. The mode check is exact —
    # a lodged `mode: hard` request is a stop in flight, not a *graceful* stop
    # pending, and reporting it as one would promise an operator the current item
    # still finishes. Absent and hard both read False here; only "graceful" is True.
    graceful_pending = (
        not (state.finished or state.paused or state.stopped or state.crashed)
        and runs.read_stop_request_mode(run_dir) == "graceful"
        and runs.engine_liveness(run_dir) != "dead"
    )
    if args.json:
        machine.emit(status_document(state, graceful_stop_pending=graceful_pending))
        return 0
    kind = f" [{state.run_type}]" if state.run_type != "story" else ""
    print(f"run {state.run_id}{kind}  started {state.started_at}")
    if state.finished:
        print("status: finished")
    # Same call as status_document / tui.data._classify: a pause somebody has
    # since stopped is over, not resumable. The reason is still printed, on the
    # stopped line, because it is why the run ended.
    elif state.paused and not state.stopped:
        print(f"status: PAUSED ({state.paused_stage}) — {display_pause_reason(state)}")
    elif state.stopped:
        why = f" (was paused at {state.paused_stage}: {state.paused_reason})"
        print(f"status: stopped{why if state.paused else ''}")
    elif graceful_pending:
        print("status: in progress — graceful stop pending (will stop after the current item)")
    else:
        print("status: in progress (or interrupted)")
    if state.run_type == "sweep":
        print(_sweep_options_line(run_dir, state))
    if state.sweeps_refused:
        detail = ", ".join(f"{trigger} ({why})" for trigger, why in state.sweeps_refused.items())
        print(f"auto-sweep not run: {detail} — deferred work is untouched")
        print(f"  run `{namespace.PRODUCT} sweep` with a clean worktree")
    raw_total, weighted_total, weight = run_token_totals(state)
    if raw_total:
        print(
            f"tokens: {weighted_total:,} weighted "
            f"({raw_total:,} raw incl. cache reads, cache_read_weight {weight})"
        )
    for key, task in state.tasks.items():
        raw = task.tokens.total
        # Gate on raw (does this task have ANY tokens?), never on weighted: with
        # cache_read_weight = 0 a cache-read-only task weighs 0 but has nonzero
        # raw, and must render "0", not "-" — "-" means no tokens at all, i.e.
        # missing data. Mirrors tui/screens/dashboard.py. Do not "simplify" this
        # to `if weighted` now that weighted is the displayed value.
        tokens = f"{task.tokens.weighted_total(weight):,}t ({raw:,} raw)" if raw else "-"
        extra = task.defer_reason or task.commit_sha or ""
        if task.preserve_ref:
            extra = f"{extra} [{task.preserve_ref}]".lstrip()
        # 17 = len("awaiting-operator"), the longest Phase token; a narrower
        # field does not truncate, it shifts every following column on that one
        # row, which reads as corrupt output rather than as a long status.
        print(
            f"  {key:40s} {task.phase:17s} dev×{task.attempt} review×{task.review_cycle} "
            f"{tokens} {extra}"
        )
    if state.source == "stories":
        _print_stories_status(state, project)
    else:
        try:
            paths = bmadconfig.load_paths(project)
            ss = sprintstatus.load(paths.sprint_status)
            remaining = [s.key for s in ss.stories if s.status in sprintstatus.ACTIONABLE_STATUSES]
            print(f"sprint backlog remaining: {len(remaining)}")
        except (bmadconfig.BmadConfigError, sprintstatus.SprintStatusError):
            pass
    try:
        missed = decisions.pending_missed_decisions(project)
        if missed:
            print(
                f"deferred-work decisions awaiting an answer: {len(missed)} ({namespace.PRODUCT} decisions)"
            )
    except bmadconfig.BmadConfigError:
        pass
    return 0


def cmd_list(args: argparse.Namespace) -> int:
    project = _project(args)
    infos, fault = runs.discover_runs(project)  # oldest first
    if args.json:
        machine.emit(list_document(infos, listing_fault=fault))
        return 0
    if fault is not None:
        # DW-468: an unreadable runs dir (or run dir) is not "no runs".
        print(f"warning: run listing incomplete: {fault}", file=sys.stderr)
    if not infos:
        if fault is None:
            print("no runs found")
        return 0
    print(f"{'REF':6} {'TYPE':6} {'STATUS':10} RUN ID")
    for ri in infos:
        print(f"{runs.short_ref(ri.run_id):6} {ri.run_type:6} {ri.status:10} {ri.run_id}")
    return 0


#: Strips terminal escape sequences from a pane log before it is shown to a
#: person. The log is a verbatim tee of a TUI, so most of its bytes are cursor
#: moves and colour — printing it raw is unreadable and can leave the operator's
#: own terminal in a changed mode.
_ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]|\x1b[@-Z\\-_]")


def _intervene_window(run_id: str, task_id: str) -> str | None:
    """The window hosting this task's session, or None.

    Resolved by NAME rather than by taking the session's active window: an
    llm-run has the orchestrator and a dispatched worker side by side, and
    "whatever is selected" would put the operator's words into whichever one a
    previous attach happened to leave in front. The engine names each window
    after its task (`generic.py`'s `new_window`), so the name is the only
    unambiguous handle available from outside.
    """
    from .adapters.multiplexer import get_multiplexer

    mux = get_multiplexer()
    session = runs.session_name(run_id)
    try:
        if not mux.has_session(session):
            return None
        rows = mux.list_windows(session, ["window_id", "window_name"])
    except Exception:  # noqa: BLE001 — a transport failure reads as "no window"
        return None
    want = task_id[-40:]
    for row in rows:
        if len(row) >= 2 and row[1] == want:
            return row[0]
    return None


def _hold_fields(held, lease_s: int) -> dict[str, object]:
    """The lease as the document reports it. `until` travels because a caller
    driving a conversation needs to know when to refresh without re-deriving the
    policy's lease length; `granted` and `refreshes` travel because they are what
    separate one long intervention from a hundred forgotten ones."""
    return {
        "until": held.until,
        "granted": held.granted,
        "refreshes": held.refreshes,
        "lease_s": lease_s,
    }


def cmd_intervene(args: argparse.Namespace) -> int:
    """Operator authority over a live session, with the journal as its price.

    Reading and speaking to a session were always possible with raw multiplexer
    commands. Routing them through one command buys the property that made them
    unsafe to encourage: every intervention lands in the run's journal, so the
    record of what drove a story stays true even when a human was the one
    driving. An operator who works around this command is not blocked — they are
    simply invisible to whoever reads the run afterwards.

    `--say` refreshes the hold before it types, because the alternative is a
    conversation that quietly spends the session's own timeout.
    """
    project = _project(args)
    if args.run_id:
        try:
            run_dir = runs.resolve_run_dir(project, args.run_id)
        except runs.RunRefError as e:
            print(str(e), file=sys.stderr)
            return 1
    else:
        run_dir, fault = runs.latest_run_dir(project)
        if run_dir is None and fault is not None:
            # "No runs" over a listing that failed would send the operator looking
            # for a run that may well exist (DW-468).
            print(f"error: cannot list runs: {fault}", file=sys.stderr)
            return 1
    if run_dir is None:
        print("no runs found", file=sys.stderr)
        return 1

    journal = Journal(run_dir)
    who = args.by or "operator"

    def record(action: str, **fields: object) -> None:
        journal.append("operator", action=action, by=who, reason=args.reason, **fields)

    def human(message: str) -> None:
        """The readable line, suppressed in JSON mode.

        The contract is exactly one JSON object on stdout and nothing else, so a
        courtesy line printed alongside it would break every consumer — the
        failure would be a parse error on the FIRST call, not a slow drift, but
        it would also be introduced by anyone adding a print here later."""
        if not args.json:
            print(message)

    # `Any` rather than `object`: these land as the document builder's typed
    # keyword parameters, and a splat of `object` erases every one of them.
    # documents.py keeps the real types — this edge just forwards.
    def done(**fields: Any) -> int:
        if args.json:
            machine.emit(
                intervene_document(run_id=run_dir.name, by=who, reason=args.reason, **fields)
            )
        return 0

    # A note is about the run, not about a session, so it is the one action that
    # works between sessions — which is exactly when an operator has most to say
    # (a pause they resolved, a decision they made by hand).
    if args.note:
        record("note", text=args.note)
        human(f"noted on run {run_dir.name}")
        return done(action="note", task=None, journalled=True, text=args.note)

    if args.task:
        # Named explicitly, so it is honoured even with a cold heartbeat: an
        # operator who typed the id knows which session they mean better than a
        # freshness comparison does.
        task_id = args.task
        if not (run_dir / "tasks" / task_id).is_dir():
            print(f"run {run_dir.name} has no task {task_id}", file=sys.stderr)
            return 1
    else:
        live = operatorhold.live_task(run_dir)
        if live is None:
            print(
                f"run {run_dir.name} has no session being waited on right now — "
                "nothing to read, speak to, or hold (use --note to record something anyway)",
                file=sys.stderr,
            )
            return 1
        task_id = live[0]
    task_dir = run_dir / "tasks" / task_id

    if args.read:
        log = run_dir / LOGS_DIR / f"{task_id}.log"
        try:
            text = log.read_text(encoding="utf-8", errors="replace")
        except OSError as e:
            print(f"cannot read {log}: {e}", file=sys.stderr)
            return 1
        lines = _ANSI_RE.sub("", text).splitlines()
        tail = lines[-max(1, args.lines) :]
        human(f"--- {task_id} (last {len(tail)} lines) ---")
        human("\n".join(tail))
        # Reading is not journalled: it changes nothing, and an entry per glance
        # would bury the interventions that did change something.
        return done(action="read", task=task_id, journalled=False, lines=tail, log=str(log))

    limits = policy_mod.load(project / policy_mod.POLICY_FILE).limits

    if args.release:
        dropped = operatorhold.release(task_dir)
        record("release", task=task_id, had_hold=dropped)
        human(f"hold released on {task_id}" if dropped else f"no hold was held on {task_id}")
        return done(action="release", task=task_id, journalled=True, had_hold=dropped)

    if args.hold:
        held = operatorhold.refresh(
            task_dir, limits.operator_hold_lease_s, by=who, reason=args.reason
        )
        record("hold", task=task_id, lease_s=limits.operator_hold_lease_s)
        ceiling = limits.operator_hold_max_min
        human(
            f"holding {task_id} for {limits.operator_hold_lease_s}s"
            + (f" (refresh #{held.refreshes})" if held.refreshes else "")
            + (
                ""
                if ceiling
                else " — WARNING: [limits] operator_hold_max_min = 0, so the "
                "engine will credit nothing and the session clock keeps running"
            )
        )
        return done(
            action="hold",
            task=task_id,
            journalled=True,
            hold=_hold_fields(held, limits.operator_hold_lease_s),
            crediting_disabled=not ceiling,
        )

    # --say
    text = args.say
    if "\n" in text or "\r" in text:
        print(
            "refusing multi-line text: the multiplexer submits at each newline, so a "
            "three-line message arrives as three separate turns — send one line at a time",
            file=sys.stderr,
        )
        return 1
    if not text.strip():
        print("refusing empty text", file=sys.stderr)
        return 1
    window = _intervene_window(run_dir.name, task_id)
    if window is None:
        print(
            f"no live window named for task {task_id} — the session's heartbeat is fresh "
            "but its window is gone; the engine will settle this on its own",
            file=sys.stderr,
        )
        return 1
    # Hold first, then speak: the clock must already be stopped when the agent
    # starts spending it on the operator's turn.
    held = operatorhold.refresh(task_dir, limits.operator_hold_lease_s, by=who, reason=args.reason)
    from .adapters.multiplexer import get_multiplexer

    try:
        get_multiplexer().send_text(window, text)
        delivered = True
    except Exception as e:  # noqa: BLE001 — reported, and journalled as undelivered
        delivered = False
        send_error = str(e)
    # Journalled either way: the attempt is a fact about the run, and an
    # undelivered one is the more important of the two to have on record.
    record("say", task=task_id, text=text, delivered=delivered)
    if not delivered:
        # An error under machine.py's contract — the command could not do its
        # job — so stdout stays empty even in JSON mode.
        print(f"send failed: {send_error}", file=sys.stderr)
        return 1
    human(f"said to {task_id}: {text}")
    return done(
        action="say",
        task=task_id,
        journalled=True,
        text=text,
        hold=_hold_fields(held, limits.operator_hold_lease_s),
        crediting_disabled=not limits.operator_hold_max_min,
    )


def cmd_attach(args: argparse.Namespace) -> int:
    from .tui import launch  # import-safe: launch.py has no textual imports

    project = _project(args)
    if args.run_id:
        try:
            run_dir = runs.resolve_run_dir(project, args.run_id)
        except runs.RunRefError as e:
            print(str(e), file=sys.stderr)
            return 1
    else:
        run_dir = _latest_run_dir(project)
    if run_dir is None:
        print("no runs found", file=sys.stderr)
        return 1
    plan = launch.attach_plan(project, run_dir.name)
    if plan is None:
        print(f"nothing to attach for run {run_dir.name}", file=sys.stderr)
        return 1
    argv, return_window = plan
    # Record where to send the client once the sweep finishes this cycle's
    # decisions (see launch.return_attached_client), so answering them hands the
    # terminal back instead of stranding the user in the orchestrator window.
    # Backend-honest inside-the-multiplexer probe: current_return_target() is
    # None outside, so a resolvable own pane means "switch the client back
    # here", anything else means a throwaway client was attached and must
    # detach.
    if return_window is not None:
        ret = launch.current_return_target()
        if ret is not None:
            launch.set_return_pane(return_window, ret)
        else:
            launch.set_return_pane(return_window, launch.RETURN_DETACH)
    return subprocess.call(argv)


def cmd_stop(args: argparse.Namespace) -> int:
    project = _project(args)
    try:
        run_dir = runs.resolve_run_dir(project, args.run_id)
    except runs.RunRefError as e:
        print(str(e), file=sys.stderr)
        return 1
    args.run_id = run_dir.name
    if args.cancel_graceful:
        return _cmd_cancel_graceful(run_dir, args.run_id)
    if args.graceful:
        return _cmd_request_graceful(run_dir, args.run_id)
    # Hard stop: lodge a `mode: "hard"` stop request, signal the engine (the POSIX
    # fast path), and let it tear the run down; kill its agent window either way.
    try:
        stopped = runs.stop_run(run_dir)
    except (runs.StopRunError, ProcessHostError) as e:
        print(str(e), file=sys.stderr)
        return 1
    if not stopped:
        print(f"run {args.run_id} already finished", file=sys.stderr)
        return 1
    print(f"run {args.run_id} stopped")
    return 0


def _cmd_cancel_graceful(run_dir: Path, run_id: str) -> int:
    """`stop --cancel-graceful`: discard a pending request so the run keeps going.

    Mode-neutral, like the clear it delegates to: the only hard request that can
    still be on disk for a human to reach is one `stop_run` deliberately left
    lodged after refusing to force-kill an unverifiable pid, and withdrawing that
    is a legitimate thing to want. So the messages name a *stop request*, not a
    graceful one (#319)."""
    if runs.clear_graceful_stop(run_dir):
        print(f"run {run_id}: stop request cancelled")
        return 0
    if runs.graceful_stop_requested(run_dir):
        # The clear answers False for "nothing pending" and "could not remove it"
        # alike; re-read so we never tell an operator their request is gone while it
        # is still on disk and still honorable. Exit 1 either way — only the message
        # differs, so no caller's exit-code expectation moves.
        print(
            f"run {run_id}: stop request could not be cancelled "
            f"({runs.STOP_REQUEST_FILE} is not removable) — it is still pending",
            file=sys.stderr,
        )
        return 1
    print(f"run {run_id} has no stop request pending", file=sys.stderr)
    return 1


def _cmd_request_graceful(run_dir: Path, run_id: str) -> int:
    """`stop --graceful`: ask a live run to finish its in-flight item, then stop
    cleanly (resumable). Delivery + refusal live in runs.request_graceful_stop;
    here we only translate its status token into operator-facing messaging."""
    try:
        outcome = runs.request_graceful_stop(run_dir)
    except runs.GracefulStopError as e:
        print(str(e), file=sys.stderr)
        return 1
    except OSError as e:
        # The lodge creates the file first and writes the body into it, and it
        # deliberately does not roll back a failed write (see _create_stop_request:
        # an unlink there resolves the *name*, so it could delete a hard request a
        # concurrent `stop` escalated onto it). So a write that failed part-way
        # still leaves a request standing, and a short body reads as graceful —
        # the mode we were asked for. Say so rather than reporting a clean failure
        # the operator would act on by asking again (#319).
        print(
            f"run {run_id}: stop request could not be written ({e}) — a graceful "
            f"request may still be pending; check `{namespace.PRODUCT} status {run_id}` and "
            f"use `{namespace.PRODUCT} stop {run_id} --cancel-graceful` to withdraw it",
            file=sys.stderr,
        )
        return 1
    if outcome == "already-pending":
        # Mode-neutral for the same reason `--cancel-graceful` is: the pending
        # request may be a *hard* one (a `stop` that could not prove the engine
        # dead leaves it lodged at rest), and the token is deliberately mode-blind.
        # Naming it "graceful" would report a strictly stronger stop as a weaker
        # one (#319).
        print(f"run {run_id} already has a stop request pending")
        return 0
    if outcome == "requested-unverifiable":
        print(
            f"run {run_id}: could not confirm a live engine (unverifiable pid) — the "
            f"request stands and fires if one is running",
            file=sys.stderr,
        )
    # The in-flight item the run will finish before stopping: the first task not yet
    # in a terminal phase. None when the request lands between items (it takes effect
    # at the next boundary regardless).
    state = load_state(run_dir)
    current = next((key for key, task in state.tasks.items() if not task.terminal), None)
    item = current if current is not None else "none in flight"
    print(
        f"graceful stop requested — run {run_id} will stop after the current item "
        f"completes (current item: {item}); continue later with "
        f"`{namespace.resume_command(state.source, run_id)}`"
    )
    return 0


def _stop_or_block_live_engine(run_dir: Path, run_id: str, force: bool) -> int | None:
    """Shared delete/archive guard. One liveness sample drives both the warning and the
    block, so a mid-check identity flip can't fire one without the other. An unverifiable
    pid (``unknown``) warns but never blocks cleanup; only a provably-live engine blocks,
    or is stopped first under ``force``. Returns an exit code to propagate, or None to
    proceed with cleanup."""
    live = runs.engine_liveness(run_dir)
    if live == "unknown":
        print(f"run {run_id}: engine may still be live (unverifiable pid)", file=sys.stderr)
    if live == "alive":
        if not force:
            print(f"run {run_id} is still live — stop it first (or pass --force)", file=sys.stderr)
            return 1
        try:
            runs.stop_run(run_dir)
        except (runs.StopRunError, ProcessHostError) as e:
            print(str(e), file=sys.stderr)
            return 1
    return None


def cmd_delete(args: argparse.Namespace) -> int:
    project = _project(args)
    try:
        run_dir = runs.resolve_run_dir(project, args.run_id)
    except runs.RunRefError as e:
        print(str(e), file=sys.stderr)
        return 1
    args.run_id = run_dir.name
    rc = _stop_or_block_live_engine(run_dir, args.run_id, args.force)
    if rc is not None:
        return rc
    try:
        runs.delete_run(project, run_dir, force=args.force)
    except runs.LiveEngineError as e:
        print(str(e), file=sys.stderr)
        return 1
    except runs.LiveSessionError as e:
        print(f"{e} (or pass --force)", file=sys.stderr)
        return 1
    print(f"run {args.run_id} deleted")
    return 0


def cmd_archive(args: argparse.Namespace) -> int:
    project = _project(args)
    try:
        run_dir = runs.resolve_run_dir(project, args.run_id)
    except runs.RunRefError as e:
        print(str(e), file=sys.stderr)
        return 1
    args.run_id = run_dir.name
    rc = _stop_or_block_live_engine(run_dir, args.run_id, args.force)
    if rc is not None:
        return rc
    try:
        dest = runs.archive_run(project, run_dir, force=args.force)
    except runs.LiveEngineError as e:
        print(str(e), file=sys.stderr)
        return 1
    except runs.LiveSessionError as e:
        print(f"{e} (or pass --force)", file=sys.stderr)
        return 1
    print(f"run {args.run_id} archived to {dest}")
    return 0


def _warn_legacy_leftovers(
    leftovers: dict[str, list[str]], unverified: list[str] | tuple[str, ...] = ()
) -> None:
    """Name what each legacy multiplexer registry still holds after the sweep.

    Silent on the normal path — the list is empty on every platform without a
    registry namespace and on every machine that never ran the pre-registry
    build. When it is not empty, saying nothing would be the failure: cleanup
    prints a removal count, and a count that quietly excludes sessions it chose
    not to migrate reads as "everything is clean". stderr rather than stdout, the
    `unverifiable_pid` precedent, so `cleanup > log` keeps the receipt; in
    `--json` mode this lives in the document instead and stderr stays empty.

    **One line per registry, naming it.** There is more than one legacy registry
    now — psmux's default, and any root this process displaced — and the
    operator's next action is to open the one holding these sessions. A message
    that named the default for all of them sent the reader to a registry the
    sessions are not in, and at documentation about a registry that is not
    theirs. `runs.legacy_registry_leftovers` maps names to registries so this
    does not have to guess, and omits a registry that holds nothing so no line
    here points somewhere empty.

    Points at the docs rather than printing a command. One of the things named
    here is the machine-wide control session, and `psmux kill-session` on it kills
    every child process in every one of its windows — including, on this
    backend, a window still running an engine (the parked wrapper runs the
    command first and parks only after it exits). A remedy this prints has to be
    safe to run at the moment it is printed; that one is not, so the care lives
    where there is room to state it.

    Deliberately unconditional on dry-run: a preview that omits the remainder
    would disagree with the run it is previewing.

    ``unverified`` names each legacy registry that could not be asked at all
    (DW-469): without a line for it, a registry that raised printed exactly what
    a registry holding nothing prints — nothing."""
    for line in unverified:
        print(
            f"legacy registry not checked for sessions left behind (not migrated): {line}",
            file=sys.stderr,
        )
    for registry, names in leftovers.items():
        print(
            f"left in {registry} (not migrated): "
            + ", ".join(names)
            + " — still running, ownership unprovable there, or the shared control "
            "session; see docs/multiplexer-backends.md before removing any of them",
            file=sys.stderr,
        )


def cmd_cleanup(args: argparse.Namespace) -> int:
    from .adapters.multiplexer import MultiplexerError
    from .tui import launch  # pure stdlib; no textual import

    project = _project(args)
    # one partition sample drives the prune and every message below, so the
    # warnings and live count always match what was actually killed/skipped
    killed, live, unknown = runs.prune_sessions(project, dry_run=args.dry_run)
    # Read AFTER the prune, and by presence: what is still standing in the legacy
    # registry now that the sweep has run. On a dry run nothing was killed, so the
    # ids just announced as would-kills are handed over to be excluded — the plan
    # this command printed, never a second sample of it. Never raises: a registry
    # that could not be asked lands in `unverified` (DW-469), never in an empty
    # `leftovers` that reads as "nothing left".
    leftovers, unverified = runs.legacy_registry_leftovers(
        project, announced=killed if args.dry_run else ()
    )
    if not args.json:
        for run_id in sorted(unknown):
            # warn-only: unknown never blocks cleanup (same wording as delete/archive).
            # Pruning kills the tmux session, never the engine pid, so the warning
            # holds after the fact too. In JSON mode this lives in the document
            # instead (sessions.unverifiable_pid), leaving stderr empty.
            print(f"run {run_id}: engine may still be live (unverifiable pid)", file=sys.stderr)
    # The ctl-window half is raiser-side (its candidate scan probes has_session),
    # and the sessions above are ALREADY killed by the time it runs. Letting the
    # raise reach main()'s backstop prints an error and returns 1 with stdout
    # empty — which in --json mode destroys the record of those kills, leaving a
    # consumer unable to tell "killed nothing" from "killed three, lost the
    # receipt". The repair succeeded; only the observation failed, and
    # observation degrades. Mirrors what the TUI worker already does.
    #
    # dry-run kills nothing, so there is no kill outcome to partition: the
    # candidate list IS the plan, and the other two arms stay empty.
    scan_error: str | None = None
    try:
        if args.dry_run:
            windows, survived, unverifiable = launch.prunable_ctl_windows(project), [], []
        else:
            windows, survived, unverifiable = launch.prune_ctl_windows(project)
    except (MultiplexerError, UnicodeError) as e:
        # Three empty lists is the honest answer: the raise comes from the
        # candidate scan, so no window was killed or even chosen. But an empty
        # partition alone is also what a clean scan that found nothing emits, so
        # the document carries the failure as ctl_windows.scan_error — without
        # it a --json consumer accepts a failed preflight as "nothing to do".
        # UnicodeError: the scan's raiser-side probes decode with the strict
        # POSIX handler and do not all normalize a decode fault to the seam type
        # (#380); it is the same scan failure, and letting it reach main()'s
        # backstop would empty stdout of the sessions receipt this arm protects.
        print(f"ctl window prune failed: {e}", file=sys.stderr)
        windows, survived, unverifiable = [], [], []
        scan_error = str(e)
    if args.json:
        machine.emit(
            cleanup_document(
                dry_run=args.dry_run,
                killed=killed,
                live=live,
                unknown=unknown,
                windows=windows,
                windows_survived=survived,
                windows_unverifiable=unverifiable,
                scan_error=scan_error,
                # Flattened: `sessions.legacy_leftovers` is a documented
                # list of names and widening it would bump the schema. The
                # grouping serves the text mode, which has room to say where.
                legacy_leftovers=sorted({n for names in leftovers.values() for n in names}),
                legacy_unverified=unverified,
            )
        )
        return 0
    if args.dry_run:
        if not killed and not windows:
            print("nothing to clean up")
        else:
            for run_id in killed:
                print(f"would kill session {namespace.SESSION_PREFIX}{run_id}")
            for name in windows:
                print(f"would close ctl window {name}")
        if live:
            print(f"leaving {len(live)} live session(s) untouched")
        _warn_legacy_leftovers(leftovers, unverified)
        return 0
    # The count now excludes non-removals, so on stdout alone a smaller number is
    # indistinguishable from a quieter sweep — and `cleanup > log` keeps only
    # stdout. The marker travels with the count; the names stay on stderr, the
    # unverifiable_pid precedent.
    unaccounted = len(survived) + len(unverifiable)
    print(
        f"removed {len(killed)} session(s), {len(windows)} ctl window(s)"
        + (f" ({unaccounted} not verified — see stderr)" if unaccounted else "")
    )
    # Only ever printed when a kill did not verifiably land — silence on the
    # normal path, and the count above now excludes these rather than counting
    # them as removed (#435). Both are retried by the next cleanup.
    if survived:
        # Same wording as the TUI toast: one claim, one phrase, so an operator
        # moving between the two surfaces is reading the same thing.
        print(f"ctl window(s) still open after the kill: {', '.join(survived)}", file=sys.stderr)
    _warn_legacy_leftovers(leftovers, unverified)
    if unverifiable:
        # Not "killed but unverifiable": kill_window is a silent no-op on a
        # transport failure, so whether the kill even reached the server is part
        # of what is unknown here.
        print(
            f"ctl window(s) kill attempted, outcome unverifiable: {', '.join(unverifiable)}",
            file=sys.stderr,
        )
    if live:
        print(f"left {len(live)} live session(s) untouched")
    return 0


def _dir_size(path: Path) -> int:
    """Best-effort total bytes under ``path``, never crossing a redirect out of
    it — see :func:`walk_files_unlinked` for why plain ``os.walk`` is not enough.
    Sizes with ``lstat``, so a symlinked file counts as the link it is."""
    total = 0
    for f in walk_files_unlinked(path):
        try:
            total += f.lstat().st_size
        except OSError:
            pass
    return total


def _human_bytes(n: int) -> str:
    size = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024 or unit == "TB":
            return f"{size:.0f}{unit}" if unit == "B" else f"{size:.1f}{unit}"
        size /= 1024
    return f"{size:.1f}TB"


def cmd_clean(args: argparse.Namespace) -> int:
    """Reclaim disk from concluded runs: tear down worktrees leaked by a
    mid-flight stop, trim heavy scaffolding from runs kept for history, and
    archive/delete runs past the retention window. Only terminal (finished or
    stopped) runs are touched; running, unknown-host, paused and interrupted
    runs are always left intact.

    Every per-candidate refusal is DATA, never an abort: this is a sweep, so one
    busy run must not cost the operator the report of the runs already reclaimed
    around it (they only reach stdout in the post-loop emission). That is why the
    removals here take the run's state lock with ``wait_for_lock=False`` — a lock
    someone else holds already means what this command reports anyway, and
    waiting for it is unbounded on POSIX, where ``fcntl.flock`` never times
    out."""
    project = _project(args)
    paths = bmadconfig.load_paths(project)
    repo = paths.repo_root
    pol = policy_mod.load(_policy_path(project))
    keep = set(args.keep or ())
    retain = args.retain if args.retain is not None else pol.cleanup.run_retention
    dry = args.dry_run

    reclaimable: list[Path] = []
    protected: list[str] = []
    # A run the listing could not read is never a candidate, which only ever keeps
    # more: it is neither reclaimed nor counted toward the retention window. The
    # fault is still reported (DW-468) — "nothing to reclaim" over an unreadable
    # runs dir is not the answer.
    run_dirs, listing_fault = runs.list_run_dirs(project)
    if listing_fault is not None and not args.json:
        print(f"warning: run listing incomplete: {listing_fault}", file=sys.stderr)
    # never a pre-rename run: `clean` writes, and the legacy dir is read-only
    for run_dir in run_dirs:
        if run_dir.name in keep:
            protected.append(run_dir.name)
        elif runs.reclaimable(run_dir):
            reclaimable.append(run_dir)
        else:
            protected.append(run_dir.name)

    past = {
        p.name
        for p in runs.runs_past_retention(
            reclaimable, keep_n=retain, keep_days=pol.cleanup.retention_days
        )
    }

    freed = 0
    worktrees: list[str] = []
    trimmed: list[str] = []
    archived: list[str] = []
    deleted: list[str] = []
    unverifiable: list[str] = []
    worktree_faults: list[str] = []
    for run_dir in reclaimable:
        if runs.live_session_may_be_ours(project, run_dir.name):
            # `reclaimable` is keyed on engine pid liveness, so an orphan — engine
            # dead, agent session still live — passes it, and everything below this
            # point mutates: the worktree the session may still be working in, the
            # trimmed artifacts, and the run dir itself, which for an untagged
            # session is the only ownership proof a later prune can read (#419).
            # So the guard is the first thing in the loop, ahead of every mutation,
            # and the run is reported untouched rather than half-reclaimed.
            # `cleanup` clears the session — but for an untagged one it proves
            # ownership by this same run dir, so the operator confirms first
            # (`waves attach <id>`); the next `clean` then reclaims the run.
            protected.append(run_dir.name)
            if not args.json:
                print(
                    f"run {run_dir.name}: agent session still live — left untouched",
                    file=sys.stderr,
                )
            continue
        if runs.engine_liveness(run_dir) == "unknown":
            # warn-only: unknown never blocks cleanup, but say so before removal.
            # In JSON mode this lives in the document instead (unverifiable_pid),
            # leaving stderr empty.
            unverifiable.append(run_dir.name)
            if not args.json:
                print(
                    f"run {run_dir.name}: engine may still be live (unverifiable pid)",
                    file=sys.stderr,
                )
        # measure before mutating so the reclaim estimate holds for --dry-run too.
        # Sized over `heavy_run_entries`, not over "worktrees" alone: that is the
        # exact set `trim_run_dir` removes, so the estimate cannot go stale the
        # next time an entry joins it (the verifier stream store did).
        heavy_bytes = sum(_dir_size(p) for p in runs.heavy_run_entries(run_dir) if p.is_dir())
        run_bytes = _dir_size(run_dir)
        # collect, never print-as-you-mutate: the document is emitted once at the
        # end, so every per-item line has to survive the loop as data
        run_worktrees, wt_fault = runs.reconcile_orphan_worktrees(repo, run_dir, dry_run=dry)
        if wt_fault is not None:
            # DW-470: not "no orphaned worktrees". The passes below still run —
            # their git admin entries may outlive a trim, which `git worktree
            # prune` clears once git answers again.
            worktree_faults.append(f"{run_dir.name}: {wt_fault}")
            if not args.json:
                print(
                    f"warning: run {run_dir.name}: worktree reconcile incomplete: {wt_fault}",
                    file=sys.stderr,
                )
        for wt in run_worktrees:
            worktrees.append(str(wt))
            if not args.json:
                print(f"{'would remove' if dry else 'removed'} worktree {wt}")
        if run_dir.name in past:
            freed += run_bytes
            shrunk = runs.trim_run_dir(run_dir, dry_run=dry)  # shrink before archiving
            try:
                if args.hard or not pol.cleanup.archive_old:
                    if not dry:
                        runs.delete_run(project, run_dir, wait_for_lock=False)
                    deleted.append(run_dir.name)
                else:
                    if not dry:
                        runs.archive_run(project, run_dir, wait_for_lock=False)
                    archived.append(run_dir.name)
            except (runs.LiveEngineError, runs.LiveSessionError, LockUnavailableError) as e:
                # A session or engine appeared between the loop-top sample and the
                # authoritative removal transaction — or the run's state lock is
                # held, which says the same thing one layer down and is the only
                # one of the three that reports it in this window: `resume` takes
                # the lock FIRST and publishes its pid LAST, so for its whole
                # preflight (git work bounded by `[limits] git_timeout_s`) the
                # pid/session guards above still read dead and only the lock
                # objects. Record this run instead of letting one racer abort the
                # whole invocation, then continue with its siblings. Correct the
                # estimate down to what actually went.
                #
                # `LockUnavailableError` and NOT a bare `except OSError`: that
                # would also catch `platform_util.UnconfinedWriteError`, an
                # OSError subclass raised when a write escapes its root, and file
                # a containment refusal as a benign "left untouched".
                freed += heavy_bytes - run_bytes
                # Classify by what happened, not by what was intended: the steps
                # above may already have taken this run's worktree and artifacts,
                # and `protected` means "left untouched" in the --json contract.
                # Only a run nothing reached is protected; one already shrunk is
                # trimmed, which is exactly the state it ends in.
                (trimmed if run_worktrees or shrunk else protected).append(run_dir.name)
                if not args.json:
                    if isinstance(e, runs.LiveSessionError):
                        reason = "agent session appeared mid-clean"
                    elif isinstance(e, LockUnavailableError):
                        reason = "run state locked by another process"
                    else:
                        reason = "engine resumed mid-clean"
                    print(
                        f"run {run_dir.name}: {reason} — not removed",
                        file=sys.stderr,
                    )
        elif pol.cleanup.trim_artifacts:
            if runs.trim_run_dir(run_dir, dry_run=dry):
                freed += heavy_bytes
                trimmed.append(run_dir.name)

    # After the loop, so the counterparts the removals above already took are gone
    # from the enumeration rather than counted twice. Their bytes stay out of
    # `freed` on purpose: a state dir holds consumed event files and nothing else,
    # so sizing every one of them would buy kilobytes of accuracy for a walk of a
    # second tree. The count is the honest report of what went.
    swept_dirs, state_dir_fault = runs.reconcile_orphan_state_dirs(project, dry_run=dry)
    swept = len(swept_dirs)
    if state_dir_fault is not None and not args.json:
        # DW-470: a sweep that could not run is not "swept 0" — and not "nothing
        # to reclaim" either, which the summary below still prints on its own terms.
        print(f"warning: orphaned state-dir sweep incomplete: {state_dir_fault}", file=sys.stderr)

    if args.json:
        machine.emit(
            clean_document(
                dry_run=dry,
                retain=retain,
                cleanup_policy=pol.cleanup,
                freed_bytes=freed,
                worktrees=worktrees,
                trimmed=trimmed,
                archived=archived,
                deleted=deleted,
                protected=protected,
                unverifiable_pid=unverifiable,
                state_dirs_swept=swept,
                listing_fault=listing_fault,
                worktree_faults=worktree_faults,
                state_dir_fault=state_dir_fault,
            )
        )
        return 0
    reclaimed = bool(worktrees or trimmed or archived or deleted)
    if reclaimed:
        head = "would reclaim" if dry else "reclaimed"
        print(
            f"{head} ~{_human_bytes(freed)}: {len(worktrees)} worktree(s), "
            f"{len(trimmed)} run(s) trimmed, {len(archived)} archived, {len(deleted)} deleted"
        )
        for name in archived:
            print(f"  archived {name} -> {namespace.STATE_REL}/archive/{name}.tar.gz")
        for name in deleted:
            print(f"  deleted {name}")
    if swept:
        # its own line rather than a fifth count in the summary above, which is a
        # reclaimed-bytes report these dirs are deliberately outside of
        print(f"{'would sweep' if dry else 'swept'} {swept} orphaned run state dir(s)")
    if not reclaimed and not swept:
        print("nothing to reclaim")
    if protected:
        print(f"left {len(protected)} live/resumable run(s) untouched")
    return 0


def cmd_tui(args: argparse.Namespace) -> int:
    project = _project(args)
    # Apply low-frame-rate mode *before* importing textual: it reads TEXTUAL_FPS
    # / TEXTUAL_ANIMATIONS once at import time. setdefault so an explicit value
    # in the user's environment still wins. policy.load is textual-free.
    if args.low_frame_rate or policy_mod.load(_policy_path(project)).tui.low_frame_rate:
        os.environ.setdefault("TEXTUAL_FPS", "15")
        os.environ.setdefault("TEXTUAL_ANIMATIONS", "none")
    try:
        from .tui.app import run_tui
    except ModuleNotFoundError as e:
        # Failure-gated, not allowlisted (#678): ANY missing third-party module on
        # the TUI import chain (rich and pyte import before textual; a future dep
        # would too) means the [tui] extra is absent. Only a missing riaworks_waves_loop.*
        # submodule — a packaging defect, not an install state the hint can fix —
        # re-raises.
        if (e.name or "").partition(".")[0] != "riaworks_waves_loop":
            print(
                f"error: the TUI requires optional dependencies — uv tool install '{namespace.DISTRIBUTION}[tui]'",
                file=sys.stderr,
            )
            return 1
        raise
    return run_tui(project)


def cmd_probe(args: argparse.Namespace) -> int:
    from . import probe as probe_mod
    from . import sanitize
    from .adapters.profile import ProfileError, get_profile

    project = _project(args)
    # What this invocation actually produces — the operator messages below say
    # "report" only when a report was rendered; --json renders a document.
    noun = "document" if args.json else "report"
    hints = probe_mod.Hints(
        binary=args.binary,
        transcript=args.transcript,
        session_dir=args.session_dir,
        model=args.model,
    )

    profile = None
    codex_profile_error = False
    try:
        profile = get_profile(args.cli, project)
    except ProfileError as e:
        if args.cli == "codex":
            codex_profile_error = True
        if not args.binary:
            prefix = "Codex hook trust unverifiable: " if codex_profile_error else ""
            print(f"FAIL: {prefix}{e}", file=sys.stderr)
            return 1
        # Human-facing notice — stderr in JSON mode, where stdout is the document.
        # Withheld under --workspace: an unknown profile cannot answer it, and the
        # FAIL below would contradict an `ok:` printed first.
        if not codex_profile_error and args.workspace is None:
            print(
                f"  ok: unknown profile {args.cli!r}; reduced {noun} from --binary {args.binary}",
                file=sys.stderr if args.json else sys.stdout,
            )

    # --workspace asks a question only a declared [workspace_trust] table can
    # answer; an unknown profile (reduced --binary report) cannot either (DW-390).
    if args.workspace is not None and (profile is None or profile.workspace_trust is None):
        if profile is None:
            detail = f"no loadable profile for {args.cli!r}"
        else:
            detail = f"profile {profile.name!r} declares none"
        print(
            f"FAIL: --workspace needs a profile declaring [workspace_trust]; {detail}",
            file=sys.stderr,
        )
        return 1

    if profile is not None and profile.hookless:
        print(
            f"{profile.name}: hookless HTTP/SSE profile — probe-adapter finalizes "
            "tmux/transcript-driven CLIs (hook dialects, transcript shapes) and has "
            "nothing to collect here. The HTTP contract is documented in the "
            "opencode_http adapter (src/riaworks_waves_loop/adapters/opencode_http.py).",
            file=sys.stderr,
        )
        return 1

    # Pseudonymize the one identifier-shaped value the probe KNOWS is the
    # user's (diagnose aliases the same value, ns="project"): the project
    # directory name, which would otherwise pass the location redaction's
    # identifier gate verbatim. Registration is skipped when the name collides
    # with a token that legitimately appears in the report (the CLI or binary
    # name) — otherwise the guard's repair pass would rewrite every occurrence
    # of that legitimate token into the alias and mangle the report.
    pseudo = sanitize.Pseudonymizer()
    legit_tokens = {args.cli, Path(args.binary).name if args.binary else ""}
    if profile is not None:
        legit_tokens.add(Path(profile.binary).name)
    if project.name not in legit_tokens:
        pseudo.alias(project.name, ns="project")

    if args.probe:
        if profile is None:
            prefix = "Codex hook trust unverifiable: " if codex_profile_error else ""
            print(
                f"FAIL: {prefix}--probe needs a known profile (its hook dialect/events)",
                file=sys.stderr,
            )
            return 1
        finding = probe_mod.probe(
            cli=args.cli,
            profile=profile,
            project=project,
            hints=hints,
            timeout_s=args.timeout,
            keep_temp=args.keep_temp,
            pseudo=pseudo,
        )
    else:
        finding = probe_mod.scan(
            cli=args.cli, profile=profile, project=project, hints=hints, pseudo=pseudo
        )
    if args.workspace is not None and profile is not None:
        probe_mod.check_workspace_trust(finding, profile, Path(args.workspace))
    if codex_profile_error:
        finding.hook_trust = "unverifiable"
        finding.warnings.append("Codex hook trust unverifiable: profile cannot be loaded")
        finding.next_steps.append("Repair the Codex profile, then re-run the probe")

    # One or the other, never both: --json selects the pure JSON document
    # (machine.py contract), otherwise the human-readable markdown report.
    # Either way the renderer runs the egress self-check over its own rendered
    # bytes and raises instead of returning tainted output.
    repairs: list[tuple[str, int]] = []
    try:
        if args.json:
            report = probe_mod.render_json(finding, pseudo=pseudo, repairs=repairs)
        else:
            report = probe_mod.render_markdown(finding, pseudo=pseudo, repairs=repairs)
    except probe_mod.LeakDetected as e:
        # Fail closed BEFORE any egress: message → stderr, stdout stays empty,
        # no partial --out file, exit != 0 (the machine.py error shape).
        print(
            f"FAIL: refusing to emit — leak self-check fired: {', '.join(e.rules)}",
            file=sys.stderr,
        )
        print(
            "hint: sensitive[project:<alias>] is your project directory name; any "
            "other rule means PII/secret-shaped content reached the report — please "
            f"report the rule names above as a {namespace.PRODUCT} bug",
            file=sys.stderr,
        )
        return 1

    if repairs:
        merged: dict[str, int] = {}
        for label, count in repairs:
            merged[label] = merged.get(label, 0) + count
        summary = ", ".join(f"{label} x{count}" for label, count in sorted(merged.items()))
        print(
            f"warning: leak backstop pseudonymized {sum(merged.values())} stray "
            f"occurrence(s) ({summary}) — a per-field routing gap in {namespace.PRODUCT}; "
            "please include this line in your bug report",
            file=sys.stderr,
        )

    # Every `ok:` trailer is human-facing chatter, so in JSON mode it goes to
    # stderr — stdout is the document alone, or empty when --out took it.
    trailers = sys.stderr if args.json else sys.stdout
    trust_ok = finding.hook_trust in (None, "trusted") and finding.workspace_trust in (
        None,
        "trusted",
    )
    trailer_prefix = "ok" if trust_ok else "FAIL"
    if args.out:
        out_path = Path(args.out)
        if args.json:
            machine.write_document(out_path, report)
        else:
            out_path.write_text(report, encoding="utf-8")
        print(
            f"  {trailer_prefix}: {noun} written to {out_path} ({len(finding.warnings)} warning(s))",
            file=trailers,
        )
    else:
        if args.json:
            machine.emit_document(report)
        else:
            print(report)
        print(
            f"  {trailer_prefix}: {finding.mode} {noun} for {args.cli} "
            f"({len(finding.warnings)} warning(s))",
            file=trailers,
        )
    return 0 if trust_ok else 1


def cmd_diagnose(args: argparse.Namespace) -> int:
    from . import diagnostics, sanitize

    project = _project(args)
    if args.all:
        run_dirs, fault = runs.list_run_dirs(project)
        if fault is not None:
            print(f"warning: run listing incomplete: {fault}", file=sys.stderr)
    elif args.run_id:
        try:
            run_dirs = [runs.resolve_run_dir(project, args.run_id)]
        except runs.RunRefError as e:
            print(str(e), file=sys.stderr)
            return 1
    else:
        latest = _latest_run_dir(project)
        run_dirs = [latest] if latest is not None else []
    if not run_dirs:
        print("no runs found", file=sys.stderr)
        return 1

    pseudo = sanitize.Pseudonymizer()
    diag = diagnostics.collect(
        run_dirs, pseudo=pseudo, cap=args.max_journal_entries, project=project
    )
    repairs: list[tuple[str, int]] = []
    fail_rules: list[str] | None = None
    report = ""
    try:
        # Exactly one render — JSON mode skips render_markdown entirely. The
        # warrant has two halves, and only the first is about coverage:
        #   FIELDS: render_json's asdict() covers every field the markdown report
        #     merely samples, so nothing escapes the guard by not being rendered.
        #   ENCODING: json.dumps is NOT a faithful carrier of the bytes the guard
        #     matches on — it doubles backslashes and (by default) escapes
        #     non-ASCII, which silently defeated the absolute-home-path and
        #     sensitive-value rules that the markdown pass used to catch. That is
        #     closed at the source, not here: sanitize._ABS_HOME_RE now matches the
        #     escaped separator too, and render_json dumps with ensure_ascii=False.
        # So the JSON self-check is a superset in field coverage and equal in
        # encoding fidelity — never rely on the field half alone.
        # Dropping the second render also fixes a live double-count: both renders
        # extend the same `repairs` list, inflating the warning ~2x.
        if args.json:
            report = diagnostics.render_json(diag, pseudo=pseudo, repairs=repairs)
        else:
            report = diagnostics.render_markdown(diag, pseudo=pseudo, repairs=repairs)
    except diagnostics.LeakDetected as e:
        fail_rules = e.rules

    if args.legend:
        # Written even when the self-check refused: the legend is what decodes a
        # sensitive[<ns>:<alias>] rule name, and it never leaves this machine.
        legend_path = Path(args.legend)
        # The legend reverses the pseudonyms, so it must never land world-readable
        # via the inherited umask — create it owner-only (0600).
        fd = os.open(legend_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(pseudo.legend(), f, indent=2)
            f.write("\n")
        print(
            f"  ok: alias legend written to {legend_path} — LOCAL ONLY, do NOT share "
            "(it reverses the pseudonyms); delete after use",
            file=sys.stderr,
        )

    if fail_rules is not None:
        # The output tripped the final self-check — fail closed, emit no dump.
        print(
            f"FAIL: refusing to emit — leak self-check fired: {', '.join(fail_rules)}",
            file=sys.stderr,
        )
        print(
            "hint: sensitive[<ns>:<alias>] names a pseudonymized identifier; rerun with "
            "--legend FILE to decode it locally (never share the legend), and report the "
            f"rule names above as a {namespace.PRODUCT} bug",
            file=sys.stderr,
        )
        return 1

    if repairs:
        merged: dict[str, int] = {}
        for label, count in repairs:
            merged[label] = merged.get(label, 0) + count
        summary = ", ".join(f"{label} x{count}" for label, count in sorted(merged.items()))
        print(
            f"warning: leak backstop pseudonymized {sum(merged.values())} stray "
            f"occurrence(s) ({summary}) — a per-field routing gap in {namespace.PRODUCT}; "
            "please include this line in your bug report",
            file=sys.stderr,
        )

    if args.out:
        out_path = Path(args.out)
        if args.json:
            # Verbatim, validated, newline-terminated — byte-identical to the
            # stdout form, and the same bytes render_json's self-check verified.
            machine.write_document(out_path, report)
        else:
            out_path.write_text(report, encoding="utf-8")
        print(
            f"  ok: sanitized diagnostics for {len(diag.runs)} run(s) written to {out_path}",
            # JSON mode must leave stdout empty even when the document went to a
            # file; text mode keeps the trailer on stdout, as before.
            file=sys.stderr if args.json else sys.stdout,
        )
    elif args.json:
        # Verbatim: these are the exact bytes render_json's self-check verified.
        machine.emit_document(report)
    else:
        print(report)
    return 0


def cmd_init(args: argparse.Namespace) -> int:
    from .install import install_into

    project = _project(args)
    if args.cli:
        clis = tuple(args.cli)
    else:
        # missing policy file yields defaults -> ("claude",)
        pol = policy_mod.load(_policy_path(project))
        clis = tuple(dict.fromkeys(pol.adapter.resolved(role).name for role in ROLES))
    return install_into(project, clis=clis, skills=args.skills, force_skills=args.force_skills)


def cmd_relay(args: argparse.Namespace) -> int:
    """``waves relay <Event>`` — the hook relay as an installed console script.

    ``init`` registers the absolute entry point belonging to this installation.
    ``hooks.relay-present`` checks the path each registration actually names.

    Total by contract, unlike every other handler: a coding CLI runs this INSIDE
    the session whose completion it reports, and several of them surface a
    non-zero hook exit as a failed tool call in that session. So nothing here
    escalates. :func:`events.relay` already swallows the relay-level failures
    (unset env, garbage stdin, a hostile events dir); the backstop below covers
    the rest — an unexpected exception is a bug in this file, and a bug must not
    be the reason a run's Stop signal turns into a broken session. It reports on
    stderr, never stdout: hook stdout is parsed by the host.

    Dispatched from ``main()`` BEFORE its shared ``try``/``except`` on purpose —
    see the comment there.
    """
    try:
        return events.relay(args.event, sys.stdin)
    except Exception as e:
        # Deliberately broad, and deliberately not re-raised: the alternative to a
        # diagnostic line here is a traceback on the host's hook channel plus a
        # non-zero rc. Narrower than the BaseException it could be — a Ctrl+C or a
        # SystemExit is not a relay-level problem and keeps its own exit path.
        print(f"{namespace.PRODUCT} relay: {type(e).__name__}: {e}", file=sys.stderr)
        return ExitCode.OK


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog=PROG,
        description="Deterministic orchestrator for the BMAD implementation phase",
    )
    parser.add_argument("--version", action="version", version=f"{PROG} {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    def add(name: str, func, help: str, *, aliases=()) -> argparse.ArgumentParser:
        p = sub.add_parser(name, help=help, aliases=aliases)
        p.add_argument("--project", default=".", help="target project root (default: cwd)")
        p.set_defaults(func=func)
        return p

    init_p = add(
        "init", cmd_init, "install hooks + skills + policy template into the target project"
    )
    init_p.add_argument(
        "--cli",
        action="append",
        metavar="PROFILE",
        help="CLI profile(s) to register hooks for (claude | codex | gemini | copilot | "
        "antigravity | opencode-http (alias: opencode) | custom; "
        f"repeatable; default: profiles referenced by {namespace.STATE_REL}/policy.toml, or claude)",
    )
    init_p.add_argument(
        "--no-skills",
        dest="skills",
        action="store_false",
        help=f"skip installing the bundled {namespace.PRODUCT}-* skills (hooks/policy only)",
    )
    init_p.add_argument(
        "--force-skills",
        action="store_true",
        help=f"overwrite {namespace.PRODUCT}-* skill dirs that already exist (default: skip them)",
    )
    validate_p = add("validate", cmd_validate, "preflight checks; exit non-zero on failure")
    validate_p.add_argument(
        "--spec",
        metavar="FOLDER",
        help="validate stories mode against this epic spec folder's stories.yaml "
        "(overrides [stories].source; skips the sprint-status gate)",
    )
    validate_p.add_argument(
        "--render-probe",
        action="store_true",
        help="also execute each dev skill's render command (from its SKILL.md) in a "
        "throwaway temp copy of _bmad/ + the skill (no coding CLI, project untouched; "
        "the launcher, typically `uv run --no-cache`, fetches the renderer's deps on "
        "each probe, so it needs network access)",
    )
    machine.add_json_flag(validate_p, "check findings")

    config_p = add(
        "config",
        cmd_config,
        "the configuration map: every file a run reads, its state, and the door that "
        f"owns it ({namespace.SKILL_CONFIG} is the human's door; this is its instrument). "
        "Exit 1 when a finding is a problem",
    )
    machine.add_json_flag(config_p, "the configuration map")

    tea_p = add(
        "tea-config",
        cmd_tea_config,
        "resolve the TEA integration's configuration surface (and, with --write, "
        "refresh the _bmad/custom files this tool manages)",
    )
    tea_p.add_argument(
        "--write",
        action="store_true",
        help="write/refresh the managed _bmad/custom/bmad-testarch-*.toml files "
        "(what `init` runs); files the project owns are left untouched",
    )
    machine.add_json_flag(tea_p, "the resolved TEA configuration")

    mux_p = add(
        "mux",
        cmd_mux,
        "list terminal-multiplexer backends + selection; `mux set <name>` persists a choice",
    )
    mux_p.add_argument(
        "action",
        nargs="?",
        choices=("set",),
        help=f"set: persist a backend choice into {namespace.STATE_REL}/policy.toml",
    )
    mux_p.add_argument("name", nargs="?", help="backend name to persist (see the listing)")
    mux_p.add_argument(
        "--clear",
        action="store_true",
        help="with set: remove the persisted choice (back to auto-select)",
    )
    mux_p.add_argument(
        "--force",
        action="store_true",
        help="with set: persist a name not registered in this process (e.g. a plugin "
        "backend that only registers on the target machine)",
    )

    add(
        "adapters",
        cmd_adapters,
        "list registered coding-CLI adapter kinds + which profiles select them",
    )

    probe_p = add(
        "probe-adapter",
        cmd_probe,
        "collect + sanitize adapter-finalization data for a coding CLI",
        aliases=["collect-adapter-data"],
    )
    probe_p.add_argument(
        "cli",
        help="CLI profile name (claude | codex | gemini | copilot | antigravity | custom; "
        "opencode-http is HTTP-driven — nothing to probe)",
    )
    probe_p.add_argument(
        "--probe",
        action="store_true",
        help="opt-in LIVE capture: launch one trivial content-free turn in a temp "
        "workspace and capture real hook payloads (default: zero-launch scan)",
    )
    probe_p.add_argument(
        "--transcript", help="exact transcript file to inspect (overrides discovery)"
    )
    probe_p.add_argument(
        "--session-dir", help="dir to glob for the newest transcript (custom CLIs)"
    )
    probe_p.add_argument("--binary", help="binary name for a CLI with no profile yet")
    probe_p.add_argument("--model", help="model passed to the probe turn (probe mode)")
    probe_p.add_argument(
        "--workspace",
        metavar="PATH",
        help="also report (read-only) whether PATH is in the profile's declared "
        "workspace-trust list ([workspace_trust]); exit 1 unless trusted",
    )
    probe_p.add_argument(
        "--timeout", type=float, default=90, help="probe turn timeout (default: 90s)"
    )
    probe_p.add_argument(
        "--out",
        help="write the output (report, or the JSON document with --json) to this file instead of stdout",
    )
    machine.add_json_flag(probe_p, "probe finding")
    probe_p.add_argument("--keep-temp", action="store_true", help=argparse.SUPPRESS)

    run_p = add(
        "run",
        cmd_run,
        "run the loop — an LLM session holds the control loop by default; "
        "--deterministic runs the fixed-pipeline engine instead",
    )
    run_p.add_argument(
        "--deterministic",
        action="store_true",
        help="drive the run with the deterministic engine (a fixed pipeline that pauses "
        "for a human at every crossroads) instead of the LLM control loop",
    )
    run_p.add_argument(
        "--resume",
        metavar="REF",
        help="resume a paused LLM-held run by its ref (a deterministic run resumes with "
        "`resume <ref>`)",
    )
    run_p.add_argument(
        "--spec",
        metavar="FOLDER",
        help="force stories mode: dispatch the epic spec folder's stories.yaml by "
        "folder+id (overrides [stories].source)",
    )
    run_p.add_argument("--epic", type=int, help="only stories from this epic (sprint mode)")
    run_p.add_argument(
        "--story",
        help="story: E-S / E.S (split suffix ok, e.g. 2-6a), a slug fragment, "
        "or full key (sprint mode); a story id (stories mode)",
    )
    run_p.add_argument("--max-stories", type=int, help="stop after N stories")
    run_p.add_argument(
        "--plan",
        metavar="FILE",
        help=f"run the stories of an approved wave plan ({namespace.SKILL_MASTER_PARALLELISM}'s "
        "`epic-<N>-plan-<stamp>.md`) in wave order — a wave's fronts in parallel up to [scm] "
        'max_parallel under isolation = "worktree", else one at a time; the plan is the whole '
        "scope — exclusive with --epic/--story/--spec, --max-stories still caps it",
    )
    run_p.add_argument("--dry-run", action="store_true", help="print the plan, spawn nothing")
    run_p.add_argument("--run-id", help=argparse.SUPPRESS)  # pre-assigned id (used by the TUI)
    # The wave master's children (wavemaster.py): one front of one wave, integration held.
    run_p.add_argument("--front", help=argparse.SUPPRESS)
    run_p.add_argument("--wave", type=int, help=argparse.SUPPRESS)
    run_p.add_argument("--parent", help=argparse.SUPPRESS)

    sweep_p = add("sweep", cmd_sweep, "triage + execute open deferred-work.md entries")
    sweep_p.add_argument(
        "--no-prompt",
        action="store_true",
        help="unattended: skip decision prompts, run only decision-free bundles",
    )
    sweep_p.add_argument(
        "--decisions-only",
        action="store_true",
        help="triage + answer decisions + record them; run no bundles",
    )
    sweep_p.add_argument("--max-bundles", type=int, help="override [sweep] max_bundles")
    selectors = sweep_p.add_mutually_exclusive_group()
    selectors.add_argument(
        "--only",
        metavar="DW-ID,...",
        help="triage only the named open DW-<n> entries",
    )
    selectors.add_argument(
        "--min-severity",
        choices=("low", "medium", "high", "critical"),
        help="triage open entries at this severity or higher",
    )
    sweep_p.add_argument(
        "--repeat",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="override [sweep] repeat: after a cycle completes, re-triage and continue "
        "on newly deferred work until nothing addressable completes",
    )
    sweep_p.add_argument("--max-cycles", type=int, help="override [sweep] max_cycles")
    sweep_p.add_argument(
        "--dry-run",
        action="store_true",
        help="list open ledger entries, spawn nothing; with --archive: list the "
        "entries that would move, write nothing",
    )
    sweep_p.add_argument(
        "--archive",
        action="store_true",
        help="move closed (status: done <ISO date>) deferred-work entries to a "
        "sibling deferred-work-archive.md, leaving a minimal stub in the live "
        "ledger; use --before DATE to archive only entries closed before that "
        "date, and --dry-run to preview",
    )
    sweep_p.add_argument(
        "--before",
        metavar="DATE",
        help="with --archive: archive only entries closed before this ISO date",
    )
    sweep_p.add_argument("--run-id", help=argparse.SUPPRESS)  # pre-assigned id (used by the TUI)

    resume_p = add("resume", cmd_resume, "resume a paused run")
    resume_p.add_argument("run_id")
    resume_p.add_argument(
        "--accept-baseline",
        action="store_true",
        help="adopt the current HEAD as the new baseline of every in-place story this "
        "resume restarts, so commits above the old baseline are kept instead of being "
        "parked on attempt-preserve/* and reset over. It adopts EVERYTHING at HEAD, "
        "including any commits the interrupted attempt made, and treats every current "
        "untracked file as pre-existing (never cleaned) — check "
        "`git log <baseline>..HEAD` first. Uncommitted tracked changes still follow "
        "the normal rollback. The flag applies to this resume only, but an adopted "
        "baseline stays adopted if that resume then pauses. Not needed right after "
        "`resolve`, whose re-arm already advances the baseline; commits made after a "
        "`resolve --no-resume` re-arm still need it",
    )

    resolve_p = add(
        "resolve", cmd_resolve, "resolve a CRITICAL escalation interactively, then re-arm + resume"
    )
    resolve_p.add_argument("run_id")
    resolve_p.add_argument("--story", help="story key to resolve (default: the paused one)")
    resolve_p.add_argument(
        "--no-interactive",
        dest="interactive",
        action="store_false",
        help="skip the resolve agent (spec already fixed by hand); just re-arm + resume",
    )
    resolve_mode = resolve_p.add_mutually_exclusive_group()
    resolve_mode.add_argument(
        "--restore-patch",
        metavar="PATH",
        help="intent-gap patch-restore (#2564): re-arm the spec to `in-review` and "
        "re-apply this saved patch before the re-drive, resuming review on the "
        "attempted change instead of re-implementing (hand-driven; the interactive "
        "agent supplies it via resolution.json)",
    )
    resolve_mode.add_argument(
        "--adopt-branch",
        action="store_true",
        help="finish the escalated story from its kept worktree branch instead of "
        "re-driving it: commit and merge the branch as-is, mark the story done, and "
        "resume. Skips the resolve agent and does NOT re-run review, [verify] commands or "
        "pre_commit_gate workflows for the story "
        "(worktree isolation only; not for sweep runs)",
    )
    resolve_p.add_argument(
        "--resume",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="--resume: re-arm + resume without prompting; --no-resume: re-arm only "
        "(default: prompt to confirm, then resume)",
    )
    resolve_p.add_argument(
        "--force",
        action="store_true",
        help="proceed when engine liveness is unverifiable (unknown); "
        "a provably-live engine still blocks",
    )

    decisions_p = add(
        "decisions",
        cmd_decisions,
        "answer deferred-work decisions earlier sweeps left unanswered",
    )
    decisions_p.add_argument(
        "--list",
        action="store_true",
        help="list the pending decisions without answering them",
    )
    decisions_p.add_argument(
        "--answer",
        action="append",
        metavar="DW-N=KEY",
        help="answer non-interactively (repeatable); the whole batch is validated "
        "before any of it is written. Cannot be combined with --list or --json",
    )
    machine.add_json_flag(decisions_p, "pending decisions")

    confirm_p = add(
        "confirm",
        cmd_confirm,
        "complete a story parked at awaiting-operator once its external actions are done",
    )
    confirm_p.add_argument(
        "story_key",
        nargs="?",
        help="the parked story to confirm (omit with --list)",
    )
    confirm_p.add_argument(
        "--list",
        action="store_true",
        help="list the parked stories and what each owes, without confirming any",
    )
    confirm_p.add_argument(
        "--yes",
        action="store_true",
        help="skip the per-action acknowledgment prompts",
    )
    confirm_p.add_argument(
        "--reverify",
        action="store_true",
        help="re-run the project's [verify] commands first; a failure blocks the confirmation",
    )
    machine.add_json_flag(confirm_p, "stories awaiting operator actions")

    list_p = add("list", cmd_list, "list runs/sweeps with their short ref", aliases=["ls"])
    machine.add_json_flag(list_p, "run listing")

    status_p = add("status", cmd_status, "show run + sprint state")
    status_p.add_argument("run_id", nargs="?")
    machine.add_json_flag(status_p, "run state")

    diag_p = add(
        "diagnose",
        cmd_diagnose,
        "emit a sanitized diagnostic dump of a run/sweep to hand to maintainers",
        aliases=["diag"],
    )
    diag_p.add_argument("run_id", nargs="?", help="run ref (default: latest)")
    diag_p.add_argument("--all", action="store_true", help="dump every run in the project")
    diag_p.add_argument(
        "--out",
        help="write the output (report, or the JSON document with --json) to this file instead of stdout",
    )
    machine.add_json_flag(diag_p, "diagnostic dump")
    diag_p.add_argument(
        "--max-journal-entries",
        type=int,
        default=200,
        metavar="N",
        help="cap of fully-scrubbed journal entries per run (0 = histogram only; default 200)",
    )
    # Hidden: writes the alias->original map locally for the dump's author. Never
    # shareable — it reverses the pseudonyms.
    diag_p.add_argument("--legend", help=argparse.SUPPRESS)

    attach_p = add("attach", cmd_attach, "tmux attach to a run's session")
    attach_p.add_argument("run_id", nargs="?")

    intervene_p = add(
        "intervene",
        cmd_intervene,
        "read, speak to, or hold the clock on a run's live session — journalled",
    )
    intervene_p.add_argument("run_id", nargs="?")
    intervene_act = intervene_p.add_mutually_exclusive_group(required=True)
    intervene_act.add_argument(
        "--read", action="store_true", help="print the tail of the live session's log"
    )
    intervene_act.add_argument(
        "--say", metavar="TEXT", help="submit TEXT into the live session (holds + journals)"
    )
    intervene_act.add_argument("--note", metavar="TEXT", help="journal an operator note only")
    intervene_act.add_argument(
        "--hold", action="store_true", help="refresh the hold on the session-timeout clock"
    )
    intervene_act.add_argument("--release", action="store_true", help="drop the hold")
    intervene_p.add_argument(
        "--lines", type=int, default=40, help="with --read: how many trailing lines (default 40)"
    )
    intervene_p.add_argument(
        "--task",
        metavar="TASK_ID",
        help="which session to act on; defaults to the one with the freshest heartbeat. "
        "An llm-run can have the orchestrator and a dispatched worker live at once, "
        "and there 'freshest' is a coin toss — name the task",
    )
    intervene_p.add_argument("--by", default="", help="who is intervening; recorded in the journal")
    intervene_p.add_argument("--reason", default="", help="why; recorded in the journal")
    intervene_p.add_argument(
        "--json", action="store_true", help="emit the machine-readable document (see machine.py)"
    )

    stop_p = add("stop", cmd_stop, "stop a live run (engine + agent session)")
    stop_p.add_argument("run_id")
    stop_grp = stop_p.add_mutually_exclusive_group()
    stop_grp.add_argument(
        "--graceful",
        action="store_true",
        help="finish the in-flight item (through commit), then stop cleanly and stay "
        "resumable — instead of the default hard stop; also suppresses pending auto-sweeps",
    )
    stop_grp.add_argument(
        "--cancel-graceful",
        action="store_true",
        help="cancel a pending --graceful request (the run keeps going)",
    )

    delete_p = add("delete", cmd_delete, "delete a run directory")
    delete_p.add_argument("run_id")
    delete_p.add_argument(
        "--force", action="store_true", help="stop the run first if it is still live"
    )

    archive_p = add(
        "archive",
        cmd_archive,
        f"compress a run into {namespace.STATE_REL}/archive and remove it; "
        "for ledger archiving see `sweep --archive`",
    )
    archive_p.add_argument("run_id")
    archive_p.add_argument(
        "--force", action="store_true", help="stop the run first if it is still live"
    )

    cleanup_p = add(
        "cleanup", cmd_cleanup, "remove tmux sessions/windows for finished or stopped runs"
    )
    cleanup_p.add_argument(
        "--dry-run",
        action="store_true",
        help="list what would be removed without killing anything",
    )
    machine.add_json_flag(cleanup_p, "sessions and ctl windows removed, or that would be")

    clean_p = add(
        "clean",
        cmd_clean,
        "reclaim disk from concluded runs (tear down leaked worktrees, trim/archive per [cleanup])",
    )
    clean_p.add_argument(
        "--dry-run",
        action="store_true",
        help="list what would be reclaimed without removing anything",
    )
    clean_p.add_argument(
        "--keep",
        action="append",
        metavar="RUN_ID",
        help="run id to never touch (repeatable; e.g. a finished run whose Editor is still live)",
    )
    clean_p.add_argument(
        "--retain",
        type=int,
        metavar="N",
        help="keep the newest N concluded runs whole (overrides [cleanup] run_retention)",
    )
    clean_p.add_argument(
        "--hard",
        action="store_true",
        help="permanently delete runs past the retention window instead of archiving them",
    )
    machine.add_json_flag(clean_p, "what was reclaimed, or would be")

    tui_p = add(
        "tui",
        cmd_tui,
        f"interactive dashboard (needs `uv tool install '{namespace.DISTRIBUTION}[tui]'`)",
    )
    tui_p.add_argument(
        "--low-frame-rate",
        action="store_true",
        help="cap to 15fps + disable animations (TEXTUAL_FPS / TEXTUAL_ANIMATIONS) — "
        "fixes repaint tearing over slow/SSH links; also settable via [tui] low_frame_rate",
    )

    # The LLM-held control loop and its verb surface. Imported here rather than at
    # module scope so nothing on the deterministic path depends on the package.
    from .llm.cli import add_subcommands as _add_llm_subcommands

    _add_llm_subcommands(add)

    # Registered directly rather than through `add()`: `relay` takes no --project.
    # It is handed a run directory by the engine (via the session env) and must
    # work with no project state at all — see the dispatch below.
    relay_p = sub.add_parser(
        "relay",
        help="write one session event file from a coding-CLI hook payload on stdin "
        "(a hook target for machines, not a command to run by hand)",
    )
    relay_p.add_argument(
        "event",
        nargs="?",
        default="Unknown",
        help="canonical event name (Stop, SessionStart, …); the hooks always pass one",
    )
    relay_p.set_defaults(func=cmd_relay)

    args = parser.parse_args(argv)
    # `relay` dispatches HERE, ahead of everything below, and the placement is the
    # contract rather than an optimization. A coding CLI runs `waves relay Stop`
    # inside the session whose completion it reports, and a hook that exits non-zero
    # is surfaced by several hosts as a failed tool call in that session — so the
    # `except` arms below, which print `error: …` and return 1 (or 130), are exactly
    # the outcome the hook contract forbids. `_configure_mux(_project(args))` is
    # skipped for the same reason and one more: relay touches neither mux nor policy,
    # and a project whose policy.toml is broken must still be able to report that its
    # session stopped. `cmd_relay` is total, so nothing is lost by not wrapping it.
    if args.func is cmd_relay:
        return cmd_relay(args)
    try:
        # Install the policy [mux] backend choice before dispatch: several
        # handlers (probe/diagnose/attach/stop/cleanup/tui) reach the mux
        # without ever loading policy, so this is the one reliable seam.
        _configure_mux(_project(args))
        return args.func(args)
    except (
        bmadconfig.BmadConfigError,
        sprintstatus.SprintStatusError,
        policy_mod.PolicyError,
        verify.GitError,
    ) as e:
        print(f"error: {e}", file=sys.stderr)
        return ExitCode.FAILURE
    except KeyboardInterrupt:
        # Ctrl+C on the residual surface outside engine.run() (config load, engine
        # construction, a handler with no run loop). A KeyboardInterrupt is a
        # BaseException, so the broad `except Exception` below never caught it.
        # Uncaught it already ends at 130 — CPython re-raises SIGINT (128+2) — but as
        # death-by-signal with a bare traceback dumped after any partial --json stdout.
        # Catch it for a clean, intentional exit(130): one line on stderr, nothing on
        # stdout. The in-run interrupt is engine.run()'s own clean RunStopped (see
        # engine.py) and never reaches here.
        print("interrupted", file=sys.stderr)
        return ExitCode.INTERRUPTED
    except Exception as e:
        # backstop for the residual surface outside engine.run() (config load,
        # engine construction, render/notify): never let an unexpected exception
        # die to the parked control pane with a bare traceback.
        print(f"error: {e}", file=sys.stderr)
        return ExitCode.FAILURE


if __name__ == "__main__":
    sys.exit(main())
