"""Findings — the structured form of what ``waves validate`` reports.

``validate`` accumulated two lists of prose strings, printed one as ``  ok:`` and
the other as ``FAIL:``. That made the *outcome* addressable (the exit code) but
not the *checks*: a script wanting to branch on "hooks aren't registered" had to
match remediation sentences, which are the part most likely to be reworded. A
:class:`Finding` pairs each printed line with a stable ``check`` id, so the id is
the matchable identity and the message stays free to change.

This lives in its own module rather than in ``cli`` or ``machine``:

- ``cli`` imports ``install``, and ``install`` must *return* Findings — putting
  the type in ``cli`` would make that a cycle.
- ``machine`` is deliberately narrow: transport for the ``--json`` contract, zero
  domain knowledge. Severity is a concept no other ``--json`` command has.

:data:`VALIDATE_CHECKS` is the registry every id must be in, enforced by an
assert in :meth:`ValidationReport.add`. That is what keeps "one printed line =
exactly one Finding" true: a new check site cannot ship without first naming
itself here. The assert only ever fires on a literal an author just wrote, never
on runtime data, so it is a lint with a stack trace rather than a validation.
"""

# Strict-checked under #245 Stage 2, with one rule relaxed for this file only:
# `ValidationReport.findings` uses the idiomatic `field(default_factory=list)`,
# which pyright can only infer as `list[Unknown]` (it does not fold the declared
# `list[Finding]` annotation back into the bare `list` factory) though the field
# is correctly typed. Every other strict rule stays on.
# pyright: reportUnknownVariableType=false

from __future__ import annotations

import os
import shlex
import shutil
import sys
from collections.abc import Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

Severity = Literal["ok", "warning", "problem"]

# The id names the *gate*, not the outcome — so the same id carries the ok and
# the problem for one check ("adapter.binary" is both "codex found" and "codex
# not found on PATH"). Ids are split only where the two outcomes are genuinely
# different findings with different detail (skills.base vs base-missing vs
# base-incomplete). Scheme: <area>.<check>.
VALIDATE_CHECKS: frozenset[str] = frozenset(
    {
        "bmad-config",
        # The installed BMAD-METHOD version against `bmadconfig.BMAD_METHOD_FLOOR`:
        # ok at or above it, a problem below it, a warning when the installer's
        # manifest cannot say. Shared with the run/sweep/resume preflight so the
        # two never disagree about whether a tree is supported.
        "bmad-config.version",
        "policy",
        "policy.model-qualified",
        "policy.effort-unsupported",
        "policy.bypass-dropped",
        # opencode-http: a role's extra_args repeating an adapter-owned serve flag (DW-483)
        "policy.extra-args-unservable",
        # worktree isolation beside a project that is NOT inside repo_root (a
        # disjoint layout, #414); a nested project is supported since DW-379
        "policy.isolation-repo-root",
        # `[scm] max_parallel > 1` without `isolation = "worktree"`: both loops run
        # such a `--plan` run serially (parallel stories need a tree each), so the
        # knob is inert — a warning, because the run is still correct, only slower
        # than the operator asked for.
        "policy.parallel-needs-worktree",
        "policy.absent",
        # worktree isolation beside an artifact dir inside repo_root but outside the
        # project: shared with the main checkout, not per-worktree (DW-485)
        "policy.isolation-shared-artifact-dir",
        "adapter.profile",
        "adapter.binary",
        "adapter.binary-unrunnable",
        "adapter.hookless",
        "adapter.httpx",
        "adapter.launch-args-unservable",
        "adapter.kind",
        "adapter.external",
        "adapter.external-profile",
        "queue.sprint-status",
        "queue.sprint-status-unknown-keys",
        "queue.stories-manifest",
        "git.worktree-clean",
        "git.probe",
        "git.render-tracked",
        "git.version",
        "hooks.config-parse",
        "hooks.registered",
        "hooks.trust",
        "hooks.relay-present",
        "hooks.relay-stale",
        # The four above are the ADAPTER's hook registration (relay events in
        # the coding CLI's own config). These two are a different thing: whether
        # a PLUGIN's declarative `hooks.<stage>.cmd` can actually be executed.
        # Nothing checked that before, so a hook could be unrunnable for a whole
        # epic and only ever surface as a bare exit code mid-run.
        "plugin.hook-runnable",
        "plugin.hook-unrunnable",
        # `[plugins] enabled` entries: a name no manifest answers to (a rename the
        # policy never followed) enables nothing and used to pass as "policy OK".
        "plugins.unknown",
        "hooks.relay-path-unsafe",
        "mux.backend",
        "mux.preflight",
        "mux.backends-detected",
        "mux.selection",
        "mux.external-backend",
        # a registered backend whose platform predicate, factory or available() raised (DW-464)
        "mux.backend-probe",
        "host.process",
        "host.win32-on-wsl-path",
        "notify.desktop-unavailable",
        "plugins.manifests",
        "skills.base",
        "skills.base-missing",
        "skills.base-incomplete",
        "skills.base-shim",
        "skills.customize-legacy",
        "skills.dev-renderer",
        "skills.dev-renderer-config",
        "skills.dev-renderer-sources",
        "skills.dev-render-probe",
        "skills.review-layer-missing",
        "skills.review-layer-unresolved",
        "skills.review-layers-empty",
        "skills.customize-unreadable",
        # The bundled skills are COPIED into the project by `init`, exactly like
        # the hook relay above, and age the same way. hooks.relay-stale had said
        # so for the relay since #494; nothing said it for the skills, and a
        # project ran a monitor 110 lines behind its source through an incident
        # the missing findings would have named.
        "skills.module-stale",
        # A bundled skill's override still in `_bmad/custom/`, where its own resolver
        # no longer reads it (3.1 moved them to `_waves/custom/`). A warning naming
        # `init` for the team layer and a move by hand for the personal one.
        "customize.location",
        "skills.stories-dispatch",
        "skills.stories-dispatch-missing",
        "skills.stories-dispatch-stale",
        "skills.sweep",
        "skills.sweep-missing",
        "skills.sweep-incomplete",
        "operator.registry-stale",
        "operator.actions-malformed",
        "operator.confirm-interrupted",
        "operator.park-record-missing",
        "deferred.closes-unknown",
        "deferred.closes-malformed",
        "deferred.closes-entry-unreadable",
        "deferred.hard-gate",
        "deferred.hard-gate-unstructured",
        "deferred.ledger-unreadable",
        # The TEA configuration surface (teaconfig.py). `tea.module` is the
        # readiness fact — TEA installed, and where it writes. The rest report on
        # the `_bmad/custom/<skill>.toml` files `init` manages: absent, stale,
        # unwritable, or taken over by the project (which is a decision to respect,
        # hence a warning and never a failure).
        "tea.module",
        "tea.customization",
        "tea.customization-missing",
        "tea.customization-foreign",
        "tea.customization-stale",
        "tea.customization-unwritable",
        "deferred.ledger-untracked",
        "deferred.ledger-ignored-isolated",
    }
)


@dataclass(frozen=True)
class Finding:
    """One check's outcome: a stable ``check`` id, a severity, the human line.

    ``message`` is the exact prose the text mode prints (minus the severity
    prefix) and is **not** contracted — several are a bare ``str(e)`` from the
    config/policy/profile/sprint-status exceptions, so the wording moves with
    those modules. ``detail`` carries what the check knew before it flattened
    itself into that sentence, keyed however suits the check.
    """

    check: str
    severity: Severity
    message: str
    detail: Mapping[str, object] | None = None


@dataclass
class ValidationReport:
    """The findings of one ``validate`` pass, in emission order.

    Emission order is the order the gates ran, and it is preserved across
    severities — :meth:`render` filters, it never re-sorts, so the text output is
    byte-identical to the two-list form it replaced (all stdout lines in append
    order, then all stderr lines in append order).
    """

    findings: list[Finding] = field(default_factory=list)

    def add(
        self,
        check: str,
        severity: Severity,
        message: str,
        detail: Mapping[str, object] | None = None,
    ) -> None:
        assert check in VALIDATE_CHECKS, f"unregistered check id: {check!r}"
        self.findings.append(Finding(check, severity, message, detail))

    def ok(self, check: str, message: str, detail: Mapping[str, object] | None = None) -> None:
        self.add(check, "ok", message, detail)

    def warn(self, check: str, message: str, detail: Mapping[str, object] | None = None) -> None:
        self.add(check, "warning", message, detail)

    def fail(self, check: str, message: str, detail: Mapping[str, object] | None = None) -> None:
        self.add(check, "problem", message, detail)

    def extend(self, findings: list[Finding]) -> None:
        for finding in findings:
            self.add(finding.check, finding.severity, finding.message, finding.detail)

    @property
    def passed(self) -> bool:
        """True when nothing failed. Warnings do not clear it and do not set it —
        this is exactly the validate exit code (0 when True, 1 when False)."""
        return not any(f.severity == "problem" for f in self.findings)

    def counts(self) -> dict[str, int]:
        return {
            severity: sum(1 for f in self.findings if f.severity == severity)
            for severity in ("ok", "warning", "problem")
        }

    def render(self) -> None:
        """Print the human-readable form: notes to stdout, then problems to stderr.

        The doubled space in the warning line (``  ok:   warning: ...``) is the
        shipped output, not a typo to tidy: the warning sites stored
        ``"  warning: " + msg`` into the same list the ``  ok: `` printer walked.
        Tidying it would be a silent text change — the validate tests
        substring-match on a lowercased stream and would not notice.
        """
        for finding in self.findings:
            if finding.severity == "ok":
                print(f"  ok: {finding.message}")
            elif finding.severity == "warning":
                print(f"  ok:   warning: {finding.message}")
        for finding in self.findings:
            if finding.severity == "problem":
                print(f"FAIL: {finding.message}", file=sys.stderr)


def hook_command_problem(cmd: str, cwd: Path | None = None) -> str | None:
    """Why ``cmd`` could not be executed as a declarative plugin hook, or None.

    Answers at preflight the question the hook bus only gets to ask at dispatch
    time, by which point the answer arrives as a bare exit code: 127 when the
    program is not there, 126 when it is there but unrunnable. Both mean the
    hook never ran, and both are configuration faults visible from a cold start
    — the cheapest place to catch them is before the run, not halfway through an
    epic.

    Deliberately conservative — this gates a run, so it reports only what it can
    prove. A command it cannot statically resolve (a pipeline, an env
    assignment, a ``$VAR`` that expands at dispatch) returns None rather than
    guessing: a false "your hook is broken" that blocks validate is worse than
    the silence it replaces.

    The CRLF case is named explicitly because it reads as impossible when you
    hit it: the file exists, ``ls -l`` shows the execute bit, ``cat`` prints a
    correct ``#!/usr/bin/env bash`` — and the kernel still refuses, because the
    shebang it actually parsed names an interpreter ending in a carriage return.
    """
    try:
        argv = shlex.split(cmd)
    except ValueError:
        return None  # unbalanced quotes — the shell's diagnostic to give, not ours
    if not argv:
        return None
    program = argv[0]
    # Shell metacharacters mean the first token need not be the program
    # (`FOO=1 cmd`, `a && b`, `$(x)`); resolving that is the shell's job.
    if any(ch in cmd for ch in "|&;<>$`") or "=" in program:
        return None
    if "/" not in program:
        if shutil.which(program) is None:
            return f"{program!r} is not on PATH (the hook would exit 127)"
        return None
    path = Path(program)
    resolved = path if path.is_absolute() else (cwd or Path.cwd()) / path
    if not resolved.exists():
        return f"{resolved} does not exist (the hook would exit 127)"
    if not os.access(resolved, os.X_OK):
        return f"{resolved} is not executable — chmod +x (the hook would exit 126)"
    try:
        with resolved.open("rb") as fh:
            first = fh.readline(512)
    except OSError:
        return None
    if not first.startswith(b"#!"):
        return None
    if first.rstrip(b"\n").endswith(b"\r"):
        return (
            f"{resolved} has CRLF line endings, so its shebang names an interpreter "
            f"ending in a carriage return and the hook would exit 126 before its "
            f"first line. Convert the file to LF and pin it with `*.sh text eol=lf` "
            f"in .gitattributes — under core.autocrlf=true a fresh checkout puts the "
            f"CRLF straight back."
        )
    parts = shlex.split(first[2:].strip().decode("utf-8", "replace"))
    if not parts:
        return None
    interpreter = parts[0]
    # `/usr/bin/env foo` — what must exist is `foo`, not env itself.
    if interpreter == "env" or interpreter.endswith("/env"):
        target = next((p for p in parts[1:] if not p.startswith("-")), "")
        if target and shutil.which(target) is None:
            return f"{resolved}: shebang interpreter {target!r} is not on PATH (exit 126)"
        return None
    if not Path(interpreter).exists():
        return f"{resolved}: shebang interpreter {interpreter} does not exist (exit 126)"
    return None
