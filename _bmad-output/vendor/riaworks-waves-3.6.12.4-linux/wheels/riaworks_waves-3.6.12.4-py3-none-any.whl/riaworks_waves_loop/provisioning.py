"""The provisioning contract: the stack a unit works against, owned by the run.

`git worktree add` gives a unit a tree, and the seeds give it the gitignored
config git would not carry. What neither gives is the STACK — dependencies
installed, a database of its own, an environment file, ports that answer to it —
and until this module projects provisioned that LLM-side, per story: a session
told to run a script, paying tokens for it, and asked to remember to give the
stack back. Measured on a project's own per-front recipe (a compose project and a
port range per worktree, a database cloned from the owner's installation): it
works, and nothing but the session's memory tore it down.

`[scm] provision` and `[scm] teardown` are operator-authored shell commands the
run itself executes, in the unit's worktree, with the run's coordinates in the
environment: `provision` right after the worktree is mounted and seeded, before
any session (a failure parks the story before a session is spent); `teardown`
when the unit leaves the run — after its integration, after a deferred or
failed close — best effort, always journaled, never blocking. A paused story
keeps its stack until it closes, because it resumes in the same worktree.

The plugin stages around the same moments (`post_worktree_setup`,
`pre_worktree_teardown`) stay: a project plugin that wants to own provisioning
binds them; the policy commands are the no-plugin path. Both run through the
same operator-command transport as declarative hooks, so a timeout or a missing
interpreter is a fact in the journal and never a crash.
"""

from __future__ import annotations

import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from . import envvars
from .childrun import ChildInterrupted
from .plugins.bus import OperatorCommandError, run_operator_command

#: What the journal keeps of a command's output — the tail, where the error is.
TAIL_CHARS = 2000

Runner = Callable[..., tuple[int, str]]


class ProvisionFailed(Exception):
    """`provision` did not leave a stack the unit can work against."""


@dataclass(frozen=True)
class StepResult:
    step: str  # "provision" | "teardown"
    rc: int
    seconds: float
    tail: str
    error: str = ""
    # A pending HARD stop cut the command short (upstream's stop-aware runner,
    # DW-353): not a failure of the stack, and the caller treats it as the stop.
    interrupted: bool = False

    @property
    def ok(self) -> bool:
        return self.rc == 0 and not self.error

    def journal_fields(self) -> dict[str, Any]:
        fields: dict[str, Any] = {"rc": self.rc, "seconds": round(self.seconds, 3)}
        if self.error:
            fields["error"] = self.error
        if self.tail and not self.ok:
            fields["tail"] = self.tail
        return fields


def step_env(
    *,
    step: str,
    run_id: str,
    run_dir: Path,
    repo_root: Path,
    worktree: Path,
    story_key: str,
    epic: int | None,
    branch: str,
    target_branch: str,
    plan_position: dict[str, Any] | None = None,
) -> dict[str, str]:
    """The `WAVES_*` coordinates a provisioning command reads — the hook protocol's
    names, so a recipe written for a plugin hook and one written for the policy
    read the same variables, plus the target branch and, in a plan run, the wave
    and front. Empty strings for what does not apply; never absent, so a script
    can test them without guarding against an unset name."""
    env = dict(os.environ)
    env.update(
        {
            envvars.STAGE: step,
            envvars.RUN_ID: run_id,
            envvars.RUN_DIR: str(run_dir),
            envvars.REPO_ROOT: str(repo_root),
            envvars.WORKTREE: str(worktree),
            envvars.STORY_KEY: story_key,
            envvars.EPIC: "" if epic is None else str(epic),
            envvars.BRANCH: branch,
            envvars.TARGET_BRANCH: target_branch,
            envvars.WAVE: "" if not plan_position else str(plan_position.get("wave", "")),
            envvars.FRONT: "" if not plan_position else str(plan_position.get("front", "")),
        }
    )
    return env


def run_step(
    step: str,
    cmd: str,
    *,
    cwd: Path,
    env: dict[str, str],
    timeout_s: int,
    runner: Runner = run_operator_command,
) -> StepResult:
    """Run one provisioning command and report it — never raise. A transport
    failure (timeout, no interpreter) is a result with `error` set and rc -1, so
    the caller journals one shape whatever went wrong. A hard stop request that
    killed the command's tree is the same shape with `interrupted` set: the caller
    decides what a stop means at its step, and a best-effort teardown in the middle
    of an integration must not be unwound by one."""
    started = time.monotonic()
    try:
        rc, output = runner(cmd, cwd=str(cwd), env=env, timeout=timeout_s)
    except OperatorCommandError as exc:
        return StepResult(step, -1, time.monotonic() - started, "", str(exc))
    except ChildInterrupted as exc:
        return StepResult(step, -1, time.monotonic() - started, "", str(exc), interrupted=True)
    tail = output[-TAIL_CHARS:] if len(output) > TAIL_CHARS else output
    return StepResult(step, rc, time.monotonic() - started, tail)
