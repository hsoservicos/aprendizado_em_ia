"""The one place this fork's identity is written down.

A fork that shares an upstream's on-disk namespace is not a separate tool: it is
a second writer of the same state. Both would list each other's runs, both would
offer to resume them, and the one that does not understand a run it did not
create rebuilds it under its own assumptions — silently, because nothing in the
directory says which tool owns it.

So everything the fork touches outside the source tree is namespaced here, and
derived from a single constant rather than spelled out at each site. Spelling it
out is how a rename half-lands: the state dir moves, the session prefix does not,
and the dashboard stops finding runs that are right there on disk. The third
rename of this fork (``riaworks-waves-loop`` → ``waves``, 2.0.0) paid that debt
off: 47 modules still carried the product as a literal, so
``tests/test_portability_guard.py`` now refuses a product string in any code
literal outside this module. A site that prints the command, a skill name, a
state path or an environment variable names the constant below instead.

The rule the names follow: **brand where it is read, product where it is typed.**
"Riaworks" stays in the display name, the README title and the distribution —
typed once, at install. Everything typed daily is the product alone.

What is deliberately NOT renamed:

* the Python package (``riaworks_waves_loop``) — MIT code, not product identity, and
  renaming it would churn every import to no effect;
* the story/spec artifacts under the project's BMAD output folder — those belong
  to the method, not to whichever loop is driving it, and a project must be able
  to switch drivers without moving its work.

The previous spellings (``riaworks-waves-loop``, ``RIAWORKS_WAVES_LOOP_*``,
``.riaworks-waves/`` and the skill names of 1.x, 2.0 and the first 3.0 cut) are gone:
the compatibility layer that migrated and mirrored them retired in 3.1, on the date it
had set for itself. A project still on 1.x upgrades through 3.0.x first, whose ``init``
performs that migration.
"""

from __future__ import annotations

from pathlib import Path

#: The invocable command and the root of every namespaced name below. Changing
#: this string moves the whole footprint together.
PRODUCT = "waves"

#: The distribution on PyPI / the Git source — what is typed once, at install
#: (``uv tool install riaworks-waves``). Carries the brand: it is read far more
#: often than typed.
DISTRIBUTION = "riaworks-waves"

#: The BMAD module code: ``module.yaml``'s ``code``, the ``_bmad/<code>/`` directory
#: the installer stages the module into, and the namespace directory TEA artifacts
#: are attributed under.
MODULE_CODE = PRODUCT

#: What a human reads: the module's display name, the README title.
DISPLAY_NAME = "Riaworks Waves"

#: The product's own directory in a project. Both halves live under this one roof:
#: the epic-parallelism skills write their run state here (trackers, briefs, front
#: worktrees, the suite lock), and the loop keeps its half in ``loop/`` below.
#:
#: The corollary is a hazard worth naming: the two halves share a parent, so an
#: ``rm -rf`` aimed at one takes the other with it. Nothing here can enforce that;
#: the directories are separate and neither writes into the other's.
STATE_ROOT = Path(f".{PRODUCT}")

#: Per-project loop state: runs, policy, archives, plugins, profiles, operator
#: records. NESTED under the product's own directory rather than beside it: a
#: sibling ``.<product>-loop/`` read as a second, unrelated tool while being the
#: same product — one name a prefix of the other, and no one able to say which
#: half owned what.
STATE_DIR = STATE_ROOT / "loop"

#: The same directory as operators read it — in messages, gitignore lines, docs.
STATE_REL = STATE_DIR.as_posix()

#: The product's VERSIONED home in a project, the sibling of the BMAD Method's
#: ``_bmad/``. ``STATE_ROOT`` above is run state — locks, logs, worktrees, the
#: per-machine policy — and the parallelism skills' pre-flight excludes it from git
#: wholesale, so nothing a team shares and reviews can live there. The skills'
#: customization and the verification memory live here instead.
PROJECT_HOME = Path(f"_{PRODUCT}")

#: The overrides of every bundled skill that ships a ``customize.toml``: the team
#: layer ``<skill>.toml`` (versioned) and the personal ``<skill>.user.toml``
#: (gitignored), read by the skill's own ``assets/resolve_customization.py``. They
#: lived in ``_bmad/custom/`` until 3.1; ``init`` moves the team layer.
CUSTOM_DIR = PROJECT_HOME / "custom"

#: The verification memory ``waves-tests`` writes and the parallelism skills read:
#: how to run each kind of test, which files need what evidence, and the file→test
#: rules proven by execution.
TESTS_MEMORY_DIR = PROJECT_HOME / "tests"

#: Environment variables handed to agent sessions and read back by the signal
#: hook. Namespaced for the same reason as the state dir, and more urgently: both
#: tools register a hook in the same coding-CLI config, so both fire on every
#: session, and the only thing telling a hook whether a session is its own is the
#: variable it reads. Sharing the prefix would have each tool's hook writing
#: events for the other's runs.
ENV_PREFIX = f"{PRODUCT.upper().replace('-', '_')}_"

#: Multiplexer session names: one per run, plus the control session the dashboard
#: launches detached work into.
SESSION_PREFIX = f"{PRODUCT}-"
CTL_SESSION = f"{PRODUCT}-ctl"

#: Git ref namespace for per-unit worktree branches and preserved attempts.
REF_NAMESPACE = PRODUCT

#: The hook relay ``init`` copies into a project, and its probe-capture sibling.
#: Underscored: they are Python modules by file name, and a coding CLI's hook
#: config quotes them verbatim. ``RELAY_MARKER`` is the substring a hook command
#: must carry to count as ours (``install.merge_hooks``, ``validate``); the probe
#: name is deliberately not a superstring of it.
HOOK_RELAY = f"{PRODUCT.replace('-', '_')}_hook.py"
PROBE_HOOK = f"{PRODUCT.replace('-', '_')}_probe_hook.py"
RELAY_MARKER = HOOK_RELAY.removesuffix(".py")
PROBE_MARKER = PROBE_HOOK.removesuffix(".py")
#: Where the relay lives once copied, relative to the project root.
HOOK_RELAY_REL = STATE_DIR / HOOK_RELAY

#: Antigravity keys ``.agents/hooks.json`` by hook NAME at the top level; every
#: handler this tool registers sits under this one group.
HOOK_GROUP = PRODUCT

#: The bundled skills, by role. The names are what a human types (``/<skill>``)
#: and what ``init`` lays into each CLI's skill tree, so they are identity, not
#: implementation. One door per domain for a human — ``master-tui`` drives the loop
#: (launch, resume, watch, in either mode), ``master-parallelism`` drives an epic's
#: waves (plan, approve, execute, continue, status) — and everything a door
#: dispatches or the automation invokes on its own carries ``core-``, so nobody
#: opens it by hand.
SKILL_SETUP = f"{PRODUCT}-setup"
SKILL_PROVISIONING = f"{PRODUCT}-provisioning"
SKILL_RESOLVE = f"{PRODUCT}-resolve"
SKILL_DEFERRED = f"{PRODUCT}-deferred"
SKILL_MASTER_TUI = f"{PRODUCT}-master-tui"
SKILL_MASTER_PARALLELISM = f"{PRODUCT}-master-parallelism"
SKILL_CORE_SWEEP = f"{PRODUCT}-core-sweep"
SKILL_CORE_ORCHESTRATOR = f"{PRODUCT}-core-orchestrator"
SKILL_CORE_PARALLELISM = f"{PRODUCT}-core-parallelism"
#: The door to the verification memory: discovers how a project runs its tests and
#: writes ``TESTS_MEMORY_DIR``. Its instruments are carried by the core.
SKILL_TESTS = f"{PRODUCT}-tests"
# The human's door to the module's whole configuration: the map of every file the
# runs read (policy, tests config, provisioning recipe, skill customizations, the
# watcher's rules), its state, and the owning door for each; owns only what has no
# door of its own (the adapters per role, the skill customizations, the watcher's
# rules). Its deterministic half is `waves config --json`.
SKILL_CONFIG = f"{PRODUCT}-config"

#: The bundled Test Architect plugin, as ``[plugins] enabled`` names it.
PLUGIN_TEA = f"{PRODUCT}-tea"

#: The release in which ``init`` stops moving skill overrides out of
#: ``_bmad/custom/`` into ``CUSTOM_DIR`` and ``validate`` stops naming the ones left
#: behind. It ships in 3.1, and a migration must outlive the release that introduces
#: it by more than zero minors. Pinned by a test so the drop is a decision, not a
#: leftover.
OVERRIDES_MOVE_RETIRES_IN = "4.0"


def resume_command(source: str, run_id: str) -> str:
    """The command that actually resumes a run, chosen by its ``RunState.source``.

    Lives beside :data:`PRODUCT` because it answers the same kind of question the
    rest of this module does — how is this tool spelled at an operator — and
    because it has to be reachable from every layer that prints a suggestion
    (``runs``, the CLI, the TUI, the worktree flow) without any of them importing
    each other.

    A run whose source is ``"llm"`` is held by ``llm.supervisor``, and plain
    ``resume`` refuses it (``cli.cmd_resume``, exit 2) precisely so two
    orchestrators with different decision models never share one ``state.json``.
    So a message that names ``resume`` without reading the run first is wrong for
    every LLM-held run, and wrong in the expensive direction: the operator spends
    the trust before finding out, and an unattended orchestrator copies the
    sentence into the alert it writes for its owner. Measured 2026-08-18 — a run
    paused holding two proven stories, told its owner to run a command that did
    not exist for it, and the four hours that followed were spent on that
    sentence.
    """
    if source == "llm":
        return f"{PRODUCT} run --resume {run_id}"
    return f"{PRODUCT} resume {run_id}"


def env(name: str) -> str:
    """The namespaced spelling of an environment variable.

    ``env("RUN_DIR")`` -> ``<ENV_PREFIX>RUN_DIR``. Callers pass the bare suffix so
    no site has to know the prefix, and a prefix change stays a one-line edit
    here. The session-protocol names the engine injects are registered as
    constants in :mod:`envvars`; this is the primitive they are built from.
    """
    return f"{ENV_PREFIX}{name}"


def cmd(*words: str) -> str:
    """The product's command line as a message spells it: ``cmd("init")`` ->
    ``<PRODUCT> init``. Remediation strings are the bulk of where the product
    used to be spelled out, and every one of them is this shape."""
    return " ".join((PRODUCT, *words))
