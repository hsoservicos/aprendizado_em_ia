"""Assembling a SessionSpec from policy.

Every session the tool launches — the story loop's dev and review passes, an
injected plugin workflow, and an LLM-held run's dispatch — has to wire the same
set of policy knobs onto the same dataclass: the timeout and its override hook,
the stall-nudge cap, the four token-budget fields. There is nothing to decide in
any of it, which is exactly why it should exist once: a second copy would not
look wrong, it would just quietly disagree about, say, the cache-read weight, and
a budget judged at the wrong weight fails in the direction of spending more.

The two callers stay independent — the deterministic engine does not import the
LLM package, and the LLM package does not reach into the engine. They meet here.
"""

from __future__ import annotations

from pathlib import Path

from . import envvars
from .adapters.base import SessionSpec, SpecSnapshot
from .policy import Policy


def session_timeout_s(default_s: float) -> float:
    """The per-session wall-clock budget in seconds.

    Normally ``limits.session_timeout_min * 60``, overridden by
    ``WAVES_SESSION_TIMEOUT_S``. The policy floor is one minute,
    too coarse to exercise a timeout-teardown path in a deterministic sub-minute
    end-to-end test, and a real binary run cannot be monkeypatched. A
    non-positive or unparseable override is ignored, so a fat-fingered value can
    never silently shorten a real run's budget.
    """
    override = envvars.session_timeout_s()
    return override if override is not None else default_s


def build_spec(
    *,
    task_id: str,
    role: str,
    prompt: str,
    cwd: Path,
    env: dict[str, str],
    policy: Policy,
    model: str,
    effort: str = "",
    workflow: bool = False,
    spec_snapshot: SpecSnapshot | None = None,
    expected_spec: str | None = None,
    resume_session_id: str | None = None,
    hook_trust_bypass: bool = False,
) -> SessionSpec:
    """One session's launch spec, with every policy knob applied.

    ``workflow`` selects the stall-nudge cap: an injected workflow session gets
    its own, because a missing completion marker there should degrade to
    "stalled" sooner than a dev session that may legitimately think for a long
    time between turns.

    ``env`` carries ``GIT_OPTIONAL_LOCKS=0`` unless the caller set it: the adapters'
    launch seam adds it too (`envvars.session_exports`), but an adapter class a
    plugin registers need not go through that seam, and every adapter honours
    ``spec.env`` — so the pin holds for whatever CLI drives the session.
    """
    limits = policy.limits
    return SessionSpec(
        task_id=task_id,
        role=role,
        prompt=prompt,
        cwd=cwd,
        env={envvars.GIT_OPTIONAL_LOCKS: "0", **env},
        model=model,
        effort=effort,
        timeout_s=session_timeout_s(limits.session_timeout_min * 60),
        stall_nudges_cap=(
            limits.workflow_stall_nudges_cap if workflow else limits.dev_stall_nudges_cap
        ),
        operator_hold_max_s=float(limits.operator_hold_max_min) * 60.0,
        token_budget=limits.max_tokens_per_session,
        token_budget_mode=limits.session_budget_mode,
        token_budget_grace_s=float(limits.session_budget_grace_s),
        cache_read_weight=limits.cache_read_weight,
        spec_snapshot=spec_snapshot,
        expected_spec=expected_spec,
        resume_session_id=resume_session_id,
        hook_trust_bypass=hook_trust_bypass,
    )
