"""Central registry of the ``WAVES_*`` runtime environment variables.

These operator/test override knobs used to be read inline at scattered call
sites (`engine`, `adapters.multiplexer`, `cli`, `process_host`), which left them
undiscoverable and undocumented. This module is the one place each is named,
typed, and given a reader; the operator-facing table lives in the README under
"Environment variables".

Each reader preserves its call site's exact semantics — same parse, same
fallback — so routing a site through here changes nothing observable. Only the
core operator/test knobs belong here (the count is deliberately not stated — it
has already changed once); the `WAVES_UNITY_*` /
`WAVES_ENGINE_*` family read by the bundled Unity plugin's
stand-alone helper scripts is that plugin's own contract (documented in the
game-engine guide) and stays with it.

The session-protocol vars the engine *injects* into a child session
(`WAVES_RUN_DIR`, `WAVES_TASK_ID`, …) are a different
kind of entry: they have a producing side inside the orchestrator, and the
stdlib-only relays that read them back cannot import this module at all. They are
registered below as NAMES only — no reader — so the producing side spells each one
exactly once, through `namespace.env`, and a prefix change reaches every injection
site from one constant.

Note what the carve-out is and is not: "has a producing side" does not qualify a
name, "is read only by a stdlib-only relay that cannot import this module" does.
Anything core orchestration reads back belongs here, and
`test_portability_guard.test_riaworks_waves_loop_env_reads_only_in_the_registry` is the
enforced form of that rule.
"""

from __future__ import annotations

import math
import os
from collections.abc import Mapping

from .namespace import env

#: Overrides the per-session wall-clock budget, in seconds (test / E2E hook).
SESSION_TIMEOUT_S = env("SESSION_TIMEOUT_S")
#: Forces the terminal-multiplexer backend by registered name.
MUX_BACKEND = env("MUX_BACKEND")
#: Forces the process-host implementation by registered name (test / override).
PROCESS_HOST = env("PROCESS_HOST")
#: Suppresses the native desktop notification, leaving the ATTENTION file alone.
NO_DESKTOP_NOTIFY = env("NO_DESKTOP_NOTIFY")
#: Overrides the user-scoped state root that per-run control-plane state lives
#: under (see :func:`runs.state_root`), replacing the whole platform cascade.
STATE_DIR = env("STATE_DIR")

# ---------------------------------------------------------------- session protocol
#
# The variables the orchestrator INJECTS into a child session, and the stdlib-only
# relays and plugin scripts read back to find the run they belong to. Not operator
# knobs — no reader lives here for them (the relays cannot import this module at
# all, see the module docstring) — but they are names, and a name spelled at the
# producing side (engine, resolve, probe, plugins.bus) and again at every consuming
# side is how one half of a rename lands without the other. Register the spelling
# once; the producing side imports it, the guard in tests/test_portability_guard.py
# resolves reads through it.
#: Marks a session as orchestrator-driven (the dev primitive reads it).
MODE = env("MODE")
#: The run directory of the session's run, and the events channel beside it.
RUN_DIR = env("RUN_DIR")
EVENTS_DIR = env("EVENTS_DIR")
#: The unit the session is working; the relay stamps each event with it.
TASK_ID = env("TASK_ID")
STORY_KEY = env("STORY_KEY")
#: The pid the multiplexer's launch prelude records for the coding CLI it starts
#: (``adapters.tmux_base.LAUNCH_PRELUDE``). The relay walks its own parent chain
#: against it to tag each hook event's lineage, so a nested CLI that inherited the
#: session's variables is told from the launched one.
LAUNCH_PID = env("LAUNCH_PID")
#: Stories mode: the spec folder the dev primitive resolves the story from, and the
#: halt-after-planning flag.
SPEC_FOLDER = env("SPEC_FOLDER")
PLAN_HALT = env("PLAN_HALT")
#: Deferred-work bundle ids, comma-separated, for the adapter to stamp on the result.
DW_IDS = env("DW_IDS")
#: The resolved deferred-work ledger a triage session reads (#769): the TOML
#: config may point it somewhere the legacy YAML does not.
LEDGER = env("LEDGER")
#: Set when no follow-up review session will run.
SKIP_REVIEW = env("SKIP_REVIEW")
#: The escalation context file an interactive resolve session reads.
RESOLVE_CONTEXT = env("RESOLVE_CONTEXT")
#: The capture directory the probe-adapter hook writes full payloads into.
PROBE_CAPTURE_DIR = env("PROBE_CAPTURE_DIR")
#: Desktop-notification text handed to the platform notifier subprocess.
NOTIFY_TITLE = env("NOTIFY_TITLE")
NOTIFY_MESSAGE = env("NOTIFY_MESSAGE")

# The identity a declarative plugin hook is handed (plugins.bus.hook_env): the
# run's coordinates plus the plugin's resolved settings under SETTING_PREFIX.
STAGE = env("STAGE")
RUN_ID = env("RUN_ID")
REPO_ROOT = env("REPO_ROOT")
WORKTREE = env("WORKTREE")
EPIC = env("EPIC")
ROLE = env("ROLE")
PHASE = env("PHASE")
BRANCH = env("BRANCH")
# The provisioning contract's coordinates beyond the hook set: the branch a unit
# merges back into, and — in a --plan run — the wave and front the unit belongs to.
TARGET_BRANCH = env("TARGET_BRANCH")
WAVE = env("WAVE")
FRONT = env("FRONT")
AGENTS = env("AGENTS")
#: At-least-once stages only (`post_migrate`): the delivery's dedup key.
DELIVERY_ID = env("DELIVERY_ID")
#: `post_rollback` only (DW-322): completed | paused | failed.
ROLLBACK_OUTCOME = env("ROLLBACK_OUTCOME")
PLUGIN = env("PLUGIN")
SETTING_PREFIX = env("SETTING_")

#: The names above that are protocol, not knobs: the registry defines them and
#: never reads them — a reader for one belongs to the relay or the plugin script
#: on the consuming side — so the portability guard refuses a read of one HERE
#: the way it refuses one anywhere else outside the sanctioned readers.
SESSION_PROTOCOL = (
    MODE,
    RUN_DIR,
    EVENTS_DIR,
    TASK_ID,
    STORY_KEY,
    LAUNCH_PID,
    SPEC_FOLDER,
    PLAN_HALT,
    DW_IDS,
    LEDGER,
    SKIP_REVIEW,
    RESOLVE_CONTEXT,
    PROBE_CAPTURE_DIR,
    NOTIFY_TITLE,
    NOTIFY_MESSAGE,
)
HOOK_PROTOCOL = (
    STAGE,
    RUN_ID,
    REPO_ROOT,
    WORKTREE,
    EPIC,
    ROLE,
    PHASE,
    BRANCH,
    TARGET_BRANCH,
    WAVE,
    FRONT,
    AGENTS,
    DELIVERY_ID,
    ROLLBACK_OUTCOME,
    PLUGIN,
    SETTING_PREFIX,
)


def session_timeout_s() -> float | None:
    """The per-session wall-clock override in seconds, or ``None`` when unset.

    Anything that is not a finite positive number of seconds reads as ``None``
    (ignored), and the guard is deliberately two-sided. Rejecting zero and
    negatives keeps a fat-fingered override from silently *shortening* a real
    run's budget; rejecting non-finite values keeps ``inf`` / ``1e999`` /
    ``Infinity`` — all of which ``float()`` accepts and all of which pass a bare
    ``> 0`` — from silently *removing* it. That second half matters more than it
    looks: both adapters build their monotonic and wall-clock deadlines by
    adding this to the current time, so a non-finite budget yields a deadline
    that can never expire, and this is the outer bound every stall-grace and
    wake-nudge window defers to. Losing it means an unattended run can wedge
    with no backstop left.

    A very large *finite* value is still honoured. It is a duration, however
    unwise, and an operator asking for one is expressing intent; ``inf`` is not
    a duration at all.
    """
    raw = os.environ.get(SESSION_TIMEOUT_S)
    if raw is None:
        return None
    try:
        value = float(raw)
    except ValueError:
        return None
    if not math.isfinite(value) or value <= 0:
        return None
    return value


def mux_backend() -> str | None:
    """The forced terminal-multiplexer backend name, or ``None`` when unset.

    Returned verbatim (callers test truthiness and resolve the name), so the
    forced-selection semantics match the raw env read exactly.
    """
    return os.environ.get(MUX_BACKEND)


def process_host() -> str | None:
    """The forced process-host name, or ``None`` when unset."""
    return os.environ.get(PROCESS_HOST)


def no_desktop_notify() -> bool:
    """True when native desktop notifications are suppressed for this process.

    A quiet-mode knob for anywhere a real notification is noise rather than
    signal: a machine running the test suite (which reaches notify sites in most
    of the engine tests), a shared box, a demo. Deliberately narrower than
    ``notify.desktop = false`` in policy — that is the project's standing choice,
    this is the current process's. The ATTENTION file is untouched either way, so
    nothing observable is lost, only the popup.

    Any non-empty value that is not a recognized negative enables it, so the
    obvious ``=1`` / ``=true`` both work and an accidental ``=0`` does not.
    """
    raw = os.environ.get(NO_DESKTOP_NOTIFY)
    return bool(raw) and raw.strip().lower() not in {"0", "false", "no", ""}


def state_dir() -> str | None:
    """The overriding waves state root, or ``None`` when unset.

    Verbatim like the two name readers above — :func:`runs.state_root` uses the
    value as the state root itself, so an operator who names a directory gets that
    directory. Silently ignoring a stated override in favour of the platform
    cascade would be the same failure :func:`mux_backend` refuses: a loud
    misconfiguration turned into a quiet auto-select, discoverable only by
    noticing where a run's events did *not* appear.

    Reading verbatim is not the same as accepting anything: this reader reports
    what is set, and :func:`runs.state_root` judges it. A **relative** value is
    refused there rather than resolved, because the root is read by two processes
    with different working directories — see that function for the full reason.
    The split is deliberate; a reader that silently rewrote its variable would
    make the refusal impossible to state.

    The one value not passed through is the empty string, which reads as unset.
    ``export WAVES_STATE_DIR=`` is what an unset-looking export
    leaves behind, and it is not a directory an operator can have meant:
    ``Path("")`` is the *current directory*, so honouring it would silently root
    the control plane at whatever cwd the loop happened to be launched from.
    """
    return os.environ.get(STATE_DIR) or None


#: git's own switch, pinned to "0" in every session and hook the run launches
#: (:func:`session_exports`) and in every git the run spawns (`verify._run_git`).
#: Not a ``WAVES_*`` knob — git reads it — but the orchestrator is its producer.
#: With it, `git status` still reads the index but never takes `index.lock` to
#: write the refreshed stat data back, so a statusline, an editor integration or
#: a hook polling the checkout a merge-back lands in cannot hold the lock the merge
#: needs. Measured 2026-09-23 (run 20260922-210104-0885): a statusline's
#: `git status --porcelain`, run in the orchestrator's cwd — the target checkout —
#: on every screen refresh, is the one holder that fits the lock that refused a
#: merge-back.
GIT_OPTIONAL_LOCKS = "GIT_OPTIONAL_LOCKS"


def session_exports(env: Mapping[str, str]) -> dict[str, str]:
    """The env a launched child actually gets: ``env`` with ``GIT_OPTIONAL_LOCKS=0``
    unless ``env`` sets it itself. Applied at the adapters' launch and at the plugin
    hook bus, so every session and hook inherits it, down to the statusline and hooks
    the coding CLI spawns in turn. (Until 3.1 it also mirrored every variable into its
    1.x ``RIAWORKS_WAVES_LOOP_*`` spelling; that layer retired on schedule.)"""
    out = dict(env)
    out.setdefault(GIT_OPTIONAL_LOCKS, "0")
    return out
