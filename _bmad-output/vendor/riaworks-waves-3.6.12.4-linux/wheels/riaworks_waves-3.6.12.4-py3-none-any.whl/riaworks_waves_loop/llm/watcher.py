"""The process that waits on one dispatched session.

Runs `wait_for_completion` — the adapter's real one, with its nudge budgets,
token guard and env-fault classification intact — and writes the settled outcome
where the caller can read it. Nothing here decides anything: it is the dispatch's
second half, living in its own process so the verb that launched the session
could return.

Invoked as `python -m riaworks_waves_loop.llm.watcher <run-dir> <task-id>`.
"""

from __future__ import annotations

import sys
from pathlib import Path

from ..adapters.base import SessionResult
from ..runs import RUNS_DIR
from .dispatch import adapter_for_role, build_adapters, read_handover, read_handover_workflow
from .host import LLMHost
from .sessionio import write_session_result, write_session_usage


def project_of(run_dir: Path) -> Path:
    """The project root a run dir belongs to.

    Derived from RUNS_DIR's own depth rather than a hardcoded number of parents,
    so moving the state directory cannot leave the watcher resolving one level
    off — which would fail as "no such run" from a process nobody is watching.
    """
    # parents[0] is the runs dir itself, so the project sits exactly RUNS_DIR's
    # own depth above the run.
    return run_dir.resolve().parents[len(RUNS_DIR.parts)]


def watch(run_dir: Path, task_id: str) -> int:
    run_dir = Path(run_dir).resolve()
    host = LLMHost.open(project_of(run_dir), run_dir.name)
    handle, spec = read_handover(host.run_dir, task_id)
    adapters = build_adapters(host, spec.role)
    adapter = adapter_for_role(adapters, host.policy, spec.role)

    try:
        result = adapter.wait_for_completion(handle, spec)
    except Exception as exc:  # noqa: BLE001 - the outcome must be recorded either way
        # A watcher that died silently would leave the caller waiting on a
        # session that will never settle: `await` would sit until its timeout and
        # report nothing about why. Recording the crash AS the outcome keeps the
        # failure legible and bounded.
        result = SessionResult(status="crashed", env_fault_evidence=f"{type(exc).__name__}: {exc}")

    task_dir = host.run_dir / "tasks" / task_id
    write_session_result(task_dir, result)
    usage = None
    try:
        usage = adapter.read_usage(result)
    except Exception:  # noqa: BLE001 - usage is metadata; never worth losing the result over
        usage = None
    # Persisted, not only journalled: the journal is a record for a reader, and
    # the run's token totals live on the task. Nothing on this path was carrying
    # the count from here to there, so every LLM-held run reported zero tokens
    # however much it spent.
    write_session_usage(task_dir, usage)
    host.journal.append(
        "session-end",
        task_id=task_id,
        role=spec.role,
        status=result.status,
        tokens=usage.total if usage else None,
    )
    workflow = read_handover_workflow(host.run_dir, task_id)
    if workflow is not None:
        _settle_workflow(host, workflow, result)
    return 0


def _settle_workflow(host: LLMHost, workflow: dict[str, object], result: SessionResult) -> None:
    """Close the record a plugin-workflow dispatch opened, the way the engine
    closes its own: a `workflow-end` entry with the session's status, and — at an
    epic boundary — the step stamped `done`/`failed` in `boundary_progress`, which
    is what the dashboard paints beside the epic. The dispatch could not write
    either: it returned the moment the session was up, and this process is the one
    alive when the session settles."""
    fields: dict[str, object] = {
        "plugin": workflow.get("plugin"),
        "workflow": workflow.get("workflow"),
        "status": result.status,
        "story_key": workflow.get("story_key"),
        "env_fault": result.env_fault,
    }
    if result.env_fault_evidence:
        fields["env_fault_evidence"] = result.env_fault_evidence
    host.journal.append("workflow-end", **fields)
    if workflow.get("stage") == "post_epic_boundary":
        key = str(workflow.get("story_key"))
        name = str(workflow.get("workflow"))
        with host.mutate() as state:
            state.boundary_progress.setdefault(key, {})[name] = (
                "done" if result.status == "completed" else "failed"
            )


def main(argv: list[str] | None = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    if len(args) != 2:
        print(
            "usage: python -m riaworks_waves_loop.llm.watcher <run-dir> <task-id>", file=sys.stderr
        )
        return 2
    return watch(Path(args[0]), args[1])


if __name__ == "__main__":  # pragma: no cover - process entry point
    raise SystemExit(main())
