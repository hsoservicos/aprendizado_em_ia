"""Exclusive advisory locks: a run's state, and a plain directory.

`state.json` is read-modify-write. `journal.save_state` replaces it atomically,
which prevents a torn *read* but not a lost *update*: two writers that each read
the same state and write back serially lose the first one's mutation. Every
mutating verb therefore holds :func:`state_run_lock` across its whole
read-modify-write, for milliseconds.

That lock IS the run's state lock — :func:`journal.state_lock`, the out-of-tree
sidecar the engine, `stop`, `clean`, `delete`/`archive` and the dashboard take
around their own writes (DW-93). A private lock beside it would order the verbs
among themselves and leave every one of those writers free to interleave with
a verb between its read and its write. What this module adds is the contract
the verbs were written against: a bounded wait that ends in :class:`LockTimeout`
rather than an unbounded block, since a wedged holder is an anomaly to surface,
not contention to sit out.

:func:`run_lock` stays for a lock that is not a run's state: a plain directory
(the suite queue, ``verify.run_verify_commands``), locked through a file inside
it. Advisory, not mandatory: both bind only the processes that take them.
"""

from __future__ import annotations

import contextlib
import sys
import time
from collections.abc import Callable, Iterator
from pathlib import Path
from typing import IO

LOCK_FILE = "state.lock"
DEFAULT_TIMEOUT_S = 30.0
_POLL_S = 0.05
# How often a waiting `run_lock` asks its `abandon` predicate — the engine's
# hard-stop probe reads a file, which every 50 ms poll need not pay for.
_ABANDON_POLL_S = 0.25


class LockAbandoned(Exception):
    """The caller's `abandon` predicate answered yes while the lock was still held
    by someone else: the wait was given up on purpose, not timed out."""


class LockTimeout(Exception):
    """The run-dir lock stayed held by someone else past the timeout.

    A wedged writer is an anomaly rather than routine contention: the
    orchestrator runs verbs sequentially and each holds the lock for
    milliseconds, so this surfaces as a typed verb error the caller can act on
    instead of a silent wait."""


if sys.platform == "win32":  # pragma: no cover - exercised on the windows CI job

    def _try_acquire(handle: IO[bytes]) -> bool:
        import msvcrt

        try:
            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            return False
        return True

    def _release(handle: IO[bytes]) -> None:
        import msvcrt

        handle.seek(0)
        try:
            msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
        except OSError:
            # The lock dies with the handle (and the process) regardless, so a
            # failed explicit unlock must not mask the body's own outcome.
            pass

else:

    def _try_acquire(handle: IO[bytes]) -> bool:
        import fcntl

        try:
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            return False
        return True

    def _release(handle: IO[bytes]) -> None:
        import fcntl

        try:
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        except OSError:
            pass


@contextlib.contextmanager
def state_run_lock(run_dir: Path | str, timeout_s: float = DEFAULT_TIMEOUT_S) -> Iterator[None]:
    """Hold the run's state lock (:func:`journal.state_lock`) for the body.

    Polls the non-blocking acquisition until ``timeout_s``, then raises
    :class:`LockTimeout`. Re-entrant for the same run on this thread, as
    ``state_lock`` is — so the self-locking ``save_state`` inside the body takes
    nothing twice — and refusing a second run's lock inside the first, which is
    ``state_lock``'s guard against an ordering cycle."""
    from ..journal import state_lock
    from ..platform_util import LockUnavailableError

    directory = Path(run_dir)
    deadline = time.monotonic() + timeout_s
    with contextlib.ExitStack() as stack:
        while True:
            try:
                stack.enter_context(state_lock(directory, blocking=False))
                break
            except LockUnavailableError as exc:
                if time.monotonic() >= deadline:
                    raise LockTimeout(
                        f"run state lock held by another process: {directory}"
                    ) from exc
                time.sleep(_POLL_S)
        yield


@contextlib.contextmanager
def run_lock(
    run_dir: Path | str,
    timeout_s: float = DEFAULT_TIMEOUT_S,
    *,
    abandon: Callable[[], bool] | None = None,
) -> Iterator[None]:
    """Hold a plain directory's exclusive lock (a file inside it) for the body.

    Raises `LockTimeout` when it cannot be taken within `timeout_s`, and
    `LockAbandoned` when `abandon` answers yes first — asked between attempts, at
    most every `_ABANDON_POLL_S`, never once the lock is held. The lock file is
    created if absent and **never unlinked**: removing it would let a second
    process create a fresh inode and lock that one instead, leaving two holders
    each convinced they own the run dir.
    """
    directory = Path(run_dir)
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / LOCK_FILE
    # "a+b" creates without truncating. msvcrt locks a byte range, so the file
    # is padded to one byte; flock ignores the content entirely.
    with path.open("a+b") as handle:
        if handle.seek(0, 2) == 0:
            handle.write(b"\0")
            handle.flush()
        handle.seek(0)
        deadline = time.monotonic() + timeout_s
        next_ask = 0.0
        while not _try_acquire(handle):
            now = time.monotonic()
            if abandon is not None and now >= next_ask:
                if abandon():
                    raise LockAbandoned(f"gave up waiting for {path}")
                next_ask = now + _ABANDON_POLL_S
            if now >= deadline:
                raise LockTimeout(f"run-dir lock held by another process: {path}")
            time.sleep(_POLL_S)
        try:
            yield
        finally:
            _release(handle)
