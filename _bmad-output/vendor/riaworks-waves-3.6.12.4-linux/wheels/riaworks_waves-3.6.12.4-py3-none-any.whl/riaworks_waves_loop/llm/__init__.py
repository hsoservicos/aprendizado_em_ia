"""LLM-held orchestration: a supervisor, a verb surface, and the host they share.

The deterministic engine in `riaworks_waves_loop.engine` decides what happens after every
session from a fixed pipeline and numeric bounds. This package is the other
option: an LLM session holds the control loop and drives the same primitives
through a machine-readable verb surface, while every irreversible operation —
git, the sprint board, worktrees, the deferred-work ledger — stays here in
Python.

Wholly inert unless a run is started with `llm-run`. Nothing in this package is
imported on the deterministic path.
"""
