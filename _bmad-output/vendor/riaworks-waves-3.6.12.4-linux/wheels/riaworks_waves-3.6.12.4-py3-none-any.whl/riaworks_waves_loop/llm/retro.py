"""`unit retro`: the epic retrospective gate, for a run the LLM holds.

Upstream 0.13 gave the deterministic engine a retrospective gate at every epic
boundary and at run end for the last epic (`[gates] retrospective`): `notify` sends a
"retrospective suggested" nudge, `auto` runs a headless `/bmad-retrospective -H <epic>`
session on `[adapter.retro]`, judges it against the files on disk, commits what it
wrote and pauses when it left anything else. A run the LLM holds had none of it — its
boundary is the orchestrator's to drive, and no verb reached the gate.

The verb is the gate's two deterministic halves; when to call it stays the
orchestrator's:

- `start <epic> [--run-end]` fires the gate the policy names. `never` does nothing,
  `notify` sends the engine's nudge, `auto` applies the engine's refusals (journaled
  `retro-auto-skipped` with the same closed reasons) and, when none applies,
  dispatches the session and returns like `dispatch` does. `--run-end` adds the
  engine's run-end refusals (`retro-run-end-skipped`) first: the run's last epic never
  crossed a boundary, so the gate fires there only for an epic the board reads
  complete.
- `settle <epic> --task <id>` judges the settled session as the engine does
  (`retro-auto-finished` with the verdict, or `retro-auto-failed`), commits exactly
  the board and the retro docs, and reports any path still dirty. The engine pauses
  on that dirt; here the answer names it and the pause is the orchestrator's
  routing, like every other verb's finding.

The pieces are the engine's own where they are module-level (the prompt, the skill
name, the verdict vocabulary, the task-id composition); the instance methods are
mirrored here rather than refactored out of `engine.py`, which is upstream's.
"""

from __future__ import annotations

from pathlib import Path
from stat import S_ISREG

from .. import gates, namespace, verify
from ..engine import (
    _RETRO_DIRTY_REASON_PATHS,
    RETRO_SKILL,
    RETRO_VERDICT_REJECTED,
    RETRO_VERDICT_UNKNOWN,
    RETRO_VERDICTS,
    _retro_auto_prompt,
    _session_task_id,
)
from ..model import result_mapping
from ..runs import graceful_stop_requested
from ..sprintstatus import SprintStatusError
from ..sprintstatus import load as load_sprint_status
from .dispatch import adapter_for_role, build_adapters
from .host import LLMHost
from .result import VerbError
from .sessionio import read_session_result
from .verbs import _launch_session

RETRO_MODES = ("start", "settle")
RETRO_ROLE = "retro"


def retro_scope_key(epic: int) -> str:
    """The key a retro session rides on — the engine's synthetic task's, which is
    also the board row the retrospective skill marks `done`."""
    return f"epic-{epic}-retrospective"


def retro_task_id(epic: int, seq: int = 1) -> str:
    """The session's task id, composed exactly as the engine composes its own."""
    return _session_task_id(retro_scope_key(epic), RETRO_ROLE, seq, 0)


def verb_retro(
    host: LLMHost,
    mode: str,
    epic: int,
    *,
    run_end: bool = False,
    task_id: str | None = None,
    seq: int = 1,
) -> dict[str, object]:
    if mode not in RETRO_MODES:
        raise VerbError("invalid-args", f"unknown mode {mode!r}: one of {', '.join(RETRO_MODES)}")
    if epic < 1:
        raise VerbError("invalid-args", f"epic must be a positive number, got {epic}")
    if mode == "start":
        if task_id is not None:
            raise VerbError("invalid-args", "start mints its own task: --task is for settle")
        return _start(host, epic, run_end=run_end, seq=seq)
    if run_end:
        raise VerbError("invalid-args", "--run-end belongs to start")
    if not task_id:
        raise VerbError(
            "invalid-args", f"settle needs --task <id>: the one `retro start {epic}` returned"
        )
    return _settle(host, epic, task_id)


# ------------------------------------------------------------------------ start


def _start(host: LLMHost, epic: int, *, run_end: bool, seq: int) -> dict[str, object]:
    mode = host.policy.gates.retrospective
    base: dict[str, object] = {"epic": epic, "mode": mode}
    if mode == "never":
        return {**base, "action": "none"}
    if run_end:
        refused = _run_end_refusal(host, epic)
        if refused is not None:
            return {**base, "action": "skipped", "reason": refused}
        host.journal.append("retro-run-end", epic=epic)
    if mode == "notify":
        # Engine._nudge_retrospective, word for word.
        gates.notify(
            host.policy,
            host.run_dir,
            f"epic {epic} stories complete",
            "retrospective suggested: run /bmad-retrospective when convenient",
        )
        return {**base, "action": "notified"}
    refused = _auto_refusal(host, epic)
    if refused is not None:
        return {**base, "action": "skipped", "reason": refused}
    host.journal.append("retro-auto-start", epic=epic)
    payload = _launch_session(
        host,
        role=RETRO_ROLE,
        story_key=retro_scope_key(epic),
        prompt=_retro_auto_prompt(epic),
        seq=seq,
        label=None,
        resume_session=None,
        cwd=host.paths.repo_root,
    )
    return {**base, "action": "dispatched", **payload}


def _run_end_refusal(host: LLMHost, epic: int) -> str | None:
    """Engine._run_end_retrospective's refusals, journaled the same way: the gate
    fires at run end only for an epic whose stories the board reads all `done` and
    whose retrospective is not already `done`. An unreadable board is a refusal,
    never read as a complete epic."""
    try:
        board = load_sprint_status(host.paths.sprint_status)
    except (SprintStatusError, OSError, UnicodeDecodeError) as e:
        host.journal.append(
            "retro-run-end-skipped", epic=epic, reason="board-unreadable", error=str(e)
        )
        return "board-unreadable"
    stories = [s for s in board.stories if s.epic == epic]
    if not stories or any(s.status != "done" for s in stories):
        host.journal.append("retro-run-end-skipped", epic=epic, reason="epic-incomplete")
        return "epic-incomplete"
    if board.retros.get(epic) == "done":
        host.journal.append("retro-run-end-skipped", epic=epic, reason="already-done")
        return "already-done"
    return None


def _auto_refusal(host: LLMHost, epic: int) -> str | None:
    """Engine._maybe_auto_retro's pre-dispatch refusals, in its order, each journaled
    `retro-auto-skipped` and — unless the retro is already done — told to the
    operator as a retro to run by hand (Engine._skip_auto_retro)."""

    def skip(reason: str, error: str | None = None) -> str:
        extra = {} if error is None else {"error": error}
        host.journal.append("retro-auto-skipped", epic=epic, reason=reason, **extra)
        if reason != "already-done":
            gates.notify(
                host.policy,
                host.run_dir,
                f"auto retrospective skipped for epic {epic}",
                f"{reason}: run /bmad-retrospective for epic {epic} by hand",
            )
        return reason

    try:
        board = load_sprint_status(host.paths.sprint_status)
    except (SprintStatusError, OSError, UnicodeDecodeError) as e:
        return skip("board-unreadable", str(e))
    if board.retros.get(epic) == "done":
        return skip("already-done")
    if graceful_stop_requested(host.run_dir):
        return skip("stop-requested")
    try:
        clean = verify.worktree_clean(host.paths.repo_root, project=host.paths.project)
    except verify.GitError as e:
        return skip("git-error", str(e))
    if not clean:
        return skip("dirty")
    adapter = adapter_for_role(build_adapters(host, RETRO_ROLE), host.policy, RETRO_ROLE)
    tree = getattr(getattr(adapter, "profile", None), "skill_tree", None)
    if tree and not (host.paths.project / tree / RETRO_SKILL / "SKILL.md").is_file():
        return skip("skill-missing")
    return None


# ----------------------------------------------------------------------- settle


def _settle(host: LLMHost, epic: int, task_id: str) -> dict[str, object]:
    prefix = f"{retro_scope_key(epic)}-{RETRO_ROLE}-"
    if not task_id.startswith(prefix):
        raise VerbError(
            "invalid-args",
            f"{task_id!r} is not a retrospective session of epic {epic} (expected {prefix}<n>)",
        )
    settled = read_session_result(host.run_dir / "tasks" / task_id)
    if settled is None:
        raise VerbError(
            "state-conflict",
            f"{task_id} has not settled: `await {task_id}` first — a running session is "
            "judged by nothing but its outcome",
        )
    errors, docs = _verify(host, epic, settled)
    ok = not errors
    # `passed`, never `ok`: the verb envelope reserves `ok` for "the call itself
    # succeeded", and a retrospective that failed its checks is an answer, not a
    # failed call.
    answer: dict[str, object] = {"epic": epic, "task_id": task_id, "passed": ok}
    if ok:
        names = [d.name for d in docs]
        verdict, verdict_doc = _verdict(docs)
        host.journal.append("retro-auto-finished", epic=epic, docs=names, verdict=verdict)
        gates.notify(
            host.policy,
            host.run_dir,
            f"epic {epic} retrospective done",
            f"retrospective written: {', '.join(names)}; verdict: {verdict}",
        )
        if verdict == RETRO_VERDICT_REJECTED and verdict_doc is not None:
            # Engine._notify_retro_rejected: surfaced, never gated (DW-487).
            gates.notify(
                host.policy,
                host.run_dir,
                f"epic {epic} retrospective rejected",
                f"the auto retrospective's verdict for epic {epic} is rejected (see "
                f"{gates.notice_line(verdict_doc.name)}); the run continues with the next "
                f"epic — review its Acceptance verdict and Action items before relying on "
                f"epic {epic}'s work",
            )
        answer.update(docs=names, verdict=verdict)
    else:
        host.journal.append("retro-auto-failed", epic=epic, errors=errors)
        gates.notify(
            host.policy,
            host.run_dir,
            "auto retrospective failed",
            f"epic {epic}: {'; '.join(errors)} — run /bmad-retrospective for epic {epic} by hand",
        )
        answer["errors"] = errors
    answer.update(_settle_tree(host, epic, ok, docs))
    return answer


def _retro_docs(host: LLMHost, epic: int) -> list[Path]:
    """Engine._retro_docs: the regular files `epic-<n>-retro-*.md` in the
    implementation artifacts, sorted; raises OSError when the dir cannot be listed."""
    docs: list[Path] = []
    for candidate in sorted(host.paths.implementation_artifacts.glob(f"epic-{epic}-retro-*.md")):
        try:
            if S_ISREG(candidate.lstat().st_mode):
                docs.append(candidate)
        except OSError:
            continue
    return docs


def _verify(host: LLMHost, epic: int, settled: dict[str, object]) -> tuple[list[str], list[Path]]:
    """Engine._verify_retro over the settled outcome: a completed session whose
    `result.json` says `done`, the board's `epic-<n>-retrospective` reading `done`,
    and at least one retro doc on disk — each re-read, no session prose consulted."""
    errors: list[str] = []
    status = settled.get("status")
    raw_result = settled.get("result_json")
    if status != "completed":
        errors.append(f"session status {status}, not completed")
    elif (
        result_mapping(raw_result if isinstance(raw_result, dict) else None).get("status") != "done"
    ):
        errors.append("result.json status is not done")
    try:
        board = load_sprint_status(host.paths.sprint_status).retros.get(epic)
    except (SprintStatusError, OSError, UnicodeDecodeError):
        errors.append("sprint-status unreadable")
    else:
        if board != "done":
            errors.append(f"sprint-status epic-{epic}-retrospective is {board or 'absent'}")
    try:
        docs = _retro_docs(host, epic)
    except OSError:
        docs = []
        errors.append("implementation-artifacts unreadable")
    else:
        if not docs:
            errors.append(f"no epic-{epic}-retro-*.md retrospective doc")
    return errors, docs


def _verdict(docs: list[Path]) -> tuple[str, Path | None]:
    """Engine._retro_verdict: the newest doc's frontmatter `verdict`, matched against
    the skill's closed vocabulary; every miss is `unknown`, never an acceptance."""
    try:
        doc = max(docs, key=lambda d: (d.lstat().st_mtime_ns, d.name), default=None)
    except OSError:
        return RETRO_VERDICT_UNKNOWN, None
    if doc is None:
        return RETRO_VERDICT_UNKNOWN, None
    try:
        raw = verify.read_frontmatter(doc).get("verdict")
    except OSError:
        return RETRO_VERDICT_UNKNOWN, doc
    verdict = raw.strip().lower() if isinstance(raw, str) else ""
    return (verdict if verdict in RETRO_VERDICTS else RETRO_VERDICT_UNKNOWN), doc


def _settle_tree(host: LLMHost, epic: int, ok: bool, docs: list[Path]) -> dict[str, object]:
    """Engine._settle_retro_tree, reporting instead of pausing: on success commit
    exactly the dirty members of {the board, the retro docs}, then name every path
    still dirty. A dirty answer is the engine's epic-boundary pause — the next
    story's rollback would destroy an uncommitted retro doc or sweep it into that
    story's commit — and routing it is the caller's."""
    repo = host.paths.repo_root
    committed: str | None = None
    try:
        dirty = verify.dirty_paths(repo)
        if ok:
            wanted = {rel for p in (host.paths.sprint_status, *docs) if (rel := _repo_rel(repo, p))}
            to_commit = sorted(rel for rel in dirty if rel in wanted)
            if to_commit:
                try:
                    committed = verify.commit_paths(
                        repo,
                        f"chore(retro): epic {epic} retrospective",
                        [repo / rel for rel in to_commit],
                    )
                except verify.GitError as e:
                    host.journal.append("retro-auto-uncommitted", epic=epic, error=str(e))
                dirty = verify.dirty_paths(repo)
    except verify.GitError as e:
        host.journal.append("retro-auto-dirty", epic=epic, paths=[], error=str(e))
        return {
            "committed": committed,
            "dirty": None,
            "dirty_error": f"could not read the worktree after the retrospective: {e}",
        }
    leftover = sorted(dirty)
    if leftover:
        host.journal.append("retro-auto-dirty", epic=epic, paths=leftover, count=len(leftover))
        shown = ", ".join(leftover[:_RETRO_DIRTY_REASON_PATHS])
        more = len(leftover) - _RETRO_DIRTY_REASON_PATHS
        if more > 0:
            shown += f" (+{more} more)"
        return {
            "committed": committed,
            "dirty": leftover,
            "pause_reason": (
                f"epic {epic} boundary — the auto retrospective left uncommitted changes: "
                f"{shown}; commit or clean them, then "
                f"`{namespace.resume_command(host.state.source, host.state.run_id)}`"
            ),
        }
    return {"committed": committed, "dirty": []}


def _repo_rel(repo: Path, path: Path) -> str | None:
    try:
        return path.resolve().relative_to(repo.resolve()).as_posix()
    except (OSError, RuntimeError, ValueError):
        return None
