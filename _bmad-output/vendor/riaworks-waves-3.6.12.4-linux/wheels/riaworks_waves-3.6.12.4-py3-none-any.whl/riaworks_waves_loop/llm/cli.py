"""Argument parsing for `llm-run` and the `unit` verb group.

Kept out of the top-level `cli` module so the LLM surface stays one import away
from absent: `cli.main` registers it, and nothing on the deterministic path
depends on it.
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

from .. import bmadconfig, envvars, namespace
from .. import policy as policy_mod
from ..cli import PROG
from ..runs import RUNS_DIR
from . import retro as retro_impl
from . import verbs as verb_impl
from .host import LLMHost
from .result import VerbError, run_verb


def _host(args: argparse.Namespace) -> LLMHost:
    project = Path(args.project)
    return LLMHost.open(project, _run_ref(project, getattr(args, "run", None)))


def _run_ref(project: Path, explicit: str | None) -> str | None:
    """The run a verb addresses: `--run` when given; else the run THIS session was
    launched for; else None — the project's most recent run, for an operator at a
    terminal.

    The session's own run comes from the run dir every orchestrator and dispatched
    session carries in its environment. Without it, a verb called without `--run`
    went to whichever run of the project was newest: a deterministic run, a sweep or
    a wave master's child started after this one, and every state read, phase move
    and journal entry of the orchestrator landed on a run it does not hold.

    A session whose run lives under another project is refused rather than
    redirected: `--project` names a tree that is not this session's, and either
    reading of the call — that project's newest run, or this session's run under a
    project it does not belong to — is a guess."""
    if explicit is not None:
        return explicit
    # A session-protocol var, read back by the process the session spawned — the
    # same family-scoped exemption the hook relays have (the fork's guard inventory).
    # Blank reads as unset: `Path("")` is the cwd, not a run.
    raw = os.environ.get(envvars.RUN_DIR, "").strip()
    if not raw:
        return None
    run_dir = Path(raw)
    runs_root = (project / RUNS_DIR).resolve()
    if run_dir.resolve().parent != runs_root:
        raise VerbError(
            "invalid-args",
            f"this session belongs to run {run_dir}, which is not under {runs_root}: "
            f"call from its project, or pass --project and --run explicitly",
        )
    return run_dir.name


def _prompt_text(args: argparse.Namespace) -> str:
    """The session prompt, from a file rather than argv.

    A dispatch prompt is long and carries newlines, quotes and backticks; argv is
    the wrong shape for it and a shell would mangle it on the way in.
    """
    try:
        return Path(args.prompt_file).read_text(encoding="utf-8")
    except OSError as exc:
        raise VerbError("not-found", f"unreadable prompt file: {exc}") from exc


def _kv_pairs(raw: list[str] | None) -> dict[str, str]:
    fields: dict[str, str] = {}
    for item in raw or []:
        key, sep, value = item.partition("=")
        if not sep or not key.strip():
            raise VerbError("invalid-args", f"--field expects key=value, got {item!r}")
        fields[key.strip()] = value
    return fields


def cmd_unit(args: argparse.Namespace) -> int:
    def body() -> dict[str, object]:
        host = _host(args)
        match args.verb:
            case "state":
                return verb_impl.verb_state(host)
            case "pick":
                return verb_impl.verb_pick(host, wave=bool(getattr(args, "wave", False)))
            case "phase":
                return verb_impl.verb_phase(host, args.story_key, args.target, args.reason)
            case "journal":
                return verb_impl.verb_journal(host, args.kind, _kv_pairs(args.field))
            case "attention":
                return verb_impl.verb_attention(host, args.text)
            case "notify":
                return verb_impl.verb_notify(host, args.title, args.message)
            case "pause":
                return verb_impl.verb_pause(host, args.stage, args.reason, args.story)
            case "finish":
                return verb_impl.verb_finish(host, args.reason)
            case "verify":
                return verb_impl.verb_verify(host, args.mode, args.story)
            case "sprint":
                return verb_impl.verb_sprint_advance(host, args.story_key, args.target)
            case "boundary":
                return verb_impl.verb_boundary(host, args.epic, step=args.step, status=args.status)
            case "ledger":
                return verb_impl.verb_ledger(
                    host,
                    args.mode,
                    dw_id=args.id,
                    title=args.title,
                    reason=args.reason,
                    source_spec=args.source_spec,
                    location=args.location,
                    severity=args.severity,
                    note=args.note,
                )
            case "rollback":
                return verb_impl.verb_rollback(host, args.story_key, preserve=args.preserve)
            case "retro":
                return retro_impl.verb_retro(
                    host,
                    args.mode,
                    args.epic,
                    run_end=args.run_end,
                    task_id=args.task,
                    seq=args.seq,
                )
            case "workflows":
                return verb_impl.verb_workflows(
                    host,
                    args.mode,
                    args.stage,
                    story_key=args.story,
                    epic=args.epic,
                    name=args.name,
                    seq=args.seq,
                )
            case "dispatch":
                return verb_impl.verb_dispatch(
                    host,
                    args.role,
                    args.story_key,
                    _prompt_text(args),
                    seq=args.seq,
                    label=args.label,
                    resume_session=args.resume_session,
                )
            case "await":
                if len(args.task_id) > 1:
                    if args.until or args.match or args.quiet is not None or args.from_offset:
                        raise VerbError(
                            "invalid-args",
                            "await on several tasks answers the first to END; --until, "
                            "--match, --quiet and --from-offset are one session's questions",
                        )
                    return verb_impl.verb_await_any(host, args.task_id, timeout_s=args.timeout)
                return verb_impl.verb_await(
                    host,
                    args.task_id[0],
                    until=args.until,
                    match=args.match,
                    quiet_s=args.quiet,
                    timeout_s=args.timeout,
                    from_offset=args.from_offset,
                )
            case "tail":
                return verb_impl.verb_tail(host, args.task_id, args.from_offset, args.lines)
            case "session-result":
                return verb_impl.verb_session_result(host, args.task_id)
            case "nudge":
                return verb_impl.verb_nudge(host, args.task_id, args.text)
            case "kill":
                return verb_impl.verb_kill(host, args.task_id)
            case "open":
                return verb_impl.verb_open(host, args.story_key, args.epic)
            case "commit":
                return verb_impl.verb_commit(host, args.story_key, args.message)
            case "rebase":
                return verb_impl.verb_rebase(host, args.story_key)
            case "close":
                return verb_impl.verb_close(host, args.story_key, args.outcome)
            case _:  # pragma: no cover - argparse constrains this
                raise VerbError("invalid-args", f"unknown verb {args.verb!r}")

    return run_verb(body)


def _preflight(project: Path, policy) -> str | None:
    """Refuse a launch that cannot work, before it costs a session.

    The failure this exists for is quiet: a coding CLI that has never run in a
    project opens a first-run trust dialog, and a spawned session cannot answer
    one. The session sits at the prompt, the initial prompt is typed INTO the
    dialog and lost, and the run reports a timeout many minutes later — with a
    live-looking window and nothing in the journal to say why. Checking the
    orchestrator's own skill is present catches the same class of setup gap for
    the price of a stat.
    """
    from ..adapters.profile import ProfileError, get_profile
    from .supervisor import ORCHESTRATOR_ROLE, ORCHESTRATOR_SKILL

    cfg = policy.adapter.resolved(ORCHESTRATOR_ROLE)
    try:
        profile = get_profile(cfg.name, project)
    except ProfileError as exc:
        return f"orchestrator adapter is unusable: {exc}"

    skill_dir = project / profile.skill_tree / ORCHESTRATOR_SKILL
    if not skill_dir.is_dir():
        return (
            f"the orchestrator skill is missing at {skill_dir} — run "
            f"`{PROG} init --project {project}` first. Without it the session "
            f"starts, looks healthy, and improvises the run with no turn contract."
        )
    if profile.first_run_note and not (project / profile.hooks.config_path).is_file():
        return (
            f"{cfg.name} has no hook config at {profile.hooks.config_path} — run "
            f"`{PROG} init --project {project}`. A session whose turn-end hook never "
            f"fires is indistinguishable from one that hung."
        )
    return None


#: Launch-time scope, pinned into `RunState` when the run is opened. A resume
#: adopts what the run already carries, so accepting these alongside `--resume`
#: would silently ignore them — and an operator who narrowed a resumed run to one
#: epic and got the whole board back would have no way to tell.
_SCOPE_FLAGS = (
    ("--epic", "epic"),
    ("--story", "story"),
    ("--max-stories", "max_stories"),
    ("--plan", "plan"),
)


def cmd_llm_run(args: argparse.Namespace) -> int:
    project = Path(args.project).resolve()
    policy = policy_mod.load(project / policy_mod.POLICY_FILE)
    # Both gates apply to a resume too. `cli._resume_paused_run` settled this for
    # the deterministic engine: a resume re-reads policy.toml and config.yaml from
    # disk, which makes it a second entrypoint into the same machinery, and it
    # gets the same refusals the first one does. A resume that cannot launch an
    # orchestrator session is worth refusing before it costs a session, not after.
    if not policy.llm.enabled:
        print(
            f"the LLM control loop is switched off in {policy_mod.POLICY_FILE} "
            "([llm] enabled = false) — run the deterministic engine with "
            f"`{namespace.cmd('run', '--deterministic')}`, or turn it back on",
            file=sys.stderr,
        )
        return 2
    from ..runsetup import policy_absence

    if (absent := policy_absence(project)) is not None:
        if absent.severity == "problem":
            print(f"error: {absent.message}", file=sys.stderr)
            return 2
        print(f"warning: {absent.message}", file=sys.stderr)
    if (problem := _preflight(project, policy)) is not None:
        print(f"error: {problem}", file=sys.stderr)
        return 2
    paths = bmadconfig.load_paths(project)
    if args.resume:
        return _resume_llm_run(args, project, policy, paths)
    return _open_llm_run(args, project, policy, paths)


def _open_llm_run(args: argparse.Namespace, project: Path, policy, paths) -> int:
    from .supervisor import open_run

    supervisor = open_run(
        project,
        policy,
        paths,
        epic_filter=args.epic,
        story_filter=args.story,
        max_stories=args.max_stories,
        trusted_config_digest="",
        run_id=getattr(args, "run_id", None),
        # Resolved and validated by `cli.cmd_run` (`_resolve_plan`) before the mode
        # is chosen, so both loops read one record.
        plan=getattr(args, "plan_doc", None),
    )
    supervisor.start()
    print(f"run {supervisor.state.run_id} started (llm)")
    return _drive(supervisor)


def _resume_llm_run(args: argparse.Namespace, project: Path, policy, paths) -> int:
    """`llm-run --resume <run_id>`: pick a paused LLM-held run back up.

    The deterministic `resume` has pointed at this flag since the LLM path
    existed, and until now the flag did not exist — so a paused llm-run was a
    total loss, recoverable only by integrating its worktrees by hand and
    starting a fresh run, which cuts new trees from a frozen integration branch.
    That is exactly the damage such a run pauses to avoid.

    The order below mirrors `cli.cmd_resume`: refuse on what the run is, then on
    what the machine says about it, then re-stamp and drive.
    """
    from .. import runs
    from .supervisor import ResumeRefused, resume_run

    bad = [flag for flag, attr in _SCOPE_FLAGS if getattr(args, attr, None) is not None]
    if bad:
        print(
            f"llm-run --resume adopts the run's own scope; {', '.join(bad)} "
            "is launch-time only — drop it, or start a new run",
            file=sys.stderr,
        )
        return 2
    try:
        supervisor = resume_run(project, policy, paths, run_ref=args.resume)
    except ResumeRefused as exc:
        print(str(exc), file=sys.stderr)
        return exc.code
    run_id = supervisor.run_dir.name
    # Gated here rather than in `resume_run`, mirroring where `cmd_resume` puts
    # it: liveness is a fact about this machine, not about the run. 'alive' blocks
    # outright — two supervisors on one state.json is corruption. 'unknown' only
    # warns, because resume is the recovery path that rewrites engine.pid and must
    # stay usable when liveness cannot be verified.
    live = runs.engine_liveness(supervisor.run_dir)
    if live == "alive":
        print(
            f"run {run_id} is still live — resuming would double-drive it; stop it first",
            file=sys.stderr,
        )
        return 1
    if live == "unknown":
        print(
            f"run {run_id}: engine may still be live (unverifiable pid) — "
            "resuming could double-drive this run",
            file=sys.stderr,
        )
    # Resolved once and handed to `resume`, so the re-stamped pin describes the
    # bytes this resumed process actually launches — the reason `_launch_profiles`
    # exists on the deterministic side.
    from ..cli import _launch_profiles, _trusted_config_digest

    profiles = _launch_profiles(policy, project)
    digest = _trusted_config_digest(policy, project, profiles=profiles)
    for notice in supervisor.resume(trusted_config_digest=digest):
        print(notice, file=sys.stderr)
    print(f"run {run_id} resumed (llm)")
    return _drive(supervisor)


def _drive(supervisor) -> int:
    """The half both entrypoints share: drive to a terminal condition, and record
    an escaped exception the way the deterministic engine does so the dashboard
    shows a crashed run rather than a silently dead one."""
    try:
        outcome = supervisor.drive()
    except BaseException as exc:  # noqa: BLE001 - recorded, then re-raised
        supervisor.record_crash(exc)
        raise
    print(f"run {supervisor.state.run_id} {outcome}")
    return 0


def add_subcommands(add) -> None:
    """Register `llm-run` and `unit` on the top-level parser.

    `add` is `cli.main`'s own helper, which already attaches `--project` and
    wires `set_defaults(func=...)`.
    """
    run_p = add(
        "llm-run",
        cmd_llm_run,
        "the same as `run` — the LLM control loop is the default; the old name, kept for scripts",
    )
    run_p.add_argument("--run-id", help=argparse.SUPPRESS)  # pre-assigned id (used by the TUI)
    run_p.add_argument("--epic", type=int, help="only stories from this epic")
    run_p.add_argument("--story", help="restrict to one story (key, id, or slug fragment)")
    run_p.add_argument("--max-stories", type=int, help="stop after dispatching this many stories")
    run_p.add_argument(
        "--resume",
        metavar="RUN_ID",
        help="pick a paused LLM-held run back up over the worktrees it already "
        "has, instead of starting a new one (the spelling `resume` points at)",
    )

    unit_p = add("unit", cmd_unit, "one orchestration primitive (machine-readable)")
    unit_p.add_argument(
        "--run",
        help="run id (default: the run this session was launched for, else the project's "
        "most recent run)",
    )
    verb = unit_p.add_subparsers(dest="verb", required=True)

    # `--project` and `--run` sit on the `unit` parser, but the verb is a further
    # subparser, so `unit state --project X` would not reach them. Repeating both
    # on every verb via a parent keeps either position working.
    #
    # SUPPRESS on the defaults is load-bearing: argparse applies the subparser's
    # defaults AFTER the outer parse, so an ordinary default would silently
    # overwrite a value given before the verb (`unit --project X state` -> ".").
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--project", default=argparse.SUPPRESS, help=argparse.SUPPRESS)
    common.add_argument("--run", default=argparse.SUPPRESS, help=argparse.SUPPRESS)

    verb.add_parser(
        "state",
        parents=[common],
        help="run, tasks, board and attention as one document",
    )
    pick_p = verb.add_parser(
        "pick",
        parents=[common],
        help="the next actionable story under this run's selector",
    )
    pick_p.add_argument(
        "--wave",
        action="store_true",
        help="in a --plan run: the whole current wave — fronts, what is in flight, what is "
        "dispatchable now within [scm] max_parallel",
    )

    phase_p = verb.add_parser("phase", parents=[common], help="move a story to a phase")
    phase_p.add_argument("story_key")
    phase_p.add_argument("target")
    phase_p.add_argument("--reason", default="", help="why, recorded in the journal")

    journal_p = verb.add_parser(
        "journal", parents=[common], help="append an entry under a chosen kind"
    )
    journal_p.add_argument("kind")
    journal_p.add_argument("--field", action="append", metavar="KEY=VALUE")

    attention_p = verb.add_parser(
        "attention", parents=[common], help="write the run's ATTENTION banner"
    )
    attention_p.add_argument("text")

    notify_p = verb.add_parser(
        "notify", parents=[common], help="send the configured operator notification"
    )
    notify_p.add_argument("title")
    notify_p.add_argument("message")

    finish_p = verb.add_parser(
        "finish", parents=[common], help="end the run because its scope is done"
    )
    finish_p.add_argument("reason")

    pause_p = verb.add_parser("pause", parents=[common], help="halt the run, recording why")
    pause_p.add_argument("stage")
    pause_p.add_argument("reason")
    pause_p.add_argument("--story", help="the story the pause is about, when it is about one")

    verify_p = verb.add_parser(
        "verify", parents=[common], help="run a deterministic gate and report what it found"
    )
    verify_p.add_argument("mode", choices=("dev", "review", "commands"))
    verify_p.add_argument("--story", help="required for dev and review; ignored for commands")

    sprint_p = verb.add_parser(
        "sprint", parents=[common], help="advance a story on the sprint board"
    )
    sprint_p.add_argument("action", choices=("advance",))
    sprint_p.add_argument("story_key")
    sprint_p.add_argument("target")

    boundary_p = verb.add_parser(
        "boundary", parents=[common], help="report or read epic-boundary steps"
    )
    boundary_p.add_argument("epic", type=int)
    boundary_p.add_argument("--step", default="", help="the boundary step being reported")
    boundary_p.add_argument("--status", default="", help="running | done | failed")

    ledger_p = verb.add_parser(
        "ledger", parents=[common], help="read or write the deferred-work ledger"
    )
    ledger_p.add_argument("mode", choices=("list", "add", "close"))
    ledger_p.add_argument("--id", default=None, help="the DW id to close")
    ledger_p.add_argument("--title", default="", help="what is being deferred")
    ledger_p.add_argument("--reason", default="", help="why it is being deferred rather than done")
    ledger_p.add_argument("--source-spec", default="", help="the spec the deferral came out of")
    ledger_p.add_argument("--location", default="n/a", help="where in the tree it lives")
    ledger_p.add_argument("--severity", default=None)
    ledger_p.add_argument("--note", default="", help="resolution note recorded on close")

    rollback_p = verb.add_parser(
        "rollback", parents=[common], help="undo a failed attempt back to its recorded baseline"
    )
    rollback_p.add_argument("story_key")
    rollback_p.add_argument(
        "--preserve",
        action="store_true",
        help="park the attempt's commits on a branch first, so the reset cannot orphan them",
    )
    rebase_p = verb.add_parser(
        "rebase",
        parents=[common],
        help="rebase a story's unit branch onto the current target, in its worktree "
        "(a --plan run's later front, after an earlier one merged); conflicts come back "
        "as paths, aborted, tree clean",
    )
    rebase_p.add_argument("story_key")

    dispatch_p = verb.add_parser(
        "dispatch", parents=[common], help="launch a session and return as soon as it is up"
    )
    dispatch_p.add_argument("role", help="which [adapter.<role>] the session runs on")
    dispatch_p.add_argument("story_key")
    dispatch_p.add_argument("--prompt-file", required=True, help="file holding the session prompt")
    dispatch_p.add_argument("--seq", type=int, default=1, help="attempt number, for the task id")
    dispatch_p.add_argument("--label", help="names a non-standard session (an injected workflow)")
    dispatch_p.add_argument(
        "--resume-session",
        metavar="TASK_ID",
        help="reattach to this earlier task's CLI conversation (cheap repair; "
        "behind [llm] session_resume) — not resumable comes back as a report, not an error",
    )

    workflows_p = verb.add_parser(
        "workflows",
        parents=[common],
        help="list the plugin workflows due at a stage, or dispatch one of them "
        "(ATDD before dev, the TEA analyses at an epic boundary)",
    )
    workflows_p.add_argument("mode", choices=("list", "dispatch"))
    workflows_p.add_argument(
        "stage",
        help="pre_dev_phase | post_dev_phase | post_review_result | pre_commit_gate | "
        "post_epic_boundary",
    )
    workflows_p.add_argument("--story", default=None, help="the open story (in-unit stages)")
    workflows_p.add_argument("--epic", type=int, default=None, help="the epic (post_epic_boundary)")
    workflows_p.add_argument(
        "--name", default=None, help="dispatch: the workflow, as `name` or `plugin.name`"
    )
    workflows_p.add_argument("--seq", type=int, default=1, help="dispatch: attempt number")

    retro_p = verb.add_parser(
        "retro",
        parents=[common],
        help="the epic retrospective gate ([gates] retrospective): fire it, or settle "
        "the auto retrospective session it dispatched",
    )
    retro_p.add_argument("mode", choices=retro_impl.RETRO_MODES)
    retro_p.add_argument("epic", type=int)
    retro_p.add_argument(
        "--run-end",
        action="store_true",
        help="start: the run's last epic, fired only when the board reads it complete",
    )
    retro_p.add_argument("--task", default=None, help="settle: the task id start returned")
    retro_p.add_argument("--seq", type=int, default=1, help="start: attempt number")

    await_p = verb.add_parser(
        "await", parents=[common], help="block until a condition fires, and report which"
    )
    await_p.add_argument(
        "task_id",
        nargs="+",
        help="one task: block on its conditions; several: return when the FIRST ends",
    )
    await_p.add_argument(
        "--until",
        action="append",
        choices=sorted(verb_impl.CONDITIONS),
        help="repeatable; defaults to end",
    )
    await_p.add_argument("--match", help="regex against new pane output (with --until match)")
    await_p.add_argument("--quiet", type=float, help="seconds of silence (with --until quiet)")
    await_p.add_argument("--timeout", type=float, help="outer bound; defaults from [llm]")
    await_p.add_argument(
        "--from-offset", type=int, default=0, dest="from_offset", help="resume reading here"
    )

    tail_p = verb.add_parser("tail", parents=[common], help="read a session's pane log")
    tail_p.add_argument("task_id")
    tail_p.add_argument(
        "--from-offset", type=int, default=0, dest="from_offset", help="byte offset to read from"
    )
    tail_p.add_argument("--lines", type=int, help="cap the output to the last N lines")

    result_p = verb.add_parser(
        "session-result", parents=[common], help="what the watcher recorded, if it has settled"
    )
    result_p.add_argument("task_id")

    nudge_p = verb.add_parser("nudge", parents=[common], help="type into a live session")
    nudge_p.add_argument("task_id")
    nudge_p.add_argument("text")

    kill_p = verb.add_parser("kill", parents=[common], help="tear a session down")
    kill_p.add_argument("task_id")

    open_p = verb.add_parser(
        "open", parents=[common], help="take a story into the run: record it, pin its baseline"
    )
    open_p.add_argument("story_key")
    open_p.add_argument("--epic", type=int, required=True)

    commit_p = verb.add_parser(
        "commit", parents=[common], help="squash the story's work into one commit and finish it"
    )
    commit_p.add_argument("story_key")
    commit_p.add_argument("--message", help="overrides the configured template")

    close_p = verb.add_parser(
        "close", parents=[common], help="finish with a story's tree: merge it back, or keep it"
    )
    close_p.add_argument("story_key")
    close_p.add_argument("outcome", choices=("done", "awaiting-operator", "defer", "escalate"))
