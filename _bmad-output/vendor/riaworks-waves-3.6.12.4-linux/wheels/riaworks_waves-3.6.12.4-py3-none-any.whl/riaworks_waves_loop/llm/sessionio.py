"""How a finished session's outcome reaches the caller.

The adapter's wait loop lives in a watcher process, so its return value has to
cross a process boundary. It crosses as a file, written once when the session
settles, beside the diagnostics the adapter already keeps for that task.

Deliberately a separate file from the session's own `result.json`. That one is
written by the coding-CLI session and describes what the *work* produced; this
one is written by the watcher and describes what the *session* did — whether it
completed, stalled, timed out, blew its budget, or never reached the API. A
caller that conflated them would read "the spec says done" as "the session
finished", which is exactly the confusion the adapter's proof-of-work gate exists
to prevent.
"""

from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path

from ..adapters.base import SessionResult
from ..model import TokenUsage
from ..platform_util import atomic_replace

RESULT_FILE = "session-result.json"

#: Bumped when a field is removed or its meaning changes. Additive fields do not
#: bump it: a caller reading an older document simply sees fewer keys.
SCHEMA_VERSION = 1


def result_path(task_dir: Path) -> Path:
    return task_dir / RESULT_FILE


def write_session_result(task_dir: Path, result: SessionResult) -> Path:
    """Serialize a settled session's outcome, atomically.

    Atomic because the reader is polling: a caller that caught a half-written
    document would read a truncated JSON object as a corrupt session rather than
    as a file it should have asked for again a moment later.
    """
    task_dir.mkdir(parents=True, exist_ok=True)
    target = result_path(task_dir)
    payload = {"schema_version": SCHEMA_VERSION, **asdict(result)}
    tmp = target.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")
    atomic_replace(tmp, target)
    return target


USAGE_FILE = "session-usage.json"


def usage_path(task_dir: Path) -> Path:
    return task_dir / USAGE_FILE


def write_session_usage(task_dir: Path, usage: TokenUsage | None) -> None:
    """Persist a settled session's token usage beside its outcome.

    A file of its own, written AFTER the result, because the two have different
    standing: the result is what the caller is waiting on and must be durable,
    while usage is metadata the engine itself treats as best-effort (see the
    ordering comment at its `record_session` call). Folding usage into the result
    payload would mean rewriting a document a poller may already be reading, to
    add something nobody is blocked on.

    Silent on failure for the same reason: losing the count is a worse report,
    never a broken session.
    """
    if usage is None:
        return
    try:
        task_dir.mkdir(parents=True, exist_ok=True)
        target = usage_path(task_dir)
        tmp = target.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(usage.to_dict()), encoding="utf-8")
        atomic_replace(tmp, target)
    except OSError:
        return


def read_session_usage(task_dir: Path) -> TokenUsage | None:
    """The persisted usage, or None when it was never written or will not parse."""
    try:
        payload = json.loads(usage_path(task_dir).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    if not isinstance(payload, dict):
        return None
    try:
        return TokenUsage.from_dict(payload)
    except (TypeError, ValueError):
        return None


def read_session_result(task_dir: Path) -> dict[str, object] | None:
    """The settled outcome, or None when the session has not settled yet.

    None also covers an unreadable document. The distinction between "not there"
    and "there but broken" is not one the caller can act on differently — both
    mean "no outcome to judge" — and collapsing them keeps a torn read from
    looking like a failed session.
    """
    path = result_path(task_dir)
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return payload if isinstance(payload, dict) else None
