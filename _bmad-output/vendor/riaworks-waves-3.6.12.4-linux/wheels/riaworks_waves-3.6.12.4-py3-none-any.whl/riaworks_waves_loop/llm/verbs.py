"""The `unit` verb bodies.

Each is a thin function over a primitive that already exists, returning the
payload `result.run_verb` renders. Verbs measure and act; they never decide what
the next step is — deciding is the caller's whole purpose, and a verb that
routed on its own finding would be the deterministic engine wearing a new hat.

Two things every verb owes: it mutates under the run-dir lock or not at all, and
it journals only what actually happened.
"""

from __future__ import annotations

import dataclasses
import json
import re
import time
from collections.abc import Mapping
from pathlib import Path

from .. import devcontract, gates, namespace, sprintstatus, waveplan
from ..adapters.multiplexer import get_multiplexer
from ..codex_trust import worktree_launch_trust
from ..deferredwork import append_entry, mark_done, parse_ledger, read_for_observation
from ..engine import _session_task_id
from ..install import dev_primitive_or_default
from ..journal import LOGS_DIR, load_state
from ..model import (
    PAUSE_EPIC_BOUNDARY,
    PAUSE_ESCALATION,
    PAUSE_PLAN_CHECKPOINT,
    PAUSE_SPEC_APPROVAL,
    PAUSE_STORY_CHECKPOINT,
    PAUSE_STORY_GATE,
    Phase,
    SessionRecord,
    StoryTask,
    VerifyOutcome,
)
from ..plugins.model import WORKFLOW_ROLES, WORKFLOW_STAGES
from ..provisioning import ProvisionFailed
from ..recovery_flow import attempt_preserve_ref_name
from ..runs import session_name
from ..runsetup import ROLES
from ..sessionspec import build_spec
from ..statemachine import IllegalTransition, advance
from ..verify import (
    GitError,
    branch_exists,
    checkout_branch,
    commit_paths,
    create_branch,
    current_branch,
    finalize_commit,
    gate_commands_outcome,
    path_dirty,
    path_ignored,
    path_tracked,
    preserve_commits,
    resolve_spec_in_work_tree,
    rev_parse_head,
    safe_rollback,
    untracked_files,
    verify_dev,
    verify_review,
)
from ..workspace import open_unit_workspace
from ..worktree_flow import WorktreeFlow, provision_worktree
from .dispatch import (
    HANDOVER_FILE,
    adapter_for_role,
    build_adapters,
    read_handover,
    read_handover_identity,
    spawn_watcher,
    write_handover,
)
from .host import LLMHost
from .result import VerbError
from .sessionio import read_session_result, read_session_usage, result_path
from .watch import CONDITIONS, Conditions, await_session


def _today() -> str:
    """Today's date, ISO, for ledger bookkeeping."""
    return time.strftime("%Y-%m-%d")


def _now() -> str:
    """Timestamp in the sprint board's own format, for `last_updated`."""
    return time.strftime("%d-%m-%Y %H:%M")


# Fields the journal writes for itself. A caller-supplied value would silently
# replace the real one, making the entry lie about when it happened or which log
# it points at.
_RESERVED_JOURNAL_FIELDS = frozenset({"ts", "kind", "log_task", "log_pos"})

# The stages a pause may carry. Deliberately the model's own vocabulary rather
# than free text: `waves resume` and the resolve flow both dispatch on it, so
# an invented stage would produce a paused run nothing knows how to re-arm.
PAUSE_STAGES = frozenset(
    {
        PAUSE_SPEC_APPROVAL,
        PAUSE_EPIC_BOUNDARY,
        PAUSE_ESCALATION,
        PAUSE_STORY_GATE,
        PAUSE_PLAN_CHECKPOINT,
        PAUSE_STORY_CHECKPOINT,
    }
)


def _task_view(task: StoryTask) -> dict[str, object]:
    return {
        "story_key": task.story_key,
        "epic": task.epic,
        "phase": str(task.phase),
        "attempt": task.attempt,
        "review_cycle": task.review_cycle,
        "terminal": task.terminal,
        "spec_file": task.spec_file,
        "commit_sha": task.commit_sha,
        "defer_reason": task.defer_reason,
        "worktree_path": task.worktree_path or None,
        "branch": task.branch or None,
    }


# ------------------------------------------------------------------ reading


def verb_state(host: LLMHost) -> dict[str, object]:
    """Everything a turn needs to open with: the run, its tasks, the board, and
    the attention banner."""
    state = host.state
    try:
        board = {s.key: s.status for s in sprintstatus.load(host.paths.sprint_status).stories}
    except (sprintstatus.SprintStatusError, OSError):
        # A missing or malformed board is a fact worth reporting, not a reason to
        # refuse the whole question: the caller may legitimately be running before
        # sprint planning, and failing here would hide the run state too.
        board = {}
    attention = host.run_dir / gates.ATTENTION_FILE
    return {
        "run": {
            "run_id": state.run_id,
            "source": state.source,
            "current_epic": state.current_epic,
            "epic_filter": state.epic_filter,
            "story_filter": state.story_filter,
            "max_stories": state.max_stories,
            "paused": state.paused,
            "paused_reason": state.paused_reason,
            "paused_stage": state.paused_stage,
            "paused_story_key": state.paused_story_key,
            "finished": state.finished,
            "finish_reason": state.finish_reason,
            "stopped": state.stopped,
            "crashed": state.crashed,
            "crash_error": state.crash_error,
            "target_branch": state.target_branch or None,
        },
        "tasks": [_task_view(t) for t in state.tasks.values()],
        "board": board,
        "attention": attention.read_text(encoding="utf-8") if attention.is_file() else "",
    }


def verb_pick(host: LLMHost, *, wave: bool = False) -> dict[str, object]:
    """The next actionable story under this run's own selector, or null.

    Which stories are eligible is a fact about the board, so it stays in
    `sprintstatus`. What to do with the answer — take it, skip it, stop — is the
    caller's.
    """
    # Absent and corrupt are different answers for the caller — one means "run
    # sprint planning", the other "fix the file" — but sprintstatus.load raises
    # the same type for both, so the existence check happens here.
    if not host.paths.sprint_status.is_file():
        raise VerbError("not-found", f"no sprint status at {host.paths.sprint_status}")
    try:
        board = sprintstatus.load(host.paths.sprint_status)
    except (sprintstatus.SprintStatusError, OSError) as exc:
        raise VerbError("state-conflict", f"unreadable sprint status: {exc}") from exc
    # Every story this run has a task for, not just the finished ones: a story in
    # flight must not be picked a second time.
    handled = set(host.state.tasks)
    # A `--plan` run picks in the plan's order — wave by wave, fronts in the grid's
    # merge order — and says which wave and front the story belongs to, so the
    # orchestrator can name the front's branch and read the plan's contracts.
    order = waveplan.story_order_of(host.state.plan)
    if wave and order is None:
        raise VerbError("invalid-args", "this run has no plan: `pick --wave` needs a --plan run")
    try:
        actionable = sprintstatus.select_actionable(
            board, host.state.epic_filter, host.state.story_filter, order=order
        )
    except sprintstatus.SprintStatusError as exc:
        raise VerbError("not-found", str(exc)) from exc
    if order is None:
        for story in actionable:
            if story.key not in handled:
                return {"story": {"key": story.key, "epic": story.epic, "status": story.status}}
        return {"story": None}

    # A `--plan` run respects the plan's waves: a story of a later wave is never
    # offered while the current wave has a story in flight, a front holds one story
    # at a time, and `[scm] max_parallel` caps the stories in flight at once.
    # `wave=True` answers the whole current wave — each front, what it is working
    # on, what it would take next, and what is dispatchable now within the cap —
    # which is what a fan-out reads before opening several stories in one turn.
    # Settled = terminal in this run, or not actionable on the board (done before
    # the run, or parked by someone); in flight = a task of this run not terminal.
    plan = host.state.plan or {}
    by_key = {s.key: s for s in actionable}
    in_flight = {k for k, t in host.state.tasks.items() if not _settled(t)}
    settled = {k for k, t in host.state.tasks.items() if _settled(t)} | {
        k for k in order if k not in by_key and k not in in_flight
    }
    view = waveplan.wave_view(plan, settled, in_flight)
    # Parallel stories need a tree each. Opened in place they would share the one
    # checkout — two sessions editing, and each story's commit (`add -A`) carrying
    # the other's half-done work — so without worktree isolation the cap is 1,
    # which is what the deterministic engine does too (`wavemaster.applies`).
    cap = host.policy.scm.max_parallel
    serial_reason = None
    if cap > 1 and host.policy.scm.isolation != "worktree":
        cap = 1
        serial_reason = (
            f'[scm] max_parallel = {host.policy.scm.max_parallel} needs isolation = "worktree": '
            "in place, stories in flight would share one checkout, so this run is serial"
        )
    capacity = max(0, cap - len(in_flight))
    dispatch: list[dict[str, object]] = []
    for key in view["dispatchable"]:
        story = by_key.get(key)
        if story is None or key in handled:
            continue
        dispatch.append(
            {
                "key": story.key,
                "epic": story.epic,
                "status": story.status,
                "plan": waveplan.front_of(plan, story.key),
            }
        )
    offered = dispatch[:capacity]
    if wave:
        doc: dict[str, object] = {
            "wave": view["wave"],
            "max_parallel": cap,
            "in_flight": sorted(in_flight),
            "capacity": capacity,
            "fronts": view["fronts"],
            "dispatch": offered,
            "waiting": [d["key"] for d in dispatch[capacity:]],
        }
        if serial_reason is not None:
            doc["serial"] = serial_reason
        return doc
    if offered:
        return {"story": offered[0], "wave": view["wave"], "capacity": capacity}
    return {
        "story": None,
        "wave": view["wave"],
        "capacity": capacity,
        "in_flight": sorted(in_flight),
        "waiting": [d["key"] for d in dispatch],
    }


# ------------------------------------------------------------ writing state


def _story_advance(task: StoryTask, phase: Phase) -> None:
    """`statemachine.advance` for a STORY task, as a typed verb error.

    The table has one edge no story may take: PENDING -> DONE, which exists for the
    sweep's migrate task, whose empty manifest is a completed no-op (DW-440). A
    story reaches DONE only through COMMITTING, and every verb here moves story
    tasks — so without this refusal `phase` and `close` would let the orchestrator
    call a story done that never ran a session."""
    if task.phase is Phase.PENDING and phase is Phase.DONE:
        raise VerbError(
            "illegal-transition",
            f"{task.story_key}: {task.phase} -> {phase} (a story reaches done only "
            "through committing)",
        )
    try:
        advance(task, phase)
    except IllegalTransition as exc:
        raise VerbError("illegal-transition", str(exc)) from exc


def verb_phase(host: LLMHost, story_key: str, target: str, reason: str = "") -> dict[str, object]:
    """Move one story to `target`, refusing anything the state machine forbids.

    The refusal is the point. The caller decides *whether* to move a story;
    whether a move is coherent stays with `statemachine.TRANSITIONS`, which is
    the single source of truth for it.
    """
    try:
        phase = Phase(target)
    except ValueError as exc:
        raise VerbError(
            "invalid-args",
            f"unknown phase {target!r}; expected one of {sorted(p.value for p in Phase)}",
        ) from exc
    with host.mutate() as state:
        task = state.tasks.get(story_key)
        if task is None:
            raise VerbError("not-found", f"run has no task for story {story_key!r}")
        previous = str(task.phase)
        _story_advance(task, phase)
    # Journalled only after the mutation lands: a refused call did not happen,
    # and the journal is the record of what did.
    host.journal.append(
        "llm-phase", story_key=story_key, **{"from": previous, "to": target}, reason=reason
    )
    return {"story_key": story_key, "from": previous, "to": target}


def verb_journal(host: LLMHost, kind: str, fields: dict[str, str]) -> dict[str, object]:
    """Append one entry under a caller-chosen kind.

    The kind is free-form on purpose: the dashboard renders any kind, and this is
    where the caller records *why* it decided what it decided — the record a
    relaunched session reads to recover continuity.
    """
    kind = kind.strip()
    if not kind:
        raise VerbError("invalid-args", "journal kind must be a non-empty string")
    shadowed = sorted(_RESERVED_JOURNAL_FIELDS & set(fields))
    if shadowed:
        raise VerbError(
            "invalid-args", f"these fields are written by the journal itself: {shadowed}"
        )
    host.journal.append(kind, **fields)
    return {"kind": kind, "fields": dict(fields)}


# -------------------------------------------------------- talking to a human


def verb_attention(host: LLMHost, text: str) -> dict[str, object]:
    """Write the run's ATTENTION banner, which the dashboard surfaces."""
    text = text.strip()
    if not text:
        raise VerbError("invalid-args", "attention text must be non-empty")
    (host.run_dir / gates.ATTENTION_FILE).write_text(text + "\n", encoding="utf-8")
    host.journal.append("llm-attention", text=text)
    return {"attention": text}


def verb_notify(host: LLMHost, title: str, message: str) -> dict[str, object]:
    """Send the operator notification configured in [notify]."""
    if not title.strip():
        raise VerbError("invalid-args", "notification title must be non-empty")
    gates.notify(host.policy, host.run_dir, title, message)
    return {"title": title, "message": message}


def verb_finish(host: LLMHost, reason: str) -> dict[str, object]:
    """End the run because its scope is done — the terminal that is not a halt.

    The supervisor's loop ends on `state.finished`, and until this verb existed
    nothing on this path could set it: the only way out of a completed run was
    `pause`, which means "a human is needed" and is read that way by every
    consumer — the dashboard badge, the epic gate, the operator skimming a run
    list. A run whose last story is done and whose selector is exhausted is not
    waiting for anybody, and saying it is turns a clean finish into a false
    alarm.

    The cost of the workaround was measured, not theorised: without pausing, the
    run stays non-terminal, so every relaunch spends a turn reading state,
    finding no work, and closing — burning the relaunch quota to reach a
    conclusion nothing can record.

    Deciding that the scope IS done stays with the caller — this verb does not
    consult the board, exactly as `pause` does not judge whether a halt was
    warranted. What it refuses is the incoherent case: finishing while a story
    is still mid-flight would strand that work in a run nothing will drive
    again. Terminal phases are fine; those stories are finished with, however
    they ended.

    Idempotent: finishing an already-finished run reports the original reason
    rather than raising, because a caller that lost its turn to a relaunch must
    be able to re-assert the ending without treating success as an error.
    """
    reason = reason.strip()
    if not reason:
        raise VerbError("invalid-args", "finish reason must be non-empty")
    with host.mutate() as state:
        if state.finished:
            return {"finished": True, "reason": state.finish_reason, "already": True}
        if state.paused:
            raise VerbError(
                "state-conflict",
                f"run is paused at {state.paused_stage!r} — resolve or resume it before "
                f"finishing: {state.paused_reason}",
            )
        in_flight = sorted(key for key, task in state.tasks.items() if not task.terminal)
        if in_flight:
            raise VerbError(
                "state-conflict",
                f"cannot finish with stories still in flight: {in_flight}; drive each to a "
                "terminal phase first",
            )
        # Terminal is not enough under isolation: a committed story whose merge-back
        # has not landed lives only on its branch, and a finished run never closes it
        # again. Measured shape (run 20260922-210104-0885): the doctrine said "finish
        # when no work is left" and "never pause for one story" at once, and the story
        # the rest depended on was committed, unmerged, and retryable.
        unmerged = sorted(
            key
            for key, task in state.tasks.items()
            if task.phase in (Phase.DONE, Phase.AWAITING_OPERATOR)
            and task.worktree_path
            and not task.integrated
        )
        if unmerged:
            raise VerbError(
                "state-conflict",
                f"cannot finish with committed stories not merged into "
                f"{state.target_branch or 'the target branch'}: {unmerged}; `close` each "
                "again once the cause its last refusal named is cleared — and if only the "
                "owner can clear it, that is a pause, not a finish",
            )
        state.finished = True
        state.finish_reason = reason
    host.journal.append("llm-finish", reason=reason)
    return {"finished": True, "reason": reason, "already": False}


def verb_pause(
    host: LLMHost, stage: str, reason: str, story_key: str | None = None
) -> dict[str, object]:
    """Halt the run, recording why.

    The only verb that stops a run, and legitimate in exactly three cases: a
    genuinely ambiguous product decision, a risk of destroying work, or systemic
    failure — consecutive stories failing for the same cause that is not the
    story's. A failed verification, a failed review, an exhausted review budget
    or a red epic boundary are judgment junctions, not reasons to halt.

    The reason is mandatory and journalled, so "why did this run stop" is always
    answerable from the file rather than by inference.
    """
    reason = reason.strip()
    if not reason:
        raise VerbError("invalid-args", "pause reason must be non-empty")
    if stage not in PAUSE_STAGES:
        raise VerbError(
            "invalid-args",
            f"unknown pause stage {stage!r}; expected one of {sorted(PAUSE_STAGES)}",
        )
    with host.mutate() as state:
        if state.paused:
            raise VerbError(
                "state-conflict",
                f"run is already paused at {state.paused_stage!r}: {state.paused_reason}",
            )
        state.paused_stage = stage
        state.paused_reason = reason
        state.paused_story_key = story_key
    host.journal.append("llm-pause", stage=stage, reason=reason, story_key=story_key)
    return {"paused": True, "stage": stage, "reason": reason, "story_key": story_key}


# ------------------------------------------------------ deterministic judgment


def _settled(task: StoryTask) -> bool:
    """A story that needs nothing more from this run: landed on the target, or
    closed to an outcome that will not land, or closed on the shared checkout.
    Terminal alone is not enough — the LLM loop's `commit` moves a story to DONE
    before `close` integrates it, and a DONE story with a mounted worktree is
    still in flight as far as its wave and its front are concerned."""
    return task.settled


def _task_or_404(host: LLMHost, story_key: str) -> StoryTask:
    task = host.state.tasks.get(story_key)
    if task is None:
        raise VerbError("not-found", f"run has no task for story {story_key!r}")
    return task


def _outcome_view(outcome: VerifyOutcome) -> dict[str, object]:
    """A VerifyOutcome as the caller reads it.

    Every discriminator the judgment table keys on is exposed by name rather than
    folded into a verdict string: `fixable` says a repair pass has concrete
    evidence to act on, `env_fault` says the fault is the machine's and must not
    charge a story budget, `contradiction` says a session revoked something the
    orchestrator had already established. Collapsing these into pass/fail would
    put the routing back inside the tool.
    """
    return {
        "ok": outcome.ok,
        "reason": outcome.reason,
        "severity": outcome.severity,
        "fixable": outcome.fixable,
        "env_fault": outcome.env_fault,
        "contradiction": outcome.contradiction,
        "retryable": outcome.retryable,
    }


def verb_verify(host: LLMHost, mode: str, story_key: str | None = None) -> dict[str, object]:
    """Run one deterministic gate and report what it found.

    This verb measures. It does not retry, defer, escalate or route: the reason
    the control loop moved out of Python at all is that those decisions belong to
    a caller who can read the failing log first.
    """
    if mode == "commands":
        outcome = gate_commands_outcome(host.policy, host.paths)
        return {"mode": mode, "outcome": _outcome_view(outcome)}
    if story_key is None:
        raise VerbError("invalid-args", f"verify {mode} needs a story key")
    task = _task_or_404(host, story_key)
    if mode == "dev":
        # The dev gate judges on-disk artifacts against what the session claimed,
        # so it needs the claim. Read from the settled session-result file rather
        # than from `task.sessions`: only the deterministic engine records
        # sessions onto the task (`engine.py`'s lone `record_session` call), so on
        # this path that list is always empty and this gate answered "dev
        # result.json missing spec_file" for every story, with the claim sitting
        # readable on disk the whole time.
        result_json = _latest_dev_result(host, story_key)
        _stamp_spec_file(host, task, result_json)
        # Measure the proof-of-work in the tree that holds it. Under
        # scm.isolation=worktree the story's commit lives only in its worktree
        # until the merge, so the gate's `has_changes_since` against the main
        # checkout answers "no changes in worktree since baseline commit" for
        # every isolated story, with the work committed and readable the whole
        # time. Same shape as the `commands_root` the review gate already takes.
        #
        # And tell it the same truth about the merge that the review gate already
        # gets. With review disabled this is the LAST gate, and it demanded a
        # board reading `done` while the review gate demanded `awaiting-merge` for
        # the same isolated story — mutually exclusive values on a board that
        # never regresses, so satisfying one closed the other permanently. Same
        # `_work_root`, so the two gates and `verb_close` cannot disagree about
        # whether a merge is still outstanding.
        dev_worktree = _work_root(task)
        outcome = verify_dev(
            task,
            host.paths,
            result_json,
            review_enabled=devcontract.dev_review_enabled(host.policy),
            work_root=dev_worktree,
            merge_pending=dev_worktree is not None,
        )
    elif mode == "review":
        # The review gate reads `task.spec_file`, and under scm.isolation=worktree
        # the spec the sessions wrote lives ONLY in the story's worktree until the
        # merge — so a stamp that is relative (resolved against whatever cwd the
        # orchestrator happens to have) or that points into the main checkout
        # reads as an absent spec and the gate answers `spec status is ''`, with
        # a finalized spec sitting readable on disk the whole time. Re-stamp from
        # the review session's own claim, falling back to dev's.
        _stamp_spec_file(
            host,
            task,
            _latest_dev_result(host, story_key, "review") or _latest_dev_result(host, story_key),
        )
        # Gate the commands in the tree that holds the work. Under
        # scm.isolation=worktree the story's code is in its worktree and nowhere
        # else until the merge, so running them in the main checkout tests the
        # BASELINE and passes without touching the story.
        # And tell the gate which board is the honest one. Under isolation the
        # protocol advances the board to `awaiting-merge` after review passes and
        # only to a terminal status once `close` reports `merged` — so a gate
        # demanding `done` here would fail a story whose board was exactly right,
        # and `judgment.md` routes a review failure to repair and then to a defer
        # that rolls the work back. Derived from the same `task.worktree_path`
        # that decides `verb_close`'s `isolated`, so the two cannot disagree about
        # whether a merge is still outstanding.
        worktree = _work_root(task)
        outcome = verify_review(
            task,
            host.paths,
            host.policy,
            commands_root=worktree,
            merge_pending=worktree is not None,
        )
    else:
        raise VerbError("invalid-args", f"unknown verify mode {mode!r}")
    return {"mode": mode, "story_key": story_key, "outcome": _outcome_view(outcome)}


# ------------------------------------------------------------------- the board


def _opt_str(value: object) -> str | None:
    """A persisted field as a string, or None when it is absent or empty."""
    return str(value) if isinstance(value, str) and value else None


def _session_owner(tasks: Mapping[str, StoryTask], task_id: str) -> tuple[str, str] | None:
    """The story a session id was minted for, and the part (role or workflow label)
    it was minted with — or None when no task composes to it.

    Matched, not parsed: the id is ``_session_task_id(story, part, seq, generation)``
    and its two variable-width ends (a hyphenated label, the ``-g<N>`` suffix a
    re-armed story carries) defeat splitting off the last two ``-`` groups. Each
    task is asked whether its own composition yields this exact id. When two do —
    ``1-1-a-dev-dev-1`` is story ``1-1-a-dev``'s dev session and also story
    ``1-1-a`` under a ``dev-dev`` label — the longer key wins, because it is the
    reading that needs no label to explain it."""
    found: tuple[str, str] | None = None
    for key, task in tasks.items():
        if not task_id.startswith(f"{key}-"):
            continue
        rest = re.sub(r"-g[1-9][0-9]*\Z", "", task_id[len(key) + 1 :])
        part, sep, seq = rest.rpartition("-")
        if not (sep and part and seq.isdigit()):
            continue
        if _session_task_id(key, part, int(seq), task.generation) != task_id:
            continue
        if found is None or len(key) > len(found[0]):
            found = (key, part)
    return found


def _absorb_settled_session(host: LLMHost, task_id: str) -> None:
    """Record a settled session onto its story task, once.

    The deterministic engine does this the moment a session ends — `record_session`
    plus `attach_session_usage`, which is what makes `task.tokens` add up. This
    loop had no equivalent moment, so an LLM-held run carried `sessions: []` and
    reported zero tokens however much it had spent, and the dashboard's token
    column stayed at 0 for the life of the run.

    Done where the ORCHESTRATOR observes the outcome rather than in the watcher,
    because the watcher is a detached process that must not contend for the
    run-dir lock with the turn that is driving. Both `await` and `session-result`
    call it, since either may be the verb that first sees the session settle.

    Idempotent by task id: a caller that polls `session-result` three times must
    not add the usage three times. That is also why the guard is the session
    record and not the usage file — the file stays on disk and would re-add on
    every poll.
    """
    task_dir = host.run_dir / "tasks" / task_id
    settled = read_session_result(task_dir)
    if not isinstance(settled, dict):
        return
    identity_fault: str | None = None
    with host.mutate() as state:
        owner = _session_owner(state.tasks, task_id)
        if owner is None:
            return
        story_key, role = owner
        task = state.tasks[story_key]
        if any(rec.task_id == task_id for rec in task.sessions):
            return
        try:
            adapter, model = read_handover_identity(host.run_dir, task_id)
        except (OSError, ValueError) as exc:
            adapter, model = "", ""
            identity_fault = f"{type(exc).__name__}: {exc}"
        task.record_session(
            SessionRecord(
                task_id=task_id,
                role=role,
                status=str(settled.get("status") or ""),
                # The identity the engine stamps on its own records: without it
                # the dashboard's agent column fell back to "-" the moment the
                # session stopped being the live one.
                adapter=adapter,
                model=model,
                # Coerced through str(): the settled document is
                # `dict[str, object]` off disk, and a field that arrives as a
                # non-string would otherwise be filed as one and surface later as
                # a transcript path that cannot be opened.
                session_id=_opt_str(settled.get("session_id")),
                transcript_path=_opt_str(settled.get("transcript_path")),
                usage=read_session_usage(task_dir),
            )
        )
    if identity_fault is not None:
        # The record still lands — its status and usage are what the run needs —
        # but an unstamped record must not pass for one that predates stamping.
        host.journal.append(
            "llm-session-identity-unreadable", task_id=task_id, error=identity_fault
        )


def _count_session(host: LLMHost, story_key: str, role: str) -> None:
    """Charge a launched dev or review session to its story, as the engine does.

    The engine bumps `task.attempt` for every dev session it launches and
    `task.review_cycle` for every review pass, and those counters are what the
    dashboard's `dev ×N` / `review ×N` columns, `status`, `diagnose` and the turn
    digest's "(attempt N)" read. Nothing in this loop ever moved them: an LLM-held
    run showed `dev ×0` beside a story that had been through two dev sessions, and
    `unit status` answered `attempt: 0` against the `attempt: 1` its own reference
    documents — so the orchestrator could not see its retry budget either.

    Counted only once the session is up (a refused or failed launch spent
    nothing), and only for the story stages: a triage or a plugin workflow session
    is neither an attempt nor a review cycle. A conversation resume counts — it is
    another session of that stage. A re-arm (`runs.rearm_escalation`) resets both,
    exactly as for the engine."""
    if role not in ("dev", "review"):
        return
    with host.mutate() as state:
        task = state.tasks.get(story_key)
        if task is None:
            return
        if role == "dev":
            task.attempt += 1
        else:
            task.review_cycle += 1


def _latest_dev_result(
    host: LLMHost, story_key: str, role: str = "dev"
) -> dict[str, object] | None:
    """The newest settled session's result payload for this story and role, or None.

    Found by task-dir name because that is the only handle this verb is given:
    `dispatch` mints ids as `<story>-<role>-<seq>` (see `verb_dispatch`), and the
    settled outcome — including the skill's own `result_json`, read back by the
    adapter — is what `write_session_result` persisted beside it.

    Newest wins on the numeric suffix, not on mtime: a re-dispatched attempt is
    seq 2, and a filesystem whose timestamps are coarse (or a file touched by a
    later read) must not make attempt 1 look like the current claim.
    """
    tasks = host.run_dir / "tasks"
    best: tuple[int, dict[str, object]] | None = None
    try:
        entries = sorted(tasks.iterdir())
    except OSError:
        return None
    # Ids are recomputed through the same composition point `_launch_session` mints
    # with, for the story's CURRENT generation only: a re-armed story's abandoned
    # attempt left results under the un-suffixed ids, and reading those back as the
    # current claim is the #705 replay. Parsing names instead would also break on a
    # long key `safe_segment` shortened to a digest.
    owner = host.state.tasks.get(story_key)
    generation = owner.generation if owner is not None else 0
    seq_of = {
        _session_task_id(story_key, role, n, generation): n for n in range(1, len(entries) + 1)
    }
    for task_dir in entries:
        seq = seq_of.get(task_dir.name)
        if seq is None or not task_dir.is_dir():
            continue
        settled = read_session_result(task_dir)
        if not isinstance(settled, dict):
            continue
        payload = settled.get("result_json")
        if isinstance(payload, dict) and (best is None or seq > best[0]):
            best = (seq, payload)
    return best[1] if best is not None else None


def _work_root(task: StoryTask) -> Path | None:
    """The tree that holds the story's work: its worktree under
    `scm.isolation = "worktree"`, or None for a run opened in place.

    Derived from the SAME `task.worktree_path` that decides `verb_close`'s
    `isolated` and the review gate's `merge_pending`, so the record of where the
    tree was mounted is the one thing every reader of it agrees on.
    """
    root = Path(task.worktree_path) if task.worktree_path else None
    return root if root is not None and root.is_dir() else None


def _stamp_is_live(spec_file: str | None, work_root: Path | None) -> bool:
    """True while a stamp still names the spec the gates must read.

    `9726ea9` made a live stamp authoritative over a later claim — so a stale
    re-dispatch cannot overwrite a good record — and tested "readable" as the
    predicate for live. Under isolation readable is not enough: the shared
    checkout's copy of the spec is readable AND wrong, still at the baseline
    because the work lives on the unit branch. So the first crooked stamp fixed
    itself permanently, and the review gate's own re-stamp — which exists for
    precisely this — was dead on arrival, guarded out by the function it calls
    (DW-396). Hence live means readable IN THE TREE THAT HOLDS THE WORK.

    With no worktree the two readings coincide and the original predicate stands.
    """
    if not spec_file:
        return False
    path = Path(spec_file)
    if not path.is_file():
        return False
    if work_root is None:
        return True
    try:
        return path.resolve().is_relative_to(work_root.resolve())
    except (OSError, RuntimeError):
        # `resolve` reports a symlink loop as RuntimeError below 3.13. A stamp we
        # cannot place is not a stamp we should keep: treating it as dead lets
        # the claim below replace it, which is the recoverable direction.
        return False


def _stamp_spec_file(host: LLMHost, task: StoryTask, result_json: dict[str, object] | None) -> None:
    """Record the spec the dev session reported, the way the engine does.

    `verify review` reads `task.spec_file`, and on this path nobody was writing
    it — the engine stamps it when it accepts a dev result, and this loop has no
    equivalent moment. Doing it here keeps the two loops recording the same fact
    from the same evidence, so the review gate stops failing on a field that was
    simply never filled in.

    Bookkeeping, not routing: the verb still only measures, and re-stamping the
    same value is a no-op. A path that does not resolve to a file is ignored
    rather than recorded — a wrong spec_file would send the review gate at
    something the session never wrote.
    """
    if not isinstance(result_json, dict):
        return
    # A stamp is kept only while it still names a readable file IN the tree that
    # holds the work. One that does not is worse than none: the gates resolve it
    # against the process cwd and then report the spec's status as empty rather
    # than as missing — or, under isolation, report the baseline's status as the
    # story's, which is worse still because it reads like a finished answer.
    work_root = _work_root(task)
    if _stamp_is_live(task.spec_file, work_root):
        return
    claimed = result_json.get("spec_file")
    if not claimed:
        return
    spec_path = resolve_spec_in_work_tree(str(claimed), host.paths, work_root)
    if not spec_path.is_file():
        return
    # Absolute on purpose: the run directory outlives this process, and a
    # relative stamp means a different file to the next turn's cwd.
    stamped = str(spec_path.resolve())
    with host.mutate() as state:
        current = state.tasks.get(task.story_key)
        if current is not None and not _stamp_is_live(current.spec_file, work_root):
            current.spec_file = stamped
    task.spec_file = stamped


def _bookkeeping_commit_rel(host: LLMHost, path: Path) -> tuple[str | None, str]:
    """Asked BEFORE a verb writes the board or the ledger: the repo-relative path to
    commit once the write lands, or None and the reason it will not be committed.

    Under isolation the target checkout is where every story MERGES, and nothing in
    this host commits what the verbs write there — the engine's post-merge carries
    are the engine's. Left uncommitted, that bookkeeping met the next story's merge:
    the dirt guard refused it (measured, run 20260922-210104-0885: every story after
    the first), and a ledger the story's branch also touched was reverted by the
    incoming-path cleanup, taking the verbs' `DW-` entries with it. So the write
    commits itself, by pathspec, the moment it lands — and only when that commit can
    carry nothing but the run's own bytes:

    - isolation, and the checkout on the run's target branch — in place, the story's
      own commit (`add -A`) already carries both files, and a commit here would land
      between a story's baseline and its work;
    - the path inside the repository and tracked — an untracked file that already
      exists is somebody's, and git refuses an ignored pathspec anyway. The one
      untracked path that qualifies is one that does not exist yet and is not
      ignored: the write creates it, so every byte in it is the run's (a project's
      first `ledger add`);
    - the path CLEAN before the write — dirt already there is somebody's (an
      operator's edit, an earlier write whose commit failed), and a pathspec commit
      would sweep it in under the run's name.

    Any reading that fails answers "do not commit": the write still stands, and the
    answer says why it was not committed.
    """
    if host.policy.scm.isolation != "worktree":
        return None, "in place: the story's own commit carries it"
    repo = host.paths.repo_root
    try:
        rel = path.resolve().relative_to(repo.resolve()).as_posix()
    except (OSError, RuntimeError, ValueError):
        return None, "it lives outside the repository"
    try:
        target = host.state.target_branch
        if target and current_branch(repo) != target:
            return None, f"the checkout is not on the run's target branch {target!r}"
        if not path_tracked(repo, rel):
            if path.exists() or path_ignored(repo, path):
                return None, "git does not track it"
            return rel, ""  # created by this write: nothing in it is anyone else's
        if path_dirty(repo, rel):
            return None, (
                "it already had uncommitted changes, which are not the run's to commit — "
                "the owner commits or reverts them"
            )
    except GitError as exc:
        return None, f"its git state could not be read: {exc}"
    return rel, ""


def _commit_bookkeeping(
    host: LLMHost, path: Path, planned: tuple[str | None, str], message: str
) -> dict[str, object]:
    """Commit the write `_bookkeeping_commit_rel` cleared, and say what happened.

    ``committed`` is the new commit, or None with ``commit_skipped`` naming why. A
    failed commit (a hook, signing, a lock) leaves the write in place, uncommitted,
    and is journaled; it is never raised — the write the caller asked for landed."""
    rel, why_not = planned
    if rel is None:
        return {"committed": None, "commit_skipped": why_not}
    try:
        sha = commit_paths(host.paths.repo_root, message, [path])
    except GitError as exc:
        host.journal.append("llm-bookkeeping-uncommitted", path=rel, error=str(exc))
        return {"committed": None, "commit_skipped": f"the commit failed: {exc}"}
    if sha is None:
        return {"committed": None, "commit_skipped": "the write changed nothing"}
    host.journal.append("llm-bookkeeping-commit", path=rel, commit=sha, message=message)
    return {"committed": sha}


def verb_sprint_advance(host: LLMHost, story_key: str, target: str) -> dict[str, object]:
    """Advance a story on the sprint board — the single writer of it.

    `sprintstatus.advance` never regresses a story, so what lands can differ from
    what was asked. This reports the status that ended up on disk rather than the
    one requested; a caller told "done" while the board says otherwise would go
    on to make decisions against a board that never moved.
    """
    if not host.paths.sprint_status.is_file():
        raise VerbError("not-found", f"no sprint status at {host.paths.sprint_status}")
    planned = _bookkeeping_commit_rel(host, host.paths.sprint_status)
    try:
        landed = sprintstatus.advance(
            host.paths.sprint_status,
            story_key,
            target,
            now=_now(),
            # The board is the method's artifact and its own LLM-executed updater
            # can only order the statuses its STATUS DEFINITIONS block names, so
            # the writer defines each status we write that the method lacks —
            # `awaiting-merge` reaches the board only through this verb. A board
            # with no such block gets a journal line, never an invented block.
            on_degraded=lambda reason: host.journal.append(
                "board-status-undocumented", story_key=story_key, target=target, reason=reason
            ),
        )
    except sprintstatus.SprintStatusError as exc:
        raise VerbError("state-conflict", str(exc)) from exc
    if landed is None:
        raise VerbError("not-found", f"sprint status has no entry for {story_key!r}")
    host.journal.append("llm-sprint-advance", story_key=story_key, target=target, landed=landed)
    committed = _commit_bookkeeping(
        host,
        host.paths.sprint_status,
        planned,
        f"chore(sprint-status): {story_key} to {landed} ({namespace.PRODUCT} run {host.state.run_id})",
    )
    return {"story_key": story_key, "requested": target, "status": landed, **committed}


# ---------------------------------------------------------------------- boundary


_BOUNDARY_STATUSES = ("running", "done", "failed")


def verb_boundary(host: LLMHost, epic: int, step: str = "", status: str = "") -> dict[str, object]:
    """Report or read epic-boundary progress.

    The deterministic engine persists per-step boundary progress in
    `RunState.boundary_progress` and the dashboard paints it beside the epic's
    stories. This verb is the LLM-held run's way onto the same channel: name a
    step, stamp its state, and the boundary shows up the way the engine's
    does. Reading back (no step) is how a later turn learns what boundary work
    already ran instead of redoing it — an empty answer is an answer.

    The statuses are the dashboard's closed vocabulary, shared with the
    engine's own hook step; free text would render as nothing.

    **Does not**: run the boundary's workflows or hooks, decide whether the
    boundary passed, or pause the run — `unit pause --stage epic-boundary` is
    the caller's routing, not this verb's finding.
    """
    if epic < 1:
        raise VerbError("invalid-args", f"epic must be a positive number, got {epic}")
    key = f"epic-{epic}"
    if not step and not status:
        return {"epic": epic, "steps": dict(host.state.boundary_progress.get(key, {}))}
    if not step or not status:
        raise VerbError("invalid-args", "boundary needs --step and --status together")
    if status not in _BOUNDARY_STATUSES:
        raise VerbError(
            "invalid-args",
            f"unknown boundary status {status!r}: one of " + ", ".join(_BOUNDARY_STATUSES),
        )
    with host.mutate() as state:
        state.boundary_progress.setdefault(key, {})[step] = status
    host.journal.append("llm-boundary-step", epic=epic, step=step, status=status)
    return {"epic": epic, "step": step, "status": status}


# ------------------------------------------------------------------ the ledger


def verb_ledger(
    host: LLMHost,
    mode: str,
    *,
    dw_id: str | None = None,
    title: str = "",
    reason: str = "",
    source_spec: str = "",
    location: str = "n/a",
    severity: str | None = None,
    note: str = "",
) -> dict[str, object]:
    """Read or write the deferred-work ledger.

    Deferring is how the orchestrator converges without pretending: the residue
    of a decision gets an id and stays findable, instead of being dropped or
    holding the run open.
    """
    ledger = host.paths.deferred_work
    if mode == "list":
        # The observation arm of the ledger-read contract (DW-146): absence reads as
        # no entries, but an unreadable ledger is NOT an empty one, so the fault rides
        # back attributed instead of the orchestrator deciding on a silent `[]`.
        text, fault = read_for_observation(ledger)
        entries = parse_ledger(text) if text else []
        listed: dict[str, object] = {
            "mode": mode,
            "entries": [{"id": e.id, "title": e.title, "status": e.status} for e in entries],
        }
        if fault is not None:
            listed["fault"] = fault
        return listed
    if mode == "add":
        if not title.strip() or not reason.strip():
            raise VerbError("invalid-args", "ledger add needs a title and a reason")
        planned = _bookkeeping_commit_rel(host, ledger)  # before the touch that creates it
        ledger.parent.mkdir(parents=True, exist_ok=True)
        ledger.touch(exist_ok=True)
        new_id = append_entry(
            ledger,
            title=title,
            origin="llm-orchestrator",
            source_spec=source_spec or "n/a",
            reason=reason,
            location=location,
            severity=severity,
        )
        if new_id is None:
            raise VerbError("state-conflict", "the ledger entry could not be appended")
        host.journal.append("llm-ledger-add", dw_id=new_id, title=title)
        committed = _commit_bookkeeping(
            host,
            ledger,
            planned,
            f"chore(deferred-work): add {new_id} ({namespace.PRODUCT} run {host.state.run_id})",
        )
        return {"mode": mode, "dw_id": new_id, **committed}
    if mode == "close":
        if not dw_id:
            raise VerbError("invalid-args", "ledger close needs an id")
        if not ledger.is_file():
            raise VerbError("not-found", f"no ledger at {ledger}")
        planned = _bookkeeping_commit_rel(host, ledger)
        if not mark_done(ledger, dw_id, _today(), note or "closed by the orchestrator"):
            raise VerbError("state-conflict", f"{dw_id} is missing or already done")
        host.journal.append("llm-ledger-close", dw_id=dw_id, note=note)
        committed = _commit_bookkeeping(
            host,
            ledger,
            planned,
            f"chore(deferred-work): close {dw_id} ({namespace.PRODUCT} run {host.state.run_id})",
        )
        return {"mode": mode, "dw_id": dw_id, **committed}
    raise VerbError("invalid-args", f"unknown ledger mode {mode!r}")


# ----------------------------------------------------------------------- git


def _artifact_relpaths(host: LLMHost) -> tuple[str, ...]:
    """Repo-relative posix prefixes of the BMAD artifact folders — the board,
    the specs, the generated output. These are orchestrator-owned, not part of
    any one attempt's dirt, so a rollback carries them through the reset;
    mirror of the engine's `protected_relpaths`. Folders configured outside
    the repo are skipped — nothing to protect there."""
    out: list[str] = []
    for protected in (
        host.paths.output_folder,
        host.paths.implementation_artifacts,
        host.paths.planning_artifacts,
    ):
        try:
            rel = protected.relative_to(host.paths.repo_root).as_posix()
        except ValueError:
            continue  # configured outside the repo; nothing to protect here
        # "." (folder == repo root) as a keep/preserve prefix would cover the
        # whole tree and disable the rollback — drop it.
        if rel and rel != ".":
            out.append(rel)
    return tuple(out)


def verb_rollback(host: LLMHost, story_key: str, preserve: bool = False) -> dict[str, object]:
    """Undo a failed attempt, optionally parking its commits first.

    Git stays behind this verb rather than in the caller's shell, and not for
    tidiness: these resets run around disposable coding-CLI sessions that stage
    and commit on their own initiative, so the rollback has to be the one that
    knows what this attempt created. `safe_rollback` reverts to the recorded
    baseline and removes only that — never a blanket clean, which would eat
    untracked files the operator already had.

    Two guards mirror the deterministic engine. A rollback aimed at the shared
    checkout (no unit worktree) is refused unless `scm.rollback_on_failure`
    opts in — the engine never touches the main working tree without that flag,
    it pauses for manual recovery, and this verb must not be a door past the
    same policy. Judged by path, not by `scm.isolation`: a worktree rollback
    resets only its disposable copy and needs no opt-in. And every reset
    carries the BMAD artifact folders through it: the board and the specs
    record the whole run's progress, and one story's rollback erasing another
    story's `done` is exactly what happened the time this wasn't here.
    """
    task = _task_or_404(host, story_key)
    if not task.baseline_commit:
        raise VerbError("state-conflict", f"{story_key} has no recorded baseline to roll back to")
    repo = Path(task.worktree_path) if task.worktree_path else host.paths.repo_root
    if repo.resolve() == host.paths.repo_root.resolve() and not host.policy.scm.rollback_on_failure:
        raise VerbError(
            "state-conflict",
            f"rollback of {story_key} targets the shared checkout and "
            "scm.rollback_on_failure is off: in-place recovery is disabled by "
            "policy, so leave the tree for the operator (this is the engine's "
            "manual-recovery pause). To allow it, set [scm] "
            'rollback_on_failure = true, or run units under [scm] isolation = "worktree".',
        )
    protected = _artifact_relpaths(host)
    parked: str | None = None
    try:
        if preserve:
            # The engine's own name, `attempt-preserve/<run>-<tip8>`: one ref per
            # parked tip, so a second rollback of the same story parks beside the
            # first instead of over it. The old per-story name took `branch -f`, and
            # the second `--preserve` rollback moved it off the first attempt's
            # work — recoverable from the reflog at best, no longer by name. The
            # tip is pinned once, so the name and the parked commit cannot disagree;
            # the run id is ref-sanitized there, as for the engine.
            tip = rev_parse_head(repo)
            parked = preserve_commits(
                repo,
                task.baseline_commit,
                attempt_preserve_ref_name(host.state.run_id, tip),
                revision=tip,
            )
        safe_rollback(
            repo,
            task.baseline_commit,
            baseline_untracked=task.baseline_untracked,
            keep=(str(namespace.STATE_DIR), *protected),
            preserve=protected,
        )
    except GitError as exc:
        raise VerbError("git", str(exc)) from exc
    host.journal.append(
        "llm-rollback", story_key=story_key, baseline=task.baseline_commit, preserve_ref=parked
    )
    return {"story_key": story_key, "baseline": task.baseline_commit, "preserve_ref": parked}


# ------------------------------------------------------- observing a session


def _task_dir(host: LLMHost, task_id: str) -> Path:
    return host.run_dir / "tasks" / task_id


def _log_path(host: LLMHost, task_id: str) -> Path:
    return host.run_dir / LOGS_DIR / f"{task_id}.log"


def verb_tail(
    host: LLMHost, task_id: str, from_offset: int = 0, lines: int | None = None
) -> dict[str, object]:
    """Read a session's pane log from `from_offset`, and report where to resume.

    Offsets rather than "the last N lines": a session can emit megabytes, and a
    caller that re-read from the top on every wake would spend its context on
    output it had already judged. Threading the returned offset into the next
    call is what makes a long session readable in slices.

    The decode is lenient because the log is raw terminal output and an offset
    can land mid-sequence — a fact about where the reader stopped, not a reason
    to refuse the read.
    """
    path = _log_path(host, task_id)
    if not path.is_file():
        raise VerbError("not-found", f"no pane log for task {task_id!r} at {path}")
    if from_offset < 0:
        raise VerbError("invalid-args", f"--from must be >= 0, got {from_offset}")
    try:
        with path.open("rb") as handle:
            handle.seek(from_offset)
            chunk = handle.read()
    except OSError as exc:
        raise VerbError("env", f"unreadable pane log: {exc}") from exc
    text = chunk.decode("utf-8", errors="replace")
    truncated = False
    if lines is not None and lines > 0:
        split = text.splitlines()
        if len(split) > lines:
            text = "\n".join(split[-lines:])
            truncated = True
    return {
        "task_id": task_id,
        "from_offset": from_offset,
        "next_offset": from_offset + len(chunk),
        "truncated_to_last_lines": truncated,
        "text": text,
    }


def verb_session_result(host: LLMHost, task_id: str) -> dict[str, object]:
    """What the watcher recorded when the session settled, or that it has not.

    `settled: false` is an answer, not an error: a caller polling a running
    session must be able to tell "still going" from "something is wrong", and an
    exception collapses those.
    """
    task_dir = _task_dir(host, task_id)
    if not task_dir.is_dir():
        raise VerbError("not-found", f"no task {task_id!r} in this run")
    result = read_session_result(task_dir)
    if result is not None:
        _absorb_settled_session(host, task_id)
    log = _log_path(host, task_id)
    return {
        "task_id": task_id,
        "settled": result is not None,
        "result": result,
        "log_path": str(log) if log.is_file() else None,
        "log_size": log.stat().st_size if log.is_file() else 0,
        "heartbeat": _heartbeat(task_dir),
    }


def _heartbeat(task_dir: Path) -> dict[str, object] | None:
    """The wait loop's last proof of life, if it has written one."""
    try:
        payload = json.loads((task_dir / "heartbeat.json").read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return payload if isinstance(payload, dict) else None


# ------------------------------------------------------------ driving a session


def _resume_blocked(host: LLMHost, adapter: object, resume_session: str) -> str:
    """Why this dispatch cannot reattach, or "" when it can.

    Report, never assume: every miss here is an answer the caller routes on —
    not an error, and never a quiet fresh launch wearing resume's name."""
    if not host.policy.llm.session_resume:
        return "[llm] session_resume is off; the policy has to opt in before a dispatch reattaches"
    task_dir = _task_dir(host, resume_session)
    result = read_session_result(task_dir) if task_dir.is_dir() else None
    if result is None:
        return f"no settled session result for {resume_session!r} — nothing to reattach to"
    if not result.get("session_id"):
        return f"the {resume_session!r} session recorded no native session id"
    profile = getattr(adapter, "profile", None)
    if not tuple(getattr(profile, "resume_args", ()) or ()):
        name = getattr(adapter, "name", "this adapter")
        return f"{name} declares no resume path (profile resume_args is empty)"
    return ""


#: Roles a session may be dispatched on: the engine's three, plus every role a
#: plugin workflow may run as. Closed on purpose — `[adapter.<role>]` exists for
#: exactly these, and a name outside the set is a typo, or the CLI's name mistaken
#: for a role. Measured 2026-09-05: `unit dispatch codex 8-1 …` was accepted, the
#: unknown role resolved to the base `[adapter]` table, and the "dev" ran on
#: claude — the binary the operator had pointed dev AWAY from — with nothing in
#: the journal but a role nobody had configured.
DISPATCH_ROLES: tuple[str, ...] = tuple(ROLES) + tuple(sorted(WORKFLOW_ROLES - set(ROLES)))


def _open_task(host: LLMHost, story_key: str) -> StoryTask:
    """The story's task, refused when the run never opened it.

    A session on an unopened story has no baseline to roll back to, no phase for
    the dashboard to paint, and nothing on the board — the run looks empty while
    a session works. Measured 2026-09-05: an orchestrator skipped `unit open`,
    dispatched, and the tasks table stayed blank for the whole session."""
    task = host.state.tasks.get(story_key)
    if task is None:
        raise VerbError(
            "not-found",
            f"{story_key} is not open in this run — `unit open {story_key} --epic <n>` first. "
            "A session on a story the run never opened has no baseline to roll back to and "
            "nothing on the board for the dashboard to show it under",
        )
    return task


#: The roles whose session IS a run of the dev primitive: the dev pass, and the review
#: pass — a review is the primitive re-invoked on the story's spec, as the engine's
#: `_review_prompt` dispatches it. Triage and the plugin workflow roles bring their own
#: skills in their own prompts.
PRIMITIVE_ROLES: tuple[str, ...] = ("dev", "review")


def _primitive_invocation(prompt: str, story_key: str, primitive: str) -> str:
    """The dev primitive's invocation, with the orchestrator's text as its intent.

    The engine dispatches dev and review as `/<primitive> <story> …`: the primitive
    runs the method — the spec, the review layers, the frontmatter sign-off and the
    `## Auto Run Result` the verify gate reads. A free-form prompt skips all of it.
    MEASURED 2026-10-03 on an LLM-held run: an orchestrator that wrote its own "add
    the function, run the tests" got the code with no spec and no result; the session
    ended its turn with nothing to settle on, sat idle into upstream 0.13's parked
    rule (an idle claude is not nudged) for the whole stall grace, and `unit verify
    dev` refused the tree — one wasted session and ten minutes, caught only by the
    gate, with nothing in the protocol to stop the next one.

    So the verb owns the slash command, as the engine's prompt builders do. A prompt
    that does not already invoke the primitive becomes its intent —
    `/<primitive> <story> — <prompt>`, the channel the primitive reads freeform
    direction from (`engine._generic_dev_prompt` inlines repair feedback the same
    way). A prompt whose first word IS the invocation — a repair resuming the spec at
    a named path, say — goes through unchanged."""
    text = prompt.strip()
    if text.split(maxsplit=1)[0] == f"/{primitive}":
        return prompt
    return f"/{primitive} {story_key} — {text}"


def verb_dispatch(
    host: LLMHost,
    role: str,
    story_key: str,
    prompt: str,
    seq: int = 1,
    label: str | None = None,
    resume_session: str | None = None,
) -> dict[str, object]:
    """Launch a session and return as soon as it is up.

    The wait is handed to a detached watcher rather than held here. The adapter's
    wait loop carries the stall-nudge budget, the mid-session token guard and the
    env-fault classification in process memory; a dispatch that blocked would
    make the caller blind for the session's whole length, and one that returned
    without a watcher would drop that machinery on the floor.

    Two refusals, both `invalid-args`/`not-found` rather than routing: the role
    must be one of :data:`DISPATCH_ROLES` (the CLI is chosen in `[adapter.<role>]`,
    never named here), and the story must have been opened — see :func:`_open_task`.
    A plugin workflow is not dispatched through here but through
    :func:`verb_workflows`, which renders the manifest's prompt and journals the
    step the way the engine does.

    `resume_session` names an earlier task whose CLI *conversation* this
    dispatch should reattach to — cheap repair. The window is long dead (the
    adapter kills it on every path, deliberately); the conversation is not,
    and `<cli> --resume <native-id>` is the way back into it. Preconditions
    are reported, never assumed: the policy flag off, no settled session
    result, no native session id recorded, or an adapter with no declared
    resume path all come back as `{"resumable": false, "reason": …}` — with
    nothing launched — and a fresh dispatch stays one call away. A resume that
    quietly became a from-scratch session would be worse than not offering
    one. What cannot be prechecked is the CLI refusing the id at launch; that
    presents in the session itself, which is one more reason to read the pane
    log before trusting a repair.
    """
    if role not in DISPATCH_ROLES:
        raise VerbError(
            "invalid-args",
            f"unknown role {role!r}: one of {', '.join(DISPATCH_ROLES)}. A role names the "
            "[adapter.<role>] table a session runs on; the CLI (claude, codex, …) is chosen "
            "there, never here",
        )
    if not prompt.strip():
        raise VerbError("invalid-args", "a session needs a non-empty prompt")
    task = _open_task(host, story_key)
    # A sessao roda NA arvore da story. Sem isto, com scm.isolation="worktree" a
    # sessao edita o checkout compartilhado enquanto a worktree fica vazia, e o
    # commit da story sai vazio (medido: story inteira implementada fora dela).
    cwd = Path(task.worktree_path) if task.worktree_path else host.paths.repo_root
    return _launch_session(
        host,
        role=role,
        story_key=story_key,
        prompt=prompt,
        seq=seq,
        label=label,
        resume_session=resume_session,
        cwd=cwd,
    )


def _codex_worktree_trust(host: LLMHost, adapter: object, cwd: Path) -> bool:
    """The engine's DW-341 gate, for a session the LLM loop launches in a unit
    worktree: ``True`` = launch with the profile's ``hook_trust_bypass_args`` (the
    worktree inherits the main checkout's Codex hook trust), ``False`` = no bypass
    needed. Not a Codex adapter, or the main checkout → ``False``, nothing asked.

    Refused as ``env`` when Codex neither trusts the worktree nor lets it inherit:
    its hooks would be skipped and the session's Stop would never arrive. This loop
    used to launch it anyway, and only Codex's own launch flags decided whether
    that worked."""
    profile = getattr(adapter, "profile", None)
    hooks = getattr(profile, "hooks", None)
    if profile is None or getattr(hooks, "dialect", None) != "codex-hooks-json":
        return False
    if cwd.resolve() == host.paths.repo_root.resolve():
        return False
    extra_args = getattr(adapter, "extra_args", None)
    queried = (
        profile if extra_args is None else dataclasses.replace(profile, bypass_args=extra_args)
    )
    trust, inherited, not_inherited = worktree_launch_trust(
        host.paths.repo_root, cwd, queried, binary=getattr(adapter, "binary", None)
    )
    if trust.status != "trusted":
        raise VerbError(
            "env",
            f"Codex hook trust is {trust.status} for the worktree {cwd} ({trust.reason}); "
            f"it does not inherit the main checkout's grant: {not_inherited}. "
            "Its hooks would be skipped and the session's Stop would never arrive. "
            "Open Codex once in the main checkout and trust its hooks, so that every "
            "worktree with the same hook config inherits that grant, or open Codex in "
            "this worktree and accept its prompt.",
        )
    return inherited


def _launch_session(
    host: LLMHost,
    *,
    role: str,
    story_key: str,
    prompt: str,
    seq: int,
    label: str | None,
    resume_session: str | None,
    cwd: Path,
    workflow: dict[str, object] | None = None,
) -> dict[str, object]:
    """The launch itself, shared by `dispatch` and `workflows dispatch`: build the
    spec, start the session, hand the wait to the watcher, journal the start.
    Validation belongs to the callers — this trusts its arguments."""
    # The engine's one composition point: whole-composition sanitizing, and the
    # `-g<N>` suffix a re-armed story carries so its next attempt cannot mint the
    # same id as the abandoned one and have that attempt's verdict read back (#705).
    owner = host.state.tasks.get(story_key)
    task_id = _session_task_id(
        story_key, label or role, seq, owner.generation if owner is not None else 0
    )
    adapters = build_adapters(host, role)
    adapter = adapter_for_role(adapters, host.policy, role)
    cfg = host.policy.adapter.resolved(role)

    if label is None and role in PRIMITIVE_ROLES and resume_session is None:
        # The primitive named by the session's OWN skill tree, resolved where the
        # session runs — the same resolution the engine's dev seam and the
        # workflow-marker clause below make. A resume is exempt: it continues the
        # conversation the primitive already holds, and its prompt is that
        # conversation's next turn.
        prompt = _primitive_invocation(
            prompt,
            story_key,
            dev_primitive_or_default(
                host.paths.rebased(cwd).project,
                getattr(getattr(adapter, "profile", None), "skill_tree", None),
            ),
        )

    if label is not None:
        # An injected plugin-workflow session, and `label` is what says so here —
        # the same discriminator `build_spec(workflow=...)` below already spends on
        # the stall cap. The two belong together: the cap declares what a missing
        # completion marker COSTS, this clause is what tells the session there is a
        # marker to write at all. A dev or review session gets neither; its skill
        # carries its own result convention.
        #
        # Appended LAST, after the caller's rendered prompt, for the reason the
        # engine appends it last: the marker protocol is the load-bearing tail, and
        # a session that ends its turn without it livelocks the loop until
        # session_timeout_min. Measured before this existed, on an LLM-held run at
        # an epic boundary: the TEA step finished its analysis, wrote its reports
        # under test-artifacts, and sat at the prompt — every Stop read as
        # `no-artifact` under implementation-artifacts, one stall nudge each, ~28
        # minutes of dead wall clock for a step whose work was already on disk.
        #
        # Resolved against the session's OWN cwd (a unit worktree for a story
        # stage, the main checkout at a boundary), because that is the tree
        # `GenericDevAdapter._artifact_dirs` searches for the marker and the tree
        # whose skills decide how the dev primitive is spelled today.
        marker_paths = host.paths.rebased(cwd)
        prompt += devcontract.WORKFLOW_COMPLETION_CONTRACT.format(
            marker_path=devcontract.workflow_marker_path(
                marker_paths.implementation_artifacts,
                dev_primitive_or_default(
                    marker_paths.project,
                    getattr(getattr(adapter, "profile", None), "skill_tree", None),
                ),
                task_id,
            )
        )

    resume_id: str | None = None
    if resume_session is not None:
        blocked = _resume_blocked(host, adapter, resume_session)
        if blocked:
            return {"resumable": False, "reason": blocked}
        result = read_session_result(_task_dir(host, resume_session)) or {}
        resume_id = str(result["session_id"])

    hook_trust_bypass = _codex_worktree_trust(host, adapter, cwd)

    env = {
        namespace.env("MODE"): "1",
        namespace.env("RUN_DIR"): str(host.run_dir),
        namespace.env("TASK_ID"): task_id,
        namespace.env("STORY_KEY"): story_key,
    }
    spec = build_spec(
        task_id=task_id,
        role=role,
        prompt=prompt,
        cwd=cwd,
        env=env,
        policy=host.policy,
        model=cfg.model,
        effort=cfg.effort,
        workflow=label is not None,
        resume_session_id=resume_id,
        hook_trust_bypass=hook_trust_bypass,
    )

    try:
        handle = adapter.start_session(spec)
    except Exception as exc:  # noqa: BLE001 - every launch failure is the caller's to route
        raise VerbError(
            "env", f"could not launch the session: {type(exc).__name__}: {exc}"
        ) from exc

    write_handover(host.run_dir, task_id, handle, spec, workflow=workflow, adapter=cfg.name)
    watcher_pid = spawn_watcher(host, task_id)
    if label is None:
        _count_session(host, story_key, role)

    host.journal.set_active_log(task_id)
    resumed = {"resumed_from": resume_session} if resume_id is not None else {}
    host.journal.append(
        "session-start",
        task_id=task_id,
        role=role,
        story_key=story_key,
        # The resolved identity, `[adapter.<role>] name` — what the engine journals and
        # stamps on its records — not the adapter object's transport-qualified name.
        adapter=cfg.name,
        model=cfg.model,
        **resumed,
    )
    payload: dict[str, object] = {
        "task_id": task_id,
        "role": role,
        "story_key": story_key,
        "adapter": cfg.name,
        "model": cfg.model,
        "window_id": handle.native_id,
        "log_path": str(host.run_dir / LOGS_DIR / f"{task_id}.log"),
        "watcher_pid": watcher_pid,
    }
    if resume_id is not None:
        payload["resumable"] = True
        payload["resumed_from"] = resume_session
        payload["session_id"] = resume_id
    return payload


# ------------------------------------------------------------ plugin workflows


def _workflow_progress(host: LLMHost, scope_key: str, boundary: bool) -> dict[str, str]:
    """`{workflow name: pending|running|done|failed}` for one scope. A boundary
    reads the engine's own persisted channel (`boundary_progress`, what the
    dashboard paints); a story reads the `workflow-start`/`workflow-end` pair the
    engine and `workflows dispatch` both write, latest entry winning."""
    if boundary:
        return dict(host.state.boundary_progress.get(scope_key, {}))
    progress: dict[str, str] = {}
    for entry in host.journal.entries():
        if entry.get("story_key") != scope_key:
            continue
        name = str(entry.get("workflow", ""))
        if entry.get("kind") == "workflow-start":
            progress[name] = "running"
        elif entry.get("kind") == "workflow-end":
            progress[name] = "done" if entry.get("status") == "completed" else "failed"
    return progress


def verb_workflows(
    host: LLMHost,
    mode: str,
    stage: str,
    *,
    story_key: str | None = None,
    epic: int | None = None,
    name: str | None = None,
    seq: int = 1,
) -> dict[str, object]:
    """List the plugin workflows due at a stage, or dispatch one of them.

    The deterministic engine runs these itself — `pre_dev_phase` (the TEA ATDD
    scaffold) before a story's first dev session, `post_epic_boundary` (the Test
    Architect's four analyses) once an epic's last story is committed — and until
    this verb an LLM-held run had no way to: the plugin was enabled, the sprint
    tree listed its boundary steps, and nothing ever dispatched them.

    `list` answers what is due at `stage` for the scope and what already ran,
    from the same registry the dashboard enumerates its step names from, so the
    two agree; plugins that are enabled but inert here, and enabled names no
    plugin answers to, are named in `inert` with the reason, so an empty list is
    explained rather than silent. `dispatch` launches ONE
    step as a session exactly as the engine would — the manifest's prompt
    rendered for the scope, the workflow's own role and adapter, the
    `<plugin>.<name>` label, the `workflow-start` entry, a boundary step stamped
    `running` — and returns like `dispatch`; the watcher writes `workflow-end`
    and, at a boundary, stamps the step `done`/`failed` for the dashboard.

    **Does not**: decide whether a step's outcome matters (`blocking` is
    reported, not enforced — a boundary cannot block and a `pre_dev_phase`
    scaffold never does), fire the plugin's in-process hooks (artifact
    attribution, the commit-time gates and the boundary's own commit stay the
    engine's for now), or pause the run.
    """
    if mode not in ("list", "dispatch"):
        raise VerbError("invalid-args", f"unknown workflows mode {mode!r}: list or dispatch")
    if stage not in WORKFLOW_STAGES:
        raise VerbError(
            "invalid-args",
            f"unknown workflow stage {stage!r}: one of " + ", ".join(sorted(WORKFLOW_STAGES)),
        )
    boundary = stage == "post_epic_boundary"
    if boundary:
        if epic is None or epic < 1:
            raise VerbError("invalid-args", f"{stage} is an epic's stage: it needs --epic <n>")
        scope_key = f"epic-{epic}"
        cwd = host.paths.repo_root
    else:
        if not story_key:
            raise VerbError("invalid-args", f"{stage} is a story's stage: it needs --story <key>")
        task = _open_task(host, story_key)
        scope_key = story_key
        cwd = Path(task.worktree_path) if task.worktree_path else host.paths.repo_root

    from ..plugins.registry import PluginRegistry

    registry = PluginRegistry.build(host.project, host.policy)
    due = registry.workflows_for(stage)
    progress = _workflow_progress(host, scope_key, boundary)
    rows: list[dict[str, object]] = [
        {
            "plugin": lp.name,
            "name": wf.name,
            "label": f"{lp.name}.{wf.name}",
            "role": wf.role,
            "blocking": wf.blocking,
            "status": progress.get(wf.name, "pending"),
        }
        for lp, wf in due
    ]
    # Enabled but contributing nothing, each with its reason: a plugin that declared
    # itself inert here, and an enabled name no plugin answers to (a rename the
    # policy never followed) — the second is what made an empty list unexplained
    # and a story start without its scaffold.
    inert_rows = registry.inert_plugins()
    unknown_rows = registry.unknown_plugins()
    inert = [{"plugin": plugin, "reason": reason} for plugin, reason in inert_rows + unknown_rows]
    if mode == "list":
        return {"mode": mode, "stage": stage, "scope": scope_key, "workflows": rows, "inert": inert}

    if not name:
        raise VerbError("invalid-args", "workflows dispatch needs --name <workflow>")
    matches = [(lp, wf) for lp, wf in due if name in (wf.name, f"{lp.name}.{wf.name}")]
    if not matches:
        known = ", ".join(str(r["label"]) for r in rows) or "none"
        why = "; ".join(
            [f"{plugin} is inert: {reason}" for plugin, reason in inert_rows]
            + [f"{plugin} {reason}" for plugin, reason in unknown_rows]
        )
        raise VerbError(
            "not-found",
            f"no workflow {name!r} is due at {stage}: {known}" + (f" — {why}" if why else ""),
        )
    if len(matches) > 1:
        raise VerbError(
            "invalid-args",
            f"{name!r} names more than one workflow at {stage}: say which as plugin.name — "
            + ", ".join(f"{lp.name}.{wf.name}" for lp, wf in matches),
        )
    lp, wf = matches[0]
    # The engine's own rendering, token for token, so a step dispatched here reads
    # the same prompt it reads there: the manifest's placeholders, then the scope.
    # The completion contract is NOT part of this rendering in either loop — the
    # engine appends it post-gate and `_launch_session` appends it here, both off
    # the label, so the plugin's text cannot strip it.
    prompt = lp.manifest.render(wf.prompt).replace("{run_id}", host.state.run_id)
    prompt = (
        prompt.replace("{epic}", str(epic))
        if boundary
        else prompt.replace("{story_key}", scope_key)
    )
    host.journal.append(
        "workflow-start",
        plugin=lp.name,
        workflow=wf.name,
        stage=stage,
        role=wf.role,
        story_key=scope_key,
    )
    if boundary:
        with host.mutate() as state:
            state.boundary_progress.setdefault(scope_key, {})[wf.name] = "running"
    meta: dict[str, object] = {
        "plugin": lp.name,
        "workflow": wf.name,
        "stage": stage,
        "story_key": scope_key,
    }
    if boundary:
        meta["epic"] = epic
    payload = _launch_session(
        host,
        role=wf.role,
        story_key=scope_key,
        prompt=prompt,
        seq=seq,
        label=f"{lp.name}.{wf.name}",
        resume_session=None,
        cwd=cwd,
        workflow=meta,
    )
    payload.update(
        {
            "mode": mode,
            "stage": stage,
            "plugin": lp.name,
            "workflow": wf.name,
            "blocking": wf.blocking,
        }
    )
    return payload


def verb_nudge(host: LLMHost, task_id: str, text: str) -> dict[str, object]:
    """Type into a live session.

    The channel the adapter already uses for its own stall and budget nudges, so
    this is not a new mechanism — it is the caller getting at one that existed.
    Steering a session mid-flight is cheaper than killing it and paying for a
    fresh one to rediscover what it already knows.
    """
    if not text.strip():
        raise VerbError("invalid-args", "a nudge needs non-empty text")
    handle, spec = _live_handle(host, task_id)
    adapter = adapter_for_role(build_adapters(host, spec.role), host.policy, spec.role)
    try:
        adapter.send_text(handle, text)
    except Exception as exc:  # noqa: BLE001
        raise VerbError("env", f"could not reach the session: {type(exc).__name__}: {exc}") from exc
    host.journal.append("llm-nudge", task_id=task_id, text=text)
    return {"task_id": task_id, "sent": text}


def verb_kill(host: LLMHost, task_id: str) -> dict[str, object]:
    """Tear a session down.

    Kills the window and reaps what it spawned. The watcher notices and settles
    the outcome; nothing here writes the result, so a killed session and one that
    died on its own settle through the same path.
    """
    handle, spec = _live_handle(host, task_id)
    adapter = adapter_for_role(build_adapters(host, spec.role), host.policy, spec.role)
    try:
        adapter.kill(handle)
    except Exception as exc:  # noqa: BLE001
        raise VerbError("env", f"could not kill the session: {type(exc).__name__}: {exc}") from exc
    host.journal.append("llm-kill", task_id=task_id, role=spec.role)
    return {"task_id": task_id, "killed": True}


def _live_handle(host: LLMHost, task_id: str):
    """The handle and spec of a dispatched session, or a typed refusal.

    A settled session is refused rather than reached into: its window is gone, so
    send_text and kill would either fail obscurely or hit whatever reused the id.
    """
    task_dir = host.run_dir / "tasks" / task_id
    if not (task_dir / HANDOVER_FILE).is_file():
        raise VerbError("not-found", f"no dispatched session for task {task_id!r}")
    if read_session_result(task_dir) is not None:
        raise VerbError("state-conflict", f"session {task_id!r} has already settled")
    try:
        return read_handover(host.run_dir, task_id)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise VerbError("state-conflict", f"unreadable session handover: {exc}") from exc


def verb_await(
    host: LLMHost,
    task_id: str,
    *,
    until: list[str] | None = None,
    match: str | None = None,
    quiet_s: float | None = None,
    timeout_s: float | None = None,
    from_offset: int = 0,
) -> dict[str, object]:
    """Block until a condition the caller named fires, and report which.

    Bounds default from policy rather than from a constant here: how long a
    project's sessions legitimately go quiet is a property of that project, and
    a default baked into the tool would be wrong for someone.
    """
    task_dir = host.run_dir / "tasks" / task_id
    if not task_dir.is_dir():
        raise VerbError("not-found", f"no task {task_id!r} in this run")
    asked = set(until or ["end"])
    unknown = sorted(asked - CONDITIONS)
    if unknown:
        raise VerbError(
            "invalid-args", f"unknown wait condition(s) {unknown}; expected {sorted(CONDITIONS)}"
        )
    if "match" in asked and not match:
        raise VerbError("invalid-args", "the match condition needs a pattern")
    if match:
        # Compiled here rather than at first use inside the wait: an unusable
        # pattern is a malformed call, and the caller should learn that now
        # instead of after blocking for the whole timeout.
        try:
            re.compile(match)
        except re.error as exc:
            raise VerbError("invalid-args", f"unusable match pattern: {exc}") from exc
    try:
        conditions = Conditions(
            timeout_s=float(
                timeout_s if timeout_s is not None else host.policy.llm.await_default_timeout_s
            ),
            end="end" in asked,
            match=match if "match" in asked else None,
            quiet_s=(
                float(quiet_s if quiet_s is not None else host.policy.llm.await_default_quiet_s)
                if "quiet" in asked
                else None
            ),
            stale_heartbeat="stale-heartbeat" in asked,
            vanished="vanished" in asked,
        )
    except re.error as exc:
        raise VerbError("invalid-args", f"unusable match pattern: {exc}") from exc

    window_alive = None
    if conditions.vanished:
        window_alive = _window_probe(host, task_id)

    wake = await_session(
        result_path=result_path(task_dir),
        log_path=host.run_dir / LOGS_DIR / f"{task_id}.log",
        heartbeat_path=task_dir / "heartbeat.json",
        conditions=conditions,
        from_offset=from_offset,
        window_alive=window_alive,
    )
    # Unconditional: the helper is a no-op unless a settled result is on disk,
    # and a wait that woke on  or  may still find the session
    # finished by the time it returns.
    _absorb_settled_session(host, task_id)
    return {"task_id": task_id, **wake.to_dict()}


def verb_await_any(
    host: LLMHost, task_ids: list[str], *, timeout_s: float | None = None, poll_s: float = 1.0
) -> dict[str, object]:
    """Block until the FIRST of several sessions ends, and say which.

    The fan-out's wait: a turn that opened one story per front has several
    sessions running and wants to act on whichever settles first, not on a fixed
    one. Only the `end` condition applies across sessions — the pane-reading
    conditions (`match`, `quiet`) are one session's questions and stay with
    `await <task_id>`. `timeout` is the outer bound, from `[llm]` when unnamed;
    on timeout every session named is still pending and the answer says so.
    """
    if not task_ids:
        raise VerbError("invalid-args", "await needs at least one task id")
    dirs = {tid: host.run_dir / "tasks" / tid for tid in task_ids}
    missing = [tid for tid, d in dirs.items() if not d.is_dir()]
    if missing:
        raise VerbError("not-found", f"no task {missing[0]!r} in this run")
    bound = float(timeout_s if timeout_s is not None else host.policy.llm.await_default_timeout_s)
    deadline = time.monotonic() + bound
    while True:
        for tid, d in dirs.items():
            if result_path(d).is_file():
                _absorb_settled_session(host, tid)
                return {
                    "task_id": tid,
                    "wake": "end",
                    "pending": [t for t in task_ids if t != tid],
                }
        if time.monotonic() >= deadline:
            return {"task_id": None, "wake": "timeout", "pending": list(task_ids)}
        time.sleep(min(poll_s, max(0.0, deadline - time.monotonic())))


def _window_probe(host: LLMHost, task_id: str):
    """A predicate for the `vanished` condition, or None when liveness cannot be
    asked. None keeps the condition inert: an unreachable multiplexer is not
    evidence a session died, and treating it as such would abandon live work."""
    try:
        handle, _spec = read_handover(host.run_dir, task_id)
    except (OSError, KeyError, TypeError, ValueError):
        return None
    try:
        mux = get_multiplexer()
        session = session_name(host.state.run_id)
    except Exception:  # noqa: BLE001
        return None

    def alive() -> bool:
        try:
            return handle.native_id in mux.list_window_ids(session)
        except Exception:  # noqa: BLE001
            # Unknown, not dead. Reporting False here would wake the caller with
            # "vanished" every time the transport hiccuped.
            return True

    return alive


# ------------------------------------------------------- the story's lifecycle


def verb_open(host: LLMHost, story_key: str, epic: int) -> dict[str, object]:
    """Take a story into this run: record it, pin its baseline, mount its tree.

    The baseline is captured here, before any session runs, because everything a
    rollback later needs is defined relative to it: which commits an attempt
    made, and which untracked files it created rather than found. Capturing it
    afterwards would make the tool unable to tell the two apart, and a rollback
    that cannot tell them apart either deletes the operator's own files or leaves
    the attempt's behind.
    """
    isolated = host.policy.scm.isolation == "worktree"
    with host.mutate() as state:
        existing = state.tasks.get(story_key)
        if existing is not None and not (
            isolated and not existing.worktree_path and existing.phase == Phase.PENDING
        ):
            raise VerbError(
                "state-conflict",
                f"{story_key} is already in this run at {existing.phase}",
            )
        # Uma task pendente SEM worktree é o resto de um `open` que criou a task
        # e morreu ao montar a árvore: nada rodou ainda, então re-abrir aqui é
        # retomar a mesma abertura, não abrir a story duas vezes.
        repo = host.paths.repo_root
        try:
            baseline = rev_parse_head(repo)
            untracked = sorted(untracked_files(repo))
        except GitError as exc:
            raise VerbError("git", f"could not pin a baseline: {exc}") from exc
        task = StoryTask(
            story_key=story_key,
            epic=epic,
            baseline_commit=baseline,
            baseline_untracked=untracked,
        )
        state.tasks[story_key] = task
        if isolated and not state.target_branch:
            # O engine determinístico fixa o branch-alvo no começo do laço
            # (Engine._ensure_target_branch); o caminho `llm-run` não tem esse
            # laço, então o primeiro `open` de um run LLM o encontrava vazio e
            # falhava. Fixa aqui, uma vez, com a mesma semântica.
            state.target_branch = _resolve_target_branch(host)
            host.journal.append("target-branch", branch=state.target_branch)
        target = state.target_branch

    unit = None
    if isolated:
        unit = _mount_worktree(host, story_key, target)
        with host.mutate() as state:
            task = state.tasks[story_key]
            task.worktree_path = str(unit.path)
            task.branch = unit.branch
            task.baseline_commit = unit.baseline
        host.journal.append(
            "worktree-opened", story_key=story_key, branch=unit.branch, path=str(unit.path)
        )
        # The provisioning contract, before any session. The story stays open with
        # its worktree mounted: the orchestrator reads the failure, repairs the
        # stack or closes the story (`escalate` / `defer`), which tears it down.
        try:
            _worktree_flow(host).provision_unit(host.state.tasks[story_key], unit)
        except ProvisionFailed as exc:
            raise VerbError(
                "env",
                f"{exc}. The story is open and its worktree stays mounted; repair the stack "
                f"and open a session, or `close {story_key} escalate` (or `defer`) to give it "
                "back",
            ) from exc

    host.journal.append(
        "story-start", story_key=story_key, epic=epic, baseline=baseline, isolated=isolated
    )
    return {
        "story_key": story_key,
        "epic": epic,
        "baseline": unit.baseline if unit else baseline,
        "isolated": isolated,
        "worktree_path": str(unit.path) if unit else None,
        "branch": unit.branch if unit else None,
    }


def _resolve_target_branch(host: LLMHost) -> str:
    """O branch para o qual toda unit deste run vai fazer merge de volta.

    Espelha `WorktreeFlow.ensure_target_branch`: alvo configurado é criado se
    faltar e fica com checkout no repo principal; sem configuração, é o branch
    com checkout agora. HEAD destacado não tem branch para onde voltar — recusa
    em vez de deixar o merge cair num commit sem referência.
    """
    repo = host.paths.repo_root
    configured = host.policy.scm.target_branch.strip()
    try:
        if configured:
            if not branch_exists(repo, configured):
                create_branch(repo, configured, "HEAD")
                host.journal.append("target-branch-created", branch=configured)
            if current_branch(repo) != configured:
                checkout_branch(repo, configured)
                host.journal.append("target-branch-checkout", branch=configured)
            return configured
        current = current_branch(repo)
    except GitError as exc:
        raise VerbError("git", f"could not pin the target branch: {exc}") from exc
    if current == "HEAD":
        raise VerbError(
            "state-conflict",
            "isolation=worktree on a detached HEAD: check out a branch or set "
            "scm.target_branch before opening a story",
        )
    return current


def _mount_worktree(host: LLMHost, story_key: str, target_branch: str):
    """Cut this unit's worktree from the target branch, and seed what git will
    not carry there — the gitignored skill trees and hook config a fresh checkout
    lacks, without which the session launches into a tree missing the very
    primitive it was told to run."""
    if not target_branch:
        raise VerbError(
            "state-conflict",
            "the run has no target branch; worktree isolation needs one pinned at run start",
        )
    try:
        unit = open_unit_workspace(
            host.paths.repo_root,
            host.paths,
            host.state.run_id,
            story_key,
            target_branch,
            host.policy.scm.branch_per,
            host.run_dir,
        )
    except GitError as exc:
        raise VerbError("git", f"could not open a worktree: {exc}") from exc

    profiles = _worktree_profiles(host)
    seeds = list(host.policy.scm.worktree_seed)
    if host.policy.scm.seed_adapter_defaults:
        for profile in profiles:
            seeds.extend(profile.seed_files)
    skipped = provision_worktree(
        unit.path,
        profiles,
        host.paths.repo_root,
        seed_files=list(dict.fromkeys(seeds)),
        seed_globs=(),
        on_degraded=lambda msg: host.journal.append(
            "worktree-degraded", story_key=story_key, detail=msg
        ),
    )
    if skipped:
        # A seed whose destination already exists is a no-op — harmless for a file
        # the checkout legitimately carries, but a directory entry is skipped
        # WHOLE the moment any child is tracked, so a seed that looks applied can
        # be copying nothing. Provisioning is quiet by contract; this is the only
        # place it becomes visible.
        host.journal.append("worktree-seed-skipped", story_key=story_key, entries=skipped)
    return unit


def _worktree_profiles(host: LLMHost) -> list:
    """The CLI profiles whose gitignored config the worktree needs seeded — one
    per distinct client any role resolves to."""
    from ..adapters.profile import ProfileError, get_profile

    names = {host.policy.adapter.resolved(role).name for role in ("dev", "review")}
    profiles = []
    for name in sorted(names):
        try:
            profiles.append(get_profile(name, host.project))
        except ProfileError as exc:
            raise VerbError("env", f"unresolvable CLI profile {name!r}: {exc}") from exc
    return profiles


def verb_commit(host: LLMHost, story_key: str, message: str | None = None) -> dict[str, object]:
    """Collapse the story's work into one commit and finish the task.

    Squashed onto the baseline rather than left as a chain: the dev primitive
    commits per iteration and the orchestrator writes bookkeeping on top, so a
    story would otherwise land as an unpredictable number of commits. One story,
    one commit, carrying the configured message — which is what makes the message
    template and any pre-commit rewrite authoritative regardless of how many
    times the session committed along the way.
    """
    task = _task_or_404(host, story_key)
    if task.commit_sha:
        raise VerbError("state-conflict", f"{story_key} already committed at {task.commit_sha}")
    repo = Path(task.worktree_path) if task.worktree_path else host.paths.repo_root
    text = (message or "").strip() or _default_commit_message(host, task)
    try:
        sha = finalize_commit(repo, task.baseline_commit, text)
    except GitError as exc:
        raise VerbError("git", f"could not commit: {exc}") from exc
    if sha is None:
        raise VerbError("state-conflict", f"{story_key} has nothing to commit above its baseline")

    with host.mutate() as state:
        committing = state.tasks[story_key]
        committing.commit_sha = sha
        try:
            # Not forced: COMMITTING is reachable only from a verified phase, and
            # that is the state machine refusing to let a story that never ran a
            # session land a commit. The caller drives the phases; this verb only
            # asks for the move it is entitled to.
            if committing.phase is not Phase.COMMITTING:
                advance(committing, Phase.COMMITTING)
            advance(
                committing,
                Phase.AWAITING_OPERATOR if committing.operator_actions else Phase.DONE,
            )
        except IllegalTransition as exc:
            raise VerbError("illegal-transition", str(exc)) from exc
        final_phase = str(committing.phase)
    host.journal.append("story-done", story_key=story_key, commit=sha, phase=final_phase)
    return {"story_key": story_key, "commit": sha, "phase": final_phase, "message": text}


def _default_commit_message(host: LLMHost, task: StoryTask) -> str:
    """The configured template, or a plain sentence when none is set. Literal
    substitution rather than str.format, so a stray brace in a template — a JSON
    trailer, say — does not raise at commit time."""
    template = host.policy.scm.commit_message_template.strip()
    if template:
        return (
            template.replace("{story_key}", task.story_key)
            .replace("{run_id}", host.state.run_id)
            .replace("{story_title}", task.story_key)
        )
    return f"story {task.story_key}: implemented via {namespace.PRODUCT}"


def _worktree_flow(host: LLMHost) -> WorktreeFlow:
    """A WorktreeFlow bound to this run.

    Constructed rather than reimplemented. Integration carries collision
    cleaning, the kept-failed branch, the isolated-ledger carry and the
    degraded-seed exclusions — a second implementation of that would not read as
    wrong, it would just be subtly less careful in the situations that made each
    of those necessary. The sixteen injected collaborators are the seam that
    exists so a second host can drive it.

    Plugin hooks fire through `emit`: an integration is a lifecycle moment a
    plugin may legitimately observe, and silencing them here would make a story
    integrated by this path invisible to a plugin that saw every other one.

    A failed merge-back does not escalate here (`merge_back_failed`): the story
    keeps the terminal phase `close` gave it, the worktree stays mounted, and the
    failure comes back as a `GitError` that `verb_close` turns into its retryable
    `git` refusal. The escalation the engine uses is a dead end under this host —
    ESCALATED has no transition out, and no verb re-merges a kept branch.
    """
    from ..plugins import HookBus, HookContext, PluginRegistry
    from ..workspace import Workspace

    registry = PluginRegistry.build(host.project, host.policy, journal=host.journal)
    bus = HookBus(registry, host.journal)
    workspace = Workspace(root=host.paths.repo_root, paths=host.paths)
    holder = {"workspace": workspace}

    def emit(stage: str, task=None, **fields):
        ctx = HookContext(
            stage,
            run_id=host.state.run_id,
            story_key=task.story_key if task is not None else None,
            repo_root=str(host.paths.repo_root),
            **fields,
        )
        bus.emit(stage, ctx)
        return ctx

    def refuse(reason: str, story_key: str | None = None, **_kw):
        # WorktreeFlow pauses the run by raising through this. Here it becomes a
        # typed refusal instead: the caller owns the decision to pause, and a verb
        # that halted a run as a side effect of integrating would take that away.
        raise VerbError("git", reason)

    def merge_back_failed(task: StoryTask, unit, reason: str):
        host.journal.append(
            "unit-merge-failed",
            story_key=task.story_key,
            branch=unit.branch,
            target=host.state.target_branch,
            phase=str(task.phase),
            reason=reason,
        )
        raise GitError(reason)

    return WorktreeFlow(
        paths=host.paths,
        policy=host.policy,
        state=host.state,
        journal=host.journal,
        run_dir=host.run_dir,
        registry=registry,
        adapters_get=lambda: build_adapters(host),
        open_unit_workspace=open_unit_workspace,
        emit=emit,
        save=host.save,
        gate_unit=lambda _task: False,
        # Ledger bookkeeping the engine owns: a gitignored deferred-work ledger is
        # omitted by finalize_commit's `add -A` and would vanish with a successful
        # teardown. Under this host the caller writes the ledger through its own
        # verb, in the main checkout, so there is nothing left in the unit tree to
        # carry — a no-op with a reason rather than an oversight.
        carry_isolated_ledger_writes=lambda _task: None,
        escalation_pause=refuse,
        workspace_get=lambda: holder["workspace"],
        workspace_set=lambda ws: holder.__setitem__("workspace", ws),
        merge_back_failed=merge_back_failed,
        # no post-merge carries here: the board and ledger verbs commit as they write
        carries_bookkeeping=False,
    )


def verb_close(host: LLMHost, story_key: str, outcome: str) -> dict[str, object]:
    """Finish with a story's tree: merge it back, or keep it for inspection.

    `outcome` names the terminal phase the caller has decided on. It is applied
    before integration because integration reads it — a merged story and a kept
    branch are the same code path taking different turns on the phase, so the
    phase has to be true first.

    That ordering is also what makes a failed integration safe to retry: the
    phase move already happened and is durable, so a caller that calls `close`
    again with the same outcome after a git failure is not redoing a decision,
    only resuming the integration that decision implied. `_set_terminal`
    tolerates a task already at the requested phase for exactly this reason, and
    `_worktree_flow` keeps a failed merge-back from escalating the story, which
    is what made the promise true (it was not, until 2026-09-23: every merge-back
    failure set ESCALATED before raising, and the retry met `allowed: []`).

    A story a failed merge-back escalated BEFORE that — state written by an
    earlier version, still on disk — is reopened by the same call, on the
    journal's evidence alone (`_merge_back_escalation`).
    """
    terminal = {
        "done": Phase.DONE,
        "awaiting-operator": Phase.AWAITING_OPERATOR,
        "defer": Phase.DEFERRED,
        "escalate": Phase.ESCALATED,
    }
    if outcome not in terminal:
        raise VerbError(
            "invalid-args", f"unknown outcome {outcome!r}; expected one of {sorted(terminal)}"
        )
    task = _task_or_404(host, story_key)
    _plan_merge_gate(host, task, outcome)
    if not task.worktree_path:
        # In-place mode has no tree to hand back; the phase move is the whole of
        # closing. Reported rather than refused: the caller should not have to
        # know which isolation mode the run is in to close a story.
        with host.mutate() as state:
            _set_terminal(state.tasks[story_key], terminal[outcome])
            state.tasks[story_key].integrated = True
            phase = str(state.tasks[story_key].phase)
        host.journal.append("story-closed", story_key=story_key, phase=phase, isolated=False)
        return {"story_key": story_key, "phase": phase, "isolated": False, "merged": False}

    reopened = _merge_back_escalation(host, task, terminal[outcome])
    with host.mutate() as state:
        if reopened is not None:
            # A direct move, like `_set_terminal`'s never-started case: ESCALATED
            # has no transition in the table, and this is not a decision being
            # changed — it is the phase the commit verb already gave the story,
            # restored because the escalation that replaced it was the merge's.
            state.tasks[story_key].phase = terminal[outcome]
        else:
            _set_terminal(state.tasks[story_key], terminal[outcome])
    if reopened is not None:
        host.journal.append("story-merge-reopened", story_key=story_key, **reopened)
    host.state = load_state(host.run_dir)
    task = host.state.tasks[story_key]

    flow = _worktree_flow(host)
    try:
        unit = flow.reopen_unit(task)
        flow.integrate_unit(task, unit)
    except GitError as exc:
        raise VerbError(
            "git",
            f"could not integrate {story_key}: {exc}. The story is already at its "
            f"terminal phase and its worktree is still mounted at {task.worktree_path}; "
            f"once the cause above is cleared, calling `close` again with the same "
            f"outcome ({outcome!r}) retries the integration without redoing the work. "
            f"The run is not paused: a `resume` named above is the owner's command "
            f"for after a pause, not a step for you.",
        ) from exc
    host.save()
    host.journal.append("story-closed", story_key=story_key, phase=str(task.phase), isolated=True)
    return {
        "story_key": story_key,
        "phase": str(task.phase),
        "isolated": True,
        "merged": task.phase in (Phase.DONE, Phase.AWAITING_OPERATOR),
        "branch": task.branch or None,
    }


def _merge_back_escalation(host: LLMHost, task: StoryTask, phase: Phase) -> dict[str, str] | None:
    """The evidence that ``task`` is ESCALATED only because its merge-back failed,
    or None when there is none.

    Before 2026-09-23 a failed merge-back under this host escalated the story
    (`WorktreeFlow.keep_branch_and_escalate`), and runs still hold stories in that
    state: committed, their branch kept and mounted, integrated by hand or not at
    all. `close` may reopen exactly those, and the journal says which they are,
    because after `story-done` nothing but `close`'s own integration can escalate
    a story here — no verb moves a DONE story, and the transition table gives it
    no way out. So the story qualifies when:

    - `story-done` recorded THIS commit (`task.commit_sha`) with the phase being
      asked for — a parked `awaiting-operator` story is not reopened as `done`;
    - the last lifecycle event for the story after it is `story-escalated`, and
      no `unit-merged` or `story-closed` came between — a merge that landed is not
      re-run;
    - the worktree is still mounted — the retry integrates from it.

    Returns the fields journaled beside the reopen, so the record names the commit
    and the escalation it undid.
    """
    if task.phase is not Phase.ESCALATED or phase not in (Phase.DONE, Phase.AWAITING_OPERATOR):
        return None
    if not task.commit_sha or not task.worktree_path or not Path(task.worktree_path).is_dir():
        return None
    done_at: int | None = None
    escalated: dict[str, object] | None = None
    for i, entry in enumerate(host.journal.entries()):
        if entry.get("story_key") != task.story_key:
            continue
        kind = entry.get("kind")
        if kind == "story-done":
            if entry.get("commit") == task.commit_sha and entry.get("phase") == str(phase):
                done_at, escalated = i, None
            else:
                done_at, escalated = None, None
        elif done_at is not None and kind in ("unit-merged", "story-closed"):
            done_at, escalated = None, None
        elif done_at is not None and kind == "story-escalated":
            escalated = entry
    if done_at is None or escalated is None:
        return None
    return {"commit": task.commit_sha, "escalation": str(escalated.get("reason", ""))[:500]}


def _plan_merge_gate(host: LLMHost, task: StoryTask, outcome: str) -> None:
    """A --plan run merges in the grid's order, and only what the ladder verified.

    Two refusals, both BEFORE the terminal move so the story stays where it was
    and `close` is simply called again later. Order: a front merges after every
    front before it in its wave's `merge_order` is terminal — merged, deferred or
    escalated; while an earlier front's story is in flight the answer names it.
    Currency: a unit branch the target has moved past (an earlier front merged)
    is not merged as it stands — `unit rebase` first, then the ladder again on
    what will actually land, then `close`. Outside a plan run neither applies:
    one unit at a time never falls behind.
    """
    plan = host.state.plan
    if not plan or outcome not in ("done", "awaiting-operator"):
        return
    where = waveplan.front_of(plan, task.story_key)
    if where is None:
        return
    waves = plan.get("waves") or ()  # namespace: the plan's YAML key, not the product
    wave = next((w for w in waves if w.get("wave") == where["wave"]), None)
    if wave is not None:
        order = [str(n) for n in (wave.get("merge_order") or ())]
        fronts = wave.get("fronts") or {}
        earlier = order[: order.index(where["front"])] if where["front"] in order else []
        for name in earlier:
            for key in (fronts.get(name) or {}).get("stories") or ():
                other = host.state.tasks.get(str(key))
                if other is not None and not _settled(other):
                    raise VerbError(
                        "state-conflict",
                        f"merge order: in wave {where['wave']} front {name} ({key}) merges "
                        f"before front {where['front']}, and {key} is still in flight "
                        f"({other.phase}) — await it (or its deferral), then close "
                        f"{task.story_key}",
                    )
    if task.worktree_path:
        flow = _worktree_flow(host)
        unit = flow.reopen_unit(task)
        if flow.behind_target(unit):
            raise VerbError(
                "state-conflict",
                f"{task.story_key}'s branch {task.branch} is behind {host.state.target_branch}: "
                f"an earlier front merged since it was cut. `unit rebase {task.story_key}`, "
                f"re-run the verify ladder on the rebased tree, then close",
            )


def verb_rebase(host: LLMHost, story_key: str) -> dict[str, object]:
    """Rebase a story's unit branch onto the current target, in its own worktree.

    The rebase-and-reverify path of a --plan run (see `_plan_merge_gate`). The
    answer is a fact, not a verdict: `rebased: true` means the branch now sits on
    the target and the ladder must run again before `close`; `rebased: false`
    comes with `conflicts`, the paths the rebase stopped on, ABORTED already — the
    tree is clean and the branch untouched, and resolving them is a session's
    work in that worktree, after which this verb is called again. `attempt`
    counts the rebases this story has paid; how many is too many is yours.
    """
    task = _task_or_404(host, story_key)
    # DONE is not the bar: the LLM loop's `commit` moves a story to DONE before
    # `close` lands it, and that is exactly the story a rebase serves. Settled is.
    if _settled(task):
        raise VerbError(
            "state-conflict",
            f"{story_key} is already settled ({task.phase}"
            f"{', merged' if task.integrated else ''}): nothing left to rebase",
        )
    if not task.worktree_path:
        raise VerbError(
            "state-conflict",
            f"{story_key} works on the shared checkout (no unit worktree): nothing to rebase",
        )
    flow = _worktree_flow(host)
    unit = flow.reopen_unit(task)
    with host.mutate() as state:
        live = state.tasks[story_key]
        try:
            result = flow.rebase_unit(live, unit)
        except GitError as exc:
            raise VerbError("git", f"could not rebase {story_key}: {exc}") from exc
        attempt = live.rebases
    return {"story_key": story_key, "attempt": attempt, **result}


def _set_terminal(task: StoryTask, phase: Phase) -> None:
    """Move a task to its terminal phase, tolerating one it is already at.

    Re-closing a story that a crash left mid-integration must not be refused by
    the transition table: the phase is where the caller wants it, and the work
    left to do is the integration, not the move.
    """
    if task.phase is phase:
        return
    if (
        task.phase is Phase.PENDING
        and phase in (Phase.DEFERRED, Phase.ESCALATED)
        and not task.sessions
    ):
        # A story that never started — its stack could not be provisioned, or the
        # orchestrator decided against it before a session — has no work to protect
        # and no legal move in the table. The engine makes this same deliberate
        # direct move for a unit whose worktree failed to open; without it a failed
        # provision would leave a story nobody can close.
        task.phase = phase
        return
    _story_advance(task, phase)
