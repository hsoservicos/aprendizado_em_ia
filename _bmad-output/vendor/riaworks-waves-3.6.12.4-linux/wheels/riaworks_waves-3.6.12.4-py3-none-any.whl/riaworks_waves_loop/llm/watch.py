"""Waiting on a live session, on a condition the caller chose.

A dispatch that blocked until the session ended would make the orchestrator
blinder than it needs to be. The transport publishes plenty while a session runs
— the pane log grows continuously, the adapter's wait loop rewrites a heartbeat,
the multiplexer knows whether the window is still there — and none of it is
reachable if the only available answer is "call me when it is over".

So waiting is its own operation, and the *condition* is an argument. The caller
decides what is worth being woken for; this module decides nothing except which
condition fired first.

The honest limit: the caller only thinks between tool calls, so it does not react
when something happens — it reacts when the wait returns. The granularity of its
attention is exactly the condition it wrote. Asking only for `end` is choosing to
be blind, and that is a legitimate choice, not a defect.
"""

from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass
from pathlib import Path

#: What a wait can be woken by. `timeout` is always in play as the outer bound.
CONDITIONS = frozenset({"end", "match", "quiet", "stale-heartbeat", "vanished"})

#: How often the conditions are sampled. Short enough that a match is noticed
#: while it still matters, long enough that a long wait is not a spin.
POLL_S = 0.5

#: A heartbeat older than this, under a session with no result, means the writer
#: stopped: the wait loop is gone (crashed, killed, host suspended). Generous
#: relative to the adapter's 30s cadence so an ordinary scheduling hiccup does
#: not read as death.
DEFAULT_HEARTBEAT_STALE_S = 180.0


@dataclass(frozen=True)
class Wake:
    """Why the wait returned, and where the caller should read from next."""

    reason: str
    detail: str = ""
    #: Byte offset reached in the pane log. Threading it back into the next
    #: `tail` is what keeps a long session readable in slices instead of re-read
    #: from the top every time.
    log_offset: int = 0

    def to_dict(self) -> dict[str, object]:
        return {"woke": self.reason, "detail": self.detail, "log_offset": self.log_offset}


@dataclass(frozen=True)
class Conditions:
    """The bounds of one wait. Every field is optional except the timeout: a wait
    with no outer bound is a hang with better manners."""

    timeout_s: float
    end: bool = True
    match: str | None = None
    quiet_s: float | None = None
    stale_heartbeat: bool = False
    vanished: bool = False
    heartbeat_stale_s: float = DEFAULT_HEARTBEAT_STALE_S

    def compiled(self) -> re.Pattern[str] | None:
        return re.compile(self.match) if self.match else None


def _size(path: Path) -> int:
    try:
        return path.stat().st_size
    except OSError:
        return 0


def _heartbeat_age_s(path: Path, now: float) -> float | None:
    """Seconds since the wait loop last wrote proof of life, or None when it has
    not written any. Read from the payload's own timestamp rather than the file's
    mtime: the adapter rewrites the file each beat, and an mtime can be
    coarse-grained or skewed on a network/virtualized filesystem."""
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    ts = payload.get("ts")
    if not isinstance(ts, (int, float)):
        return None
    return max(0.0, now - float(ts))


def _read_since(path: Path, offset: int) -> tuple[str, int]:
    """Text appended past `offset`, and the new offset.

    Decoded leniently: the pane log is raw terminal output and can be cut
    mid-multibyte-sequence at any offset, which is not a reason to fail a wait.
    """
    try:
        with path.open("rb") as fh:
            fh.seek(offset)
            chunk = fh.read()
    except OSError:
        return "", offset
    return chunk.decode("utf-8", errors="replace"), offset + len(chunk)


def await_session(
    *,
    result_path: Path,
    log_path: Path,
    heartbeat_path: Path,
    conditions: Conditions,
    from_offset: int = 0,
    window_alive=None,
    poll_s: float = POLL_S,
    now=time.monotonic,
    wall=time.time,
) -> Wake:
    """Block until one of `conditions` fires, and name which.

    `window_alive` is an optional zero-argument predicate for the `vanished`
    condition; passing None leaves that condition inert rather than guessing that
    a missing multiplexer means a dead session.
    """
    pattern = conditions.compiled()
    deadline = now() + conditions.timeout_s
    offset = from_offset
    last_growth = now()

    while True:
        if conditions.end and result_path.is_file():
            _, offset = _read_since(log_path, offset)
            return Wake("end", str(result_path), offset)

        text, new_offset = _read_since(log_path, offset)
        if new_offset != offset:
            offset = new_offset
            last_growth = now()
            if pattern is not None:
                found = pattern.search(text)
                if found is not None:
                    return Wake("match", found.group(0)[:200], offset)

        if conditions.quiet_s is not None and now() - last_growth >= conditions.quiet_s:
            return Wake("quiet", f"no output for {conditions.quiet_s:g}s", offset)

        if conditions.stale_heartbeat:
            age = _heartbeat_age_s(heartbeat_path, wall())
            if age is not None and age >= conditions.heartbeat_stale_s:
                return Wake("stale-heartbeat", f"last beat {age:.0f}s ago", offset)

        if conditions.vanished and window_alive is not None and not window_alive():
            # Checked after the result probe on purpose: a session that finished
            # and had its window torn down is `end`, not `vanished`. Only a window
            # that is gone with no result is the anomaly worth reporting.
            if not result_path.is_file():
                return Wake("vanished", "session window is gone with no result", offset)

        if now() >= deadline:
            return Wake("timeout", f"{conditions.timeout_s:g}s elapsed", offset)

        time.sleep(poll_s)
