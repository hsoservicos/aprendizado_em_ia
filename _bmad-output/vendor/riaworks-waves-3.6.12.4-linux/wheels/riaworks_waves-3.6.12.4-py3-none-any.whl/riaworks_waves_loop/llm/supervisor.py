"""The process that owns an LLM-held run.

A verb is short-lived, so no verb can own `engine.pid`: between two verbs there
would be no live pid and the dashboard would classify the run as interrupted.
The supervisor is the stable owner for the run's whole life — it writes the pid,
handles both stop channels, and records a crash the way the deterministic engine
does, so every reader that already understands a run understands this one.

In this milestone it launches nothing and its wait loop only observes. The
orchestrator session, the turn protocol and the relaunch digest replace the body
of `wait_until_stopped` in the next.
"""

from __future__ import annotations

import contextlib
import json
import signal
import time
import traceback
from pathlib import Path
from types import FrameType

from .. import envvars, namespace, runs
from ..adapters.profile import ProfileError
from ..bmadconfig import ProjectPaths
from ..cli import PROG
from ..install import _relay_executable
from ..journal import Journal, load_state, save_state
from ..model import PAUSE_ESCALATION, RunState
from ..policy import Policy
from ..process_host import get_process_host
from ..runs import RUNS_DIR
from ..runsetup import _claim_identity, _claim_run_dir, build_run_state
from ..sessionspec import build_spec
from . import turn
from .dispatch import build_own_adapter
from .host import LLMHost
from .lock import state_run_lock
from .sessionio import write_session_result

#: The role an orchestrator session runs on, so it can carry its own
#: `[adapter.orchestrator]` model and effort rather than borrowing dev's.
ORCHESTRATOR_ROLE = "orchestrator"

#: The bundled skill an orchestrator session loads. Named in the prompt rather
#: than left to the CLI's own discovery: a session that did not load it would
#: still start, still look healthy, and improvise its way through a run with no
#: turn contract and no judgement table — the failure would present as bad
#: decisions rather than as a missing skill.
ORCHESTRATOR_SKILL = namespace.SKILL_CORE_ORCHESTRATOR

#: How a turn says it is over. The orchestrator's session runs on a result-file
#: adapter (`dispatch.build_own_adapter`), whose Stop completes only on the
#: `tasks/<task_id>/result.json` the session writes. This is the clause the engine's
#: retrospective prompt ends with, in the same shape. A turn that forgets it gets
#: the adapter's resultless-Stop nudge, then the stall grace.
ORCHESTRATOR_COMPLETION = (
    "\n\n## Completion signal (required)\n"
    "When this turn is over — its decisions journaled, and the run finished, paused or "
    "left for the next turn — write\n"
    f"${envvars.RUN_DIR}/tasks/${envvars.TASK_ID}/result.json as\n"
    + json.dumps({"workflow": ORCHESTRATOR_SKILL, "status": "done"})
    + ", then end your turn."
)


def orchestrator_prompt(digest: str) -> str:
    """One turn's prompt: the skill named in the canonical "/skill args" form every
    CLI profile renders for its own invocation syntax (a slash command here, a
    $mention there), the digest as its arguments, and the completion clause."""
    return f"/{ORCHESTRATOR_SKILL} {digest}{ORCHESTRATOR_COMPLETION}"


#: A hung turn is bounded by `limits.session_timeout_min`, not by a turn-specific
#: knob. `_run_turn` builds the orchestrator's session through the same
#: `build_spec` every dispatched session uses and waits on the same
#: `wait_for_completion`, so the adapter's dual-clock timeout kills a wedged
#: orchestrator window and returns `timeout`, which lands here as an ordinary
#: turn outcome and relaunches.
#:
#: `[llm] turn_timeout_min` used to sit in the policy for this and was never read
#: by any executing code — a second ceiling over the same session would only have
#: fought the first, and at its 30-minute default it would have won, killing turns
#: that are long by design (a turn is meant to span a story, often an epic). It
#: was removed rather than implemented.

#: Why the run stopped, as `wait_until_stopped` reports it.
OUTCOME_STOPPED = "stopped"
OUTCOME_PAUSED = "paused"
OUTCOME_FINISHED = "finished"
OUTCOME_CRASHED = "crashed"

CRASH_FILE = "crash.txt"


class SupervisorError(Exception):
    """The supervisor was asked to do something out of order."""


class ResumeRefused(Exception):
    """`resume_run` will not adopt this run, and why.

    Carries the exit code the CLI should return so the refusal reads the same
    from either resume entrypoint: `code = 2` for "you typed the wrong command"
    (a deterministic run handed to `llm-run --resume`, the mirror of
    `cmd_resume`'s own pointer at this one), `code = 1` for "this run cannot be
    resumed at all". The `ExitCode` allocation is closed, so those are the only
    two.
    """

    def __init__(self, message: str, code: int = 1) -> None:
        super().__init__(message)
        self.code = code


class Supervisor:
    def __init__(
        self,
        *,
        project: Path,
        run_dir: Path,
        journal: Journal,
        state: RunState,
        policy: Policy,
        paths: ProjectPaths,
    ) -> None:
        self.project = project
        self.run_dir = run_dir
        self.journal = journal
        self.state = state
        self.policy = policy
        self.paths = paths
        self._started = False
        self._stop_requested = False

    # ------------------------------------------------------------- lifecycle

    def start(self) -> None:
        """Make the run real and observable, before anything else happens.

        Deliberately separate from `open_run`: a caller that fails its own
        preflight must not leave a half-born run in the picker.
        """
        save_state(self.run_dir, self.state)
        runs.write_pid(self.run_dir)
        self.journal.append(
            "run-start",
            run_id=self.state.run_id,
            source=self.state.source,
            adapter_orchestrator=self.policy.adapter.resolved("orchestrator").name,
        )
        self._arm()

    def resume(self, *, trusted_config_digest: str) -> list[str]:
        """Re-arm this supervisor over a run that already exists, and return the
        operator notices the caller should print.

        The sibling of :meth:`start`, and deliberately not a call to it: `start`
        means "this run begins now", and re-running it over a live run directory
        would journal a second `run-start` and re-baseline the turn record the
        dashboard reads. What a resume owes instead is the bookkeeping
        `cli._resume_paused_run` does for the deterministic engine, in the same
        order and for the same reasons — the policy snapshot and the integrity
        pin describe the process that is about to enforce them, and the pid lands
        BEFORE the cleared pause so no observer catches a window of "not paused +
        dead pid" and calls the run interrupted.

        Notices are returned rather than printed because the supervisor writes to
        the journal and the run dir, never to a terminal; the CLI owns stderr.
        """
        # Read the outgoing weight BEFORE the re-stamp below replaces it, exactly
        # as the deterministic resume does: the session-end entries this run
        # already wrote were weighted at it, and the (now newer) snapshot cannot
        # reconstruct them. Scalars only — journal entries are unsanitized at
        # write time, so no policy key or value goes in here.
        # One read-modify-write under the run's state lock — the same one `stop`,
        # `clean` and the dashboard take — with state RE-READ inside it: the
        # snapshot this supervisor opened with may predate a stop or a pause
        # written since, and publishing it whole would erase that write (DW-93;
        # the deterministic resume holds the lock the same way, in
        # `cli._prepare_resume_locked`).
        with state_run_lock(self.run_dir):
            self.state = load_state(self.run_dir)
            notices: list[str] = []
            new_snapshot = self.policy.to_dict()
            # #498's split, mirrored: the out-of-tree file is the baseline resume
            # trusts, and the copy in state.json is the fallback for a run whose
            # state key moved (or that was launched before the file existed). `None`
            # means "no file" — distinct from an empty file, which is a real answer of
            # "no baseline". An llm-run launches with the pin EMPTY today
            # (`llm.cli.cmd_llm_run` passes ""), so a run's first resume establishes
            # its baseline and cannot warn; every later one can.
            pinned, digest_fault = runs.read_trusted_config_digest(self.project, self.state.run_id)
            if digest_fault is not None:
                # The deterministic resume's notice (DW-467), word for word: an
                # unreadable baseline is not "paused before #498", and the fallback
                # below is a copy the driven session can rewrite.
                notices.append(
                    f"warning: run {self.state.run_id}: the trusted host-exec config"
                    f" baseline could not be read ({digest_fault}); falling back to the"
                    " copy in state.json, which the driven session can rewrite — a"
                    " changed-config warning may be missing below"
                )
            if pinned is None:
                pinned = self.state.trusted_config_digest
            security_config_changed = bool(pinned) and trusted_config_digest != pinned
            fields: dict[str, object] = {
                "security_config_changed": security_config_changed,
                "was_paused": self.state.paused_reason,
                "cache_read_weight": self.policy.limits.cache_read_weight,
                # Compare JSON-normalized, the way save_state persists it: to_dict()
                # returns tuples where the reloaded snapshot has lists, so a plain !=
                # reports "changed" on every resume — including one where policy.toml
                # was never touched.
                "policy_changed": bool(self.state.policy_snapshot)
                and json.dumps(new_snapshot, sort_keys=True)
                != json.dumps(self.state.policy_snapshot, sort_keys=True),
            }
            prior_weight = self.state.cache_read_weight()
            if prior_weight != self.policy.limits.cache_read_weight:
                fields["cache_read_weight_was"] = prior_weight
            self.journal.append("run-resume", **fields)
            if security_config_changed:
                # STATIC category names only. A single sha256 cannot say which of them
                # moved, and naming the old/new values is exactly what this must not
                # do — the mutation is attacker-controlled text headed for a terminal.
                notices.append(
                    f"warning: run {self.state.run_id}: the host-exec config pinned at"
                    " launch has changed — one or more of: verify commands, launch"
                    " binary/args/env, plugin allowlist. Resuming trusts the config now"
                    f" on disk; re-read {namespace.STATE_REL}/policy.toml and"
                    f" {namespace.STATE_REL}/profiles/ first if you did not make that edit."
                )
            self.state.policy_snapshot = new_snapshot
            runs.write_trusted_config_digest(self.project, self.state.run_id, trusted_config_digest)
            self.state.trusted_config_digest = trusted_config_digest
            # The point of the whole command: the pause is cleared and the run carries
            # on over the worktrees it already has. `clear_pause` also clears `stopped`
            # and `crashed`, which is why a stopped or crashed llm-run re-arms rather
            # than being refused — the same choice `RunState.clear_pause` documents for
            # the deterministic engine.
            self.state.clear_pause()
            # A resume is fresh user intent: discard any graceful-stop request left
            # over from a prior stopped run so the re-armed loop does not consume it on
            # its first pass and stop again at once. Fires BEFORE write_pid — the
            # moment the pid lands the run is "live" and a lingering request becomes
            # honorable.
            if runs.clear_graceful_stop(self.run_dir):
                notices.append(
                    f"run {self.state.run_id}: discarded a stale graceful-stop request"
                    " before resuming"
                )
            runs.write_pid(self.run_dir)
            save_state(self.run_dir, self.state)
        self._arm()
        return notices

    def _arm(self) -> None:
        """The half of the lifecycle both `start` and `resume` need: from here on
        the process answers for the run, so it must be able to hear a stop."""
        self._install_signal_handlers()
        self._started = True

    def drive(self) -> str:
        """Run the orchestrator until the run reaches a terminal condition.

        One turn per iteration: launch a session, let it work, then read what it
        left behind. The turn is where all the deciding happens — this loop only
        decides whether there should be another one. The run's mux session is then
        released the way the engine releases its own (:meth:`_release_session`).
        """
        if not self._started:
            raise SupervisorError("drive() before start()")
        outcome = self._drive_turns()
        self._release_session(outcome)
        return outcome

    def _release_session(self, outcome: str) -> None:
        """The run's `waves-<id>` session at a terminal outcome, as the engine leaves
        its own: finished or stopped under `[adapter] cleanup_session_on_finish` →
        killed; paused or crashed → kept, so a resume (or a person reading the
        windows) still finds them.

        MEASURED 2026-10-03: every LLM-held run left its session behind — the
        orchestrator's window and each dev window it had dispatched — while the
        engine's runs, under the same policy, cleaned theirs."""
        if outcome in (OUTCOME_FINISHED, OUTCOME_STOPPED) and (
            self.policy.adapter.cleanup_session_on_finish
        ):
            runs.kill_session(self.state.run_id)

    def _drive_turns(self) -> str:
        # Two counts, because they answer different questions. `turns` names the
        # session — it is what makes `orchestrator-<n>` and its log unique, so it
        # only ever climbs. `silent` is the budget, and it asks whether the
        # orchestrator is broken *now*: a turn that wrote its reasoning and
        # handed the run on clears it.
        #
        # `turns` is SEEDED from the run's own turn record rather than from zero,
        # because a resumed run has already spent some. Restarting the count would
        # relaunch as `orchestrator-1` and overwrite the task dir, the session
        # result and the pane log of the very turn whose reasoning the operator
        # resumed to act on. `turn.progress` is the same reader the dashboard
        # counts turns with, so the supervisor and the display can never disagree
        # about how many a run has had.
        #
        # `silent` deliberately restarts at zero on a resume: the run paused
        # BECAUSE the budget ran out, so carrying the count forward would spend one
        # turn and pause again on the same reason. A human typing resume is the
        # answer to that escalation, and this is the same "resume is fresh user
        # intent" the deterministic path applies to a stale graceful-stop request.
        turns = turn.progress(self.run_dir, self.policy.llm.max_turn_relaunches).turns
        silent = 0
        violation = ""
        command = self._verb_command()
        while True:
            if self._stop_requested or runs.graceful_stop_requested(self.run_dir):
                return self._mark_stopped()

            state = self._read_state() or self.state
            prompt = turn.digest(self.run_dir, state, violation=violation, command=command)
            mark = turn.TurnMark.take(self.run_dir)
            self.journal.append("turn-start", relaunch=turns, violation=bool(violation))

            outcome = self._run_turn(prompt, turns)

            state = self._read_state() or self.state
            verdict = turn.classify(
                state, mark, self.run_dir, strict=self.policy.llm.protocol == "strict"
            )
            self.journal.append("turn-end", verdict=verdict, session=outcome, relaunch=turns)

            if verdict == turn.TERMINAL:
                return self._terminal_outcome(state)

            turns += 1
            violation = ""
            if verdict != turn.VIOLATION:
                silent = 0
                continue

            violation = f"the turn ended {outcome} having written neither state nor journal"
            silent += 1
            if silent > self.policy.llm.max_turn_relaunches:
                # The orchestrator itself is what is broken. Another launch would
                # spend a session's worth of tokens reaching the same place, so
                # the run pauses with the count named rather than burning through
                # a budget nobody is watching.
                return self._pause(
                    f"orchestrator relaunched {silent - 1} times without reaching a "
                    f"terminal state; last turn ended {outcome}"
                )

    def _verb_command(self) -> str:
        """The command the orchestrator types for a verb: THIS installation's entry
        point, quoted for this host's shell — the resolution upstream's hook relay
        registers with (`install._relay_executable`), independent of PATH.

        MEASURED 2026-10-03: a session's shell builds PATH from the operator's
        profile, not from the run's environment, so a bare name reached another
        installation — an older global one — and every verb of the turn ran code the
        run was not started with. Unresolvable → the bare name, journaled, so the
        degrade is on the record rather than silent."""
        try:
            return get_process_host().shell_quote(str(_relay_executable()))
        except ProfileError as exc:
            self.journal.append("orchestrator-command-unresolved", error=str(exc))
            return namespace.PRODUCT

    def _run_turn(self, prompt: str, relaunch: int) -> str:
        """One orchestrator session, start to finish. Returns its status.

        The supervisor waits here itself rather than handing off to a watcher:
        it is long-lived by definition, and a second process would only add a
        file to read.
        """
        task_id = f"orchestrator-{relaunch + 1}"
        # Its OWN adapter, never dev's on the same client: a turn completes on the
        # result.json its completion clause asks for, not on a dev spec appearing
        # (see build_own_adapter).
        adapter = build_own_adapter(self._host(), ORCHESTRATOR_ROLE)
        cfg = self.policy.adapter.resolved(ORCHESTRATOR_ROLE)
        env = {
            namespace.env("MODE"): "1",
            namespace.env("RUN_DIR"): str(self.run_dir),
            namespace.env("TASK_ID"): task_id,
        }
        spec = build_spec(
            task_id=task_id,
            role=ORCHESTRATOR_ROLE,
            prompt=orchestrator_prompt(prompt),
            cwd=self.paths.repo_root,
            env=env,
            policy=self.policy,
            model=cfg.model,
            effort=cfg.effort,
        )
        self.journal.set_active_log(task_id)
        self.journal.append(
            "session-start",
            task_id=task_id,
            role=ORCHESTRATOR_ROLE,
            adapter=cfg.name,
            model=cfg.model,
        )
        try:
            handle = adapter.start_session(spec)
        except Exception as exc:  # noqa: BLE001 - a failed launch is a turn outcome
            self.journal.append("session-end", task_id=task_id, status="launch-failed")
            return f"launch-failed: {type(exc).__name__}"
        try:
            result = adapter.wait_for_completion(handle, spec)
        except Exception as exc:  # noqa: BLE001
            self.journal.append("session-end", task_id=task_id, status="crashed")
            return f"crashed: {type(exc).__name__}"
        finally:
            with contextlib.suppress(Exception):
                adapter.kill(handle)
        write_session_result(self.run_dir / "tasks" / task_id, result)
        self.journal.append("session-end", task_id=task_id, status=result.status)
        return result.status

    def _host(self) -> LLMHost:
        """A host view of this run, for the pieces that take one."""
        return LLMHost(
            project=self.project,
            run_dir=self.run_dir,
            paths=self.paths,
            policy=self.policy,
            journal=self.journal,
            state=self.state,
        )

    def _terminal_outcome(self, state: RunState) -> str:
        if state.stopped:
            return OUTCOME_STOPPED
        if state.crashed:
            return OUTCOME_CRASHED
        if state.paused:
            return OUTCOME_PAUSED
        return OUTCOME_FINISHED

    def _pause(self, reason: str) -> str:
        with state_run_lock(self.run_dir):
            state = load_state(self.run_dir)
            if not state.paused:
                state.paused_reason = reason
                state.paused_stage = PAUSE_ESCALATION
                save_state(self.run_dir, state)
        self.journal.append("run-paused", reason=reason)
        return OUTCOME_PAUSED

    def wait_until_stopped(self, poll_s: float = 1.0) -> str:
        """Block until the run reaches a terminal condition, without driving it.

        The observation half of `drive`, kept for a supervisor that is only
        watching — a run whose orchestrator is being driven by hand, or a test.
        """
        if not self._started:
            raise SupervisorError("wait_until_stopped before start()")
        while True:
            if self._stop_requested or runs.graceful_stop_requested(self.run_dir):
                return self._mark_stopped()
            state = self._read_state()
            if state is not None:
                if state.finished:
                    return OUTCOME_FINISHED
                if state.paused:
                    return OUTCOME_PAUSED
            time.sleep(poll_s)

    def _read_state(self) -> RunState | None:
        """The run's state, or None when it cannot be read right now.

        A verb replaces `state.json` atomically, but a reader can still meet a
        transient failure; treating that as a terminal condition would end the
        run on a torn read. None simply means "ask again next poll".
        """
        try:
            return load_state(self.run_dir)
        except (OSError, json.JSONDecodeError, KeyError, TypeError, ValueError):
            return None

    # ------------------------------------------------------------------ stops

    def request_stop(self) -> None:
        """Ask the wait loop to stop at its next poll. Safe from a signal
        handler: it sets a flag and touches nothing else."""
        self._stop_requested = True

    def _install_signal_handlers(self) -> None:
        def _handler(_signum: int, _frame: FrameType | None) -> None:
            # A flag, not a state mutation: the wait loop takes the run-dir lock,
            # and taking a lock inside a handler can deadlock against the very
            # section it interrupted.
            self._stop_requested = True

        for sig in (signal.SIGTERM, signal.SIGINT):
            try:
                signal.signal(sig, _handler)
            except (ValueError, OSError):
                # Not on the main thread, or the platform lacks the signal. The
                # stop-request file still works, so this degrades rather than
                # fails.
                pass

    def _mark_stopped(self) -> str:
        with state_run_lock(self.run_dir):
            state = load_state(self.run_dir)
            state.stopped = True
            save_state(self.run_dir, state)
        # Consume the request, so a later resume does not stop again at once.
        runs.clear_graceful_stop(self.run_dir)
        self.journal.append("run-stopped")
        return OUTCOME_STOPPED

    def record_crash(self, exc: BaseException) -> None:
        """Persist an escaped exception the way the engine does, so the dashboard
        shows a crashed run rather than a silently dead one."""
        (self.run_dir / CRASH_FILE).write_text(
            "".join(traceback.format_exception(exc)), encoding="utf-8"
        )
        error = f"{type(exc).__name__}: {exc}"
        with state_run_lock(self.run_dir):
            state = load_state(self.run_dir)
            state.crashed = True
            state.crash_error = error
            save_state(self.run_dir, state)
        self.journal.append("run-crash", error=error)


def open_run(
    project: Path,
    policy: Policy,
    paths: ProjectPaths,
    *,
    epic_filter: int | None,
    story_filter: str | None,
    max_stories: int | None,
    trusted_config_digest: str,
    run_id: str | None = None,
    plan: dict[str, object] | None = None,
) -> Supervisor:
    """Allocate a fresh LLM-held run and its supervisor. Nothing is written until
    :meth:`Supervisor.start`. ``plan`` is a wave plan's record (`waveplan`) when
    the run was launched with ``--plan``: the run's scope, in the plan's order."""
    # A caller that already named the run (the TUI, which tracks the id it
    # launched) keeps its id; everyone else gets a fresh one.
    run_id = run_id or runs.new_run_id()
    run_dir = project / RUNS_DIR / run_id
    # Claimed, not just named: the deterministic composer's claim (DW-446) is the
    # only creation of a run dir that refuses an id already naming a run — and
    # `Journal` below creates the directory either way, adopting an existing one
    # without complaint. Its stat is the mint-time identity every worktree mount
    # and every writer below the run dir is pinned to; a run carrying none is
    # refused by every one of those pins.
    claim = _claim_run_dir(run_dir)
    state = build_run_state(
        run_id=run_id,
        project=project,
        repo_root=paths.repo_root,
        policy=policy,
        epic_filter=epic_filter,
        story_filter=story_filter,
        max_stories=max_stories,
        stories_on=False,
        spec_folder="",
        trusted_config_digest=trusted_config_digest,
        llm_on=True,
        plan=plan,
        run_dir_identity=_claim_identity(claim),
    )
    return Supervisor(
        project=project,
        run_dir=run_dir,
        journal=Journal(run_dir),
        state=state,
        policy=policy,
        paths=paths,
    )


def resume_run(
    project: Path,
    policy: Policy,
    paths: ProjectPaths,
    *,
    run_ref: str,
) -> Supervisor:
    """Adopt an existing LLM-held run and its supervisor — the sibling of
    :func:`open_run`. Nothing is written until :meth:`Supervisor.resume`.

    `open_run` mints a run id and a fresh state; this one resolves a run the
    operator names, loads the state it already has, and builds the same
    `Supervisor` over the same run dir and `Journal`. Everything after
    construction — `drive`, the turn contract, the relaunch budget, both stop
    channels — is shared, because a resumed run is not a different kind of run.

    Keeping the run dir is the entire point. A paused llm-run holds mounted
    worktrees with proven work in them; starting a fresh run instead would cut
    new trees from whatever the integration branch is *now*, which is the damage
    the run paused to avoid.

    Raises :class:`ResumeRefused` for the three things that are wrong with the
    run itself. The liveness gate lives in the CLI, mirroring `cmd_resume`, since
    it is a fact about the machine rather than about the run.
    """
    try:
        run_dir = runs.resolve_run_dir(project, run_ref)
    except runs.RunRefError as exc:
        raise ResumeRefused(str(exc)) from exc
    try:
        state = load_state(run_dir)
    except (OSError, json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
        # Loud rather than "start a new run": an unreadable state.json on a run
        # that owns worktrees is a thing to look at, not to route around.
        raise ResumeRefused(f"run {run_dir.name}: cannot read its state ({exc})") from exc
    # FIRST, before any other verdict: `llm-run` must not pronounce on a run it
    # does not own. This is the exact mirror of `cli._resume_paused_run` refusing
    # an `llm` run and pointing here, and the pair is what makes both messages
    # true — the pointer that named this flag before it existed is what #2.1 of
    # the incident report was about.
    if state.source != "llm":
        raise ResumeRefused(
            f"run {run_dir.name} is a {state.source} run, not an LLM-held one — "
            f"resume it with `{PROG} resume {run_dir.name}`",
            code=2,
        )
    if state.finished:
        # The one terminal state a resume cannot clear. `clear_pause` deliberately
        # clears `paused`, `stopped` and `crashed` — those runs re-arm — but a
        # finished run has no work left to drive and re-arming it would relaunch an
        # orchestrator with nothing to do.
        raise ResumeRefused(f"run {run_dir.name} already finished")
    return Supervisor(
        project=project,
        run_dir=run_dir,
        journal=Journal(run_dir),
        state=state,
        policy=policy,
        paths=paths,
    )
