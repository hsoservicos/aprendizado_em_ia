"""How a verb answers.

Success is one JSON document on stdout with exit 0; failure is one JSON document
on **stderr** with stdout empty and a non-zero exit. That is `machine.py`'s
stated rule — "stdout is either one complete valid document or empty" — while
still handing the caller a machine-routable `kind` instead of prose to parse.

The caller is an LLM driving a shell. A Python traceback tells it nothing it can
act on, so no exception escapes `run_verb`.
"""

from __future__ import annotations

import json
import sys
from collections.abc import Callable

from .host import HostError

VERB_SCHEMA_VERSION = 1

# Keys the envelope owns. A verb body returning one would be overwriting the
# contract rather than filling in its payload.
_RESERVED = frozenset({"ok", "schema_version"})

# Closed vocabulary. The caller routes on the kind, so adding one is a contract
# change: the skill's reference documents each kind and what to do about it.
ERROR_KINDS = frozenset(
    {
        "invalid-args",  # the call was malformed; fix the arguments
        "not-found",  # the named run / story / task does not exist
        "illegal-transition",  # the phase move is not in the state machine
        "lock-timeout",  # another writer held the run dir too long
        "git",  # a git operation failed
        "state-conflict",  # state.json is unreadable, or contradicts the request
        "env",  # the environment is at fault, not the request
    }
)


class VerbError(Exception):
    def __init__(self, kind: str, message: str):
        if kind not in ERROR_KINDS:
            raise ValueError(f"unknown verb error kind: {kind!r}")
        super().__init__(message)
        self.kind = kind


def emit_ok(payload: dict[str, object]) -> int:
    clashes = sorted(_RESERVED & set(payload))
    if clashes:
        raise ValueError(f"verb payload uses reserved envelope keys: {clashes}")
    doc: dict[str, object] = {"schema_version": VERB_SCHEMA_VERSION, "ok": True}
    doc.update(payload)
    sys.stdout.write(json.dumps(doc, indent=2) + "\n")
    return 0


def emit_error(kind: str, message: str) -> int:
    doc = {
        "schema_version": VERB_SCHEMA_VERSION,
        "ok": False,
        "kind": kind,
        "error": message,
    }
    sys.stderr.write(json.dumps(doc, indent=2) + "\n")
    return 1


def run_verb(fn: Callable[[], dict[str, object]]) -> int:
    """Run one verb body and render its outcome.

    Catches `Exception`, not `BaseException`: a KeyboardInterrupt or SystemExit
    is the operator or the interpreter talking, and dressing either up as an
    environment fault would swallow a Ctrl-C.
    """
    try:
        return emit_ok(fn())
    except VerbError as exc:
        return emit_error(exc.kind, str(exc))
    except HostError as exc:
        return emit_error(exc.kind, str(exc))
    except Exception as exc:  # noqa: BLE001 - this boundary exists to swallow
        # `env` rather than a new kind: from the caller's side, a failure we did
        # not model is indistinguishable from the environment misbehaving. The
        # type name survives because it is the only actionable part.
        return emit_error("env", f"{type(exc).__name__}: {exc}")
