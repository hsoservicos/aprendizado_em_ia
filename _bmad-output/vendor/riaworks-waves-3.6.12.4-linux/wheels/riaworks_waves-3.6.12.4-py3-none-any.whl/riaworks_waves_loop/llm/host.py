"""The object graph a verb needs, rebuilt from a run dir.

A verb is a short-lived process: it opens the run, performs one primitive, and
exits. Run state therefore lives in `state.json` and never in a resident object,
and `mutate()` re-reads it under the lock so a host opened seconds ago cannot
write back over a change another verb has since landed.
"""

from __future__ import annotations

import contextlib
import json
from collections.abc import Iterator
from pathlib import Path

from .. import bmadconfig
from .. import policy as policy_mod
from ..bmadconfig import BmadConfigError, ProjectPaths
from ..journal import Journal, load_state, save_state
from ..model import RunState
from ..policy import Policy, PolicyError
from ..runs import RUNS_DIR, is_valid_run_id, latest_run_dir
from .lock import LockTimeout, state_run_lock


class HostError(Exception):
    """A host failure carrying one of the closed verb error kinds.

    The kind is what the caller routes on, so it is chosen at the raise site
    where the cause is still known — never re-derived from the message.
    """

    def __init__(self, kind: str, message: str):
        super().__init__(message)
        self.kind = kind


class LLMHost:
    """One run, opened for one verb's worth of work."""

    def __init__(
        self,
        *,
        project: Path,
        run_dir: Path,
        paths: ProjectPaths,
        policy: Policy,
        journal: Journal,
        state: RunState,
    ) -> None:
        self.project = project
        self.run_dir = run_dir
        self.paths = paths
        self.policy = policy
        self.journal = journal
        self.state = state

    @classmethod
    def open(cls, project: Path, run_id: str | None = None) -> "LLMHost":
        """Open a run by id, or the project's most recent one.

        Defaulting to the latest run is what lets the orchestrator call verbs
        without threading an id through every shell command; the supervisor knows
        the id and can always pass it explicitly.
        """
        project = Path(project).resolve()
        if run_id is None:
            run_dir, fault = latest_run_dir(project)
            if run_dir is None:
                # A listing that failed is not an empty one: "no runs" would send
                # the orchestrator looking for a run it cannot see, where the
                # environment is what needs repairing.
                if fault is not None:
                    raise HostError("env", fault)
                raise HostError("not-found", f"no runs under {project / RUNS_DIR}")
        else:
            if not is_valid_run_id(run_id):
                raise HostError("invalid-args", f"malformed run id: {run_id!r}")
            run_dir = project / RUNS_DIR / run_id
            if not (run_dir / "state.json").is_file():
                raise HostError("not-found", f"no such run: {run_id}")
        return cls(
            project=project,
            run_dir=run_dir,
            paths=_load_paths(project),
            policy=_load_policy(project),
            journal=Journal(run_dir),
            state=_load_state(run_dir),
        )

    def save(self) -> None:
        """Persist the state this host holds, without re-reading.

        For a caller that owns its own locking and already holds the authoritative
        state — the supervisor at run start and at crash. Verbs use `mutate()`.
        """
        save_state(self.run_dir, self.state)

    @contextlib.contextmanager
    def mutate(self) -> Iterator[RunState]:
        """Take the run-dir lock, re-read state, yield it, save on clean exit.

        Re-reading is the point rather than an optimization: this process may
        have been spawned while another verb was mid-write, so the snapshot taken
        at `open()` is already stale. A body that raises leaves the on-disk state
        untouched, so a failed verb never lands a partial mutation.
        """
        try:
            with state_run_lock(self.run_dir):
                self.state = _load_state(self.run_dir)
                yield self.state
                save_state(self.run_dir, self.state)
        except LockTimeout as exc:
            raise HostError("lock-timeout", str(exc)) from exc


def _load_state(run_dir: Path) -> RunState:
    try:
        state = load_state(run_dir)
    except (OSError, json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
        raise HostError("state-conflict", f"unreadable state.json in {run_dir}: {exc}") from exc
    _reabsolutize_specs(state)
    return state


def _reabsolutize_specs(state: RunState) -> None:
    """Restore `StoryTask.spec_file` to its in-memory form: absolute.

    The field is "absolute in memory and worktree-relative on disk"
    (`documents.spec_relpath`): `StoryTask.to_dict` persists it relative to the
    worktree so a kept run's state.json survives the worktree being moved, and
    never dangles into a pruned one. That makes the round-trip ASYMMETRIC —
    `from_dict` hands the relative form straight back — and whoever loads it owes
    the other half.

    The deterministic engine pays it when it reopens the unit
    (`worktree_flow._reopen_unit`). This loop had no equivalent moment, so every
    reader here got the relative path and resolved it against the ORCHESTRATOR's
    cwd — the shared checkout, where the story's spec is still the baseline. The
    review gate read `planned` off a story whose spec said `done`, and nothing a
    session did inside the worktree could move the file it was reading: a gate
    unpassable by construction rather than failing on the merits (DW-396).

    Only the relative-with-a-worktree case moves. An in-place run persists the
    path verbatim, and a spec that lives outside the worktree was already kept
    absolute by `to_dict` — re-rooting either would invent a path nobody wrote.
    """
    for task in state.tasks.values():
        if task.worktree_path:
            # The model's single implementation of the rule, which moves the
            # attempt-owned `dispatched_spec_file` together with `spec_file` — one
            # re-anchored and not the other would leave a task naming two trees.
            task.rebase_spec_paths_on(Path(task.worktree_path))


def _load_policy(project: Path) -> Policy:
    try:
        return policy_mod.load(project / policy_mod.POLICY_FILE)
    except (PolicyError, OSError) as exc:
        raise HostError("env", f"unreadable policy: {exc}") from exc


def _load_paths(project: Path) -> ProjectPaths:
    try:
        return bmadconfig.load_paths(project)
    except (BmadConfigError, OSError) as exc:
        raise HostError("env", f"unresolvable BMAD project layout: {exc}") from exc
