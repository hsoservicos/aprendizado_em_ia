"""The turn contract, and what the orchestrator is told when it is relaunched.

A turn is the life of one orchestrator session: prompt, N tool calls, the CLI's
turn-end. The normal turn is long — ideally a whole epic in one session, which is
the live context this whole design exists to buy. Relaunch is recovery (a crash,
a compaction, a timeout), not a cadence.

That is what makes the contract structural rather than bureaucratic: the journal
is the orchestrator's memory across relaunches. A session that dies mid-story is
only resumable if the previous one recorded *why* it decided what it decided. So
the one thing a turn owes is a written trace, and a turn that ends having written
nothing is indistinguishable from a turn that crashed on its first tool call.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from .. import namespace
from ..journal import JOURNAL_FILE, STATE_FILE
from ..model import RunState

#: How a turn ended, from the supervisor's side.
TERMINAL = "terminal"  # the run reached a state it should not be driven out of
PROGRESSED = "progressed"  # the turn wrote something; relaunch and carry on
VIOLATION = "violation"  # the turn wrote nothing at all

#: Journal entries carried into a relaunch digest. Enough to reconstruct the last
#: few decisions and their reasons; not so many that the digest competes with the
#: work for the session's context.
DIGEST_ENTRIES = 25


#: Journal kinds the supervisor writes itself, bracketing every turn. They are
#: excluded from the write check for a reason that is easy to miss: counting them
#: would have the supervisor measuring its own bookkeeping, so a turn that did
#: nothing at all would still read as productive and the contract would never
#: fire once.
SUPERVISOR_KINDS = frozenset(
    {
        "run-start",
        "run-stopped",
        "run-crash",
        "run-paused",
        # `llm-run --resume` writes this one before the first turn of a resumed
        # run. Supervisor bookkeeping like the rest: counting it would let the
        # act of resuming make the resumed run's first turn read as productive.
        "run-resume",
        "turn-start",
        "turn-end",
        "session-start",
        "session-end",
        # An operator intervention (`waves intervene`) is journalled
        # by whoever typed it, not by the orchestrator — so it is excluded for
        # the same reason the supervisor's own bookkeeping is. Counting it would
        # let a human talking to the session make a turn that wrote nothing read
        # as productive, which masks the one failure the violation budget exists
        # to catch: an orchestrator that is broken and cannot say so.
        "operator",
    }
)


@dataclass(frozen=True)
class TurnMark:
    """Where the run stood when a turn began.

    State is compared by size and mtime — it is replaced wholesale, so both
    together answer "did it move" without reading it. The journal is counted
    instead of measured, because only the entries the *orchestrator* wrote count
    as evidence that a turn did something.
    """

    orchestrator_entries: int
    state_size: int
    state_mtime_ns: int

    @classmethod
    def take(cls, run_dir: Path) -> "TurnMark":
        return cls(
            orchestrator_entries=_orchestrator_entries(run_dir),
            state_size=_size(run_dir / STATE_FILE),
            state_mtime_ns=_mtime_ns(run_dir / STATE_FILE),
        )

    def wrote_anything(self, run_dir: Path) -> bool:
        now = TurnMark.take(run_dir)
        return (
            now.orchestrator_entries != self.orchestrator_entries
            or now.state_size != self.state_size
            or now.state_mtime_ns != self.state_mtime_ns
        )


def _orchestrator_entries(run_dir: Path) -> int:
    """How many journal entries were written by something other than the
    supervisor. A malformed line counts as one: it came from somewhere, and
    refusing to count it would make a corrupt write look like silence."""
    try:
        lines = (run_dir / JOURNAL_FILE).read_text(encoding="utf-8").splitlines()
    except OSError:
        return 0
    total = 0
    for line in lines:
        if not line.strip():
            continue
        try:
            entry = json.loads(line)
        except json.JSONDecodeError:
            total += 1
            continue
        if not isinstance(entry, dict) or entry.get("kind") not in SUPERVISOR_KINDS:
            total += 1
    return total


def _size(path: Path) -> int:
    try:
        return path.stat().st_size
    except OSError:
        return 0


def _mtime_ns(path: Path) -> int:
    try:
        return path.stat().st_mtime_ns
    except OSError:
        return 0


def classify(state: RunState, mark: TurnMark, run_dir: Path, *, strict: bool) -> str:
    """What the supervisor should do about a turn that just ended.

    Terminal wins over everything: a turn that paused the run deliberately and
    then ended has done exactly what it should, and calling that a violation
    because state changed in the "wrong" way would punish the correct move.

    Under `strict = False` a silent turn is reported as progress and journalled
    instead — the same reading, without spending relaunch budget on it.
    """
    if state.finished or state.paused or state.stopped or state.crashed:
        return TERMINAL
    if mark.wrote_anything(run_dir):
        return PROGRESSED
    return VIOLATION if strict else PROGRESSED


def digest(
    run_dir: Path, state: RunState, *, violation: str = "", command: str = namespace.PRODUCT
) -> str:
    """Plain text handed to a relaunched orchestrator.

    Assembled from the run dir rather than remembered, and deliberately NOT the
    skill: the coding CLI loads that itself, and re-injecting it would spend the
    fresh session's context on instructions it already has. What it cannot have
    is what happened before it existed.
    """
    lines = [
        f"You are resuming run {state.run_id}. A previous orchestrator turn ended;",
        "this is the state it left behind. Read it, then continue from there.",
        "",
        f"run: {state.run_id}   source: {state.source}",
        # The command names THIS run's installation: the skill writes the verbs
        # with the bare name, and a bare name resolves through the session shell's
        # PATH — which may reach another installation (Supervisor._verb_command).
        f"verbs: {command} unit <verb> … — this run's own {namespace.PRODUCT}; a bare "
        f"`{namespace.PRODUCT}` from PATH may be another installation",
    ]
    if state.current_epic is not None:
        lines.append(f"current epic: {state.current_epic}")
    if state.epic_filter is not None or state.story_filter:
        lines.append(
            f"scope: epic={state.epic_filter} story={state.story_filter} "
            f"max_stories={state.max_stories}"
        )
    if state.plan:
        order = state.plan.get("story_order") or []
        lines.append(
            f"plan: {state.plan.get('scope')} ({state.plan.get('path')}) — "
            f"{len(order)} stories in wave order; `unit pick` follows it and names "
            "each story's wave and front"
        )

    lines.append("")
    if state.tasks:
        lines.append("stories this run has touched:")
        for key, task in state.tasks.items():
            detail = f"  {key}: {task.phase}"
            if task.attempt:
                detail += f" (attempt {task.attempt})"
            if task.defer_reason:
                detail += f" — deferred: {task.defer_reason}"
            lines.append(detail)
    else:
        lines.append("no story has been picked yet.")

    entries = _recent(run_dir)
    if entries:
        lines += ["", f"the last {len(entries)} journal entries, oldest first:"]
        for entry in entries:
            lines.append(f"  {_render(entry)}")

    if violation:
        lines += [
            "",
            "PROTOCOL VIOLATION on the previous turn: " + violation,
            "A turn that writes neither state nor journal cannot be told apart from",
            "one that crashed on its first call. Open by reading state, and record",
            "each decision and its reason as you make it.",
        ]

    lines += [
        "",
        "Continue. Do not restart work that is already on disk — the phases above",
        "and the journal say what has been done.",
    ]
    return "\n".join(lines)


def _recent(run_dir: Path, limit: int = DIGEST_ENTRIES) -> list[dict]:
    path = run_dir / JOURNAL_FILE
    try:
        raw = path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return []
    out: list[dict] = []
    for line in raw[-limit:]:
        try:
            parsed = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(parsed, dict):
            out.append(parsed)
    return out


@dataclass(frozen=True)
class Progress:
    """How an LLM-held run is doing, as a reader can see it from the run dir.

    Exists because none of this is visible in the deterministic run model the
    dashboard was built on: a `story` run has attempts and phases, an LLM-held
    one has turns and a relaunch budget, and a reader that only knows the first
    vocabulary shows an llm-run as if nothing were happening.
    """

    turns: int  # turns started, i.e. orchestrator sessions launched
    open_turn: bool  # a turn is running right now (started, not yet ended)
    last_verdict: str  # of the last CLOSED turn: terminal/progressed/violation, or ""
    violations: int  # consecutive violations at the end of the series
    quota: int  # limits.max_turn_relaunches this run was launched under


def progress(run_dir: Path, quota: int, limit: int = 0) -> Progress:
    """Read the turn record out of the journal.

    Consecutive violations are counted from the END backwards, because that is
    what the supervisor spends: a productive turn zeroes the count, so a total
    would overstate the budget consumed and raise an alarm that is already over.

    `limit` caps how many journal lines are read (0 = all). A turn record is
    cheap, but this runs on the dashboard's poll, and the file grows for the
    life of the run.
    """
    entries = _recent(run_dir, limit) if limit else _recent(run_dir, 10**9)
    turns = 0
    open_turn = False
    verdicts: list[str] = []
    for entry in entries:
        kind = entry.get("kind")
        if kind == "turn-start":
            turns += 1
            open_turn = True
        elif kind == "turn-end":
            open_turn = False
            verdicts.append(str(entry.get("verdict") or ""))
    violations = 0
    for verdict in reversed(verdicts):
        if verdict != VIOLATION:
            break
        violations += 1
    return Progress(
        turns=turns,
        open_turn=open_turn,
        last_verdict=verdicts[-1] if verdicts else "",
        violations=violations,
        quota=quota,
    )


def _render(entry: dict) -> str:
    """One journal entry as a line, with the reasoning kept and the plumbing
    dropped. `why` and `reason` lead because they are the part a relaunched
    session cannot reconstruct from anything else."""
    kind = entry.get("kind", "?")
    parts = []
    for key in ("story_key", "task_id", "status", "to", "why", "reason", "summary", "next"):
        value = entry.get(key)
        if value:
            parts.append(f"{key}={value}")
    return f"{kind} " + " ".join(parts) if parts else str(kind)
