"""Launching a session and handing the wait to a watcher.

`GenericAdapter.wait_for_completion` is not a sleep. It holds the stall-nudge
budget, the mid-session token guard, spec-status sampling, env-fault
classification and the post-kill reconcile — all in process memory. A dispatch
that launched and returned would destroy that state, and the caller would be left
reimplementing it in a worse form from artifacts.

So the wait runs in a detached watcher: same `wait_for_completion`, in its own
process, writing the settled outcome where the caller can read it. The dispatch
returns as soon as the session is up.

The watcher is a subprocess rather than a fork. `os.fork` does not exist on
Windows, and this tool runs there; a small serialized handover buys portability
at the cost of one JSON file.
"""

from __future__ import annotations

import json
import subprocess
import sys
from dataclasses import asdict
from pathlib import Path

from ..adapters.base import CodingCLIAdapter, SessionHandle, SessionSpec
from ..platform_util import detach_kwargs
from ..policy import Policy
from ..runsetup import ROLES, make_adapters
from .host import LLMHost
from .result import VerbError

#: What the watcher needs to reconstruct the wait. Written by the dispatch,
#: consumed by the watcher, kept afterwards as the record of what was launched.
HANDOVER_FILE = "watch.json"


def _sharing_role(adapters: dict[str, CodingCLIAdapter], policy: Policy, role: str) -> str | None:
    """The bootstrap role whose client ``role`` resolves to, or None when none of
    the built roles drives that client. First match in ROLES order — the order
    :func:`adapter_for_role` has always searched in, so the object a same-client
    role shares does not move."""
    wanted = policy.adapter.resolved(role).name
    for built in ROLES:
        if built in adapters and policy.adapter.resolved(built).name == wanted:
            return built
    return None


def adapter_for_role(
    adapters: dict[str, CodingCLIAdapter], policy: Policy, role: str
) -> CodingCLIAdapter:
    """The adapter object a role should run on: its own when one was built for
    it, else the built role's whose client it resolves to, matched BY RESOLVED
    NAME.

    Never aliased to dev's object on the assumption the two agree. A
    `[adapter.<role>]` table that names no client inherits the top-level
    `[adapter]` name, so the moment `[adapter.dev]` points at a different client
    than the base, aliasing hands the role dev's binary while
    `policy.adapter.resolved(role)` still describes the base one — the session
    launches one client carrying another's model name, and fails on the first
    real attempt with nothing in the config to explain it.

    A role matching none of the built clients is REFUSED, as an `env` fault
    naming the role and the client. It used to fall back to dev's object — "a gap
    rather than a decision" — and the gap was reachable from one line of policy:
    base `claude`, `[adapter.orchestrator] name = "gemini"`, and the orchestrator
    started in `claude --model <gemini model>`. The caller that can close it is
    :func:`build_adapters`, which builds a role on its own client when asked to;
    reaching this raise means a dispatching call site did not name its role.
    """
    if role in adapters:
        return adapters[role]
    shared = _sharing_role(adapters, policy, role)
    if shared is not None:
        return adapters[shared]
    wanted = policy.adapter.resolved(role).name
    raise VerbError(
        "env",
        f"no adapter built for role {role!r}: it resolves to client {wanted!r}, which "
        f"none of the built roles ({', '.join(sorted(adapters))}) drives — "
        f"build_adapters(host, {role!r}) builds one",
    )


def _handover_path(run_dir: Path, task_id: str) -> Path:
    return run_dir / "tasks" / task_id / HANDOVER_FILE


def write_handover(
    run_dir: Path,
    task_id: str,
    handle: SessionHandle,
    spec: SessionSpec,
    workflow: dict[str, object] | None = None,
    adapter: str = "",
) -> Path:
    """Record what the watcher must reattach to.

    `spec_snapshot` is dropped: it is process-transient by design (the engine
    documents it as not persisted), and a watcher that revived a stale one would
    hand the adapter a fingerprint of a file that has since moved on.

    `workflow` names the plugin workflow this session IS, when it is one —
    `{"plugin", "workflow", "stage", "story_key"}` plus `"epic"` at a boundary.
    The watcher is the process alive when the session settles, so it is the one
    that can close the engine's own `workflow-start` / `workflow-end` pair and
    stamp a boundary step `done`/`failed`; without this record it would only know
    it watched a session with a label.

    `adapter` is the resolved adapter's name — with `spec.model`, the identity the
    session record is stamped with once it settles (:func:`read_handover_identity`).
    """
    payload: dict[str, object] = {
        "handle": asdict(handle),
        "spec": {k: v for k, v in asdict(spec).items() if k != "spec_snapshot"},
    }
    payload["spec"]["cwd"] = str(spec.cwd)  # type: ignore[index]
    if workflow is not None:
        payload["workflow"] = dict(workflow)
    if adapter:
        payload["adapter"] = adapter
    path = _handover_path(run_dir, task_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")
    return path


def read_handover(run_dir: Path, task_id: str) -> tuple[SessionHandle, SessionSpec]:
    path = _handover_path(run_dir, task_id)
    payload = json.loads(path.read_text(encoding="utf-8"))
    spec_fields = dict(payload["spec"])
    spec_fields["cwd"] = Path(spec_fields["cwd"])
    return SessionHandle(**payload["handle"]), SessionSpec(**spec_fields)


def read_handover_workflow(run_dir: Path, task_id: str) -> dict[str, object] | None:
    """The plugin-workflow record a dispatch left in the handover, or None for a
    plain dev/review/triage session (and for a handover written before the
    record existed — the absent key reads as "not a workflow", never as an
    error, so an old run's watcher keeps settling its sessions)."""
    path = _handover_path(run_dir, task_id)
    payload = json.loads(path.read_text(encoding="utf-8"))
    workflow = payload.get("workflow")
    return dict(workflow) if isinstance(workflow, dict) else None


def read_handover_identity(run_dir: Path, task_id: str) -> tuple[str, str]:
    """The `(adapter, model)` a dispatch launched this session on — the identity the
    engine stamps on every `SessionRecord` it writes, and the one the dashboard's
    agent column and `diagnose` read once the session is no longer live.

    `("", "")` for a handover written before the identity was recorded: the record's
    documented meaning for an empty adapter is "predates identity stamping", which is
    exactly what that session is. An unreadable handover raises, as
    :func:`read_handover` does — the caller decides how loud that is."""
    payload = json.loads(_handover_path(run_dir, task_id).read_text(encoding="utf-8"))
    adapter = payload.get("adapter")
    if not isinstance(adapter, str) or not adapter:
        return "", ""
    spec = payload.get("spec")
    model = spec.get("model") if isinstance(spec, dict) else None
    return adapter, model if isinstance(model, str) else ""


def spawn_watcher(host: LLMHost, task_id: str) -> int:
    """Start the detached watcher for a launched session, returning its pid.

    Detached deliberately: the dispatch verb exits within milliseconds, and a
    watcher tied to it would die with it, leaving a live session nobody is
    waiting on and no outcome ever written.
    """
    argv = [sys.executable, "-m", "riaworks_waves_loop.llm.watcher", str(host.run_dir), task_id]
    kwargs: dict[str, object] = {
        "cwd": str(host.project),
        "stdin": subprocess.DEVNULL,
        "stdout": subprocess.DEVNULL,
        "stderr": subprocess.DEVNULL,
        **detach_kwargs(),
    }
    try:
        return subprocess.Popen(argv, **kwargs).pid  # type: ignore[arg-type]
    except OSError as exc:
        raise VerbError("env", f"could not start the session watcher: {exc}") from exc


def build_own_adapter(host: LLMHost, role: str) -> CodingCLIAdapter:
    """An adapter built for ``role`` alone, from its own resolved table, never
    shared with a bootstrap role on the same client.

    For a session that must not complete on another role's contract. Sharing is
    right for a plugin workflow role (its completion marker is found by the dev
    adapter's artifact read-back), and wrong for the orchestrator. On the common
    single-client policy, sharing handed the orchestrator dev's synthesizing
    adapter, whose Stop completes only when a spec newer than the launch carries a
    result. A turn that dispatched no dev, such as a retrospective-only run end, met
    a resultless Stop. Under upstream 0.13's parked rule it was not nudged, so it
    waited out the whole stall grace. MEASURED 2026-10-03: ten minutes after
    `unit finish`.

    Built with the role's own name, a non-dev role gets the family's result-file
    adapter: its Stop completes on the skill-written `tasks/<task_id>/result.json`,
    as a triage or retrospective session's does."""
    try:
        return make_adapters(host.project, host.run_dir, host.policy, roles=(role,))[role]
    except SystemExit as exc:  # make_adapters aborts on an unresolvable profile
        raise VerbError("env", f"adapter setup failed: {exc}") from exc


def build_adapters(host: LLMHost, *roles: str) -> dict[str, CodingCLIAdapter]:
    """The bootstrap's adapters (one per ROLES entry), plus one for each extra
    ``role`` the caller is about to run that no bootstrap role's client covers.

    An extra role — the `llm-run` orchestrator, a plugin workflow role — resolves
    its own `[adapter.<role>]` table, and the object it runs on is picked BY
    RESOLVED CLIENT. A role whose client one of the built roles already drives
    shares that object (:func:`adapter_for_role` finds it by name; the
    session-shape knobs travel with the client, and a second object for the same
    binary would only duplicate transport state — this is the pre-fix behaviour
    for the common single-client policy, kept on purpose). A role on a client
    NONE of them drives gets its own adapter, built by a second `make_adapters`
    pass naming only the missing roles, from its own resolved config. It used to
    be handed dev's object instead — the binary of one client launched carrying
    the model of another.

    Callers that dispatch, steer or wait on a session name its role; the
    WorktreeFlow consumer names none and keeps getting exactly the bootstrap set,
    which its seeding contract is keyed on.
    """
    policy = host.policy
    try:
        adapters = make_adapters(host.project, host.run_dir, policy)
        missing = tuple(
            role
            for role in dict.fromkeys(roles)
            if role not in adapters and _sharing_role(adapters, policy, role) is None
        )
        if missing:
            adapters.update(make_adapters(host.project, host.run_dir, policy, roles=missing))
    except SystemExit as exc:  # make_adapters aborts on an unresolvable profile
        raise VerbError("env", f"adapter setup failed: {exc}") from exc
    return adapters
