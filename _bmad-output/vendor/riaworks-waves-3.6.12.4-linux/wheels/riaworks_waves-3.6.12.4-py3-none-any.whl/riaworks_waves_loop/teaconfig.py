"""Single source of truth for the TEA integration: where its artifacts live, how
they are attributed to a scope, and what this tool manages inside ``_bmad/``.

Three facts shaped every decision here.

**The BMAD Method's TEA skills write to fixed names.** ``bmad-testarch-nfr`` emits
``nfr-assessment.md``, ``-trace`` emits ``traceability-matrix.md`` +
``gate-decision.json`` + ``e2e-trace-summary.json``, ``-test-review`` emits
``test-review.md`` — all directly under the configured ``test_artifacts``
directory, with nothing in the name saying which story or epic they are about. Run
per story they already overwrite each other; run in two cadences at once (a story
gate and an epic report) they would collide outright, and a gate reading "the most
recent file" would happily veto a commit on the previous epic's verdict.

**Their output path is not configurable.** Of the six TEA skills, five expose only
the standard quartet (``activation_steps_prepend`` / ``_append``,
``persistent_facts``, ``on_complete``); only ``bmad-testarch-test-review`` adds
``output_file_override``, and even that is a scalar with no story token, so it
cannot express "one directory per unit". Asking for a path in the prompt is
likewise not a contract — it is prose the session may or may not follow.

**So attribution is measured, not requested.** :meth:`TeaLayout.snapshot` records
the artifacts directory before a step's session launches and
:meth:`TeaLayout.claim` diffs it afterwards: whatever appeared or changed IS that
step's output, whatever the session chose to name it. The delta is copied — never
moved — into a scope-addressed directory this module computes, so a project's own
CI keeps finding the file where TEA put it while the gate reads a copy that cannot
be confused with another unit's. A path that is *calculated* is a path a test can
assert; a glob over "the newest match" passes for reasons that have nothing to do
with correctness.

What this module deliberately does NOT decide: where a project keeps executable
tests. That belongs to the skill's own ``workflow.yaml`` (``test_dir``) and to the
project, and the managed customization below only restates the BMAD Method's own
separation — executables to the suite, reports to ``test_artifacts`` — without
naming a single path.
"""

from __future__ import annotations

import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from . import namespace
from .checks import Finding
from .platform_util import atomic_write_text

# TEA's presence marker and its config. Reading this file is how every surface
# (the plugin's readiness gate, `validate`, the TUI) agrees on whether the BMAD
# Method's Test Architect module is installed at all.
TEA_CONFIG_REL = Path("_bmad") / "tea" / "config.yaml"

# Where the BMAD Method reads a project's per-skill overrides from. `<skill>.toml`
# is the team layer (versioned, ours to manage); `<skill>.user.toml` is personal
# and is NEVER written or read by this module.
CUSTOMIZE_DIR = Path("_bmad") / "custom"

# The installer default, used when `test_artifacts:` cannot be read. Same literal
# the BMAD Method's own installer writes.
DEFAULT_TEST_ARTIFACTS = "{project-root}/_bmad-output/test-artifacts"

# Our subtree inside whatever `test_artifacts` resolves to. One directory, so a
# project that wants TEA's own output untouched can ignore exactly this path, and
# `git clean` semantics stay obvious.
NAMESPACE = namespace.MODULE_CODE

# The header that marks a customization file as managed by this tool. A file
# under CUSTOMIZE_DIR that does NOT open with it belongs to the project: we read
# it, we report on it, we never overwrite it. This is the same doctrine
# `install.merge_hooks` applies to a coding CLI's hook config, minus the merge —
# a TOML document with a foreign block cannot be edited in place without a
# round-trip that would reorder the author's file.
MANAGED_HEADER = f"# managed by {namespace.PRODUCT} init — remove this line to take ownership"

# The rule the atdd/automate steps need in force, phrased as a fact rather than a
# path. It restates the separation the skills' own workflow.yaml already encodes
# (`test_dir` for executables, `default_output_file` for the checklist), which is
# why it is safe to ship to every project: it names no directory, no framework and
# no suite command.
_TEST_LOCATION_FACT = (
    "An executable test file belongs where this project's own suite already keeps its "
    "tests — the directory this skill's workflow.yaml resolves as test_dir. Only "
    "reports, matrices and checklists belong under the configured test_artifacts "
    "directory: a spec that lives outside the suite is run by no gate."
)

# Which skills get a managed customization, and the facts each one carries. Only
# the two steps that WRITE executable code are listed — a report-only skill has
# nothing to get wrong about test location, and a managed file with nothing to say
# is a file a project has to reason about for no reason.
MANAGED_FACTS: dict[str, tuple[str, ...]] = {
    "bmad-testarch-atdd": (_TEST_LOCATION_FACT,),
    "bmad-testarch-automate": (_TEST_LOCATION_FACT,),
}

# Every artifact a gate step may leave, by step name. These are the BMAD Method's
# own fixed output names, and they are used for RECOGNITION (which of the claimed
# files carries the verdict), never for discovery — discovery is the snapshot
# diff. `trace` lists its JSON first because it emits `gate_status` for exactly
# this purpose, and the markdown matrix is the fallback.
GATE_ARTIFACTS: dict[str, tuple[str, ...]] = {
    "trace": ("gate-decision.json", "e2e-trace-summary.json", "traceability-matrix.md"),
    "nfr": ("nfr-assessment.md",),
    "test-review": ("test-review.md",),
}

ScopeKind = Literal["story", "epic"]


@dataclass(frozen=True)
class Scope:
    """What a TEA step was run ABOUT: one story, or one whole epic.

    ``ident`` is the story key or the epic number as a string. Both are already
    path-safe in every shape the orchestrator produces (story keys are
    ``<epic>-<n>-<slug>``), and :meth:`rel` refuses anything that is not — a
    traversal here would write outside the artifacts tree.
    """

    kind: ScopeKind
    ident: str

    def rel(self) -> Path:
        """This scope's directory, relative to the namespace root."""
        ident = self.ident.strip()
        if not ident or "/" in ident or "\\" in ident or ident.startswith("."):
            raise ValueError(
                f"unusable {self.kind} identifier for an artifact path: {self.ident!r}"
            )
        return Path(self.kind) / ident

    @classmethod
    def for_story(cls, story_key: str) -> "Scope":
        return cls("story", story_key)

    @classmethod
    def for_epic(cls, epic: int | str) -> "Scope":
        return cls("epic", str(epic))


@dataclass(frozen=True)
class TeaLayout:
    """Where TEA writes in one checkout, and where we keep our scoped copies.

    Built per call rather than cached: under worktree isolation each unit has its
    own root, and a layout resolved against the main checkout would attribute a
    worktree's artifacts to the wrong tree.
    """

    root: Path
    test_artifacts: Path
    installed: bool

    @property
    def namespace_dir(self) -> Path:
        return self.test_artifacts / NAMESPACE

    def scope_dir(self, scope: Scope) -> Path:
        """The calculated home of one scope's artifacts. No glob, no mtime, no
        "most recent" — the same inputs always name the same directory, which is
        what makes the gate's read assertable in a test."""
        return self.namespace_dir / scope.rel()

    # ------------------------------------------------------------- attribution

    def snapshot(self) -> dict[str, tuple[int, int]]:
        """``{relative path: (mtime_ns, size)}`` for every file TEA's artifacts
        directory holds right now, excluding our own namespace.

        Our namespace is excluded because a claim writes into it: including it
        would make each step's delta contain the previous step's copies, and every
        gate would then read an artifact its sibling produced. An unreadable or
        absent directory yields ``{}`` — a missing measurement is reported by the
        caller as "nothing claimed", never guessed at.
        """
        out: dict[str, tuple[int, int]] = {}
        base = self.test_artifacts
        if not base.is_dir():
            return out
        namespace = self.namespace_dir
        for path in base.rglob("*"):
            try:
                if not path.is_file():
                    continue
                if namespace == path or namespace in path.parents:
                    continue
                stat = path.stat()
                out[path.relative_to(base).as_posix()] = (stat.st_mtime_ns, stat.st_size)
            except OSError:
                continue  # a file that vanished mid-walk is simply not in the baseline
        return out

    def claim(self, scope: Scope, before: dict[str, tuple[int, int]]) -> tuple[Path, ...]:
        """Copy everything that appeared or changed since ``before`` into
        ``scope``'s directory, and return the copies' paths.

        COPY, never move: a project's own CI, its scripts and TEA's own resume
        modes read these files where TEA put them, and relocating an artifact to
        suit our bookkeeping would break a contract we do not own. The duplicate
        is small (reports and JSON summaries) and is the only copy any gate reads.

        Best-effort per file: an unreadable source or an undeletable destination
        skips that file and keeps the rest, because a half-claimed step still lets
        the gate read the artifacts it did get, while raising would fail a boundary
        over a copy.
        """
        after = self.snapshot()
        changed = sorted(rel for rel, sig in after.items() if before.get(rel) != sig)
        if not changed:
            return ()
        target = self.scope_dir(scope)
        claimed: list[Path] = []
        for rel in changed:
            source = self.test_artifacts / rel
            # Flattened onto the file's basename: the scope directory IS the
            # namespacing, and preserving TEA's own subdirectories under it would
            # put `traceability/gate-decision.json` and `gate-decision.json` in two
            # places a gate would have to search — the exact discovery problem this
            # layout exists to remove.
            destination = target / Path(rel).name
            try:
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, destination)
            except OSError:
                continue
            claimed.append(destination)
        return tuple(claimed)

    def gate_artifacts(self, step: str, scope: Scope) -> tuple[Path, ...]:
        """The claimed artifacts that may carry ``step``'s verdict, in probe
        order. Existence is not checked here — the caller distinguishes "absent"
        (fail-open) from "present but unparseable" (also fail-open, but a
        different journal line)."""
        directory = self.scope_dir(scope)
        return tuple(directory / name for name in GATE_ARTIFACTS.get(step, ()))


def load(root: Path) -> TeaLayout:
    """Resolve TEA's layout for ``root``.

    Never raises: a project without TEA gets ``installed=False`` and the installer
    default path, because every caller here has a defined behaviour for "TEA is not
    installed" and none of them is helped by an exception (the readiness gate wants
    to phrase its own message; the gate wants to fail open).
    """
    config = root / TEA_CONFIG_REL
    installed = config.is_file()
    value = DEFAULT_TEST_ARTIFACTS
    try:
        for raw in config.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if line.startswith("test_artifacts:"):
                value = line.split(":", 1)[1].strip().strip("\"'") or DEFAULT_TEST_ARTIFACTS
                break
    except OSError:
        pass  # fall through to the installer default
    expanded = value.replace("{project-root}", str(root)).replace(
        "{output_folder}", str(root / "_bmad-output")
    )
    path = Path(expanded)
    return TeaLayout(
        root=root,
        test_artifacts=path if path.is_absolute() else root / expanded,
        installed=installed,
    )


# ------------------------------------------------------------- customizations


@dataclass(frozen=True)
class ManagedCustomization:
    """One ``_bmad/custom/<skill>.toml`` this tool writes and keeps current."""

    skill: str
    rel_path: Path
    body: str

    def is_ours(self, root: Path) -> bool | None:
        """True when the file on disk is ours to rewrite, False when it belongs to
        the project, None when it is absent or unreadable."""
        path = root / self.rel_path
        try:
            return path.read_text(encoding="utf-8").startswith(MANAGED_HEADER)
        except OSError:
            return None

    def current(self, root: Path) -> str | None:
        try:
            return (root / self.rel_path).read_text(encoding="utf-8")
        except OSError:
            return None


def _render(skill: str, facts: tuple[str, ...]) -> str:
    lines = [
        MANAGED_HEADER,
        f"# Project overrides for the BMAD Method skill `{skill}`, resolved by",
        "# _bmad/scripts/resolve_customization.py on every activation of it.",
        "#",
        "# Personal overrides belong in the sibling .user.toml, which this tool",
        "# never reads or writes.",
        "",
        "[workflow]",
        "persistent_facts = [",
    ]
    for fact in facts:
        # TOML basic strings: the facts are plain prose, so escaping quotes and
        # backslashes covers every character they can contain.
        escaped = fact.replace("\\", "\\\\").replace('"', '\\"')
        lines.append(f'  "{escaped}",')
    lines.append("]")
    return "\n".join(lines) + "\n"


def managed_customizations() -> tuple[ManagedCustomization, ...]:
    """Every customization file this tool owns, in a stable order."""
    return tuple(
        ManagedCustomization(skill, CUSTOMIZE_DIR / f"{skill}.toml", _render(skill, facts))
        for skill, facts in sorted(MANAGED_FACTS.items())
    )


def write_customizations(root: Path) -> list[Finding]:
    """Write (or refresh) the managed customization files. Idempotent.

    A file the project owns — present without :data:`MANAGED_HEADER` — is left
    exactly as it is and reported, because a project that took ownership of a
    skill's overrides has made a decision this tool must not silently reverse.
    """
    findings: list[Finding] = []
    for managed in managed_customizations():
        path = root / managed.rel_path
        owned = managed.is_ours(root)
        if owned is False:
            findings.append(
                Finding(
                    "tea.customization-foreign",
                    "warning",
                    f"{managed.rel_path.as_posix()} is maintained by this project "
                    f"(no managed header) — left untouched; the test-location fact for "
                    f"`{managed.skill}` is yours to keep in it",
                    {"skill": managed.skill, "path": managed.rel_path.as_posix()},
                )
            )
            continue
        if managed.current(root) == managed.body:
            continue
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            atomic_write_text(path, managed.body)
        except OSError as e:
            findings.append(
                Finding(
                    "tea.customization-unwritable",
                    "problem",
                    f"could not write {managed.rel_path.as_posix()}: {e}",
                    {"skill": managed.skill, "path": managed.rel_path.as_posix()},
                )
            )
            continue
        findings.append(
            Finding(
                "tea.customization",
                "ok",
                f"customization written: {managed.rel_path.as_posix()}",
                {"skill": managed.skill, "path": managed.rel_path.as_posix()},
            )
        )
    return findings


def check(root: Path) -> list[Finding]:
    """Revalidate the TEA configuration surface. Read-only.

    Called by ``validate``, by the plugin's readiness gate at startup, and again
    before each injected step — the BMAD Method re-resolves a skill's
    customization on every activation, and a configuration this tool wrote at
    install time is worth exactly as much as the last time something confirmed it
    is still there.
    """
    findings: list[Finding] = []
    layout = load(root)
    if not layout.installed:
        findings.append(
            Finding(
                "tea.module",
                "warning",
                f"the BMAD Method's Test Architect (TEA) module is not installed "
                f"(missing {TEA_CONFIG_REL.as_posix()}) — the TEA steps have nothing to invoke; "
                f"the {namespace.PLUGIN_TEA} plugin stays inert until it is (install it with "
                "`npx bmad-method install`, or set [plugins] enabled = [] to opt out)",
                {"config": TEA_CONFIG_REL.as_posix()},
            )
        )
        return findings
    findings.append(
        Finding(
            "tea.module",
            "ok",
            f"TEA installed: artifacts at {layout.test_artifacts}",
            {"test_artifacts": str(layout.test_artifacts)},
        )
    )
    for managed in managed_customizations():
        owned = managed.is_ours(root)
        rel = managed.rel_path.as_posix()
        if owned is None:
            findings.append(
                Finding(
                    "tea.customization-missing",
                    "warning",
                    f"{rel} is missing — run `{namespace.PRODUCT} init` to restore the "
                    f"test-location fact for `{managed.skill}`",
                    {"skill": managed.skill, "path": rel},
                )
            )
        elif owned is False:
            findings.append(
                Finding(
                    "tea.customization-foreign",
                    "warning",
                    f"{rel} is maintained by this project (no managed header) — "
                    f"not checked further",
                    {"skill": managed.skill, "path": rel},
                )
            )
        elif managed.current(root) != managed.body:
            findings.append(
                Finding(
                    "tea.customization-stale",
                    "warning",
                    f"{rel} was written by an older version of this tool — "
                    f"run `{namespace.PRODUCT} init` to refresh it",
                    {"skill": managed.skill, "path": rel},
                )
            )
        else:
            findings.append(
                Finding("tea.customization", "ok", f"customization current: {rel}", {"path": rel})
            )
    return findings
