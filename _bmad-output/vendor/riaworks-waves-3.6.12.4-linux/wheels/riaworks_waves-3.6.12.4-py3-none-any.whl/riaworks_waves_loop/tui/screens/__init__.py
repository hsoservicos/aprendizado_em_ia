"""Dashboard, modal, and settings screens for the waves TUI."""
