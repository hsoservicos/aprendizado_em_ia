"""``python -m riaworks_waves_loop`` entry point — delegates to the console-script main().

Mirrors the ``if __name__ == "__main__"`` guard at the foot of ``cli.py`` so the
module form and the installed ``waves`` script share one dispatch path.
"""

import sys

from riaworks_waves_loop.cli import main

if __name__ == "__main__":
    sys.exit(main())
