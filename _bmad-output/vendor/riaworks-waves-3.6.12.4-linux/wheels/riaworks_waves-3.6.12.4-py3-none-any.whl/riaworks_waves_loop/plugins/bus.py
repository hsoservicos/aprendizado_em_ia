"""HookBus: dispatch lifecycle stages to plugin hooks (declarative + python).

The bus is the single fan-out point between the engine's stages and the loaded
plugins. It enforces the two invariants that keep plugins safe:

  * **No-op fast path.** ``active(stage)`` is an O(1) set membership test
    precomputed at build time. A run with no plugin bound to a stage never
    builds a context or calls ``emit`` — zero-plugin runs stay byte-identical.
  * **Failure isolation.** Every hook — subprocess or in-process Python — is
    wrapped. A python hook that raises is caught (``except Exception`` only;
    ``RunStopped``/SIGTERM as ``BaseException`` propagate), journalled, and the
    offending instance disabled for the rest of the run. A declarative hook that
    errors (timeout, bad interpreter) fails open by default (the run survives);
    ``fail_closed`` turns an error into a defer veto.
  * **Stop-aware declarative hooks** (DW-353). Declarative hooks run through
    :func:`riaworks_waves_loop.childrun.run_child`, which kills the hook's whole process
    tree on a timeout or a pending HARD stop request. An interrupted hook is
    neither an error nor a veto: the bus journals ``plugin-hook-interrupted``
    and re-raises :class:`~riaworks_waves_loop.childrun.ChildInterrupted`, which the
    engine turns into a hard stop (``RunStopped``) — even under ``fail_closed``.

Dispatch order is registry order (manifest ``priority`` then load order).
Mutations pipeline — a later plugin sees an earlier plugin's edits. Vetoes are
collected without short-circuit so order can never hide a severer objection;
the context resolves the most-conservative one.
"""

from __future__ import annotations

import json
import os
from typing import Any, Callable

from .. import envvars
from ..childrun import ChildInterrupted, run_child
from .context import MUTABLE_FIELDS, VETO_ACTIONS, HookContext, Veto
from .model import LoadedPlugin
from .registry import PluginRegistry

# (returncode, combined-output) — the declarative-hook transport. Injectable so
# tests can drive the bus without spawning real subprocesses.
HookRunner = Callable[..., "tuple[int, str]"]

# (title, message) — how the bus reaches a human. Same shape as the tail of
# `gates.notify`, so an embedder can pass a closure over it without this module
# importing gates or holding run state.
Notifier = Callable[[str, str], None]

# Shell exit codes that mean the command NEVER RAN, so the rc carries no verdict
# from the hook itself. POSIX-conventional and emitted by the shell, not by the
# script: 127 when the program cannot be found, 126 when it is found but cannot
# be executed — no execute bit, or an unresolvable `#!` line. A CRLF line ending
# lands squarely here: `#!/usr/bin/env bash\r` sends env looking for an
# interpreter literally named "bash\r", and the hook dies before its first line.
_HOOK_NEVER_RAN = {
    126: "found but not executable (permissions, or an unresolvable shebang — check for CRLF)",
    127: "command not found",
}


class _HookError(Exception):
    """A declarative hook could not run to completion (timeout / launch failure),
    as distinct from a clean non-zero exit. Decides fail-open vs fail-closed."""


def _run_subprocess(
    cmd: str, *, cwd: str | None, env: dict[str, str], timeout: int
) -> tuple[int, str]:
    """Default declarative-hook transport: a shell command with the plugin env,
    capturing output, run through the stop-aware :func:`run_child` (DW-353) — the
    same seam as the deterministic verify commands, so a timeout or a pending hard
    stop kills the hook's whole process tree. An interrupted hook raises
    :class:`ChildInterrupted`, deliberately not ``_HookError``: a hard stop is not
    a hook failure and must never become a fail-closed veto.

    Output decodes with ``errors="replace"`` (#383): a hook's output is arbitrary
    operator-tool text whose bytes are not ours to constrain, and a strict decode
    raised ``UnicodeDecodeError`` — a ``ValueError``, named by neither ``except``
    arm below — which escaped ``_HookError``, the bus's designed
    transport-failure channel, and crashed the run, losing even a passing hook's
    exit code. Same fix and reasoning as ``verify.run_verify_commands`` (#378)."""
    try:
        child = run_child(cmd, cwd=cwd, env=env, timeout=timeout)
    except OSError as e:
        raise _HookError(str(e)) from e
    if child.interrupted:
        raise ChildInterrupted(f"hook interrupted by a hard stop request: {cmd}")
    if child.timed_out or child.returncode is None:
        raise _HookError(f"timed out after {timeout}s")
    return child.returncode, child.stdout + child.stderr


class OperatorCommandError(Exception):
    """An operator-authored command could not run to completion: a timeout, or a
    shell/interpreter that never launched. Public sibling of the bus's own
    transport failure, for the callers outside the bus that run such commands."""


def run_operator_command(
    cmd: str, *, cwd: str | None, env: dict[str, str], timeout: int
) -> tuple[int, str]:
    """The one shell-out for operator-authored commands outside the hook bus —
    the provisioning contract's `[scm] provision` / `teardown` — on the exact
    transport declarative hooks use, so a timeout or a missing interpreter is a
    typed failure here as it is there, never a crash."""
    try:
        return _run_subprocess(cmd, cwd=cwd, env=env, timeout=timeout)
    except _HookError as exc:
        raise OperatorCommandError(str(exc)) from exc


def _instance_stages(instance: Any) -> set[str]:
    """The stages an in-process plugin handles: every ``on_<stage>`` method it
    defines. Lets ``active()`` stay precise — a python plugin only marks the
    stages it actually implements, so the fast path holds for the rest."""
    return {
        name[3:]
        for name in dir(instance)
        if name.startswith("on_") and callable(getattr(instance, name, None))
    }


def _hook_env(ctx: HookContext, lp: LoadedPlugin) -> dict[str, str]:
    """The ``WAVES_*`` environment a declarative hook reads — the run's
    identity fields plus the plugin's resolved settings as ``WAVES_SETTING_*``.
    Generalizes ``engine._run_engine_hook``'s env block to any plugin/stage."""
    env = dict(os.environ)
    fields = {
        envvars.STAGE: ctx.stage,
        envvars.RUN_ID: ctx.run_id,
        envvars.RUN_DIR: ctx.run_dir or "",
        envvars.REPO_ROOT: ctx.repo_root or "",
        envvars.WORKTREE: ctx.worktree or ctx.repo_root or "",
        envvars.STORY_KEY: ctx.story_key or "",
        # `ctx.epic` arrives populated (the engine passes the finished epic at a
        # boundary, and the task's epic per story) but used not to be exported,
        # so a declarative hook had to RECONSTRUCT a number the engine already
        # held — typically by re-reading the sprint status and guessing, which
        # answers "unknown" precisely when the engine was certain.
        # Explicit `is None`, never `or ""`: epic 0 is valid and `0 or ""` would
        # collapse it to the empty string the filter below drops.
        envvars.EPIC: "" if ctx.epic is None else str(ctx.epic),
        envvars.ROLE: ctx.role or "",
        envvars.PHASE: ctx.phase or "",
        envvars.BRANCH: ctx.branch or "",
        envvars.AGENTS: ",".join(ctx.agents),
        # at-least-once stages only (post_migrate); the consumer's dedup key
        envvars.DELIVERY_ID: ctx.delivery_id or "",
        # post_rollback only (DW-322): completed | paused | failed
        envvars.ROLLBACK_OUTCOME: ctx.rollback_outcome or "",
        envvars.PLUGIN: lp.name,
    }
    env.update({k: v for k, v in fields.items() if v != ""})
    # the plugin's *resolved* settings (defaults overlaid by [plugins.<name>]),
    # not bare manifest defaults, so a declarative hook sees the operator's config.
    for key, value in lp.settings.items():
        env[f"{envvars.SETTING_PREFIX}{key.upper()}"] = str(value)
    # both env spellings for one minor, and no optional git locks — see
    # envvars.session_exports
    return envvars.session_exports(env)


def _last_json(output: str) -> dict[str, Any] | None:
    """A declarative hook may emit a JSON object on its last non-empty stdout
    line to mutate the context. Anything else is treated as plain advisory log
    text. Parse failures are ignored (the hook still ran)."""
    for line in reversed(output.splitlines()):
        line = line.strip()
        if not line:
            continue
        if line.startswith("{") and line.endswith("}"):
            try:
                payload = json.loads(line)
            except json.JSONDecodeError:
                return None
            return payload if isinstance(payload, dict) else None
        return None
    return None


class HookBus:
    """Fan stage emits out to every loaded plugin. Build once per run from the
    registry; share with the engine."""

    def __init__(
        self,
        registry: PluginRegistry,
        journal: Any = None,
        *,
        runner: HookRunner | None = None,
        notifier: Notifier | None = None,
    ):
        self._registry = registry
        self._journal = journal
        self._runner = runner or _run_subprocess
        # How this bus reaches a human. Injected as a plain callable rather than
        # importing `gates` + carrying a Policy/run_dir: the bus has never known
        # either, and taking them now would couple the plugin layer to run state
        # for no gain. The engine passes a closure over its own `gates.notify`;
        # tests and any embedder pass whatever they want. None = inert, which is
        # exactly the behaviour before this channel existed.
        self._notifier = notifier
        # plugins disabled mid-run after an in-process hook raised (failure
        # isolation): skipped for every subsequent stage.
        self._disabled: set[str] = set()
        # precompute the active-stage set for the O(1) fast path.
        self._active: set[str] = set()
        self._py_stages: dict[str, set[str]] = {}
        for lp in registry.plugins():
            # An inert plugin (enabled, constructed, nothing to do in this
            # project) binds nothing — neither its declarative hooks nor its
            # handlers — for the same reason its workflows are not injected.
            if lp.inert:
                continue
            for hook in lp.manifest.hooks:
                self._active.add(hook.stage)
            if lp.instance is not None:
                stages = _instance_stages(lp.instance)
                if stages:
                    self._py_stages[lp.name] = stages
                    self._active.update(stages)

    # ----------------------------------------------------------- fast path

    def active(self, stage: str) -> bool:
        """True iff some loaded plugin binds ``stage``. The engine guards every
        emit with this so a zero-plugin run does no work."""
        return stage in self._active

    def any_active(self) -> bool:
        return bool(self._active)

    def active_plugins(self) -> list[str]:
        """Names of plugins that bind at least one stage — for a one-line
        run-start journal entry when (and only when) plugins are live."""
        out: list[str] = []
        for lp in self._registry.plugins():
            if lp.inert:
                continue
            if lp.manifest.hooks or lp.name in self._py_stages:
                out.append(lp.name)
        return out

    # -------------------------------------------------------------- dispatch

    def emit(self, stage: str, ctx: HookContext) -> HookContext:
        """Dispatch ``stage`` to every plugin bound to it, in registry order.
        Returns the same context (carrying mutations + collected vetoes). A no-op
        when no plugin binds the stage."""
        if stage not in self._active:
            return ctx
        for lp in self._registry.plugins():
            if lp.name in self._disabled or lp.inert:
                continue
            hook = lp.manifest.hook_for(stage)
            if hook is not None:
                self._dispatch_declarative(lp, hook, ctx)
            if lp.instance is not None and stage in self._py_stages.get(lp.name, ()):
                self._dispatch_python(lp, stage, ctx)
        return ctx

    def _dispatch_declarative(self, lp: LoadedPlugin, hook: Any, ctx: HookContext) -> None:
        cmd = lp.manifest.render(hook.cmd)
        env = _hook_env(ctx, lp)
        cwd = ctx.worktree or ctx.repo_root or None
        # post_story fires after an isolated unit merged and its worktree was
        # removed, so that path no longer exists and subprocess would raise
        # before the shell starts (#779). Only there does the project root stand
        # in; any other stage keeps the error — the root is the wrong tree for a
        # hook mid-story. ctx and WAVES_WORKTREE keep the original path.
        if hook.stage == "post_story" and ctx.worktree and not os.path.isdir(ctx.worktree):
            cwd = ctx.repo_root or None
        try:
            rc, output = self._runner(cmd, cwd=cwd, env=env, timeout=hook.timeout_sec)
        except ChildInterrupted:
            # A hard stop, not a hook failure: no plugin-hook-error, no veto (even
            # under fail_closed). Journalled so the record says which hook the stop
            # cut short, then handed to the engine to become RunStopped.
            self._log("plugin-hook-interrupted", plugin=lp.name, stage=hook.stage)
            raise
        except _HookError as e:
            self._log("plugin-hook-error", plugin=lp.name, stage=hook.stage, error=str(e))
            self._notify(f"plugin hook errored: {lp.name}.{hook.stage}", f"{e} — cmd: {cmd}")
            if hook.blocking and hook.fail_closed:
                ctx.add_veto(
                    Veto("defer", f"plugin {lp.name!r} hook {hook.stage} errored: {e}", lp.name)
                )
            return
        explicit_veto = self._apply_stdout(lp, ctx, output)
        # Hand the rc back to the caller (see HookContext.hook_results): a stage
        # that must report on its own outcome cannot do it from the journal.
        ctx.hook_results.append((lp.name, rc))
        # An exit code is not a verdict until you know the hook actually ran.
        # 127/126 mean it never did (see _HOOK_NEVER_RAN), which is a CONFIGURATION
        # fault and needs a different fix from "the hook ran and reported a
        # problem" — so it is journalled under a different kind (`plugin-hook-error`,
        # the same one a transport failure uses) instead of being flattened into a
        # `plugin-hook` line carrying a bare rc.
        #
        # And any non-zero rc now reaches the operator. `blocking = false` has
        # always meant "does not stop the unit"; it was silently also meaning
        # "nobody is ever told", which is how a hook can be dead for a whole epic
        # with the run reporting nothing wrong. rc == 0 stays silent on purpose:
        # notifying on success is how an operator learns to skip the line that
        # matters.
        if rc in _HOOK_NEVER_RAN:
            self._log(
                "plugin-hook-error",
                plugin=lp.name,
                stage=hook.stage,
                rc=rc,
                cmd=cmd,
                error=_HOOK_NEVER_RAN[rc],
            )
            self._notify(
                f"plugin hook did not run: {lp.name}.{hook.stage}",
                f"exit {rc} ({_HOOK_NEVER_RAN[rc]}) — cmd: {cmd}. "
                f"The hook never executed, so nothing it was meant to do happened.",
            )
        elif rc != 0:
            self._notify(
                f"plugin hook failed: {lp.name}.{hook.stage}",
                f"exit {rc}"
                + ("" if hook.blocking else " (advisory — the unit was not blocked)")
                + f": {output.strip()[-500:]}",
            )
        if not hook.blocking:
            self._log("plugin-hook", plugin=lp.name, stage=hook.stage, rc=rc)
            return
        # blocking hook: a non-zero exit vetoes (defer) unless the hook already
        # asked for a specific action via its stdout JSON.
        if rc != 0 and not explicit_veto:
            tail = output.strip()[-500:]
            ctx.add_veto(
                Veto("defer", f"plugin {lp.name!r} hook {hook.stage} exited {rc}: {tail}", lp.name)
            )
        self._log("plugin-hook", plugin=lp.name, stage=hook.stage, rc=rc, blocking=True)

    def _apply_stdout(self, lp: LoadedPlugin, ctx: HookContext, output: str) -> bool:
        """Merge a declarative hook's optional stdout-JSON: ``shared`` updates,
        whitelisted ``mutate`` fields, and an explicit ``veto``. Returns whether
        an explicit veto was supplied (so the exit-code path doesn't double-veto)."""
        payload = _last_json(output)
        if not payload:
            return False
        shared = payload.get("shared")
        if isinstance(shared, dict):
            ctx.shared.update(shared)
        mutate = payload.get("mutate")
        if isinstance(mutate, dict):
            for key, value in mutate.items():
                if key in MUTABLE_FIELDS:
                    setattr(ctx, key, value)
        veto = payload.get("veto")
        if isinstance(veto, dict) and veto.get("action") in VETO_ACTIONS:
            ctx.add_veto(Veto(veto["action"], str(veto.get("reason", "")), lp.name))
            return True
        return False

    def _dispatch_python(self, lp: LoadedPlugin, stage: str, ctx: HookContext) -> None:
        instance = lp.instance
        ctx._current_plugin = lp.name
        try:
            instance.hook(stage, ctx)  # type: ignore[union-attr]
        except Exception as e:  # isolate plugin failures; never BaseException
            self._log("plugin-error", plugin=lp.name, stage=stage, error=f"{type(e).__name__}: {e}")
            # disable the misbehaving instance for the rest of the run; its
            # declarative hooks (if any) keep working — they are out-of-process.
            self._disabled.add(lp.name)
            if getattr(instance, "fail_closed", False):
                ctx.add_veto(Veto("defer", f"plugin {lp.name!r} hook {stage} raised: {e}", lp.name))
        finally:
            ctx._current_plugin = ""

    def _log(self, kind: str, **fields: Any) -> None:
        if self._journal is not None:
            self._journal.append(kind, **fields)

    def _notify(self, title: str, message: str) -> None:
        """Best-effort, mirroring `gates.notify`'s own contract: a broken
        notifier must never break a hook dispatch, so this swallows everything.
        The journal line each caller writes first stays the durable record."""
        if self._notifier is None:
            return
        try:
            self._notifier(title, message)
        except Exception:  # nosec B110 - swallowing IS the contract, see docstring above
            pass
