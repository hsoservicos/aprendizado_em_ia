"""PluginRegistry: the inter-pillar contract.

The registry collapses discovery + trust + in-process resolution into one
read-only object the rest of the system consumes:

  * the settings pillar reads ``settings_schema()``;
  * the hook bus reads ``hooks_for(stage)``;
  * custom orchestration reads ``provided_workflows()``.

Neither consumer reaches into loader internals. Building the registry is the
single place trust is enforced and failure is isolated:

  * a plugin with no ``[python]`` loads as a data-only/declarative LoadedPlugin
    (instance None) — its shell hooks are available to the bus;
  * a ``[python]`` plugin is constructed only if it is in ``[plugins] enabled``
    (``trust.require_enabled`` gates ``exec_module``); otherwise it is recorded
    untrusted and its module is never imported;
  * any exception while importing/constructing a trusted instance is caught
    (``except Exception`` — never ``BaseException``, so RunStopped/SIGTERM
    propagate), journalled, and the instance disabled. The run survives.
"""

from __future__ import annotations

import importlib.util
from dataclasses import replace
from pathlib import Path

from . import trust
from .loader import load_plugins
from .model import (
    WORKFLOW_ROLES,
    HookSpec,
    LoadedPlugin,
    Plugin,
    PluginManifest,
    SettingSpec,
    WorkflowSpec,
)


def _resolve_settings(manifest: PluginManifest, policy) -> dict:
    """Manifest defaults overlaid by the ``[plugins.<name>]`` policy table. The
    single resolved view the instance is built with and the bus reads for env."""
    resolved = dict(manifest.setting_defaults())
    plugins_pol = getattr(policy, "plugins", None) if policy is not None else None
    overrides = getattr(plugins_pol, "settings", {}).get(manifest.name, {}) if plugins_pol else {}
    resolved.update(overrides)
    return resolved


def _instantiate(manifest: PluginManifest, settings: dict) -> Plugin:
    """Import the plugin's module and construct its Plugin subclass with its
    resolved settings.

    Caller is responsible for the trust gate; this performs the actual
    ``exec_module``. Kept tiny so the registry's try/except wraps exactly the
    import + construct surface.
    """
    scripts_dir = Path(manifest.scripts_dir)
    module_path = scripts_dir / manifest.python.module  # type: ignore[union-attr]
    # `_parse_python` rejects an absolute, parent-climbing or root-naming module at
    # manifest load, but lexically: a project-relative name that is a symlink out of
    # the plugin resolves fine and would be exec'd. Re-check after resolution, since
    # what happens below is arbitrary code execution, not a copy.
    # Strictly below, not merely inside: `is_relative_to` is true for equal paths,
    # so a module resolving to the plugin dir itself would pass an inside-check.
    try:
        resolved, base = module_path.resolve(), scripts_dir.resolve()
        contained = resolved != base and resolved.is_relative_to(base)
    except (OSError, RuntimeError):
        contained = False
    if not contained:
        raise ImportError(f"plugin module escapes its plugin directory: {module_path}")
    if not module_path.is_file():
        raise FileNotFoundError(f"plugin module not found: {module_path}")
    spec = importlib.util.spec_from_file_location(
        f"riaworks_waves_loop_plugin_{manifest.name}", module_path
    )
    if spec is None or spec.loader is None:
        raise ImportError(f"cannot load plugin module: {module_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    cls_name = manifest.python.cls  # type: ignore[union-attr]
    cls = getattr(module, cls_name, None)
    if cls is None:
        # manifest.python is validated non-None before this loader runs (mirrors
        # the manifest.python.cls access above).
        raise AttributeError(
            f"plugin module {manifest.python.module!r} has no {cls_name!r}"  # pyright: ignore[reportOptionalMemberAccess]
        )
    if not (isinstance(cls, type) and issubclass(cls, Plugin)):
        raise TypeError(f"{cls_name!r} must subclass plugins.Plugin")
    return cls(manifest, settings)


def _resolve(
    manifest: PluginManifest, policy, journal, project: Path | None = None
) -> LoadedPlugin:
    settings = _resolve_settings(manifest, policy)
    if manifest.python is None:
        if journal is not None:
            journal.append("plugin-loaded", plugin=manifest.name, mode="declarative")
        return LoadedPlugin(manifest=manifest, settings=settings)

    if not trust.is_enabled(policy, manifest.name):
        if journal is not None:
            journal.append(
                "plugin-untrusted",
                plugin=manifest.name,
                reason="[python] module requires [plugins] enabled",
            )
        return LoadedPlugin(manifest=manifest, trusted=False, settings=settings)

    try:
        instance = _instantiate(manifest, settings)
        # Handed the project before the applicability probe, which needs it for the
        # same reason `validate` does: cwd is the project only while nobody passed
        # `--project`. Set here so the probe and the gate read the same tree.
        instance.project_root = project
        inert = instance.inapplicable_reason()
    except Exception as e:  # isolate plugin failures; never BaseException
        if journal is not None:
            journal.append("plugin-error", plugin=manifest.name, error=f"{type(e).__name__}: {e}")
        return LoadedPlugin(manifest=manifest, disabled=True, error=str(e), settings=settings)

    if inert:
        # Enabled, healthy, and with nothing to do here: kept (the settings screen
        # still lists it, on) but contributing nothing — see Plugin.inapplicable_reason.
        if journal is not None:
            journal.append("plugin-inert", plugin=manifest.name, reason=inert)
        return LoadedPlugin(manifest=manifest, instance=instance, inert=inert, settings=settings)

    if journal is not None:
        journal.append("plugin-loaded", plugin=manifest.name, mode="python")
    return LoadedPlugin(manifest=manifest, instance=instance, settings=settings)


def unknown_enabled(
    manifests: dict[str, PluginManifest], policy, journal=None
) -> list[tuple[str, str]]:
    """``(name, reason)`` for every ``[plugins] enabled`` entry no manifest answers to.

    An enabled name that matches nothing is the allowlist's quiet failure mode:
    the operator turned something on, nothing turned on, and every consumer
    reads an empty list. Measured 2026-09-07: a policy still naming the 1.x
    ``riaworks-waves-tea`` ran for days with the bundled TEA plugin untrusted —
    no ATDD scaffold, no epic-boundary step — while ``validate`` said "policy OK"
    and ``unit workflows list`` returned an empty list with an empty ``inert``.
    The policy is never rewritten: the entry is the operator's.
    """
    available = ", ".join(sorted(manifests)) or "none"
    out: list[tuple[str, str]] = []
    for name in sorted(trust.enabled_names(policy)):
        if name in manifests:
            continue
        reason = (
            f"is enabled but no bundled or project plugin has that name "
            f"(available: {available})"
        )
        if journal is not None:
            journal.append("plugin-unknown", plugin=name, reason=reason)
        out.append((name, reason))
    return out


class PluginRegistry:
    """Read-only view over the loaded plugins. Build once per run."""

    def __init__(
        self,
        loaded: list[LoadedPlugin],
        project: Path | None = None,
        unknown: list[tuple[str, str]] | None = None,
    ):
        # stable order: manifest priority then load (discovery/overlay) order.
        self._loaded = sorted(loaded, key=lambda lp: lp.manifest.priority)
        # `[plugins] enabled` entries no manifest matched — see `unknown_enabled`.
        self._unknown: tuple[tuple[str, str], ...] = tuple(unknown or ())
        # The project this registry was built for, handed to each in-process
        # plugin as `Plugin.project_root` before `validate` runs. Optional so
        # every existing construction site keeps working; a plugin that reads it
        # falls back to cwd, which is only ever wrong when `--project` points
        # somewhere other than the working directory (see Plugin.project_root).
        self._project = project

    @classmethod
    def build(cls, project: Path | None = None, policy=None, journal=None) -> PluginRegistry:
        manifests = load_plugins(project, journal=journal)
        loaded = [_resolve(m, policy, journal, project) for m in manifests.values()]
        return cls(loaded, project, unknown_enabled(manifests, policy, journal))

    # ----------------------------------------------------------- consumers

    def plugins(self) -> list[LoadedPlugin]:
        return list(self._loaded)

    def get(self, name: str) -> LoadedPlugin | None:
        for lp in self._loaded:
            if lp.manifest.name == name:
                return lp
        return None

    def hooks_for(self, stage: str) -> list[tuple[LoadedPlugin, HookSpec]]:
        """Every (plugin, hook) bound to ``stage``, in registry order. A
        disabled instance still contributes its *declarative* hooks (those are
        out-of-process and independent of the in-process module that failed).
        An inert plugin contributes none: it said there is nothing to do here,
        and that covers its shell hooks as much as its handlers."""
        out: list[tuple[LoadedPlugin, HookSpec]] = []
        for lp in self._loaded:
            if lp.inert:
                continue
            hook = lp.manifest.hook_for(stage)
            if hook is not None:
                out.append((lp, hook))
        return out

    def settings_schema(self) -> list[tuple[str, tuple[SettingSpec, ...]]]:
        """(plugin name, setting specs) for every plugin that contributes
        settings, in registry order. Consumed by the settings pillar."""
        return [
            (lp.manifest.name, lp.manifest.settings) for lp in self._loaded if lp.manifest.settings
        ]

    def provided_workflows(self) -> dict[str, tuple[str, ...]]:
        """plugin name -> declared workflow names (for introspection / docs)."""
        return {
            lp.manifest.name: tuple(w.name for w in lp.manifest.workflows)
            for lp in self._loaded
            if lp.manifest.workflows
        }

    def workflow_stages(self) -> frozenset[str]:
        """Every stage some loaded plugin binds a *still-enabled* workflow to. The
        engine reads this once to precompute an O(1) injection guard — a run whose
        plugins provide no workflows pays nothing at the per-stage check.

        A workflow a setting has disabled (``<name>_enabled = false``) is dropped
        here too, so the guard stays exact: when every step at a stage is turned
        off the stage falls out of the set and the engine skips it entirely. This
        mirrors the same skip in ``workflows_for`` (the settings-overlay
        convention; see ``WorkflowSpec``).

        It reads the same ACTIVE set ``workflows_for`` does, not every loaded
        manifest: an un-enabled ``[python]`` plugin is inert, and a bundled one
        would otherwise put its stage in this set for every project on earth —
        opening a stage the engine then walks with nothing to dispatch, and (at the
        epic boundary) recording an empty progress entry for a boundary that ran
        nothing. The guard must answer "is there work here", not "could there be"."""
        return frozenset(
            w.stage
            for lp in self._active_for_seeds()
            for w in lp.manifest.workflows
            if lp.settings.get(f"{w.name}_enabled") is not False
        )

    def workflows_for(self, stage: str) -> list[tuple[LoadedPlugin, WorkflowSpec]]:
        """Every (plugin, workflow) injected at ``stage``, in registry order.

        Only *active* plugins contribute: a data-only/declarative plugin always,
        an in-process plugin only once enabled+constructed (instance built). An
        un-enabled or errored ``[python]`` plugin is inert — its workflows must
        not fire any more than its module runs (same gate as ``_active_for_seeds``).

        Settings overlay: a plugin's resolved settings can tune a workflow per the
        ``<workflow-name>_enabled`` / ``_blocking`` / ``_role`` convention (see
        ``WorkflowSpec``). ``<name>_enabled = false`` drops the step;
        ``<name>_blocking`` overrides the manifest's ``blocking`` flag;
        ``<name>_role`` overrides which adapter runs it. Absent settings preserve
        the manifest values exactly, so a plugin that declares no such settings is
        byte-identical to the pre-overlay behaviour.

        ``_role`` exists because the alternative is worse. A project that wants one
        step on its own adapter — a cheap model for a sweep, an expensive one for an
        audit — could otherwise only get it by dropping a same-named plugin manifest
        into the project tree, and overlay is BY NAME: that replaces the bundled
        plugin whole, so the project ends up carrying a copy of every workflow,
        prompt and setting in order to change one field. Measured downstream: 195
        lines copied to move `atdd` off `dev`. An unknown role is ignored rather than
        raised — the manifest's own load-time check is where a typo belongs, and a
        setting must not be able to crash a run at dispatch time."""
        out: list[tuple[LoadedPlugin, WorkflowSpec]] = []
        for lp in self._active_for_seeds():
            for wf in lp.manifest.workflows_for(stage):
                if lp.settings.get(f"{wf.name}_enabled") is False:
                    continue  # a setting can disable a step
                blocking = bool(lp.settings.get(f"{wf.name}_blocking", wf.blocking))
                # The manifest refuses blocking=true at the two stages that cannot
                # honour it — an epic boundary (no unit to defer) and pre_dev_phase
                # (a PENDING task has no terminal transition) — but that check runs
                # at load, and this override lands on top of it. Without the same
                # rule here, a `<name>_blocking = true` setting re-enables the flag
                # after the manifest passed and it reaches dispatch anyway.
                # Enforced at the seam that can reintroduce it rather than in the
                # engine, so the rule stays beside the check that states it.
                if wf.stage in ("post_epic_boundary", "pre_dev_phase"):
                    blocking = False
                role = lp.settings.get(f"{wf.name}_role", wf.role)
                if not isinstance(role, str) or role not in WORKFLOW_ROLES:
                    role = wf.role
                changed = {}
                if blocking != wf.blocking:
                    changed["blocking"] = blocking
                if role != wf.role:
                    changed["role"] = role
                out.append((lp, replace(wf, **changed) if changed else wf))
        return out

    def instances(self) -> list[Plugin]:
        """Constructed, trusted, non-disabled, applicable in-process plugins. An
        inert one (``LoadedPlugin.inert``) is constructed and healthy but said it
        has nothing to do in this project, so it is not handed out to run."""
        return [lp.instance for lp in self._loaded if lp.instance is not None and not lp.inert]

    def inert_plugins(self) -> list[tuple[str, str]]:
        """``(name, reason)`` for every enabled plugin that declared itself inert
        here — for ``validate`` and the dashboard, which owe the operator the
        reason a default-on plugin is contributing nothing."""
        return [(lp.name, lp.inert) for lp in self._loaded if lp.inert]

    def unknown_plugins(self) -> list[tuple[str, str]]:
        """``(name, reason)`` for every ``[plugins] enabled`` entry no plugin answered
        to — for ``validate`` and ``unit workflows list``, which owe the operator the
        reason an entry they wrote enables nothing (see ``unknown_enabled``)."""
        return list(self._unknown)

    def _active_for_seeds(self) -> list[LoadedPlugin]:
        """Plugins whose declared seeds apply: data-only/declarative plugins
        (always active) and enabled in-process plugins (instance built and
        applicable). An un-enabled, errored or inert ``[python]`` plugin
        contributes nothing — its module never ran, or ran and said there is
        nothing for it here — so its seeds must not leak into a worktree (e.g. the
        Unity plugin's skill tree when unity isn't enabled)."""
        return [
            lp
            for lp in self._loaded
            if lp.manifest.python is None or (lp.instance is not None and not lp.inert)
        ]

    def seed_files(self) -> list[str]:
        """Union of every active plugin's ``seed_files`` (literal project-relative
        paths), order-preserving + deduped. Consumed by worktree provisioning so a
        plugin can prime an isolated checkout with gitignored paths it needs."""
        return list(
            dict.fromkeys(f for lp in self._active_for_seeds() for f in lp.manifest.seed_files)
        )

    def seed_globs(self) -> list[str]:
        """Union of every active plugin's ``seed_globs`` (patterns expanded against
        the main repo), order-preserving + deduped."""
        return list(
            dict.fromkeys(g for lp in self._active_for_seeds() for g in lp.manifest.seed_globs)
        )

    def validate(self, policy) -> None:
        """Let every constructed in-process plugin self-validate against the run
        policy (``Plugin.validate``). A plugin raises to reject an incompatible
        config; the registry lets it propagate so the run fails fast at startup."""
        for lp in self._loaded:
            # An inert plugin is not asked: it already said there is nothing to
            # do here, and its readiness gate would only be checking the
            # prerequisites of work that will not run.
            if lp.instance is not None and not lp.inert:
                # Handed here rather than through __init__ so the Plugin
                # constructor signature — part of the api_version 1 contract —
                # stays as it is. Additive, like `fail_closed`.
                if self._project is not None:
                    lp.instance.project_root = self._project
                lp.instance.validate(policy)
