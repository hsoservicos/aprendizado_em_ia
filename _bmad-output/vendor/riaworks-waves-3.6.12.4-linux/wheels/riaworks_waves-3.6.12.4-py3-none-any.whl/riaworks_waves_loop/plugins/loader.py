"""Discover + load plugin manifests (folder-drop now; entry-points later).

Discovery walks three sources in overlay precedence — exactly the
builtin-then-project pattern of ``load_profiles`` (adapters/profile.py), with an
entry-point source wedged in the middle as a locked future-additive seam:

    builtin (riaworks_waves_loop.data/plugins/*)         lowest precedence
    entry_point (riaworks_waves_loop.plugins group)      written, returns nothing today
    project (<project>/.waves/loop/plugins/*)   highest precedence (same-name override)

Each plugin is a directory holding ``plugin.toml`` plus any helper scripts; the
directory is its ``{scripts}`` dir. Resolving bundled plugins to a real
filesystem path assumes a regular (non-zipped) install — the same assumption the
rest of the package makes for packaged skills/profiles/engines.

api_version mismatch handling lives here because it is source-dependent: a
builtin we ship with the wrong version is a packaging bug (hard error); a
third-party plugin written for a newer/older API is skipped with a warning so a
stale drop-in can never take a run down.
"""

from __future__ import annotations

import os
import warnings
from collections.abc import Callable, Iterator
from importlib import resources
from importlib.resources.abc import Traversable
from pathlib import Path

from .. import namespace
from . import trust
from .manifest import load_manifest
from .model import PluginError, PluginManifest

PLUGIN_FILE = "plugin.toml"
USER_PLUGINS_REL = namespace.STATE_DIR / "plugins"
ENTRY_POINT_GROUP = "riaworks_waves_loop.plugins"


def _read_manifest_text(toml: Traversable | Path, source: str) -> str:
    """Read a plugin manifest as text, converting a read fault into PluginError.

    Not reachable by widening `load_manifest`'s CONVERSION_FAULTS funnel: that
    funnel wraps the manifest *parse*, and the decode happens in the argument
    expression at both discovery call sites, before `load_manifest` is entered.
    So a non-UTF-8 `plugin.toml` escaped as a raw `UnicodeDecodeError` (a
    ValueError) while every consumer keys its fault handling on PluginError —
    `tui/settings.py`'s `except (PolicyError, PluginError)` degrade let it
    through and took the settings surface down at construction. The sibling
    guard is `adapters/profile.py`'s `_read_profile_text` (#473); both-arms
    precedent is `stories.py`'s manifest read.

    Takes the packaged built-ins too. They are trusted, but a corrupt package
    is a packaging bug and should say so with a typed error rather than a
    traceback. One helper covers both call shapes: an `importlib.resources`
    Traversable and a `Path` each expose ``read_text(encoding=...)``.
    """
    try:
        return toml.read_text(encoding="utf-8")
    except UnicodeDecodeError as e:
        raise PluginError(f"plugin {source}: not valid UTF-8: {e}") from e
    except OSError as e:
        # A manifest that is present but cannot be read — permissions, an I/O
        # error, a dead mount. Discovery's `is_file()` rules out ABSENCE and
        # nothing else, so this escaped as a bare OSError.
        raise PluginError(f"plugin {source}: unreadable: {e}") from e


def _plugin_dirs(
    root: Traversable, sort_key: Callable[[Traversable], str]
) -> list[tuple[Traversable, Traversable]]:
    """Every ``(plugin dir, plugin.toml)`` pair under a plugins root, or ``[]``
    when the root is absent — with any filesystem fault converted to PluginError.

    The whole enumeration sits behind one conversion, not just the listing: on the
    3.11 floor `Path.is_dir()`/`is_file()` swallow only absence errnos (ENOENT,
    ENOTDIR, EBADF, ELOOP) and RAISE on EACCES, so a root whose parent is not
    searchable faults on the existence probe, and an unsearchable entry on its
    `is_file()`. Every consumer keys on PluginError (validate --json reports it as
    a finding; `PluginRegistry.build` and the TUI settings screen degrade on it),
    and the manifest read itself is already converted by `_read_manifest_text`.
    Collected eagerly so no fault can surface mid-yield from a later probe.
    """
    try:
        if not root.is_dir():
            return []
        found: list[tuple[Traversable, Traversable]] = []
        for entry in sorted(root.iterdir(), key=sort_key):
            toml = entry.joinpath(PLUGIN_FILE)
            if entry.is_dir() and toml.is_file():
                found.append((entry, toml))
        return found
    except OSError as e:
        raise PluginError(f"plugin dir {root}: unreadable: {e}") from e


def _discover_builtin() -> Iterator[PluginManifest]:
    packaged = resources.files("riaworks_waves_loop.data").joinpath("plugins")
    for entry, toml in _plugin_dirs(packaged, lambda e: e.name):
        source = f"{entry.name}/{PLUGIN_FILE}"
        yield load_manifest(
            _read_manifest_text(toml, source),
            source,
            str(entry),
            origin="builtin",
        )


def _discover_entry_points() -> Iterator[PluginManifest]:
    """Future-additive seam for ``importlib.metadata`` entry points (group
    ``riaworks_waves_loop.plugins``, the modern selectable API on Python >= 3.11). Locked
    shut for now: folder-drop is the only distribution path, so this yields
    nothing. Wiring it later needs no changes to callers — discovery order and
    overlay precedence already account for this source.
    """
    return
    yield  # pragma: no cover - marks this a generator without emitting


def _discover_project(project: Path) -> Iterator[PluginManifest]:
    # normcase: the order `sorted(Path.iterdir())` gave siblings — case-folded on
    # Windows — so which of two same-named manifests wins the overlay is unchanged.
    for entry, toml in _plugin_dirs(project / USER_PLUGINS_REL, lambda e: os.path.normcase(e.name)):
        yield load_manifest(
            _read_manifest_text(toml, str(toml)), str(toml), str(entry), origin="project"
        )


def discover(project: Path | None = None) -> Iterator[PluginManifest]:
    """Yield manifests in overlay order (builtin < entry_point < project).

    Later same-name manifests override earlier ones; ``load_plugins`` collapses
    the stream into a name->manifest dict honoring that precedence.
    """
    yield from _discover_builtin()
    yield from _discover_entry_points()
    if project is not None:
        yield from _discover_project(project)


def load_plugins(project: Path | None = None, *, journal=None) -> dict[str, PluginManifest]:
    """Packaged built-ins overlaid by project-local plugins, api-checked.

    A builtin with an unsupported api_version is a hard error (we shipped it); a
    third-party one is skipped with a warning (and journalled when a journal is
    given) so it can never crash a run.
    """
    plugins: dict[str, PluginManifest] = {}
    for manifest in discover(project):
        problem = trust.check_api(manifest)
        if problem is not None:
            if manifest.source == "builtin":
                raise PluginError(problem)
            warnings.warn(problem, stacklevel=2)
            if journal is not None:
                journal.append("plugin-skipped", plugin=manifest.name, reason=problem)
            continue
        plugins[manifest.name] = manifest
    return plugins


def get_plugin(name: str, project: Path | None = None) -> PluginManifest:
    plugins = load_plugins(project)
    manifest = plugins.get(name)
    if manifest is None:
        raise PluginError(f"unknown plugin: {name!r} (available: {sorted(plugins)})")
    return manifest
