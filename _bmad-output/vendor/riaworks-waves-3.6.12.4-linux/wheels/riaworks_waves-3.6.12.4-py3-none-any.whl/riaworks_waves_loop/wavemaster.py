"""The deterministic engine as the master of a wave — Phase 7 of the roadmap's
"Parallel unit execution".

The engine drives one unit at a time by construction: `Engine.workspace` is the
tree the whole machine reads and writes for the unit in flight, swapped in and out
around each unit, and seventy-odd sites depend on that. A wave of N fronts in one
process would need N of them at once. So the fan-out is by PROCESS, which is how
the engine already isolates a unit from the checkout: the run that carries a
`--plan` and a `[scm] max_parallel` above one becomes the wave master, launches
one CHILD run per front of the current wave (`waves run --deterministic --plan
<plan> --front <name> --wave <n>`), at most `max_parallel` at a time, and each
child is the ordinary engine — its own workspace, its own run dir, the
provisioning contract, the verify queue — driving its front's stories in order
with ONE difference: it holds integration. A child leaves every DONE unit on its
branch, worktree mounted, and exits.

The master then lands the wave in the grid's merge order: adopts each child's
tasks into its own state (one run to look at, one journal of record), rebases a
unit the target moved past and runs the verify ladder again on what will actually
land, merges through the same `integrate_unit` every unit takes (board carry,
teardown, hooks), and parks — deferred, branch kept, reason journaled — a unit
whose rebase conflicts or whose ladder goes red after it: the plan's
`failure_policy: resolve-and-continue`. Epic boundaries fire after the wave for
every epic the plan owes nothing more to. Then the next wave.

No LLM in any of this: the plan's judgment was the planner's, the children are
the engine, the master is Python. The child runner is a seam (subprocesses by
default) so the whole loop can be driven in one process under test.
"""

from __future__ import annotations

import subprocess
import sys
import time
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

from . import gates, runs, waveplan
from .engine import RunPaused, RunStopped
from .journal import load_state
from .model import PAUSE_ESCALATION, Phase, StoryTask
from .sprintstatus import ACTIONABLE_STATUSES
from .sprintstatus import load as load_sprint_status

if TYPE_CHECKING:
    from .engine import Engine

#: Seconds between launches of two children, so concurrent `git worktree add`
#: calls on one repository do not race each other's ref locks.
LAUNCH_STAGGER_S = 1.0
POLL_S = 2.0


@dataclass(frozen=True)
class ChildSpec:
    wave: int
    front: str
    stories: tuple[str, ...]
    run_id: str

    @property
    def key(self) -> str:
        return f"w{self.wave}:{self.front}"


@dataclass(frozen=True)
class ChildLaunch:
    spec: ChildSpec
    argv: list[str]
    run_dir: Path


#: The seam: run every launch, at most `max_parallel` at a time, calling `poll`
#: between waits (it raises `RunStopped` when the master was told to stop, and the
#: runner then forwards the stop to the live children before re-raising). Returns
#: each child's run dir by `spec.key`.
ChildRunner = Callable[[Sequence[ChildLaunch], int, Callable[[], None]], dict[str, Path]]


def applies(engine: Engine) -> bool:
    """A --plan run under worktree isolation with room for more than one unit."""
    state = engine.state
    return (
        bool(state.plan)
        and not state.hold_integration
        and engine.policy.scm.max_parallel > 1
        and bool(getattr(engine, "_isolated", False))
    )


def child_argv(project: Path, plan_path: str, spec: ChildSpec, parent_run_id: str) -> list[str]:
    return [
        sys.executable,
        "-m",
        "riaworks_waves_loop",
        "run",
        "--deterministic",
        "--project",
        str(project),
        "--plan",
        plan_path,
        "--front",
        spec.front,
        "--wave",
        str(spec.wave),
        "--parent",
        parent_run_id,
        "--run-id",
        spec.run_id,
    ]


def default_child_runner(
    launches: Sequence[ChildLaunch], max_parallel: int, poll: Callable[[], None]
) -> dict[str, Path]:
    """Subprocess children, `max_parallel` at a time. A stop on the master is
    forwarded to every live child in the same mode, and the master waits for them
    before it re-raises: a child killed under a running session is exactly the
    orphaned worktree a stop exists to avoid."""
    pending = list(launches)
    live: dict[str, tuple[ChildLaunch, subprocess.Popen[bytes]]] = {}
    done: dict[str, Path] = {}
    try:
        while pending or live:
            while pending and len(live) < max_parallel:
                launch = pending.pop(0)
                proc = subprocess.Popen(  # noqa: S603 # nosec B603 - the run's own CLI, argv built above
                    launch.argv, stdin=subprocess.DEVNULL, start_new_session=False
                )
                live[launch.spec.key] = (launch, proc)
                time.sleep(LAUNCH_STAGGER_S)
            for key, (launch, proc) in list(live.items()):
                if proc.poll() is not None:
                    done[key] = launch.run_dir
                    del live[key]
            poll()
            if live:
                time.sleep(POLL_S)
    except RunStopped as stop:
        for _key, (launch, proc) in live.items():
            if launch.run_dir.is_dir():
                if stop.graceful:
                    runs.request_graceful_stop(launch.run_dir)
                else:
                    runs.stop_run(launch.run_dir)
        for _key, (_launch, proc) in live.items():
            try:
                proc.wait(timeout=600)
            except subprocess.TimeoutExpired:
                proc.kill()
        raise
    return done


class WaveMaster:
    """Drives a --plan run wave by wave through child runs; see the module doc."""

    def __init__(self, engine: Engine, child_runner: ChildRunner | None = None):
        self.engine = engine
        self.runner: ChildRunner = child_runner or default_child_runner

    # ------------------------------------------------------------------ the loop

    def run(self) -> None:
        e = self.engine
        plan = e.state.plan or {}
        order = set(waveplan.story_order_of(plan) or ())
        while True:
            e._check_stop_request()
            settled = self._settled(order)
            view = waveplan.wave_view(plan, settled, set())
            if view["wave"] is None:
                # The serial loop's run end, in its order (DW-488): the last epic's
                # retrospective gate, then the run-end sweep over what it committed.
                e._run_end_retrospective()
                e._maybe_auto_sweep("run-end", "run-end")
                return
            wave = int(view["wave"])
            specs = [
                ChildSpec(
                    wave,
                    front["front"],
                    tuple(s for s in front["stories"] if s not in settled),
                    self._child_id(wave, front["front"]),
                )
                for front in view["fronts"]
                if not front["done"]
            ]
            e.journal.append(
                "wave-start",
                wave=wave,
                scope=plan.get("scope", ""),
                fronts=[
                    {"front": s.front, "stories": list(s.stories), "run": s.run_id} for s in specs
                ],
                max_parallel=e.policy.scm.max_parallel,
            )
            e._save()
            dirs = self._run_children(specs)
            for spec in specs:
                self._land_front(spec, dirs.get(spec.key))
            e.journal.append("wave-end", wave=wave)
            e._save()
            after = self._settled(order)
            if after == settled:
                reason = (
                    f"wave {wave} made no progress: none of its stories reached a terminal "
                    "state in their child runs — read the children's journals "
                    f"({', '.join(s.run_id for s in specs)})"
                )
                e.journal.append("wave-stalled", wave=wave, fronts=[s.front for s in specs])
                gates.notify(e.policy, e.run_dir, f"wave {wave} stalled", reason)
                raise RunPaused(
                    reason,
                    PAUSE_ESCALATION,
                    specs[0].stories[0] if specs and specs[0].stories else None,
                )
            self._boundaries_after_wave(plan, wave)

    # -------------------------------------------------------------- the children

    def _settled(self, order: set[str]) -> set[str]:
        e = self.engine
        try:
            board = load_sprint_status(e.paths.sprint_status)
            on_board = {
                s.key
                for s in board.stories
                if s.key in order and s.status not in ACTIONABLE_STATUSES
            }
        except Exception:  # noqa: BLE001 - an unreadable board settles nothing extra
            on_board = set()
        return {k for k, t in e.state.tasks.items() if t.settled} | on_board

    def _child_id(self, wave: int, front: str) -> str:
        key = f"w{wave}:{front}"
        known = self.engine.state.plan_children.get(key)
        if known:
            return known
        child_id = runs.new_run_id()
        self.engine.state.plan_children[key] = child_id
        return child_id

    def _run_children(self, specs: Sequence[ChildSpec]) -> dict[str, Path]:
        e = self.engine
        runs_root = e.run_dir.parent
        plan_path = str((e.state.plan or {}).get("path", ""))
        dirs: dict[str, Path] = {}
        launches: list[ChildLaunch] = []
        for spec in specs:
            run_dir = runs_root / spec.run_id
            state_path = run_dir / "state.json"
            if state_path.is_file():
                try:
                    finished = load_state(run_dir).finished
                except Exception as exc:  # noqa: BLE001 - relaunch rather than trust a broken child
                    e.journal.append(
                        "child-state-unreadable",
                        run=spec.run_id,
                        error=f"{type(exc).__name__}: {exc}",
                    )
                    finished = False
                if finished:
                    dirs[spec.key] = run_dir  # a resume: the child already ran
                    continue
            launches.append(
                ChildLaunch(
                    spec, child_argv(e.paths.project, plan_path, spec, e.state.run_id), run_dir
                )
            )
        if launches:
            e.journal.append("children-launched", runs=[launch.spec.run_id for launch in launches])
            dirs.update(self.runner(launches, e.policy.scm.max_parallel, e._check_stop_request))
        return dirs

    # ---------------------------------------------------------------- landing

    def _land_front(self, spec: ChildSpec, child_dir: Path | None) -> None:
        e = self.engine
        if child_dir is None or not (child_dir / "state.json").is_file():
            e.journal.append("front-unreached", wave=spec.wave, front=spec.front, run=spec.run_id)
            return
        child_state = load_state(child_dir)
        for story in spec.stories:
            task = child_state.tasks.get(story)
            if task is None:
                e.journal.append(
                    "front-story-unreached", wave=spec.wave, front=spec.front, story_key=story
                )
                continue
            e.state.tasks[story] = task
            e.state.current_epic = task.epic
            e.journal.append(
                "story-adopted",
                story_key=story,
                child=child_state.run_id,
                phase=str(task.phase),
                plan=waveplan.front_of(e.state.plan, story),
            )
            e._save()
            if task.phase in (Phase.DONE, Phase.AWAITING_OPERATOR) and not task.integrated:
                if task.worktree_path and Path(task.worktree_path).is_dir():
                    self._land_held(task)
                else:
                    e.journal.append("unit-lost", story_key=story, path=task.worktree_path)
            elif (
                task.phase is Phase.DEFERRED
                and task.worktree_path
                and Path(task.worktree_path).is_dir()
            ):
                e._integrate_unit(
                    task, e._reopen_unit(task)
                )  # the deferred path: capture, keep or drop
            e._save()

    def _land_held(self, task: StoryTask) -> None:
        e = self.engine
        flow = e._worktree_flow
        unit = e._reopen_unit(task)
        if flow.behind_target(unit):
            result = flow.rebase_unit(task, unit)
            conflicts = cast(list[str], result.get("conflicts") or [])
            if conflicts:
                self._park(
                    task,
                    unit,
                    f"rebase onto {e.state.target_branch} conflicts on: " + ", ".join(conflicts),
                )
                return
            prev = e.workspace
            e.workspace = unit.workspace
            try:
                outcome, _records = e._verify_commands_with_results(task, "post-rebase")
            finally:
                e.workspace = prev
            if not outcome.ok:
                self._park(
                    task, unit, f"the verify ladder failed on the rebased tree: {outcome.reason}"
                )
                return
        e._integrate_unit(task, unit)
        e.journal.append(
            "unit-landed",
            story_key=task.story_key,
            plan=waveplan.front_of(e.state.plan, task.story_key),
        )

    def _park(self, task: StoryTask, unit: Any, reason: str) -> None:
        """A unit that cannot land as it stands: deferred with the reason, the
        branch and (under keep_failed) the worktree kept — recoverable, journaled,
        and the wave goes on. Set directly, as the engine sets every phase it
        reaches outside a legal transition."""
        e = self.engine
        task.defer_reason = reason
        task.phase = Phase.DEFERRED
        e.journal.append("story-parked", story_key=task.story_key, reason=reason)
        gates.notify(e.policy, e.run_dir, f"parked: {task.story_key}", reason)
        e._integrate_unit(task, unit)

    # --------------------------------------------------------------- boundaries

    def _boundaries_after_wave(self, plan: dict[str, Any], wave: int) -> None:
        e = self.engine
        waves = plan.get("waves") or ()  # namespace: the plan's YAML key, not the product
        later: list[str] = []
        current: list[str] = []
        for w in waves:
            fronts = w.get("fronts") or {}
            keys = [str(s) for f in fronts.values() for s in (f.get("stories") or ())]
            if w.get("wave") == wave:
                current.extend(keys)
            elif (w.get("wave") or 0) > wave:
                later.extend(keys)
        epics_now: set[int] = {e.state.tasks[k].epic for k in current if k in e.state.tasks}
        epics_later: set[int] = set()
        for k in later:
            epic = e.state.tasks[k].epic if k in e.state.tasks else _epic_of(k)
            if epic is not None:
                epics_later.add(epic)
        # As the pick loop does: a boundary is the moment the run moves from one
        # epic to another. An epic with nothing after it in the plan gets none here —
        # the serial engine fires none at the end of a run either.
        if not epics_later:
            return
        for epic in sorted(x for x in epics_now if x not in epics_later):
            e._epic_boundary(epic, min(epics_later))


def _epic_of(story_key: str) -> int | None:
    head = story_key.split("-", 1)[0]
    return int(head) if head.isdigit() else None
