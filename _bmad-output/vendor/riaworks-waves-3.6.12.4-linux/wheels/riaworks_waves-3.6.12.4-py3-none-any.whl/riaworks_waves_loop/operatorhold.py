"""Operator hold: a short lease that stops a live session's timeout clock while
a human is talking to it.

``limits.session_timeout_min`` is wall-clock and knows nothing about who is
typing. The engine's own repair path already types into a live session (the
stall and resultless-Stop nudges), so an operator speaking to one is the same
class of event — except for the clock: a conversation spends the session's
budget, and the ceiling is read once at launch and re-read only on ``resume``,
so with a run in flight it cannot be raised. Without a hold, talking to a
session is a way to get it killed mid-work.

A lease, deliberately, and not a switch
---------------------------------------
The hold carries an expiry and must be refreshed. Three properties follow, and
each one is the answer to a way the naive version fails:

* **The operator vanishing is safe.** A dropped connection, a closed laptop, a
  killed skill — the lease lapses on its own and the ordinary timeout resumes.
  A switch would have to be turned off by the same person who is no longer
  there.
* **A forgotten hold cannot pin a session forever.** Crediting stops at
  ``limits.operator_hold_max_min`` no matter how faithfully the lease is
  refreshed, so the worst case is bounded rather than open.
* **A host suspend cannot be laundered into credit.** The wait loop credits at
  most the lease's own remainder per tick, so a nap longer than the lease
  expires it instead of being paid for. This is the one sanctioned exception to
  #157's "the wall clock may expire a deadline, never extend it", and it is
  sanctioned only because both bounds above hold.

What it does NOT do
-------------------
It does not pause the session, the agent, or the run. Work continues while the
hold is live; only the *deadline* moves. Nothing here is a completion path:
the session still finishes on a hook Stop or on window death, and the
post-session verification is unchanged.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass
from pathlib import Path

from .platform_util import atomic_replace

#: Per-task, never per-run. A hold is granted for the conversation happening in
#: one session and must not outlive it: the next session opens its own task dir
#: and starts with a clean clock, so a hold nobody released cannot bleed into
#: work the operator never looked at.
HOLD_FILE = "operator-hold.json"

#: A heartbeat older than this means no session is being waited on right now.
#: Six missed beats at the adapter's 30s cadence — the same slack the monitors
#: use, so operator tooling and the engine agree on what "live" means.
LIVE_HEARTBEAT_MAX_S = 180.0


@dataclass(frozen=True)
class Hold:
    """A granted lease. ``until`` is wall-clock, because the process that writes
    it and the process that reads it are different and share no monotonic
    origin."""

    until: float
    by: str
    reason: str
    granted: float
    refreshes: int

    def remaining(self, now: float) -> float:
        return max(0.0, self.until - now)

    def to_dict(self) -> dict:
        return {
            "until": self.until,
            "by": self.by,
            "reason": self.reason,
            "granted": self.granted,
            "refreshes": self.refreshes,
        }


def hold_path(task_dir: Path) -> Path:
    return task_dir / HOLD_FILE


def read(task_dir: Path) -> Hold | None:
    """The lease on disk, or None when there is none to trust.

    Missing, unreadable, malformed and wrong-typed all answer None — the same
    answer, on purpose. This is read on every tick of the wait loop, and a
    reader that raised there would let a corrupt byte kill a healthy session.
    Refusing to credit is always the safe direction: the worst outcome is that
    the operator's clock keeps running, which is exactly what happens today.
    """
    try:
        raw = json.loads(hold_path(task_dir).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    if not isinstance(raw, dict):
        return None
    try:
        until = float(raw["until"])
        granted = float(raw.get("granted", until))
        refreshes = int(raw.get("refreshes", 0))
    except (KeyError, TypeError, ValueError):
        return None
    return Hold(
        until=until,
        by=str(raw.get("by", "")),
        reason=str(raw.get("reason", "")),
        granted=granted,
        refreshes=refreshes,
    )


def live(task_dir: Path, now: float | None = None) -> Hold | None:
    """The lease, only while it is still in force."""
    held = read(task_dir)
    if held is None:
        return None
    return held if held.remaining(time.time() if now is None else now) > 0 else None


def refresh(
    task_dir: Path,
    lease_s: float,
    *,
    by: str,
    reason: str = "",
    now: float | None = None,
) -> Hold:
    """Grant or extend the lease, and return what is now in force.

    Written whole through ``atomic_replace``: the wait loop reads this file
    every tick, and a torn read would land as "no hold" — a momentary, silent
    loss of the very protection the operator just asked for.

    ``granted`` and ``refreshes`` survive an extension so the record shows how
    long a conversation actually held the clock, which is what a later reader
    needs to judge whether the cap was reached because of one long intervention
    or a hundred forgotten ones.
    """
    stamp = time.time() if now is None else now
    previous = read(task_dir)
    held = Hold(
        until=stamp + max(0.0, lease_s),
        by=by,
        reason=reason,
        granted=previous.granted if previous is not None else stamp,
        refreshes=(previous.refreshes + 1) if previous is not None else 0,
    )
    task_dir.mkdir(parents=True, exist_ok=True)
    tmp = hold_path(task_dir).with_suffix(".json.tmp")
    tmp.write_text(json.dumps(held.to_dict(), ensure_ascii=False), encoding="utf-8")
    atomic_replace(tmp, hold_path(task_dir))
    return held


def release(task_dir: Path) -> bool:
    """Drop the lease. True when one was there to drop.

    Releasing is a courtesy, never a requirement: the lease expires on its own,
    and every path that forgets to call this degrades to waiting out the
    remainder rather than to a stuck session.
    """
    try:
        hold_path(task_dir).unlink()
        return True
    except OSError:
        return False


def live_task(run_dir: Path, now: float | None = None) -> tuple[str, dict] | None:
    """The task whose session is being waited on right now, and its heartbeat.

    Read from ``tasks/<id>/heartbeat.json`` rather than from state.json because
    the heartbeat is written by the wait loop itself: it answers "is a session
    being waited on **at this moment**", which is the only question an operator
    about to type into a window actually has. A run between sessions, paused, or
    with a dead engine has no fresh heartbeat and answers None.
    """
    stamp = time.time() if now is None else now
    best: tuple[str, dict] | None = None
    best_ts = 0.0
    tasks = run_dir / "tasks"
    try:
        entries = sorted(tasks.iterdir())
    except OSError:
        return None
    for task_dir in entries:
        if not task_dir.is_dir():
            continue
        try:
            beat = json.loads((task_dir / "heartbeat.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if not isinstance(beat, dict):
            continue
        try:
            ts = float(beat.get("ts", 0.0))
        except (TypeError, ValueError):
            continue
        if stamp - ts > LIVE_HEARTBEAT_MAX_S:
            continue
        if ts >= best_ts:
            best_ts, best = ts, (task_dir.name, beat)
    return best
