"""Where code+git work happens, decoupled from where run state lives.

A Workspace pairs the directory sessions run in (and git operates on) with the
artifact paths rebased onto it. Run state (run_dir, journal, state.json) always
lives in the main repo and is passed separately — it never moves.

- isolation = none → Workspace.default(paths): root = paths.repo_root, behavior
  identical to operating directly on the project.
- isolation = worktree → per unit: a git worktree mounted under the run dir
  (.waves/loop/runs/<run_id>/worktrees/, which `waves init` gitignores, so it
  stays invisible to the main checkout's `git status`), with paths rebased onto
  it — a project nested inside `repo_root` keeps its offset there (DW-379), while
  `root` stays the checkout root either way. open_unit_workspace /
  close_unit_workspace manage the branch + worktree lifecycle; the engine merges
  the unit branch back into the target branch from the main repo between units.
"""

from __future__ import annotations

import shutil
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

from . import namespace, verify
from .bmadconfig import ProjectPaths
from .platform_util import safe_ref_segment, safe_segment
from .recovery_flow import PRESERVE_REF_PROBE_LIMIT, attempt_preserve_ref_name

# Per-unit worktrees live under the run dir (.waves/loop/runs/<run_id>/worktrees/),
# which `waves init` already gitignores — so unit checkouts never show up as
# untracked files in the main checkout. Crucially they must NOT live under .git/:
# a cwd inside .git/ is treated as git-internal by the coding CLIs (Claude Code),
# which then refuse to load the project's waves-* skills — breaking every
# worktree session (`Unknown command: /bmad-build-auto`).
WORKTREE_DIRNAME = "worktrees"


def unit_worktrees_dir(run_dir: Path) -> Path:
    """The parent dir holding this run's per-unit worktrees."""
    return run_dir / WORKTREE_DIRNAME


def _rmtree_confined(wt: Path, run_dir: Path) -> bool:
    """rmtree `wt` only when it resolves to a strict descendant of this run's
    worktrees dir; returns whether deletion was attempted. The teardown fallbacks
    reach for rmtree with paths that can arrive from persisted task state
    (`task.worktree_path` via discard_worktree and `_reopen_unit`), and rmtree —
    unlike `git worktree remove` — performs no validation of its own, so a
    corrupt or hand-edited state entry must not be able to point it at the repo
    root or anywhere else outside the run's scaffolding (same doctrine as
    runs.reconcile_orphan_worktrees / resolve_run_dir)."""
    try:
        root = unit_worktrees_dir(run_dir).resolve()
        target = wt.resolve()
        target.relative_to(root)
    except (ValueError, OSError):
        return False
    if target == root:
        return False
    shutil.rmtree(target, ignore_errors=True)
    return True


@dataclass(frozen=True)
class Workspace:
    root: Path  # where sessions run (cwd) and git operates
    # artifact paths rebased onto `root`; under isolation `paths.project` is the
    # mount project (`root` itself, or `root/<offset>` for a nested project)
    paths: ProjectPaths

    @classmethod
    def default(cls, paths: ProjectPaths) -> Workspace:
        """The zero-config workspace: work happens in the repo root in place."""
        return cls(root=paths.repo_root, paths=paths)


@dataclass(frozen=True)
class UnitWorkspace:
    """A per-unit worktree workspace plus the bookkeeping needed to merge it
    back and tear it down from the main repo."""

    workspace: Workspace  # rebased onto the worktree dir
    repo_root: Path  # the main repo (where merges + worktree removal happen)
    branch: str  # the unit branch checked out in the worktree
    path: Path  # the worktree dir
    baseline: str  # commit the worktree was cut from (for failed-diff capture)


def unit_branch_name(run_id: str, unit_key: str, branch_per: str) -> str:
    """branch_per=run shares one branch across the whole run; branch_per=story
    gives each unit its own branch.

    Both segments are ref-sanitized: `--run-id` is user-suppliable and a unit key is
    a sprint-board / ledger id, so either can carry ref-illegal sequences (`:`, `..`,
    `@{`, a trailing `.lock`) that git rejects at branch-creation time. Clean ids —
    every auto-generated run id and every conventional story key — pass through
    byte-identical. This is the single source of the name: `open_unit_workspace` is
    the sole caller and stores the result on `task.branch`, which every consumer
    (`_merge_local`, `discard_worktree`, `close_unit_workspace`) reuses.
    """
    if branch_per == "run":
        return f"{namespace.REF_NAMESPACE}/{safe_ref_segment(run_id)}"
    return f"{namespace.REF_NAMESPACE}/{safe_ref_segment(run_id)}/{safe_ref_segment(unit_key)}"


def orphan_preserve_ref_name(run_id: str, head: str) -> str:
    """Canonical snapshot ref for the uncommitted state of an orphaned mount.

    Lives under ``refs/attempt-preserve-dirty/`` — the SAME family
    :func:`verify.prune_preserve_dirty_refs` bounds with ``scm.preserve_keep`` at
    every run start — so an orphan snapshot is retained and expired on exactly
    the terms a rollback snapshot is, and no new unbounded ref family exists. The
    ``-orphan`` suffix keeps it from ever colliding with a rollback's
    ``{slug}-{baseline}-{attempt}`` shape, whose last segment is an integer.
    """
    return f"refs/attempt-preserve-dirty/{safe_ref_segment(run_id)}-{head[:8]}-orphan"


def _orphan_owned_rels(wt: Path, paths: ProjectPaths, spec_file: str | None) -> tuple[str, ...]:
    """The mount-relative paths of the orchestrator's OWN artifacts inside an
    orphaned mount at ``wt`` — the deferred-work ledger, the sprint board and the
    accepted spec — for :func:`verify.snapshot_worktree`'s ``force_include``.

    Without this the orphan snapshot cannot see them at all. Its untracked
    candidates come from ``verify.untracked_files``, i.e. ``git ls-files --others
    --exclude-standard``, which excludes IGNORED files by contract — and these three
    are ignored inside every mount by construction: ``WorktreeFlow`` seeds them into
    a checkout that carries tracked files only, and folds every seeded rel into the
    worktree-local ``info/exclude`` so the unit's ``git add -A`` cannot ride them
    onto the merge. So the mount holds the only copy, the reclaim's
    ``worktree_remove(force=True)`` deletes it, and an orphan never merges — no
    carry runs and no replay handle survives (`_replay_unlatched_ledger_carries`
    gates on ``task.worktree_path``, cleared when the flip releases the mount).
    Worse, over a CLEAN tracked tree ``snapshot_worktree`` returns ``None``, so the
    loss came with no ref, no ``on_orphan_preserved`` callback and no journal line.

    Deliberately NARROW: naming every ignored path instead would park the seeded
    ``_bmad/`` tree, the adapters' MCP configs and venv residue into a
    ``refs/attempt-preserve-dirty/*`` object that ``scm.preserve_keep`` retains 20
    deep. Refusing the reclaim instead is no remedy either — every mount has
    shielded ignored files by construction, so the flip-back path would never work
    again.

    Derived from ``paths`` rebased onto the mount, and each candidate is included
    only when it is present there as a REGULAR FILE inside the mount root: the
    ``git add -f`` in ``snapshot_worktree`` is a repair write that raises (and so
    refuses the remount) on a path it cannot stage. ``resolve()`` decides
    containment, so a candidate that lands outside the mount drops out.

    Each candidate is judged ALONE, which is the whole point of the per-candidate
    ``try``. An artifacts dir configured outside the project tree is a supported
    shape, and ``ProjectPaths.rebased`` deliberately leaves it unmoved there
    ("configured outside the project tree; doesn't move"): the ledger and the board
    then resolve outside the mount and SHOULD drop, because they are shared rather
    than per-checkout and the reclaim cannot destroy them. The spec must not drop
    with them — ``WorktreeFlow._accepted_spec_seed`` lays it INSIDE the mount
    whatever the artifacts dir is doing, so there it is still the only copy. A
    single ``try`` around the loop returned ``()`` for all three the moment the
    first candidate raised, making this fix silently inert in exactly that
    configuration — the same silence it exists to remove.

    Naming DEGRADES to ``()`` only on a setup fault (the mount path or the rebase
    itself), in ``WorktreeFlow._ledger_seed``'s style: this function decides which
    rels are orchestrator-owned, and an unanswerable question about that is not
    evidence of work to lose. The #340 gate stays where the capture is — a rel this
    DOES name that git then cannot stage raises and leaves the orphan standing.
    """
    # Setup only: a fault here has no per-candidate meaning, so it voids the answer.
    try:
        root = wt.resolve()
        mounted = paths.rebased(wt)
    except (OSError, RuntimeError):
        return ()
    spec_candidate: Path | None = None
    if spec_file and not Path(spec_file).is_absolute():
        try:
            spec_candidate = verify.resolve_spec_path(spec_file, mounted)
        except OSError:
            # That probe decides between its two locations with `is_file()`, which
            # re-raises EACCES through 3.13 (3.14 returns False instead — neither is
            # relied on). An unreadable probe drops the SPEC leg alone.
            spec_candidate = None
    candidates = [mounted.deferred_work, mounted.sprint_status]
    if spec_candidate is not None:
        candidates.append(spec_candidate)
    rels: list[str] = []
    for candidate in candidates:
        # Per candidate, never shared: one path that is out-of-mount, unreadable or a
        # broken link drops ITSELF. A single try around the loop would have the
        # out-of-tree artifacts dir — a supported configuration whose ledger and board
        # correctly drop — take the spec down with them, and the spec IS in the mount.
        try:
            target = candidate.resolve()
            if not target.is_file():
                continue
            rel = target.relative_to(root).as_posix()
        except (OSError, RuntimeError, ValueError):
            continue
        if rel and rel != "." and rel not in rels:
            rels.append(rel)
    return tuple(rels)


def _preserve_orphan_state(
    repo_root: Path,
    wt: Path,
    run_id: str,
    unit_key: str,
    paths: ProjectPaths,
    spec_file: str | None,
    on_orphan_preserved: Callable[[str, str], None] | None,
) -> None:
    """Park the uncommitted work an orphaned mount at ``wt`` still holds before the
    reclaim force-removes it. See the reclaim comment in :func:`open_unit_workspace`
    for why an orphan can stand at this path at all.

    Three-way guard before any git runs *in* ``wt``: the path exists, it is one of
    ``repo_root``'s registered linked worktrees, AND git invoked there reports that
    exact toplevel (:func:`verify.worktree_is_registered`). The run dir lives INSIDE
    the project checkout, so a leftover plain directory (rmtree fallback residue, an
    operator's copy) would otherwise make ``git status``/``add`` address the
    PROJECT's own working tree and park — or worse, report as the orphan's — the
    user's uncommitted edits. Anything that fails the guard is left to the reclaim
    exactly as before this gate existed.

    ``baseline_untracked=[]``, not ``None``: a mount is a fresh checkout, so every
    non-ignored untracked file in it was run-created (seeded skill/config files are
    shielded as ignored, see ``provision_worktree``) and there is no pre-existing
    user file to protect — ``None`` would park the tracked edits and silently drop
    every untracked file, which for a run that writes new modules is most of the
    work. The snapshot is taken against the orphan's OWN ``HEAD`` (before any story
    branch reset below moves that ref) so the parked commit is parented at the tree
    the orphan actually diverged from and holds only what was uncommitted.

    ``[]`` is nonetheless the MAXIMALLY preserving value and still not enough: the
    parked set is the derived difference ``untracked_files(repo) -
    baseline_untracked``, and ``untracked_files`` excludes ignored paths by
    contract. The orchestrator's own artifacts are ignored inside every mount by
    construction, so they need the narrow ``force_include``
    :func:`_orphan_owned_rels` derives — which is also what makes a CLEAN tracked
    tree stop being a silent total loss, since the forced ``add`` is what lifts the
    snapshot tree above HEAD.

    An orphan holding nothing in either set is a no-op (no ref, no callback). A
    capture failure raises :class:`verify.GitError` and so refuses the remount
    (#340: a capture failure over a tree with something to lose is a gate, not a
    footnote) — the orphan is left standing for manual recovery, and the caller's
    ``worktree-open-failed`` path defers the unit. ``OSError`` from the snapshot's
    temp index is folded into that same refusal rather than escaping untyped.
    """
    if not wt.exists() or not verify.worktree_is_registered(repo_root, wt):
        return
    try:
        head = verify.rev_parse_head(wt)
        base_ref = orphan_preserve_ref_name(run_id, head)
        ref = base_ref
        serial = 2
        # Same bounded serial probe as RecoveryFlow.preserve_attempt_worktree: a
        # second orphaning of the same HEAD (flip, flip back, flip again with
        # nothing committed in between) must not overwrite the first snapshot.
        while verify.ref_exists(repo_root, ref):
            if serial > PRESERVE_REF_PROBE_LIMIT:
                raise verify.PreserveRefExhaustedError(
                    f"no free snapshot refname for {base_ref}: "
                    f"{PRESERVE_REF_PROBE_LIMIT} candidates through -r{serial - 1} "
                    f"are all taken (prune refs/attempt-preserve-dirty/*, or set "
                    f"scm.preserve_keep to a positive value below that limit)"
                )
            ref = f"{base_ref}-r{serial}"
            serial += 1
        parked = verify.snapshot_worktree(
            wt,
            ref,
            baseline_untracked=[],
            force_include=_orphan_owned_rels(wt, paths, spec_file),
        )
    except OSError as e:
        raise verify.GitError(
            f"cannot snapshot orphaned worktree {wt} for {unit_key} before reclaim: {e}"
        ) from e
    except verify.GitError as e:
        raise verify.GitError(
            f"cannot snapshot orphaned worktree {wt} for {unit_key} before reclaim "
            f"(left standing; recover by hand): {e}"
        ) from e
    if parked is not None and on_orphan_preserved is not None:
        on_orphan_preserved(str(wt), parked)


def _refuse_foreign_checkout(repo_root: Path, branch: str, wt: Path) -> None:
    """Raise ``GitError`` when ``branch`` is checked out anywhere but ``wt``.

    `verify.reset_branch_if_tip` is ``git update-ref`` — a compare-and-swap on the
    ref that does not know or care which worktree has the branch checked out. Moving
    the ref under a live checkout leaves that checkout's files and index at the old
    tip while its HEAD now reads the new one: the operator's tree suddenly looks
    modified. The checkout at ``wt`` — this unit's own deterministic mount path — is
    exempt: the reclaim force-removes it right after, so nothing observes the skew.

    ``wt`` is already resolved by the caller; git's registered path is resolved the
    same way so the two compare lexically on canonical spellings. A registered path
    that cannot be resolved (gone, a permission fault, a symlink loop) is treated as
    foreign: it is not provably ours, and the failure mode of a wrong "ours" is a
    silently desynced checkout, so the doubt refuses.
    """
    holder = verify.branch_checkout_path(repo_root, branch)
    if holder is None:
        return
    try:
        resolved = holder.resolve()
    except (OSError, RuntimeError, ValueError) as e:
        raise verify.GitError(
            f"unit branch {branch} is checked out at {holder}, which cannot be "
            f"resolved ({e}); refusing to move the branch under a checkout that is "
            f"not this unit's mount path {wt}"
        ) from e
    if resolved != wt:
        raise verify.GitError(
            f"unit branch {branch} is checked out at {holder}, not at this unit's "
            f"mount path {wt}; the remount would move the branch under that checkout. "
            f"Detach it (git -C {holder} checkout --detach) or remove it "
            f"(git worktree remove {holder}) before remounting"
        )


def open_unit_workspace(
    repo_root: Path,
    paths: ProjectPaths,
    run_id: str,
    unit_key: str,
    base: str,
    branch_per: str,
    run_dir: Path,
    *,
    spec_file: str | None = None,
    on_orphan_preserved: Callable[[str, str], None] | None = None,
) -> UnitWorkspace:
    """Mount a fresh worktree for `unit_key` and return its rebased workspace.

    The worktree is mounted under the run dir (see unit_worktrees_dir), not under
    .git/. A new unit branch is cut from a pinned resolution of ``base``. Existing
    story-scoped branches are abandoned-attempt state: commits unique to their
    named tip are parked under ``attempt-preserve/*``, then the story branch is
    compare-and-swap reset to the pinned base before remount.

    Existing run-scoped branches are cumulative and reattach carrying every unit
    landed so far — but at a tip *caught up to the pinned base*, not blindly at
    their own tip. The target can advance while the run branch is unmounted (live
    policy flips isolation off, a story lands in place on the target, policy flips
    back), and a remount at the stale tip would develop the next unit without that
    story: ``merge_strategy = "ff"`` then refuses integration, the other strategies
    merge stale work. Three shapes, decided on pinned shas: the run tip already
    contains the base — mount as-is; the run tip is an ancestor of the base — the
    run branch is compare-and-swap fast-forwarded to the base BEFORE the mount, so
    the mount comes up at the base; the two diverged — mount at the tip and merge
    the base into the run branch inside the fresh mount. Divergence is the NORMAL
    serial-unit shape under ``merge_strategy = "squash"`` (the target receives a
    squash commit that does not contain the run tip), and identical content on both
    sides merges clean. A conflicting merge is aborted, the just-created mount is
    dropped, and :class:`verify.GitError` is raised: the run branch tip is unchanged
    and an operator must reconcile. The returned ``baseline`` is read AFTER that
    catch-up, so the attempt baseline is the tree the session actually starts from.

    Whatever already occupies the deterministic mount path is reclaimed first. If
    it is a registered worktree of ``repo_root`` (an orphan left standing by an
    isolation flip, see the reclaim comment) its *uncommitted* state — tracked edits,
    run-created untracked files, and the orchestrator-owned artifacts the mount
    shields as ignored (ledger, board, and the ``spec_file`` binding when one is
    passed; see :func:`_orphan_owned_rels`) — is parked under
    ``refs/attempt-preserve-dirty/<run>-<head>-orphan`` before the force-remove; an
    orphan holding none of them parks nothing. ``on_orphan_preserved`` (worktree
    path, ref) fires once per parked snapshot so a caller with a journal can record it —
    ``open_unit_workspace`` has none, in the style of ``close_unit_workspace``'s
    ``on_teardown_degraded``. A snapshot that cannot be written refuses the remount
    (raises ``GitError``) and leaves the orphan standing.

    Both ref moves — the story reset and the run fast-forward — are refused up front
    when the branch is checked out anywhere other than that mount path (an operator
    moved a retained recovery worktree, or holds the branch in the main checkout):
    the compare-and-swap would move the ref under a live checkout and the mount
    would then fail on the held branch anyway. See `_refuse_foreign_checkout`.
    """
    branch = unit_branch_name(run_id, unit_key, branch_per)
    unresolved_wt = unit_worktrees_dir(run_dir) / safe_segment(unit_key)
    try:
        wt = unresolved_wt.resolve()
    except (OSError, RuntimeError, ValueError) as e:
        raise verify.GitError(
            f"cannot resolve worktree mount path for {unit_key} ({unresolved_wt}): {e}"
        ) from e
    # Pin every moving input before the first mutation. A story branch is an
    # attempt-local name: reclaim preserves any commits unique to its old tip,
    # then resets it to the requested base with compare-and-swap semantics. A run
    # branch is cumulative and keeps its own history across remounts, catching up
    # to the pinned base below rather than being reset to it.
    pinned_base = verify.rev_parse_revision(repo_root, base)
    branch_tip: str | None = None
    if verify.branch_exists(repo_root, branch):
        branch_tip = verify.rev_parse_revision(repo_root, f"refs/heads/{branch}")
        # Both ref moves below (the story reset, the run fast-forward) are
        # `update-ref` compare-and-swaps that do not care which checkout holds the
        # branch. The orphan AT `wt` is fine — the reclaim removes it right after —
        # but a checkout anywhere ELSE (an operator `git worktree move`d a retained
        # recovery mount, or checked the branch out in the main tree) would be left
        # with its files and index at the old tip under a ref that moved, and the
        # `worktree_add` that follows fails anyway on the held branch. Refuse
        # before any mutation instead.
        _refuse_foreign_checkout(repo_root, branch, wt)
    # Park an orphan's uncommitted state FIRST — before the story reset below moves
    # the ref the orphan's HEAD points at, so the snapshot is parented at the tree
    # the orphan actually holds and captures only what was never committed.
    _preserve_orphan_state(repo_root, wt, run_id, unit_key, paths, spec_file, on_orphan_preserved)
    if branch_tip is not None and branch_per == "story":
        commits = verify.commits_above(repo_root, pinned_base, branch_tip)
        if commits:
            preserve_ref = attempt_preserve_ref_name(run_id, branch_tip)
            verify.preserve_commits(
                repo_root,
                pinned_base,
                preserve_ref,
                commits=commits,
                revision=branch_tip,
            )
        verify.reset_branch_if_tip(repo_root, branch, pinned_base, branch_tip)
    wt.parent.mkdir(parents=True, exist_ok=True)
    # Reclaim whatever still occupies this unit's mount point before adding.
    # `wt` and `branch` are both DETERMINISTIC in (run_id, unit_key, run_dir), so a
    # re-mount targets the exact path a previous mount used — and `worktree_add`
    # refuses a target that exists or a branch checked out elsewhere, which makes a
    # leftover registration a hard `GitError` rather than a recoverable state.
    # `engine._release_orphaned_mount` reaches that shape by design: when live policy
    # leaves isolation it releases the mount's state and clears the task's claim but
    # deliberately LEAVES the directory standing (the journal names it, "retained for
    # recovery"), so a later flip back to `worktree` re-derives this same path and
    # used to be unrecoverable through the normal run flow. Reclaiming here rather
    # than deleting at the flip keeps that preservation intact for the in-place run
    # and spends the orphan only when a mount actually needs its path.
    #
    # "Retained for recovery" is only honest if the reclaim does not itself destroy
    # what was retained: the force-remove below discards the orphan's uncommitted
    # files irreversibly (even under `keep_failed = true`, which governs teardown
    # after a session, not this pre-mount reclaim), while the story-branch block
    # above preserves committed work alone. `_preserve_orphan_state` closes that
    # gap — a snapshot ref for anything uncommitted, taken before this line.
    #
    # The BRANCH is deliberately not passed: `discard_worktree` would force-delete it.
    # A run-scoped name carries commits earlier units landed; a story-scoped name has
    # already been safely reset above. Dropping only the worktree frees the checkout
    # that blocks `worktree_add` without introducing a second ref mutation here.
    discard_worktree(repo_root, str(wt), "", run_dir=run_dir)
    catch_up_base: str | None = None
    if branch_tip is not None:
        if branch_per == "run" and not verify.is_ancestor(repo_root, pinned_base, branch_tip):
            if verify.is_ancestor(repo_root, branch_tip, pinned_base):
                # The base strictly advanced past the run tip: fast-forward the run
                # branch (compare-and-swap on the pinned tip) so the mount comes up
                # at the base. No mount holds the branch here — the occupancy
                # check above refused any checkout other than the one at ``wt``,
                # and the reclaim released that — so the ref move cannot desync a
                # checkout.
                verify.reset_branch_if_tip(repo_root, branch, pinned_base, branch_tip)
            else:
                catch_up_base = pinned_base  # diverged: merge inside the fresh mount
        verify.worktree_add(repo_root, wt, branch, create=False)
        if branch_per == "story":
            try:
                mounted_tip = verify.rev_parse_head(wt)
                current_tip = verify.rev_parse_revision(repo_root, f"refs/heads/{branch}")
                if mounted_tip != pinned_base or current_tip != pinned_base:
                    raise verify.GitError(
                        f"story branch {branch} moved after reclaim reset: "
                        f"expected {pinned_base}, mounted {mounted_tip}, current {current_tip}"
                    )
            except (verify.GitError, OSError):
                # The branch may have moved after the reset CAS but before checkout.
                # Drop only the mount we just created; the rival ref is evidence and
                # must not be reset or deleted by this failure cleanup.
                discard_worktree(repo_root, str(wt), "", run_dir=run_dir)
                raise
        if catch_up_base is not None:
            try:
                verify.merge_branch(
                    wt,
                    catch_up_base,
                    strategy="merge",
                    message=f"Merge {base} ({catch_up_base[:12]}) into {branch}",
                )
            except verify.GitError as e:
                # `merge_branch` has already aborted a merge that started. Drop only
                # the mount we just created (the run branch keeps its pinned tip)
                # and refuse: the run branch and the target have diverged in a way
                # only an operator can reconcile.
                discard_worktree(repo_root, str(wt), "", run_dir=run_dir)
                raise verify.GitError(
                    f"run branch {branch} at {branch_tip[:12]} diverged from {base} at "
                    f"{catch_up_base[:12]} and the catch-up merge failed; reconcile the "
                    f"run branch by hand before remounting: {e}"
                ) from e
    else:
        verify.worktree_add(repo_root, wt, branch, base=pinned_base, create=True)
    # A story checkout was already verified against the pinned base above.  Do
    # not re-read its symbolic HEAD after that boundary: a rival ref move in this
    # final window would record unverified history as the attempt baseline even
    # though the mounted index and files still represent ``pinned_base``. A run
    # checkout is read here, AFTER the fast-forward/merge catch-up above, so the
    # baseline is the tree the session actually starts from.
    baseline = pinned_base if branch_per == "story" else verify.rev_parse_head(wt)
    return UnitWorkspace(
        workspace=Workspace(root=wt, paths=paths.rebased(wt)),
        repo_root=repo_root,
        branch=branch,
        path=wt,
        baseline=baseline,
    )


def close_unit_workspace(
    unit: UnitWorkspace,
    *,
    success: bool,
    keep_failed: bool,
    run_dir: Path,
    unit_key: str,
    delete_branch: bool = True,
    detach_kept: bool = False,
    diff_max_file_bytes: int | None = None,
    on_teardown_degraded: Callable[[str], None] | None = None,
    forensic_extra: str = "",
) -> Path | None:
    """Tear down (or preserve) a unit's worktree.

    On failure the unit's full diff against its baseline is written to
    `run_dir/failed/<unit_key>/changes.patch` for forensics; when keep_failed is
    set the worktree + branch are left mounted for inspection and nothing else
    happens. On success (or failure without keep_failed) the worktree is removed
    and, if delete_branch, the branch deleted. Returns the patch path it wrote,
    or None.

    Invariant: the teardown tail is post-merge/post-capture housekeeping — the
    unit's content is already safe (merged on success, patch-captured on failure)
    before it runs, so no git teardown failure escapes it. Every `GitError` from
    the worktree removal or branch deletion degrades to a call of
    on_teardown_degraded (given the failure message) instead of crashing the run;
    a clean or force-retried removal is silent (see the teardown tail below). A
    failed diff *capture* breaks the tail's premise instead — the worktree would
    then hold the only copy of the unit's changes — so it is reported the same
    way but preserves the worktree + branch rather than tearing them down. The
    callback itself is the caller's (the engine's `journal.append`, whose OSError
    is engine-wide journal semantics, deliberately unguarded here).

    detach_kept (branch_per=run only): when keep_failed preserves the worktree,
    detach its HEAD so the shared run branch it holds is freed for the next unit
    to mount — otherwise every later unit's `git worktree add` collides on the
    already-checked-out branch. Best effort; see the keep_failed branch below.

    diff_max_file_bytes caps the per-untracked-file size in that forensic patch
    (None = no cap); see verify.capture_diff.

    forensic_extra (failure only) is appended to the captured diff before it is
    written — the caller's record of changes `git diff` cannot see, such as a
    story's edit to a skip-worktree-pinned hook config (DW-479). A non-empty extra
    writes the patch even when the git diff is empty or its capture failed.
    """
    patch: Path | None = None
    if not success:
        capture_err: verify.GitError | None = None
        try:
            diff = (
                verify.capture_diff(unit.path, unit.baseline, max_file_bytes=diff_max_file_bytes)
                if unit.baseline
                else ""
            )
        except verify.GitError as e:
            capture_err = e
            diff = ""
        if forensic_extra:
            if diff and not diff.endswith("\n"):
                diff += "\n"
            diff += forensic_extra
        if diff:
            patch = run_dir / "failed" / safe_segment(unit_key) / "changes.patch"
            patch.parent.mkdir(parents=True, exist_ok=True)
            patch.write_text(diff, encoding="utf-8")
        if capture_err is not None and on_teardown_degraded is not None:
            # the forensic patch is the only copy of a dropped unit's changes; a
            # failed capture means the teardown below would destroy them, so the
            # unit is preserved as if keep_failed (the `or` on the branch below).
            on_teardown_degraded(
                f"diff capture failed for {unit.path}: {capture_err}; "
                "worktree and branch preserved (uncaptured changes)"
            )
        if keep_failed or capture_err is not None:
            if detach_kept:
                # branch_per=run shares one branch across the run; a kept worktree
                # left checked out on it blocks every later unit's `git worktree
                # add` (git refuses a branch checked out elsewhere). Detach HEAD to
                # free the shared branch name while preserving the working tree,
                # uncommitted changes, and the branch ref (still at the kept commit)
                # for inspection. Best effort: on failure the later unit still
                # surfaces the collision via the worktree-open-failed defer path.
                try:
                    verify.checkout_detach(unit.path)
                except verify.GitError:
                    pass
            return patch  # leave the worktree mounted (branch detached if shared)

    # success, or a failure we are not keeping: remove the worktree. A failed
    # tree is dirty, so force; a successful unit was committed + merged, so its
    # tree is clean, but force is harmless and tolerant of stray artifacts.
    try:
        verify.worktree_remove(unit.repo_root, unit.path, force=not success)
    except verify.GitError as first_err:
        try:
            # Ordinary dirty-tree case: the plain remove refused stray untracked
            # artifacts, which --force clears. Not a degradation — stay silent.
            verify.worktree_remove(unit.repo_root, unit.path, force=True)
        except verify.GitError as retry_err:
            # gh-139 fingerprint the retry CAN'T fix: a process the just-ended
            # session left running (e.g. pytest recreating `.pytest_cache`) makes
            # the plain remove fail with ENOTEMPTY (first_err), and by then git has
            # already deleted its admin entry `.git/worktrees/<id>` — so the --force
            # retry fails with "is not a working tree" (retry_err). Force can't
            # restore a dropped admin entry, so fall back to git's own reclaim path
            # (plain rmtree + prune) and degrade to a warning: the content already
            # landed, so this is housekeeping, not a run failure. Both git errors
            # go into the message — each half of the fingerprint is diagnostic.
            # The rmtree is confined to the run's worktrees dir: on resume the
            # path comes from persisted state (_reopen_unit), which git validates
            # but rmtree would not.
            removed = _rmtree_confined(unit.path, run_dir)
            verify.worktree_prune(unit.repo_root)
            msg = (
                f"worktree remove failed for {unit.path} ({first_err}); "
                f"force retry failed ({retry_err}); fell back to rmtree+prune"
            )
            if not removed:
                msg += f" (rmtree refused: {unit.path} resolves outside this run's worktrees dir)"
            elif unit.path.exists():
                # rmtree lost the race too (the writer recreated files under it):
                # the dir survives under the gitignored run dir and is reclaimed
                # later by trim_run_dir / clean — note it, don't block on it.
                msg += f" (dir still present: {unit.path})"
            if on_teardown_degraded is not None:
                on_teardown_degraded(msg)
    try:
        if delete_branch and verify.branch_exists(unit.repo_root, unit.branch):
            # the unit's content is already on the target branch (success) or saved
            # to a patch (failure), so a force delete loses nothing — and squash
            # merges leave the branch looking "unmerged" to `git branch -d`.
            # prune above frees a branch whose worktree dir was rmtree'd, so this
            # still runs after a degraded removal.
            verify.delete_branch(unit.repo_root, unit.branch, force=True)
    except verify.GitError as e:
        # second crash door in this teardown tail: branch deletion is likewise
        # post-merge housekeeping, so degrade it rather than raise past here.
        if on_teardown_degraded is not None:
            on_teardown_degraded(f"branch delete failed for {unit.branch}: {e}")
    return patch


def discard_worktree(repo_root: Path, worktree_path: str, branch: str, *, run_dir: Path) -> None:
    """Best-effort force teardown of a worktree + branch by path/name, for
    resume-restart of a crashed/interrupted unit. Tolerant of partial state.
    `worktree_path` arrives from persisted task state, so the rmtree fallback is
    confined to `run_dir`'s worktrees dir (see _rmtree_confined)."""
    if worktree_path:
        wt = Path(worktree_path)
        try:
            if wt.exists():
                verify.worktree_remove(repo_root, wt, force=True)
        except verify.GitError:
            # same gh-139 hazard as close_unit_workspace: a stray process (or a
            # dropped admin entry) can keep `git worktree remove` from clearing
            # the dir. A leftover dir breaks the resume re-mount at this same path
            # (`git worktree add` refuses a non-empty target), so drop to rmtree.
            _rmtree_confined(wt, run_dir)
        # prune git's admin entry regardless (harmless when nothing is stale) so a
        # half-removed worktree can't block that re-mount.
        verify.worktree_prune(repo_root)
    if branch:
        try:
            if verify.branch_exists(repo_root, branch):
                verify.delete_branch(repo_root, branch, force=True)
        except verify.GitError:
            pass
