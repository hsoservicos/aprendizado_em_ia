"""In-process brain for the Test Architect (TEA) plugin.

The twelve workflows are declarative — ``plugin.toml`` binds each to its stage and
the generic ``<name>_enabled`` overlay turns them on and off with no code here.
This module owns the five things that need logic.

**The readiness gate** (``validate``). Refuse to start when the BMAD Method's TEA
module is not installed, when ``epic_automate`` would write with nothing configured
to commit, and — if asked — when the managed customization files are missing. An
operator learns at startup instead of at the first boundary, hours away.

**Artifact attribution** (``on_pre_workflow_session`` / ``on_post_session``). Every
TEA skill writes to a FIXED name directly under ``test_artifacts``:
``nfr-assessment.md``, ``gate-decision.json``, ``test-review.md``. Nothing in the
name says which story or epic the verdict is about, so a per-story gate and a
per-epic report overwrite each other, and a gate that discovered its artifact by
glob or by mtime would veto a commit on the other cadence's verdict. Their output
path is not configurable either — five of the six TEA skills expose only
``persistent_facts`` and friends. So attribution is MEASURED: snapshot the
directory before the session, diff it after, and copy the delta into a
scope-addressed directory ``teaconfig`` computes. The gate then reads a path it
calculated rather than one it searched for.

**The dirty-tree veto** (``on_pre_workflow_session``). ``epic_automate`` is the one
boundary step that writes, and it must not drag someone else's uncommitted work
into the boundary's commit.

**Both gates** (``on_pre_commit``, ``on_post_epic_boundary``). A verdict of
FAIL/CONCERNS on a step marked ``<step>_enforce`` escalates the story at commit
time, or marks the epic boundary red — the two are different because their stages
are: a story has a unit to escalate, a boundary has none, and the boundary's
stories are already committed. Fail-open throughout: a missing, unparseable or
unattributable artifact never stops anything.

**The boundary commit** (``on_post_epic_boundary``). Left in the tree, the reports
and any test ``epic_automate`` wrote sit there until the next story's dev session
finds them, and get swept into THAT story's commit — wrong author, wrong message,
and a baseline check that no longer means anything.

Ordering makes the last two work: the engine runs the injected workflows FIRST and
fires the ``post_epic_boundary`` hook AFTER (``Engine._epic_boundary_steps``), so
by the time this handler runs every report is on disk and claimed.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import TYPE_CHECKING, Any

from riaworks_waves_loop import gates, namespace, teaconfig, verify
from riaworks_waves_loop.plugins.model import Plugin, PluginError

if TYPE_CHECKING:
    from riaworks_waves_loop.plugins.context import HookContext

# The roles this plugin's workflows run as. Used to recognise our own sessions in
# `post_session`, which fires for every session in the run — dev and review
# included.
TEA_ROLES = frozenset({"atdd", "td", "trace", "nfr", "test-review", "automate", "retro-prep"})

# The three steps that produce a verdict, by role. The `teaconfig.GATE_ARTIFACTS`
# key is the same string; the settings key is derived by scope
# (`story_nfr_enforce`, `epic_nfr_enforce`).
GATE_ROLES = ("trace", "nfr", "test-review")

# The step that writes into the tree at a boundary. The others read and report.
WRITING_ROLE = "automate"

# The two steps that write executable code, and therefore the only ones the
# optional `test_location_hint` is appended to.
WRITING_STEPS = frozenset({"atdd", "automate"})

# Verdicts that enforce. PASS / WAIVED (an explicit human approval to proceed) and
# an unknown-or-not-evaluated verdict never do.
BLOCKING_VERDICTS = frozenset({"FAIL", "CONCERNS"})

# How each artifact carries its verdict:
#   "json"      — a TEA machine-readable file; read `gate_status` / `decision`
#   "md_trace"  — the trace report's `## Gate Decision: <verdict>` heading
#   "md_nfr"    — the NFR report's `**Overall Status:** / **Gate Status:**` line
#   "md_review" — the test-review report's `**Recommendation**:` line
ARTIFACT_KINDS: dict[str, str] = {
    "gate-decision.json": "json",
    "e2e-trace-summary.json": "json",
    "traceability-matrix.md": "md_trace",
    "nfr-assessment.md": "md_nfr",
    "test-review.md": "md_review",
}

# Labels that precede a concrete verdict on a markdown gate line, per artifact.
_MD_LABELS: dict[str, tuple[str, ...]] = {
    "md_trace": ("gate decision",),
    "md_nfr": ("gate status", "overall status", "overall_status"),
}


def _verdict_token(text: str) -> str | None:
    """The canonical gate verdict named anywhere in ``text``, or None. CONCERNS /
    FAIL are checked before PASS so a value line that pairs them (rare) errs toward
    blocking; NOT_EVALUATED and anything unrecognized resolve to None (fail-open)."""
    up = text.upper()
    for token in ("CONCERNS", "FAIL", "WAIVED", "PASS"):
        if token in up:
            return token
    return None


def _review_token(line: str) -> str | None:
    """Map the test-review report's recommendation vocabulary onto a gate verdict:
    Block -> FAIL, Request Changes -> CONCERNS, Approve[/with Comments] -> PASS."""
    low = line.lower()
    if "block" in low:
        return "FAIL"
    if "request change" in low:
        return "CONCERNS"
    if "approve" in low:
        return "PASS"
    return None


def _scan_markdown(text: str, labels: tuple[str, ...], normalize) -> str | None:
    """First *concrete* labeled line that yields a verdict. Lines carrying ``{}``
    placeholders or ``|`` table syntax are skipped — they are template scaffolding,
    not a generated decision — so a real artifact's value line is what's read."""
    for raw in text.splitlines():
        line = raw.strip()
        if not line or "{" in line or "}" in line or "|" in line:
            continue
        if any(label in line.lower() for label in labels):
            verdict = normalize(line)
            if verdict is not None:
                return verdict
    return None


def _settings_key(scope_kind: str, role: str, suffix: str) -> str:
    """`("story", "test-review", "enforce")` -> `"story_test_review_enforce"`. The
    manifest's keys are the workflow names, and a workflow name cannot carry a
    hyphen the way a role does."""
    return f"{scope_kind}_{role.replace('-', '_')}_{suffix}"


class WavesTeaPlugin(Plugin):
    """Trust-gated in-process plugin (loads only when "waves-tea" is in
    ``[plugins] enabled``)."""

    # A readiness failure is a deliberate config rejection raised from validate()
    # (it fails the run fast), not an isolated hook crash. Every handler below is
    # advisory or fail-open by design — a boundary that cannot commit reports and
    # moves on; a gate that cannot read an artifact does not block — so an isolated
    # failure is the right outcome and fail_closed stays off.
    fail_closed = False

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        # Captured in validate(): the boundary commit runs the project's own verify
        # commands, and HookContext does not carry the policy.
        self._policy: Any = None
        # Artifact-directory snapshots taken before each of our sessions, keyed by
        # (scope kind, scope ident, role). Per-run in-memory state: a snapshot that
        # never gets its `post_session` (a crashed host) is simply dropped, and the
        # next run measures again.
        self._snapshots: dict[tuple[str, str, str], dict[str, tuple[int, int]]] = {}

    # ----------------------------------------------------------- validation

    def inapplicable_reason(self) -> str | None:
        """Inert, with the reason, in a project that has no TEA to invoke.

        The plugin ships enabled; the Test Architect module does not. In a project
        without `_bmad/tea/config.yaml` every step would dispatch a session into a
        skill that does not exist, so the honest default is to do nothing and say
        why — `validate` reports it, the sprint tree lists no boundary steps, and
        the run is otherwise the run it would have been without the plugin.

        `require_tea = true` is the strict reading: a project that DEMANDS TEA
        wants a missing install to be a startup failure, not a quiet no-op, so this
        answers None there and lets `validate` raise as it always has."""
        if self._on("require_tea", False):
            return None
        root = self.project_root or Path.cwd()
        if (root / teaconfig.TEA_CONFIG_REL).is_file():
            return None
        return (
            "the BMAD Method's Test Architect (TEA) module is not installed in this "
            f"project (missing {teaconfig.TEA_CONFIG_REL.as_posix()}) — the TEA steps have "
            "nothing to invoke. Install it with `npx bmad-method install` (choose 'Test "
            f"Architect'), set require_tea = true under [plugins.{namespace.PLUGIN_TEA}] to make "
            "this a startup failure, or set [plugins] enabled = [] to opt out"
        )

    def validate(self, policy: Any) -> None:
        """Readiness gate. Raising here propagates through ``registry.validate``,
        so the run fails at startup rather than at the first boundary — which on a
        real run is hours away."""
        self._policy = policy
        # `project_root` is set by the registry before this runs; cwd is the
        # fallback for a registry built without one. They differ whenever
        # `--project` points somewhere other than the working directory, and
        # reaching for cwd there validates one tree while the run drives another.
        root = self.project_root or Path.cwd()

        if self._on("epic_automate_enabled", False) and not self._on("commit_boundary_writes"):
            raise PluginError(
                f"plugin '{namespace.PLUGIN_TEA}': epic_automate_enabled = true with "
                "commit_boundary_writes = false leaves the tests it writes "
                "uncommitted in the working tree, where the next story's dev "
                "session picks them up under its own commit. Turn "
                "commit_boundary_writes on, or turn epic_automate off."
            )

        if self._on("require_tea", False):
            config = root / teaconfig.TEA_CONFIG_REL
            if not config.is_file():
                raise PluginError(
                    f"plugin '{namespace.PLUGIN_TEA}': the BMAD Method's Test Architect (TEA) "
                    f"module is not installed in this project (missing {config}). Install "
                    "it with `npx bmad-method install` and choose 'Test Architect', or set "
                    f"require_tea = false under [plugins.{namespace.PLUGIN_TEA}] in "
                    f"{namespace.STATE_REL}/policy.toml to run the workflows without it."
                )

        if self._on("require_test_location_fact", False):
            missing = [
                m.rel_path.as_posix()
                for m in teaconfig.managed_customizations()
                if m.is_ours(root) is None
            ]
            if missing:
                raise PluginError(
                    f"plugin '{namespace.PLUGIN_TEA}': require_test_location_fact is on and "
                    f"these customization files are missing: {', '.join(missing)}. Run "
                    f"`{namespace.PRODUCT} tea-config --write` (or `{namespace.PRODUCT} init`) "
                    "to write them, or turn the setting off."
                )

    # ------------------------------------------- attribution + the dirty veto

    def on_pre_workflow_session(self, ctx: "HookContext") -> None:
        """Three jobs, all before one of our sessions launches: veto ``automate``
        on a foreign-dirty tree, append the optional test-location hint to the two
        steps that write code, and snapshot the artifacts directory so the session's
        output can be attributed afterwards."""
        scope = self._scope(ctx)
        if scope is None or ctx.role not in TEA_ROLES:
            return

        if ctx.role == WRITING_ROLE and scope.kind == "epic" and self._veto_dirty(ctx):
            return  # vetoed: no session, so nothing to snapshot

        hint = str(self.settings.get("test_location_hint", "") or "").strip()
        if hint and ctx.role in WRITING_STEPS and ctx.proposed_prompt is not None:
            ctx.proposed_prompt = f"{ctx.proposed_prompt}\n\n{hint}"

        layout = self._layout(ctx)
        self._snapshots[(scope.kind, scope.ident, ctx.role)] = layout.snapshot()

    def _veto_dirty(self, ctx: "HookContext") -> bool:
        """Skip ``automate`` when the tree was ALREADY dirty when the boundary
        started.

        The question is "dirty by WHOM", not "dirty". By the time ``automate`` runs,
        the four reports have written their artifacts, so a plain ``git status``
        here is dirty every single time and would veto the step at every boundary,
        deterministically. ``ctx.dirty_baseline`` is what the engine measured on
        ENTRY to the boundary — exactly the foreign work this guard keeps out of the
        commit.

        Without a baseline (an engine that does not provide one), the guard stands
        down rather than guessing: a missing measurement is not evidence of dirt,
        and vetoing on it would cost a coverage expansion at every boundary for
        nothing."""
        foreign = sorted(getattr(ctx, "dirty_baseline", ()) or ())
        if not foreign:
            return False
        sample = ", ".join(foreign[:5]) + ("…" if len(foreign) > 5 else "")
        ctx.veto(
            "skip",
            f"the tree was already dirty when the boundary started "
            f"({len(foreign)}: {sample}) — automate skipped so its commit does not "
            f"carry work that is not its own",
        )
        return True

    def on_post_session(self, ctx: "HookContext") -> None:
        """Attribute what the session just wrote to its scope.

        Fires for every session in the run, so the snapshot taken in
        ``on_pre_workflow_session`` is what identifies ours: no snapshot, nothing to
        claim. Popped rather than read, so a retried step measures again instead of
        diffing against a stale baseline."""
        scope = self._scope(ctx)
        if scope is None or ctx.role not in TEA_ROLES:
            return
        before = self._snapshots.pop((scope.kind, scope.ident, ctx.role), None)
        if before is None:
            return
        self._layout(ctx).claim(scope, before)

    # ------------------------------------------------ the story gate (commit)

    def on_pre_commit(self, ctx: "HookContext") -> None:
        """For each per-story gate marked ``<step>_enforce``, read its verdict and,
        on FAIL/CONCERNS, ``pause``-veto so the story escalates for a human instead
        of committing.

        ``pre_commit`` is the first vetoable stage AFTER the ``pre_commit_gate``
        sessions have written their artifacts, and both fire unconditionally before
        every commit — review-converged, review-skipped and budget-rescue alike — so
        enforcement holds even when the orchestrator's review loop never runs.

        Fail-open throughout: a gate not enforced, with no artifact, or with an
        artifact that does not parse contributes nothing. Only a confidently-read
        blocking verdict escalates. ``pre_commit`` honors only a ``pause`` veto,
        which is the right "quality gate failed" semantic — a COMMITTING task has no
        legal move to DEFERRED."""
        scope = self._scope(ctx)
        if scope is None or scope.kind != "story":
            return
        verdicts, failed = self._read_verdicts(ctx, scope)
        if verdicts:
            ctx.shared.setdefault("tea_gates", {}).update(verdicts)
        if not failed:
            return
        detail = ", ".join(f"{role}={verdict}" for role, verdict in failed)
        ctx.veto(
            "pause",
            f"TEA gate(s) failed for {ctx.story_key or 'unit'}: {detail}. Review the "
            f"artifacts under {self._layout(ctx).scope_dir(scope)}, resolve the findings, "
            "then resume the run.",
        )

    # --------------------------------------- the epic gate + boundary commit

    def on_post_epic_boundary(self, ctx: "HookContext") -> None:
        """Report each enforced epic verdict as a boundary step, then commit what
        the boundary wrote.

        Reporting, not vetoing: a boundary has no unit to defer and its stories are
        already committed, so the sanctioned outcome is a red boundary that
        ``[gates] epic_gate = "on-failure"`` pauses on — never an undo."""
        scope = teaconfig.Scope.for_epic(ctx.epic) if ctx.epic is not None else None
        if scope is not None:
            verdicts, failed = self._read_verdicts(ctx, scope)
            if verdicts:
                ctx.shared.setdefault("tea_gates", {}).update(verdicts)
            for role, verdict in failed:
                ctx.report_step(role, verdict, ok=False)
        self._commit_boundary(ctx)

    def _commit_boundary(self, ctx: "HookContext") -> None:
        """Verify, then commit whatever the boundary's workflows wrote.

        Advisory throughout: a red suite, an unreadable tree or a failed commit is
        reported and journaled, never a veto — the epic's stories are already
        committed, and nothing here is worth undoing them for. A clean tree means
        the workflows wrote nothing (or every step was off), and this is a no-op."""
        if not self._on("commit_boundary_writes"):
            return
        root = Path(ctx.worktree or ctx.repo_root or Path.cwd())

        try:
            dirty = verify.dirty_paths(root)
        except verify.GitError:
            return  # cannot measure: leave the tree alone
        if not dirty:
            return

        epic = "?" if ctx.epic is None else str(ctx.epic)
        verified = False
        if self._on("verify_before_commit"):
            failures = self._verify_failures(root)
            # None = the project configured no verify commands. Nothing was proven,
            # but nothing failed either, and refusing to commit would leave the tree
            # dirty for the next story to swallow — the exact harm this handler
            # exists to prevent. Commit, and do not claim it was verified.
            verified = failures == []
            if failures:
                ctx.shared.setdefault("waves_tea", {})["commit"] = "verify-failed"
                self._notify(
                    ctx,
                    f"{namespace.PLUGIN_TEA}: epic {epic} — verify red after the boundary",
                    f"the boundary wrote {len(dirty)} path(s) but the project's verify "
                    f"commands failed ({'; '.join(failures)}). Nothing was committed — the "
                    f"tree is left dirty for inspection.",
                )
                ctx.report_step("boundary-commit", "verify-failed", ok=False)
                return

        message = (
            f"test(epic-{epic}): TEA boundary artifacts\n\n"
            f"Written by the {namespace.PLUGIN_TEA} workflows at the boundary of epic {epic}"
            f"{', verified by the project’s own [verify] commands' if verified else ''}."
        )
        try:
            head = verify.commit_story(root, message)
        except verify.GitError as e:
            ctx.shared.setdefault("waves_tea", {})["commit"] = "failed"
            self._notify(
                ctx,
                f"{namespace.PLUGIN_TEA}: epic {epic} — boundary commit failed",
                f"the workflows' output is still in the working tree: {e}",
            )
            ctx.report_step("boundary-commit", "failed", ok=False)
            return
        ctx.shared.setdefault("waves_tea", {})["commit"] = head

    # -------------------------------------------------------------- verdicts

    def _read_verdicts(
        self, ctx: "HookContext", scope: teaconfig.Scope
    ) -> tuple[dict[str, str], list[tuple[str, str]]]:
        """``({role: verdict}, [(role, verdict)] that enforce and failed)``.

        Only enforced gates are read at all: an operator who did not ask for
        enforcement gets no file I/O and no chance of a wrong stop."""
        layout = self._layout(ctx)
        verdicts: dict[str, str] = {}
        failed: list[tuple[str, str]] = []
        for role in GATE_ROLES:
            if not self._on(_settings_key(scope.kind, role, "enforce"), False):
                continue
            verdict = self._verdict(layout, role, scope)
            if verdict is None:
                continue  # fail-open: missing / unparseable / not evaluated
            verdicts[role] = verdict
            if verdict in BLOCKING_VERDICTS:
                failed.append((role, verdict))
        return verdicts, failed

    def _verdict(
        self, layout: teaconfig.TeaLayout, role: str, scope: teaconfig.Scope
    ) -> str | None:
        """The verdict for ``role`` in ``scope``, from the artifacts claimed into
        that scope's calculated directory — never from a search. Probes each
        candidate in declaration order and returns the first that parses; any
        read/parse error is swallowed (fail-open) and the next is tried."""
        for path in layout.gate_artifacts(role, scope):
            if not path.is_file():
                continue
            try:
                verdict = self._parse_artifact(ARTIFACT_KINDS.get(path.name, ""), path)
            except Exception:  # nosec B112 - fail-open: a parse error never blocks
                continue
            if verdict is not None:
                return verdict
        return None

    def _parse_artifact(self, kind: str, path: Path) -> str | None:
        """Extract a gate verdict from one artifact, by kind."""
        if not kind:
            return None
        text = path.read_text(encoding="utf-8")
        if kind == "json":
            data = json.loads(text)
            if isinstance(data, dict):
                raw = data.get("gate_status") or data.get("decision")
                if isinstance(raw, str):
                    return _verdict_token(raw)
            return None
        if kind == "md_review":
            return _scan_markdown(text, ("recommendation",), _review_token)
        return _scan_markdown(text, _MD_LABELS[kind], lambda line: _verdict_token(line))

    # --------------------------------------------------------------- helpers

    def _scope(self, ctx: "HookContext") -> teaconfig.Scope | None:
        """Which scope this context is about, or None when it is neither.

        The engine dispatches a boundary's workflows under a SYNTHETIC task whose
        story key is ``epic-<n>`` (``Engine._run_epic_workflows``); a real story key
        is ``<epic>-<n>-<slug>`` and can never take that shape. That convention is
        what separates the two cadences here, and it is the engine's, not a guess:
        the same synthetic key is what the dashboard keys boundary progress by."""
        story_key = ctx.story_key
        if ctx.epic is not None and story_key == f"epic-{ctx.epic}":
            return teaconfig.Scope.for_epic(ctx.epic)
        if story_key:
            return teaconfig.Scope.for_story(story_key)
        if ctx.epic is not None:
            return teaconfig.Scope.for_epic(ctx.epic)
        return None

    def _layout(self, ctx: "HookContext") -> teaconfig.TeaLayout:
        """Resolved per call against THIS context's tree: under worktree isolation
        each unit has its own root, and a layout resolved against the main checkout
        would attribute a worktree's artifacts to the wrong tree."""
        return teaconfig.load(Path(ctx.worktree or ctx.repo_root or Path.cwd()))

    def _on(self, key: str, default: bool = True) -> bool:
        """A setting's truth, read with the same default the manifest declares so
        this never disagrees with the overlay the registry applies to the workflows
        themselves."""
        return bool(self.settings.get(key, default))

    def _verify_failures(self, root: Path) -> list[str] | None:
        """``[]`` when every verify command passed, a list of "cmd (rc=N)" when some
        failed, and ``None`` when the project configured none — a distinction the
        caller needs: nothing to run is not the same as nothing failing."""
        policy = self._policy
        commands = getattr(getattr(policy, "verify", None), "commands", ())
        if not commands:
            return None
        results = verify.run_verify_commands(policy, root)
        return [f"{r.command} (rc={r.returncode})" for r in results if r.returncode != 0]

    def _notify(self, ctx: "HookContext", title: str, message: str) -> None:
        """The operator channel the engine itself uses: the run's ATTENTION file
        plus a desktop notification, both governed by ``[notify]``. Best-effort by
        construction (``gates.notify`` never raises), and skipped when there is no
        run dir or no policy to read the channel settings from."""
        if self._policy is None or not ctx.run_dir:
            return
        gates.notify(self._policy, Path(ctx.run_dir), title, message)
