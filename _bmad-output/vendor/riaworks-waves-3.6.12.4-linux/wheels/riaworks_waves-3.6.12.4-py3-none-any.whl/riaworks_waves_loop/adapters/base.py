"""Coding-CLI adapter seam.

Adapters differ along three orthogonal capability axes, declared as class
attributes so the engine can reason about transport quality instead of
treating every CLI as a dumb terminal:

- injection:   how a prompt reaches the CLI
               "tmux-initial-prompt" | "launch-flag" | "http"
- observation: how turn/session completion is detected
               "hook-signal" | "sse" | "transcript-poll"
- state:       where session state is readable
               "local-jsonl" | "local-json-tree" | "remote"
"""

from __future__ import annotations

import dataclasses
import stat
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

from ..model import TokenUsage
from ..platform_util import is_link_like, safe_segment

if TYPE_CHECKING:
    # `journal.py` imports nothing from `adapters/`, so the runtime import would be
    # cycle-free too; TYPE_CHECKING keeps the adapter seam's import graph as thin as
    # it was (journal pulls in model + platform_util) for the annotation alone.
    from ..journal import Journal


# `env_fault_evidence` stamped by `CodingCLIAdapter._classify_zero_token_timeout`
# (DW-364). Lands verbatim in the pause reason / ATTENTION line, e.g.
# `environment fault: dev session timeout (<this>)`.
ZERO_TOKEN_TIMEOUT_EVIDENCE = (  # nosec B105 - diagnostic prose, not a credential
    "session timed out having consumed zero tokens (tracked usage) — "
    "the CLI never got a usable response from the provider"
)


class AdapterTaskDirectoryError(ValueError):
    """A built-in adapter refused an unsafe or redirected task directory."""


def validated_task_directory(tasks_dir: Path, task_id: str) -> Path:
    """Return ``tasks/<task_id>`` only when its authored name is confined.

    Validation is deliberately identity-based rather than sanitizing: callers use
    ``task_id`` for handles, environment, logs, and artifacts, so rewriting it here
    would split one session across multiple identities.  The link-like check covers
    both symlinks and Windows directory junctions through ``platform_util``.

    This is a pre-write boundary, not descriptor-anchored I/O; callers must invoke
    it before any operation derived from the task id.
    """
    if safe_segment(task_id) != task_id:
        raise AdapterTaskDirectoryError(
            f"unsafe adapter task id {task_id!r}: expected one clean path segment"
        )

    if is_link_like(tasks_dir):
        raise AdapterTaskDirectoryError(
            f"adapter tasks directory is a symlink or junction: {tasks_dir}"
        )

    task_dir = tasks_dir / task_id
    if is_link_like(task_dir):
        raise AdapterTaskDirectoryError(
            f"adapter task directory is a symlink or junction: {task_dir}"
        )
    return task_dir


def validate_adapter_artifact_paths(root_dir: Path, paths: tuple[Path, ...]) -> None:
    """Refuse redirecting or special standing entries before adapter writes.

    A regular file with one link is the only existing leaf an adapter may open in
    place.  Symlinks, junctions, hardlinks, FIFOs, and devices can redirect or
    block a later write; callers provide every leaf they will write during the
    session and invoke this boundary before mutating any task or log artifact.
    """
    if is_link_like(root_dir):
        raise AdapterTaskDirectoryError(
            f"adapter artifact directory is a symlink or junction: {root_dir}"
        )

    for path in paths:
        if is_link_like(path):
            raise AdapterTaskDirectoryError(f"adapter artifact is a symlink or junction: {path}")
        try:
            entry = path.lstat()
        except FileNotFoundError:
            continue
        except OSError as exc:
            raise AdapterTaskDirectoryError(
                f"cannot inspect adapter artifact before writing: {path}"
            ) from exc
        if not stat.S_ISREG(entry.st_mode) or entry.st_nlink != 1:
            raise AdapterTaskDirectoryError(
                f"adapter artifact is special or multiply linked: {path}"
            )


def reset_task_prompt(task_dir: Path, prompt: str) -> None:
    """Write ``prompt.txt`` without following a redirecting filesystem entry.

    A normal single-link file is truncated in place so its inode and metadata keep
    the clean-session behavior.  A symlink, hardlink, FIFO, or device is unlinked
    first so the replacement is an ordinary file and no outside target is touched.
    """
    prompt_path = task_dir / "prompt.txt"
    try:
        entry = prompt_path.lstat()
    except FileNotFoundError:
        pass
    except OSError as exc:
        raise AdapterTaskDirectoryError(
            f"cannot inspect adapter prompt before writing: {prompt_path}"
        ) from exc
    else:
        if not stat.S_ISREG(entry.st_mode) or entry.st_nlink != 1:
            try:
                prompt_path.unlink()
            except OSError as exc:
                raise AdapterTaskDirectoryError(
                    f"cannot replace unsafe adapter prompt: {prompt_path}"
                ) from exc
    prompt_path.write_text(prompt + "\n", encoding="utf-8")


@dataclass(frozen=True)
class SpecSnapshot:
    """Launch-state fingerprint of a review session's spec, captured by the
    engine immediately after the pre-review-launch marker strip
    (``_reset_spec_for_review``) and threaded onto its ``SessionSpec``.

    Lets the generic adapter's missing-marker fallback deterministically refuse
    to synthesize from a candidate whose bytes are byte-identical to the spec's
    launch state: such a spec is provably untouched by this session, so the
    terminal ``status:`` it carries is the PRIOR pass's ``done`` (re-opened for
    review), not proof this session finished (#276 M1).

    Process-transient: it rides the live ``SessionSpec`` only and is deliberately
    NOT persisted (no ``StoryTask.to_dict`` entry). A crash-resume that
    reconstructs the ``SessionSpec`` therefore carries no snapshot, and the
    fallback degrades to its conservative 2-observation fingerprint path."""

    path: str
    mtime_ns: int
    sha256: str
    fm_status: str


@dataclass(frozen=True)
class SessionSpec:
    task_id: str
    role: str  # "dev" | "review" | "retro"
    prompt: str
    cwd: Path
    env: dict[str, str] = field(default_factory=dict)
    model: str = ""  # empty = CLI default
    effort: str = ""  # empty = CLI default; rendered only by a profile with effort_args
    # fallback only; real dev/review/retro sessions get limits.session_timeout_min * 60
    timeout_s: float = 90 * 60
    # total stall wake-nudges this session may ever receive; None (the raw
    # constructor default) = unbounded. Unlike the adapter's refillable
    # per-silence budget, this cap is monotonic — a session that keeps ending
    # its turn without a result cannot re-earn nudges forever, because the
    # nudge is itself a submitted turn whose reply refills the budget (#149).
    # The engine sets it for every session it drives: workflow_stall_nudges_cap
    # for injected workflow sessions, dev_stall_nudges_cap otherwise, so a
    # missing completion artifact degrades to "stalled" instead of livelocking
    # until timeout_s.
    stall_nudges_cap: int | None = None
    # Ceiling on clock the wait loop may credit back to this session from
    # operator holds (`limits.operator_hold_max_min`, in seconds). 0 — the raw
    # constructor default — disables crediting entirely, so an adapter built
    # outside the engine never silently grows a session's budget.
    operator_hold_max_s: float = 0.0
    # Mid-session token-budget guard (#158): weighted per-session cap the wait
    # loop samples cumulative usage against on its heartbeat cadence. None (the
    # raw constructor default) or mode "off" leaves the guard inert, so adapters
    # constructed outside the engine (tests, MockAdapter) are unaffected. The
    # engine sets these from limits.max_tokens_per_session /
    # limits.session_budget_mode / limits.session_budget_grace_s /
    # limits.cache_read_weight for every session it drives.
    token_budget: int | None = None
    token_budget_mode: str = "off"  # "off" | "warn" | "enforce"
    token_budget_grace_s: float = 240.0
    cache_read_weight: float = 0.1
    # Launch-state snapshot of a review session's spec (#276 M1): captured by the
    # engine right after the pre-review-launch marker strip and threaded here so
    # the generic adapter's missing-marker fallback can deterministically refuse
    # to synthesize from a spec still byte-identical to its launch state. None for
    # every non-review session and on a crash-resume (process-transient — see
    # SpecSnapshot). Kept LAST so positional SessionSpec constructions stay valid.
    spec_snapshot: SpecSnapshot | None = None
    # The spec path this session is REQUIRED to write, when the orchestrator
    # already knows it (#261): `StoryTask.spec_file`, recorded by verify_dev /
    # verify_dev_bundle on dev success and handed to the review session in its own
    # prompt. Set for every leg with a recorded spec — always a review, and a dev
    # retry — and None on a dev attempt 1, whose spec does not exist yet.
    #
    # When set, the generic adapter reads back from THIS path instead of scanning
    # the implementation-artifacts dir for the newest qualifying `*.md`. That scan
    # is shared with every concurrent run: a foreign story's spec landing there
    # after launch (a merge-back into the main checkout, a human edit, a sweep)
    # wins on mtime and is adopted as this session's result, so a review that
    # produced nothing is scored `completed:done` and unreviewed code merges.
    #
    # Deliberately independent of `spec_snapshot`, which degrades to None on a torn
    # read: the identity constraint must not silently disappear with it.
    #
    # Unlike SpecSnapshot this SURVIVES a crash-resume. The field itself is not
    # persisted, but its source is: `StoryTask.spec_file` round-trips through
    # state.json (stored relative to the worktree, re-absolutized by
    # WorktreeFlow on resume), and the engine re-derives this on every launch. So a
    # resumed run is protected too — always an absolute path by the time it lands
    # here. Kept LAST alongside spec_snapshot so positional constructions stay valid.
    expected_spec: str | None = None
    # Native session id to REATTACH to instead of starting a fresh conversation
    # (cheap repair, behind [llm] session_resume). None = normal launch. Only
    # adapters whose profile declares resume_args honor it; the dispatch verb
    # refuses to set it anywhere else, so it can never silently degrade into a
    # fresh session wearing resume's name. Appended after the kept-LAST pair —
    # positional constructions that far in do not exist.
    resume_session_id: str | None = None
    # This fork. Launch with the profile's `hook_trust_bypass_args` because this
    # unit-worktree session INHERITS the main checkout's Codex hook trust
    # (`codex_trust.worktree_launch_trust`). The orchestrator sets it only after that
    # check passed; an adapter whose profile declares no bypass ignores it.
    hook_trust_bypass: bool = False


@dataclass(frozen=True)
class SessionHandle:
    task_id: str
    native_id: str  # tmux window id, HTTP session id, ...
    launched_ns: int = 0  # wall-clock ns just before launch; floor for hook events
    # The CLI session id the adapter chose at launch (DW-505) and passed via the
    # profile's `session_id_flag`; seeds hook-event attribution
    # (`signals.SessionAttribution(pinned_id=...)`). None = the profile declares
    # no such flag, so attribution learns the id from the first SessionStart.
    # Never persisted. Kept LAST so positional constructions stay valid.
    pinned_session_id: str | None = None


@dataclass(frozen=True)
class SessionResult:
    # "aborted" is the in-session hard-stop verdict (#319): the wait loop saw a
    # `mode: "hard"` stop-request.json and tore the session down. It is an abort,
    # NEVER a completion — sessions complete only on hook Stop events or window
    # death (AGENTS.md) — and it never escapes `Engine._run_session`, which
    # unwinds it as a RunStopped before any SessionRecord is written.
    status: str  # "completed" | "stalled" | "timeout" | "crashed" | "over_budget" | "aborted"
    result_json: dict[str, Any] | None = None
    session_id: str | None = None
    transcript_path: str | None = None
    # wall time.time() when wait_for_completion declared the deadline elapsed;
    # None unless this session's timeout actually fired (#157).
    timeout_fired_at: float | None = None
    # which clock(s) had expired at fire time: "monotonic" | "wall" | "both".
    # "wall" alone is the suspend signature — a frozen monotonic clock.
    timeout_expired_clock: str | None = None
    # weighted usage sampled when the session-budget guard tripped (#158); None
    # unless the guard tripped. Set on every post-trip exit — warn-mode sessions
    # that run to completion carry it too — so the engine can journal it.
    budget_weighted: int | None = None
    # transport-failure classification (#194): True when a non-completed session
    # was post-mortem-matched as an *environment fault* (the coding CLI lost its
    # API connection and idled out the session clock instead of doing real work).
    # Set by the _classify_env_fault hook; env_fault_evidence carries the matched,
    # ANSI-stripped log line. New fields are APPENDED below these, never inserted
    # among them, so every positional SessionResult construction stays valid.
    env_fault: bool = False
    env_fault_evidence: str | None = None
    # Whether a `Stop` hook event arrived during this session — the hook half of the
    # #261 proof-of-work gate (see `_ResultFileMixin._produced_work`). Deliberately
    # NOT `session_id is not None`: SessionStart and SessionEnd populate that too,
    # and both fire on a CLI that launched and wedged without doing anything. Stop
    # is the only canonical event that means a turn actually ended.
    stop_seen: bool = False
    # Set on a `crashed` verdict when the mux no longer reports the SESSION, not
    # just its window (#489) — see `GenericAdapter._session_vanished` for why the
    # two are otherwise indistinguishable. Diagnostic label only: it changes the
    # reason text, never the routing. Deliberately NOT carried by
    # `_post_kill_reconcile`'s hand-built result — that path gates on
    # stalled/timeout/over_budget, which this flag can never accompany; add it
    # there if `crashed` ever joins that rescue set.
    session_vanished: bool = False
    # Whether the session showed ANY sign of working before it ended on a
    # non-completed verdict (#727). `True` when a `Stop` arrived, when the adapter
    # has no pane log to read (opencode-http, unit fixtures — "unknown never
    # blocks"), when the pane log changed on a tick later than
    # `generic.FIRST_FRAME_S` after the wait loop started and before the first
    # stall wake nudge was sent, or when the CLI's own transcript changed after
    # its first sample / the usage sampler read a nonzero spend from it (writes a
    # misbound pane sink cannot hide). `False` means the CLI painted at most its
    # first frame and then sat still until the grace, the nudge and the exit: a
    # permission dialog, a login prompt, a dead-on-arrival window. `decide_dev`
    # PAUSEs such a session ahead of the attempt budget, the way an environment
    # fault does, so re-arm restores the attempt instead of a fresh session being
    # launched into the identical wall. Distinct from `stop_seen` (the hook half
    # alone) and from `_ResultFileMixin._produced_work` (the #261 read-back gate's
    # byte floor, which a rendered dialog clears). Default `True` so every
    # positional construction keeps today's routing. APPENDED, never inserted.
    produced_work: bool = True
    # Parked-session signal (DW-348/DW-350): the CLI was waiting on a human — a
    # permission, idle or quota prompt — when the stall grace expired, so the
    # wait loop WITHHELD the stall wake nudge (its Enter could answer the prompt,
    # #727) and ended the session `stalled`. Set only on that `stalled` exit,
    # from a latched parked hook event or a `parked_prompt_patterns` match on the
    # visible pane; never on a `crashed` (window death outranks it) or completed
    # result. Every engine/sweep site PAUSEs on it like `env_fault` (which
    # outranks it), so re-arm restores the attempt instead of a retry relaunching
    # into the same prompt. `parked_evidence` names what matched. APPENDED.
    parked: bool = False
    parked_evidence: str | None = None


class CodingCLIAdapter(ABC):
    name: str = "abstract"
    injection: str = ""
    observation: str = ""
    state: str = ""
    # The run's journal, attached by the engine to every adapter it owns so the
    # adapter can record what only it can see (the #680 `session-idle` /
    # `session-active` pair). None outside an engine — `resolve.run_session`,
    # `probe`, unit fixtures — and every adapter-side emit is gated on it: no
    # journal, no entry. The wait loop runs on the engine thread while the
    # engine's own journal is quiescent, so this adds no second writer, and
    # entries keep the engine's `log_task`/`log_pos` stamps.
    journal: Journal | None = None

    @abstractmethod
    def start_session(self, spec: SessionSpec) -> SessionHandle: ...

    @abstractmethod
    def wait_for_completion(self, handle: SessionHandle, spec: SessionSpec) -> SessionResult: ...

    def send_text(self, handle: SessionHandle, text: str) -> None:
        """Nudge a running session. Optional capability."""
        raise NotImplementedError(f"{self.name} cannot inject into a running session")

    def interactive_argv(self, spec: SessionSpec) -> list[str]:
        """argv that launches the CLI agent attached to the caller's terminal,
        seeded with spec.prompt. Used by the interactive escalation-resolution
        flow; optional capability (e.g. HTTP adapters have no terminal)."""
        raise NotImplementedError(f"{self.name} has no interactive (attached) session mode")

    def interactive_env(self, spec: SessionSpec) -> dict[str, str]:
        """Env vars to layer onto the caller's environment for interactive_argv."""
        return dict(spec.env)

    def kill(self, handle: SessionHandle) -> None:  # optional cleanup
        pass

    def read_usage(self, result: SessionResult) -> TokenUsage | None:
        return None

    def run(self, spec: SessionSpec) -> SessionResult:
        handle = self.start_session(spec)
        try:
            result = self.wait_for_completion(handle, spec)
        finally:
            self.kill(handle)
        result = self._post_kill_reconcile(handle, spec, result)
        result = self._classify_env_fault(handle, spec, result)
        return self._classify_zero_token_timeout(result)

    def _post_kill_reconcile(
        self, handle: SessionHandle, spec: SessionSpec, result: SessionResult
    ) -> SessionResult:
        """Last-chance reconcile after the session's window has been torn down.

        Runs only on the normal return path — a raising wait_for_completion
        still kills the window and propagates without reaching this hook.
        Base behavior: identity. Adapters whose completion trust keys on
        window death (see GenericDevAdapter) may re-inspect on-disk state here,
        now that the kill has settled the liveness question a live-window
        verdict had to leave open."""
        return result

    def _observe_tick(self, handle: SessionHandle, spec: SessionSpec) -> None:
        """Heartbeat-cadence hook for mid-session on-disk observation, called from
        the wait loop's heartbeat-throttled block (~every HEARTBEAT_INTERVAL_S; the
        first tick always fires). Base behavior: nothing. Adapters that drive a
        skill whose terminal on-disk state is heuristic to attribute may sample it
        here (see GenericDevAdapter's `_DevSynthesisMixin`, which records the spec's
        first non-terminal status transition to make a later terminal frontmatter
        deterministic proof this session wrote it, #276 M2). An observation seam
        only — it MUST NOT mutate session state or the spec, and any read failure is
        a sample it silently skips, never a verdict."""
        return None

    def _classify_env_fault(
        self, handle: SessionHandle, spec: SessionSpec, result: SessionResult
    ) -> SessionResult:
        """Last-chance post-mortem: label a non-completed session an environment
        fault (#194) when the CLI never got usable work out of the provider —
        connection lost, or quota/rate limit refused — and idled out the session
        clock rather than doing real work.

        Runs LAST in ``run()`` — after ``_post_kill_reconcile`` — so a reconcile
        upgrade to ``completed`` is never re-classified, and only a genuinely
        non-completed verdict (``result_json is None``) is ever inspected. Base
        behavior: identity, like ``_post_kill_reconcile``, so an adapter with no
        session log at all (mock) stays inert.

        Any adapter that writes a per-task diagnostic log should mix in
        ``EnvFaultMixin``, which matches profile patterns against the tail of the
        file its ``ENV_FAULT_LOG_SUFFIX`` names and stamps ``env_fault`` /
        ``env_fault_evidence`` onto the result. That covers the tmux adapters
        (pane capture, ``<task_id>.log``) and the opencode HTTP adapter (the
        serve process's stdout/stderr, ``<task_id>.server.out``, NOT its
        conversation transcript) alike — the signal is the log, not the
        transport. This docstring used to say HTTP adapters had no
        post-mortem signal; that stopped being true once opencode_http began
        teeing its server log, and the stale premise is why a provider quota
        outage went unclassified and burned three stories' retry budgets.

        A second, transport-agnostic post-mortem runs after this hook in
        ``run()``: ``_classify_zero_token_timeout`` (DW-364) labels a timeout
        with tracked zero usage an environment fault. It lives in ``run()``
        rather than here because ``EnvFaultMixin`` overrides this hook without
        calling super."""
        return result

    def _classify_zero_token_timeout(self, result: SessionResult) -> SessionResult:
        """Label a ``timeout`` that consumed zero tokens an environment fault
        (DW-364): a CLI whose session clock ran out without one billed token
        never got a usable response from the provider (a quota stall, an API
        error, a dead endpoint), so charging it as a dev attempt burns the
        retry budget on a wall. Stamps ``env_fault`` / ``ZERO_TOKEN_TIMEOUT_EVIDENCE``; the
        ``decide_*`` env-fault arms then PAUSE without charging the attempt
        (re-arm resets it).

        Runs LAST in ``run()``, after ``_classify_env_fault``, so a
        pattern-matched evidence line wins (and ``read_usage`` is not even
        consulted) and a reconcile upgrade to ``completed`` is never touched.
        Only ``status == "timeout"`` with ``result_json is None`` is inspected —
        ``stalled`` / ``crashed`` / ``over_budget`` are never classified here.

        Tracked-zero only: ``read_usage`` must return a ``TokenUsage`` whose
        ``total`` is 0. ``None`` means no usage signal (no transcript, an
        unparsed format) — untracked never reads as free, so the session is
        charged as before. Any ``read_usage`` fault leaves the verdict unchanged
        here — usage is metadata, never a gate, and an escape would unwind
        ``run()`` before the engine records the session: the engine's own
        ``read_usage`` call right after ``run()`` re-raises it on its journaled
        path, so the degrade stays visible rather than being folded into a
        classification.

        Cost: on timeout sessions only, this reads usage once more than the
        engine does. ``read_usage`` is idempotent (DW-117), so the engine's
        later read is unaffected; on an untracked timeout the generic adapter's
        ``usage_grace_s`` poll (copilot: 8s) runs here too."""
        if result.env_fault or result.status != "timeout" or result.result_json is not None:
            return result
        try:
            usage = self.read_usage(result)
        except Exception:  # usage is metadata, never a gate; the engine re-raises it
            return result
        if usage is None or usage.total != 0:
            return result
        return dataclasses.replace(
            result, env_fault=True, env_fault_evidence=ZERO_TOKEN_TIMEOUT_EVIDENCE
        )
