"""The wave plan as a run scope — `waves run --plan <file>`.

`waves-master-parallelism` measures an epic (or a story set that crosses epics) and
writes ``epic-<N>-plan-<stamp>.md``: prose for the owner, and a final fenced YAML
block for machines — waves, each with its fronts (stories, branch, resources) and a
``merge_order``; ``status``; ``integration_branch``; ``pending_approval``. That block
is the only part this module reads. The plan's judgment (which stories collide,
who merges first) stays the planner's; the engine takes the answer as an ordered
story set and never re-derives it.

Phase 1 of the roadmap's "Parallel unit execution": the plan is a SCOPE. The run
dispatches its stories one at a time, wave by wave, fronts in the grid's merge
order, stories as each front lists them — so a later wave's story never starts
before an earlier wave's, which is the one invariant a serial run can keep for a
plan written for parallel fronts. Fan-out reads the same record later.

Waves already merged (``merged: true``, or below ``next_wave``, or a front with
``merged_in``) contribute nothing: a re-measured plan carries its history, and the
executor never re-dispatches what it merged. Wave 0 lists tasks, not stories, and
is the planner's — it contributes nothing here either.
"""

from __future__ import annotations

import re
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from . import namespace

#: The planner's file name shape; `plan_glob` in its customize.toml matches it.
PLAN_NAME_RE = re.compile(r"^(?P<scope>.+)-plan-(?P<stamp>\d{4}-\d{2}-\d{2}(?:-\d{4})?)\.md$")

_FENCE_RE = re.compile(r"^```ya?ml[^\n]*\n(?P<body>.*?)^```[ \t]*$", re.MULTILINE | re.DOTALL)

#: The only status a run accepts. A draft has questions the owner has not answered
#: (the door's [A] resumes them); running it would decide them by omission.
APPROVED = "approved"


class WavePlanError(Exception):
    """The plan cannot be a run's scope, with the reason a person can act on."""


@dataclass(frozen=True)
class Front:
    name: str
    stories: tuple[str, ...]
    branch: str = ""
    sequential_resource: str = "none"
    isolated_test_resource: str = "none"
    merged_in: str = ""

    @property
    def merged(self) -> bool:
        return bool(self.merged_in)


@dataclass(frozen=True)
class Wave:
    number: int
    fronts: tuple[Front, ...]
    merge_order: tuple[str, ...] = ()
    merged: bool = False

    def ordered_fronts(self) -> tuple[Front, ...]:
        """Fronts in the grid's merge order; a front the grid does not name comes
        after the named ones, in the order the plan wrote them."""
        by_name = {f.name: f for f in self.fronts}
        named = [by_name[n] for n in self.merge_order if n in by_name]
        rest = [f for f in self.fronts if f.name not in self.merge_order]
        return tuple(named + rest)


@dataclass(frozen=True)
class WavePlan:
    path: str
    status: str
    scope: str
    epics: tuple[int, ...]
    generated: str
    integration_branch: str
    waves: tuple[Wave, ...]
    max_fronts: int | None = None
    next_wave: int | None = None
    pending_approval: tuple[str, ...] = ()
    measured_at_commit: str = ""

    def remaining(self) -> tuple[tuple[Wave, Front], ...]:
        """Every (wave, front) still owed, in dispatch order."""
        out: list[tuple[Wave, Front]] = []
        for wave in self.waves:
            if wave.merged or (self.next_wave is not None and wave.number < self.next_wave):
                continue
            for front in wave.ordered_fronts():
                if not front.merged:
                    out.append((wave, front))
        return tuple(out)

    def story_order(self) -> tuple[str, ...]:
        """The stories still owed, wave by wave, fronts in merge order, stories as
        the front lists them; a story named twice keeps its first place."""
        seen: set[str] = set()
        order: list[str] = []
        for _, front in self.remaining():
            for key in front.stories:
                if key not in seen:
                    seen.add(key)
                    order.append(key)
        return tuple(order)

    def front_of(self, story_key: str) -> dict[str, Any] | None:
        for wave, front in self.remaining():
            if story_key in front.stories:
                return {"wave": wave.number, "front": front.name, "branch": front.branch}
        return None

    def to_dict(self) -> dict[str, Any]:
        """The record a run carries in ``state.json`` — the plan's waves as written
        plus the derived ``story_order``, so the engine, `unit pick` and the
        dashboard read one shape without re-parsing the markdown."""
        return {
            "path": self.path,
            "status": self.status,
            "scope": self.scope,
            "epics": list(self.epics),
            "generated": self.generated,
            "integration_branch": self.integration_branch,
            "max_fronts": self.max_fronts,
            "next_wave": self.next_wave,
            "measured_at_commit": self.measured_at_commit,
            "waves": [  # namespace: the plan's YAML key (the planner's convention), not the product
                {
                    "wave": w.number,
                    "merged": w.merged,
                    "merge_order": list(w.merge_order),
                    "fronts": {
                        f.name: {
                            "stories": list(f.stories),
                            "branch": f.branch,
                            "sequential_resource": f.sequential_resource,
                            "isolated_test_resource": f.isolated_test_resource,
                            "merged_in": f.merged_in,
                        }
                        for f in w.fronts
                    },
                }
                for w in self.waves
            ],
            "story_order": list(self.story_order()),
        }


# ----------------------------------------------------------------- parsing


def extract_block(text: str) -> str:
    """The LAST fenced ``yaml`` block of the plan — the machine block by the
    planner's convention (section 14, after the mermaid graph). Earlier blocks are
    examples and intermediate states."""
    blocks = _FENCE_RE.findall(text)
    if not blocks:
        raise WavePlanError("no fenced ```yaml block — a plan ends in its machine-readable block")
    return blocks[-1]


def _str(d: dict[str, Any], key: str, default: str = "") -> str:
    value = d.get(key, default)
    return default if value is None else str(value)


def _front(name: str, raw: Any) -> Front:
    if not isinstance(raw, dict):
        raise WavePlanError(
            f"front {name!r} must be a mapping with `stories`, got {type(raw).__name__}"
        )
    stories = raw.get("stories")
    if not isinstance(stories, list) or not all(isinstance(s, str) for s in stories):
        raise WavePlanError(f"front {name!r}: `stories` must be a list of story keys")
    return Front(
        name=str(name),
        stories=tuple(stories),
        branch=_str(raw, "branch"),
        sequential_resource=_str(raw, "sequential_resource", "none"),
        isolated_test_resource=_str(raw, "isolated_test_resource", "none"),
        merged_in=_str(raw, "merged_in"),
    )


def _wave(raw: Any) -> Wave:
    if not isinstance(raw, dict) or "wave" not in raw:
        raise WavePlanError("every entry of the wave list is a mapping with a `wave` number")
    try:
        number = int(raw["wave"])
    except (TypeError, ValueError) as exc:
        raise WavePlanError(f"wave number must be an integer, got {raw['wave']!r}") from exc
    fronts_raw = raw.get("fronts") or {}
    if not isinstance(fronts_raw, dict):
        raise WavePlanError(f"wave {number}: `fronts` must be a mapping of front name -> front")
    fronts = tuple(_front(str(name), spec) for name, spec in fronts_raw.items())
    order_raw = raw.get("merge_order") or ()
    if not isinstance(order_raw, (list, tuple)):
        raise WavePlanError(f"wave {number}: `merge_order` must be a list of front names")
    return Wave(
        number=number,
        fronts=fronts,
        merge_order=tuple(str(n) for n in order_raw),
        merged=bool(raw.get("merged", False)),
    )


def parse(data: Any, path: str) -> WavePlan:
    """The machine block, already loaded, into a :class:`WavePlan` — or the reason
    it is not one. Shape checks only; whether its stories exist on the board is the
    selector's question (`sprintstatus.select_actionable` with ``order``)."""
    if not isinstance(data, dict):
        raise WavePlanError("the machine block must be a YAML mapping")
    status = _str(data, "status")
    if status != APPROVED:
        raise WavePlanError(
            f"plan status is {status or 'missing'!r}, not {APPROVED!r} — approve it in "
            f"{namespace.SKILL_MASTER_PARALLELISM} ([A]) before running it"
        )
    pending = data.get("pending_approval") or ()
    if not isinstance(pending, (list, tuple)):
        raise WavePlanError("`pending_approval` must be a list")
    if pending:
        raise WavePlanError(
            f"plan carries {len(pending)} pending approval(s) — resolve them in "
            f"{namespace.SKILL_MASTER_PARALLELISM} ([A]); a run cannot decide them by omission"
        )
    waves_raw = data.get("waves")  # namespace: the plan's YAML key, not the product
    if not isinstance(waves_raw, list) or not waves_raw:
        raise WavePlanError("the wave list must be a non-empty list")
    waves = tuple(_wave(w) for w in waves_raw)
    epics_raw = data.get("epics")
    epics: tuple[int, ...]
    if isinstance(epics_raw, list) and epics_raw:
        epics = tuple(int(e) for e in epics_raw)
    elif data.get("epic") is not None:
        epics = (int(data["epic"]),)
    else:
        raise WavePlanError("the plan names no epic: neither `epics[]` nor `epic`")
    scope = _str(data, "scope") or _str(data, "epic_key") or f"epic-{epics[0]}"
    max_fronts = data.get("max_fronts")
    next_wave = data.get("next_wave")
    plan = WavePlan(
        path=path,
        status=status,
        scope=scope,
        epics=epics,
        generated=_str(data, "generated"),
        integration_branch=_str(data, "integration_branch"),
        waves=waves,
        max_fronts=int(max_fronts) if max_fronts is not None else None,
        next_wave=int(next_wave) if next_wave is not None else None,
        pending_approval=tuple(str(p) for p in pending),
        measured_at_commit=_str(data, "measured_at_commit"),
    )
    if not plan.story_order():
        raise WavePlanError(
            "the plan has no story left to run: every wave is merged (or below `next_wave`)"
        )
    return plan


def load(path: Path) -> WavePlan:
    """Read a plan file. Raises :class:`WavePlanError` for a missing or unreadable
    file, a block that is not YAML, or a block that is not a runnable plan."""
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise WavePlanError(f"cannot read plan {path}: {exc}") from exc
    block = extract_block(text)
    try:
        data = yaml.safe_load(block)
    except yaml.YAMLError as exc:
        raise WavePlanError(f"the plan's machine block is not valid YAML: {exc}") from exc
    return parse(data, str(path))


# ------------------------------------------------- the record a run carries


def story_order_of(plan: dict[str, Any] | None) -> tuple[str, ...] | None:
    """The ordered story set of a run's persisted plan, or None when the run has
    no plan — the one question the engine and `unit pick` ask of it."""
    if not plan:
        return None
    order = plan.get("story_order")
    if not isinstance(order, list):
        return None
    return tuple(str(k) for k in order)


def wave_view(plan: dict[str, Any], settled: set[str], in_flight: set[str]) -> dict[str, Any]:
    """The plan's current wave as a dispatch question — what a fan-out reads.

    ``settled`` are the stories that need no more work (terminal in this run, or
    already done on the board); ``in_flight`` the ones a session is working on.
    The current wave is the first with a story in neither set or in flight; a
    later wave never opens while an earlier one has a story unsettled — the one
    invariant a plan written for parallel fronts asks of its executor. Inside a
    wave every front runs its stories in order and holds at most one in flight,
    so a front's ``next`` is dispatchable only when the front has nothing in
    flight; fronts come in the grid's merge order, so a bounded dispatch takes
    the earliest-merging fronts first.
    """
    waves = plan.get("waves") or ()  # namespace: the plan's YAML key, not the product
    for wave in waves:
        fronts_raw = wave.get("fronts") or {}
        names = list(wave.get("merge_order") or ()) + [
            n for n in fronts_raw if n not in (wave.get("merge_order") or ())
        ]
        fronts: list[dict[str, Any]] = []
        open_work = False
        for name in names:
            front = fronts_raw.get(name) or {}
            stories = [str(s) for s in (front.get("stories") or ())]
            pending = [s for s in stories if s not in settled]
            busy = [s for s in stories if s in in_flight]
            nxt = next((s for s in pending if s not in in_flight), None)
            fronts.append(
                {
                    "front": name,
                    "branch": front.get("branch", ""),
                    "stories": stories,
                    "in_flight": busy[0] if busy else None,
                    "next": nxt if not busy else None,
                    "done": not pending,
                }
            )
            open_work = open_work or bool(pending)
        if open_work:
            return {
                "wave": wave.get("wave"),
                "fronts": fronts,
                "dispatchable": [f["next"] for f in fronts if f["next"]],
            }
    return {"wave": None, "fronts": [], "dispatchable": []}


def front_stories(plan: dict[str, Any] | None, wave: int, front: str) -> tuple[str, ...]:
    """The stories one front of one wave owns, in the front's order — a child run's
    whole scope."""
    for w in (plan or {}).get("waves") or ():  # namespace: the plan's YAML key, not the product
        if w.get("wave") == wave:
            spec = (w.get("fronts") or {}).get(front) or {}
            return tuple(str(s) for s in (spec.get("stories") or ()))
    return ()


def tag(plan: dict[str, Any] | None, story_key: str) -> str:
    """The dashboard's short cell for a story's grid position — `w2·B` — or ""."""
    where = front_of(plan, story_key)
    if where is None:
        return ""
    return f"w{where['wave']}·{where['front']}"


def progress(plan: dict[str, Any] | None, tasks: Mapping[str, Any]) -> dict[str, Any] | None:
    """The run's position in its plan, for the dashboard's header: the current
    wave over the total, how many stories are in flight, how many landed, how
    many are done but waiting to merge (the grid's order, or a slot), and the
    current wave's merge queue in grid order — each story with its front and
    whether it is ready to land. None outside a plan run."""
    if not plan:
        return None
    order = set(story_order_of(plan) or ())
    settled = {k for k, t in tasks.items() if getattr(t, "settled", False)}
    in_flight = {k for k, t in tasks.items() if k in order and not getattr(t, "settled", False)}
    view = wave_view(plan, settled, in_flight)
    waves = [w.get("wave") for w in plan.get("waves") or ()]  # namespace: the plan's YAML key
    merged = sum(1 for k, t in tasks.items() if k in order and getattr(t, "integrated", False))
    ready = {k for k in in_flight if getattr(tasks[k], "terminal", False)}
    queue = [
        {"story": key, "front": front["front"], "ready": key in ready}
        for front in view["fronts"]
        for key in front["stories"]
        if key in in_flight
    ]
    return {
        "scope": plan.get("scope", ""),
        "wave": view["wave"],
        "waves_total": len(waves),
        "in_flight": len(in_flight),
        "merged": merged,
        "waiting": len(ready),
        "queue": queue,
    }


def front_of(plan: dict[str, Any] | None, story_key: str) -> dict[str, Any] | None:
    """Which wave and front of the persisted plan a story belongs to."""
    if not plan:
        return None
    for wave in plan.get("waves") or ():  # namespace: the plan's YAML key, not the product
        fronts = wave.get("fronts") or {}
        for name in wave.get("merge_order") or list(fronts):
            front = fronts.get(name) or {}
            if story_key in (front.get("stories") or ()):
                return {"wave": wave.get("wave"), "front": name, "branch": front.get("branch", "")}
        for name, front in fronts.items():
            if story_key in (front.get("stories") or ()):
                return {"wave": wave.get("wave"), "front": name, "branch": front.get("branch", "")}
    return None
